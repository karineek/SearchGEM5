
Output: