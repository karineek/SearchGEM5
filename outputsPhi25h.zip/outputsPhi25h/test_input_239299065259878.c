
#include <stdio.h>
int main(int argc, char** argv) {
    int num1 = atoi(argv[1]) + atoi(argv[2]);
    printf("The sum is %d\n", num1);
    return 0;
}