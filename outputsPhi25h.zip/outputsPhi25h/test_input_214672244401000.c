
Input: argv[1] = "Hello World"
Output: