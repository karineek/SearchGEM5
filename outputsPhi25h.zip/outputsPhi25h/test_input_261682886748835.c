
#include <stdio.h>

int main(int argc, char** argv) {
    // Check if the first argument is an integer
    int num;
    if (sscanf(argv[1], "%d", &num) != 1) {
        printf("Error: invalid input. Please enter a valid integer.\n");
        return 1;
    }

    // Check if the second argument is a floating-point number
    float pi = 3.14159265359;
    if (sscanf(argv[2], "%lf", &pi) != 1) {
        printf("Error: invalid input. Please enter a valid floating-point number.\n");
        return 1;
    }

    // Print out the input values
    printf("Input integer: %d\n", num);
    printf("Input floating-point: %f\n", pi);

    return 0;
}