
#include <stdio.h>
#define MEMORY_TO_REGISTER_PROMOTION 1

int csin(double x) {
  double y = atan2(1, sin(x)); // this is a common function used in C programming
  return y;
}

int main() {
  int n; // number of arguments to take from the user
  char *argv[];
  argc = 0;

  printf("Enter the number of arguments: ");
  scanf("%d", &n);

  for (int i=1; i<=n; i++) {
    if ((i > 1) && (MEMORY_TO_REGISTER_PROMOTION == 1)) { // check if we're using Memory-to-Register Promotion
      double x = atof(argv[i]);
      printf("%lf\n", csin(x));
    } else {
      char buffer[100]; // this is a C variable that can store up to 100 characters
      sprintf(buffer, "Value %d: ", i);
      printf("%s\n", buffer);
    }
  }

  return 0;
}