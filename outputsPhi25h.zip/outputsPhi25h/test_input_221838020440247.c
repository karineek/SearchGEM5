
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>

int main(int argc, char *argv[]) {

	if (argc != 2) {
        fprintf(stderr, "Usage: %s filename\n", argv[0]);
        exit(EXIT_FAILURE);
	}

	FILE *file = fopen(argv[1], "r");
	if (file == NULL) {
        fprintf(stderr, "%s: cannot open file %s\n", argv[0], argv[1]);
        exit(EXIT_FAILURE);
	}

	char *input;
	fgets(input, 1024, file); // read one line of input from the file

	if (strchr(input, '\n') == NULL) { // if there is no newline character, add it at the end of the input 
        *input = '\0';
	}

	char *output;
	output = malloc(strlen(input) + 1);
	sprintf(output, "%s", input); // write the input to an output string

	if (fprintf(stdout, "%s", output) == EOF) { // check if the file can be written to 
        fprintf(stderr, "%s: cannot write output.\n", argv[0]);
        exit(EXIT_FAILURE);
	}

	fclose(file); // close the input file 

	return 0;
}