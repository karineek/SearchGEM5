
#include <stdio.h>
#include <string.h>
#include <math.h>

int main(int argc, char *argv[]) {
    /* Register Allocation */
    if (strcmp(argv[1], "alloc") == 0) {
        // allocating memory for an array of integers
        int n, i;
        printf("Enter the size of the array: ");
        scanf("%d", &n);
        int *arr = malloc(sizeof(int) * n);
        if (arr == NULL) {
            printf("Memory allocation failed\n");
            return 1;
        }

        // allocating registers for integer operations
        int *regs = malloc(sizeof(int) * 3);
        if (regs == NULL) {
            printf("Register allocation failed\n");
            return 1;
        }

        // filling array with input from command line arguments
        for (i = 0; i < n; i++) {
            arr[i] = atoi(argv[2+i]);
        }

        // performing operations with the array and registers
        int result = 0;
        for (i = 0; i < n; i++) {
            result += regs[0] * arr[i];
        }

        // allocating registers again for floating point operations
        int *regs2 = malloc(sizeof(float) * 3);
        if (regs2 == NULL) {
            printf("Register allocation failed\n");
            return 1;
        }

        // converting result to floating point and storing it in a variable
        double x = atof(argv[2+n]) / pow(10, DBL_MAX_10_EXP);

        // printing the results of all operations
        printf("Sum: %.2f\n", result);
        printf("Product: %.2f\n", x);

        // releasing memory for array and registers
        free(arr);
        free(regs);
        free(regs2);

        return 0;
    } else {
        // if the command line argument is not "alloc", print an error message
        printf("Invalid command!\n");
        return 1;
    }
}