
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
  int i;

  // Loop-Invariant Code Motion
  while (i < argc) {
    printf("%s\n", argv[i]);
    i++;
  }

  return 0;
}