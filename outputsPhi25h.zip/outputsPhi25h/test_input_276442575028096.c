
#include <stdio.h>
#include <string.h>
#include <limits.h>

int main(int argc, char **argv) {
    // check if correct number of arguments is given
    if (argc != 2) {
        printf("Usage: %s file\n", *argv[0]);
        return 1;
    }

    // open input file in binary mode and read data as strings of characters
    FILE *input_file = fopen(argv[1], "rb");
    if (input_file == NULL) {
        printf("Error opening input file\n");
        return 1;
    }

    // set maximum temporary stack size for loop vectorization optimization
    #define TMP_MAX_S (sizeof(int) * 1024)

    int length = 0;
    char buffer[TMP_MAX_S];
    while ((fread(buffer, 1, sizeof(char), input_file)) != -1) {
        // check if end of file has been reached
        if (strcspn(buffer, "\0") == length) {
            fclose(input_file);
            printf("File is empty\n");
            return 1;
        }

        // increment length to include new line character
        ++length;
    }

    fclose(input_file);

    // output the data read from file
    printf("Data:\n");
    for (int i = 0; i < length; i++) {
        printf("%c", buffer[i]);
    }
    putchar('\n');

    return 0;
}