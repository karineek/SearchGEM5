
#include <stdio.h>

int main(int argc, char **argv) {
    int num1, num2;

    // Extracts the first number from the command line arguments
    sscanf(argv[1], "%d", &num1);

    // Extracts the second number from the command line arguments
    sscanf(argv[2], "%d", &num2);

    // Computes the sum of the two numbers and prints it to stdout
    printf("Sum: %d\n", num1 + num2);

    return 0;
}