
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {

    if(argc != 3){
        printf("Usage: %s input_file output_file\n", argv[0]);
        return 1;
    }

    char *inputFile = argv[1];
    char *outputFile = argv[2];

    FILE* inF = fopen(inputFile, "r");
    if(inF == NULL){
        printf("Error: Could not open input file\n");
        return 1;
    }

    FILE* outF = fopen(outputFile, "w");
    if(outF == NULL){
        printf("Error: Could not open output file\n");
        return 1;
    }

    char inputLine[256];
    while(fgets(inputLine, sizeof(inputLine), inF) != NULL){
        // Loop Fusion: concatenate strings from the input lines
        char outputLine[256];
        strcpy(outputLine, inputLine);
        printf("%s\n", outputLine);

        // Deals with object file manipulation: append the input line to an object file
        fprintf(outF, "%s\n", inputLine);
    }

    fclose(inF);
    fclose(outF);

    return 0;
}