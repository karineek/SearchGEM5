
#include <stdio.h>
#include <string.h>

#define MAX 100

int main(int argc, char *argv[]) {

    if (argc != 2) {
        fprintf(stderr, "Usage: %s filename\n", argv[0]);
        return 1;
    }

    FILE* file = fopen(argv[1], "r");
    char buffer[MAX];
    int line_num = 0;
    char *cse_input, *constraint_output;

    cse_input = malloc(sizeof(char) * MAX); // Allocate memory for the CSE input.
    constraint_output = malloc(sizeof(char) * MAX);

    fread(cse_input, sizeof(char), MAX, file); // Read in the CSE input.
    fclose(file);

    sscanf(cse_input, "%s", buffer); // Remove whitespace from the start of each line.

    char *line;

    for (int i = 0; i < strlen(buffer); i++) {
        if (isalpha(buffer[i])) {
            // If the current character is a letter, it's part of the constraint.
            line = realloc(cse_input, i+1);
            sscanf(line, "%s", buffer + i);

            // Append the constraint to the CSE input.
            sscanf(constraint_output, "%s", buffer + strlen(buffer) - 1);

            for (int j = 0; j < strlen(line); j++) {
                if (line[j] == '(') {
                    // If the constraint starts with a left parenthesis, it's an expression.
                    sscanf(constraint_output + j, "%s", line);

                } else if (line[j] == ')') {
                    // If the constraint ends with a right parenthesis, it's an assignment.
                    sscanf(constraint_output + j, "%s", line);

                } else {
                    // If the constraint is a number or a variable, it's just an operand.
                    sscanf(constraint_output + j, "%s", line);
                }

            } else if (buffer[i] == ';') {
                // If the current character is a semicolon, it's the end of a constraint.
                fprintf(stdout, "%s\n", buffer + i-1);
            } else {
                // If the current character is not a letter or semicolon, it's just an operand.
                fprintf(stdout, "%c", buffer[i]);
            }
        }

        realloc(cse_input, i+2); // Add a semicolon at the end of each constraint.
    }

    sscanf(constraint_output, "%s", buffer + strlen(buffer) - 1);
}