
#include <stdio.h>

int main(int argc, char* argv[]) {
    int val;
    if (argc > 1) {
        val = atoi(argv[1]);
    } else {
        printf("Please provide an input value using the command line argument: \n");
        return 1;
    }

    printf("Input value is %d\n", val);
    return 0;