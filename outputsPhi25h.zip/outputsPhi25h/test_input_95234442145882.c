
#include <stdio.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    FILE *in = fopen(argv[1], "r");
    if (!in) {
        printf("Error: input file not found or cannot be read.\n");
        return 1;
    }

    // Read the input from the file and print it to the standard output
    while (fgets(buffer, sizeof buffer, in)) {
        printf("%s\n", buffer);
    }

    // Close the input file
    fclose(in);

    return 0;
}