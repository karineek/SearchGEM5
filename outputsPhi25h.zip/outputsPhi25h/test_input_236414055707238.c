
#include <stdio.h>

int main(int argc, char *argv[]) {
    int n; // number of elements to be read

    if (argc != 3) { // check for correct input
        printf("Error: incorrect input\n");
        return 1;
    }

    n = atoi(argv[1]); // convert first argument to integer
    int a[n]; // array of size n

    for (int i = 0; i < n; i++) { // read input values from second argument
        a[i] = atoi(argv[2+i]);
    }

    printf("Array elements: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", a[i]);
    }
    printf("\n");

    return 0;
}