
$ ./program 1 2
The sum of the two numbers is 3