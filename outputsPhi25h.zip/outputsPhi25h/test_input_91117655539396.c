
#include <stdio.h>

int main(int argc, char *argv[]) {
    int i;
    for (i = 1; i <= atoi(argv[1]); i++) {
        printf("%d\n", i);
    }
    return 0;
}