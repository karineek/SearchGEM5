
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {
    if (argc != 3) {
        printf("Usage: %s input1 input2\n", *argv[0]);
        return 1;
    }

    char input_str[100];
    sscanf(argv[2], "%99s%d", input_str, &int_a);
    sscanf(argv[3], "%99s%d", input_str, &int_b);

    printf("Input 1: %s\n", argv[1]);
    printf("Input 2: %s\n", argv[2]);
    printf("Integer A: %d\n", int_a);
    printf("Integer B: %d\n", int_b);

    return 0;
}