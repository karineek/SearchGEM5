
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {
    double x = 0;

    // Check for invalid input (e.g. non-numeric argument)
    if (argc > 1 && !isdigit(*argv[1])) {
        printf("Invalid input\n");
        return 1;
    }

    // Check for invalid input (e.g. too many or too few arguments)
    if (argc < 2) {
        printf("Usage: %s x\n", argv[0]);
        return 1;
    }

    // Convert input to double and apply constant folding
    x = atof(argv[1]);
    x = ctanh(x);

    printf("%f", x);

    return 0;
}