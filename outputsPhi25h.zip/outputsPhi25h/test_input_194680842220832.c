
#include <stdio.h>

int main(int argc, char **argv) {
    if (argc > 1) {
        printf("Input from command line:\n");
        for (int i = 1; i < argc; i++) {
            char input[100];
            strncpy(input, argv[i], 99); // truncates the \0 at the end of the string
            printf("%s\n", input);
        }
    } else {
        printf("Please provide input using the command line.\n");
    }
    return 0;
}