
#include <stdio.h>
#include <string.h>
#include <math.h>

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }

    FILE *fp = fopen(argv[1], "r");
    if (fp == NULL) {
        printf("Error: unable to open file.\n");
        return 1;
    }

    char line[1024];
    while (fgets(line, sizeof(line), fp)) {
        vprintf_s("Line: %s", line); // using the vprintf_s function to output each line of the file
    }

    fclose(fp);
    return 0;
}