
#include <stdio.h>
#include <math.h>
#define LDBL_MAX_10_EXP 1000000

int main() {
    printf("Enter a number:\n");
    int num = atoi(argv[1]);
    if (num >= 0) {
        double result = pow(2, num);
        fprintf(stdout, "The result is %.10f\n", result);
    } else {
        printf("Error: input must be a non-negative number\n");
        exit(1);
    }
    return 0;
}