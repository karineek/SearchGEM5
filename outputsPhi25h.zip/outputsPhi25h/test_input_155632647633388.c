
#include <stdio.h>
int main(int argc, char **argv) {
    // input is taken via argv only
    if (argc != 2) {
        printf("Usage: %s filename\n", *argv[0]);
        return 1;
    }
    FILE* fp = fopen(argv[1], "r");
    if (fp == NULL) {
        printf("Error: can't open file.\n");
        return 1;
    }
    int num = 0;
    char c;
    while ((c = fgetc(fp)) != EOF) {
        num++;
    }
    fclose(fp);
    return 0;
}