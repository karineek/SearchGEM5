
#include <stdio.h> 
int main(int argc, char *argv[]) { /* This program uses argv only */
if (argc != 2) {
printf("Error: Invalid number of arguments\n");
return 1;
}
/* Code generated from the program with code triggering Debug and Profiling mode */ 
/* Example input for Cryptocode - A user may provide an input like this in a command line argument: ./crypto <input_file> */
if (argv[1] == "input.txt") { /* example file input.txt contains the following contents, which are used as input */
printf("Input from file is: \n");
fgets(argv[2], 100, stdin); 
} else {
printf("Invalid filename. Please try again\n");
return 1;
}
}