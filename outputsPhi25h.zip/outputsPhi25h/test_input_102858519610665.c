
import sys

# get command line arguments
argc = len(sys.argv)
input_file = sys.argv[1]
output_file = sys.argv[2]

# read input file and perform some operations on it
with open(input_file, 'r') as f:
    # code to process the input file here
    pass

# write output to a new file
with open(output_file, 'w') as f:
    # code to write the output to a new file here
    pass