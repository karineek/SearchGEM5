
#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <string.h>

int main(int argc, char *argv[]) {

    // check if there are enough arguments to parse
    if (argc != 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    // get the input file name from the first argument
    char *filename = argv[1];

    // open a pipe to communicate with the child process
   pipe(fd);

    // open the input and output files for reading and writing
    FILE *fin = fopen(filename, "r");
    if (fin == NULL) {
        printf("Error: cannot open %s\n", filename);
        return 1;
    }

    // read the first line of the input file as a pattern to match
    char *pattern = fgets(argv[1], 256, fin);
    if (pattern == NULL) {
        printf("Error: cannot read from %s\n", filename);
        return 1;
    }

    // close the input file
    fclose(fin);

    // open a file for writing the output
    FILE *fout = fopen("output.txt", "w");
    if (fout == NULL) {
        printf("Error: cannot open %s\n", "output.txt");
        return 1;
    }

    // start a new process that will read the input file and write the output file
    if (fork() == 0) {
        char *line = fgetc(fin);
        while (line != EOF) {
            // check if the line matches the pattern
            int match_found = strstr(line, pattern);

            // write a newline to the output file for each matching line
            if (match_found != NULL) {
                fprintf(fout, "%s\n", line);
            }

            // read the next character from the input file
            line = fgetc(fin);
        }

        // close the output file
        fclose(fout);

        // return to the parent process
        exit(0);
    } else {
        // read from the pipe and write to the output file in real time
        int fd[2];

        // receive the number of lines read from the input file
        if (read(fd, &lines_read, sizeof(int)) != 1) {
            printf("Error: cannot read from pipe\n");
            return 1;
        }

        // receive the first line of the input file
        int c = fread(fd[0], sizeof(int), 1, fin);
        if (c != 1) {
            printf("Error: cannot read from pipe\n");
            return 1;
        }

        // read the rest of the input file line by line
        for (int i = 0; i < lines_read - 1; i++) {
            fread(fd[1], sizeof(int), 1, fin);
        }

        // write the output to the file
        fwrite(fout, "%s\n", line);

        // wait for the child process to finish
        waitpid(fork(), 0, WNOHANG);
    }

    // close both file handles
    fclose(fin);
    fclose(fout);

    return 0;
}