
#include <stdio.h>
#include <sys/time.h>
#include <xmmintrin.h>

int main(int argc, char *argv[]) {

    int n;
    double sum = 0.0;

    // Check if the first command-line argument is a valid number
    if (sscanf(argv[1], "%d", &n) != 1 || argc < 2) {
        fprintf(stderr, "Usage: %s n\n", argv[0]);
        return 1;
    }

    // Use vectorization to sum the first n integers using xmm registers and SSE instructions
    double *p = malloc(sizeof(*p) * n);
    for (int i = 0; i < n; ++i) {
        p[i] = i + 1.0; // Use xmm registers to store the input values
    }

    __m128i v1 = _mm_setzero_si128(); // Set up a zero vector for the SSE instructions
    __m128i v2 = _mm_setzero_epi32(n); // Initialize the loop counter to zero
    double sum_val;

    for (int i = 0; i < n / 32 + 1; ++i) { // Loop until all inputs have been processed
        __m128i v3 = _mm_setzero_si128();
        __m128i v4 = _mm_loadu_si128((__m128i*)p);

        // Use SSE instructions to add the vector of input values
        sum_val = _mm_add_epi32(v1, v2);
        v3 = _mm_add_epi32(_mm_and_si128(sum_val, v4), v5); // Update the loop counter

        v2 = _mm_setzero_epi32(v3); // Reset the loop counter for the next iteration
    }

    double *sse_result = (double*)malloc(sizeof(*sse_result) * n);
    __m128d sse = _mm_cvtepu64_si128(sum_val, 0); // Convert the SSE results to a vector of doubles

    for (int i = 0; i < n; ++i) {
        sse_result[i] = sse.s8[i]; // Copy the SSE results to the output array
    }

    // Calculate the sum of the input values using xmm registers and scalar instructions
    double *scalar_result = (double*)malloc(sizeof(*scalar_result) * n);
    for (int i = 0; i < n; ++i) {
        scalar_result[i] = p[i]; // Use xmm registers to store the input values
    }

    double sum_val2 = _mm_accumu_epi32(scalar_result, sse_result); // Add the vector of input values and SSE results

    free(sse_result);
    free(p);

    printf("The sum is %lf\n", sum_val2.d0);

    return 0;
}