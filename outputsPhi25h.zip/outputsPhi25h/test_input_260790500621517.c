
#include <stdio.h>
#define MAX_INPUT 10
char *fgets(char str[], int size);
int main(int argc, char **argv) {
    int i;
    for (i = 1; i <= argc && fgets(argv[i], MAX_INPUT, stdin); ++i) 
        printf("%s\n", argv[i]);
    return 0;
}