
#include <stdio.h>
int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }
    FILE* file = fopen(argv[1], "r");
    if (file == NULL) {
        printf("Error opening file: %s\n", argv[1]);
        return 1;
    }
    int num = 0;
    while (!feof(file)) {
        fscanf(file, "%d ", &num);
    }
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }
    fclose(file);
    return 0;
}