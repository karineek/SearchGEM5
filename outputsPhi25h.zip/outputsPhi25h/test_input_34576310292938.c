
#include <stdio.h>

int main(int argc, char* argv[]) {

  // Get command-line arguments (input)
  int x = atoi(argv[1]);
  float y = atof(argv[2]);

  // Calculate square root and cube of input values using constant folding
  int z = sqrtf(x);
  double w = pow(y, 3.0);

  // Print the results
  printf("Square root: %d\n", z);
  printf("Cube: %lf\n", w);

  return 0;
}