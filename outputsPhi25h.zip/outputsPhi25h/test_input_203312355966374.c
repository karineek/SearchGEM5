
#include <stdio.h>

int main(int argc, char *argv[]) {
  int n = atoi(argv[1]); // convert input to integer
  printf("Binary representation of %d: ", n);
  for (int i = 31; i >= 0; i--) {
    if (n & (1 << i)) {
      puts("1");
    } else {
      puts("0");
    }
  }
  printf("\n");

  char binary[sizeof(int) * 8];
  int j = 0;
  while (n > 0) {
    binary[j++] = '0' + (n & 1);
    n >>= 1;
  }
  printf("Converted back to decimal: %s\n", binary);

  return 0;
}