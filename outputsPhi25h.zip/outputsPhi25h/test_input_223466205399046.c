
#include <stdio.h>
#include <ctype.h>

int main(int argc, char *argv[]) {
  int i;

  for (i = 1; i < argc; ++i) {
    if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help")) {
      printf("Usage: %s [-h]\n", argv[0]);
      return 1;
    } else if (strcmp(argv[i], "-a") == 0 || strcmp(argv[i], "--analyze")) {
      printf("Analyzing program...\n");
    } else if (strcmp(argv[i], "-o") == 0 || strcmp(argv[i], "--optimize")) {
      printf("Optimizing program...\n");
    } else {
      printf("Invalid argument: %s\n", argv[i]);
      return 1;
    }
  }

  printf("Program complete!\n");

  return 0;
}