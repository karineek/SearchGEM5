
#include <stdio.h>
int main(int argc, char** argv) {
    printf("Enter a number: ");
    int num;
    scanf("%d", &num);
    if (argc == 2) {
        printf("You entered %d\n", atoi(argv[1]));
    } else {
        printf("Error: incorrect input. Please enter a number and use argv[0] to terminate.");
    }
    return 0;
}