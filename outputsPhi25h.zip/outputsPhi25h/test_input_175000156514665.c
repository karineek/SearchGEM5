
#include <stdio.h>
#include "prof_opt.h"
#include "volatile.h"
int main() {
    printf("Enter a number: ");
    int x = atoi(argv[1]);
    volatile int y = 0;
    while (x > 1) {
        if (x % 2 == 0) {
            x /= 2;
            y++;
        } else {
            x = 3 * x + 1;
        }
    }
    printf("Iterations: %d\n", y);
    return 0;