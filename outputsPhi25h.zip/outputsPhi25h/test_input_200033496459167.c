
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {

  // Check if enough arguments are provided
  if (argc != 3) {
    printf("Usage: %s file1 file2\n", argv[0]);
    return 1;
  }

  // Read the input files and concatenate their contents
  char *file1 = argv[1];
  char *file2 = argv[2];
  FILE *f1, *f2;
  f1 = fopen(file1, "r");
  if (f1 == NULL) {
    perror("Error opening file 1: %s", file1);
    return 2;
  }
  f2 = fopen(file2, "r");
  if (f2 == NULL) {
    perror("Error opening file 2: %s", file2);
    return 2;
  }

  char *concatenated_str = malloc(strlen(file1) + strlen(file2));
  fseek(f1, 0, SEEK_END);
  ftell(f1);
  fseek(f2, 0, SEEK_SET);
  fread(concatenated_str, 1, ftell(f2), f2);

  // Close the input files
  fclose(f1);
  fclose(f2);

  // Replace all instances of "Inline Heuristics" with "_INLINE_HEURIS_" and "_C identifier suffix" with "_CID_Suffix_" in the concatenated string
  char *new_str = strdup(concatenated_str);
  char *str1, *str2;
  str1 = strstr(new_str, "Inline Heuristics");
  while (str1 != NULL) {
    strncpy(str1, "_INLINE_HEURIS_", 7);
    str1 += 8; // Skip the "_" character
  }

  str2 = strstr(new_str, "C identifier suffix");
  while (str2 != NULL) {
    strncpy(str2, "_CID_Suffix_", 6);
    str2 += 7; // Skip the "_" character
  }

  // Write the modified string to a file
  FILE *output_file = fopen("modified.txt", "w");
  if (output_file == NULL) {
    perror("Error opening output file: %s", argv[2]);
    return 2;
  }

  fwrite(new_str, 1, strlen(new_str), output_file);
  fclose(output_file);

  // Clean up resources
  free(concatenated_str);

  return 0;