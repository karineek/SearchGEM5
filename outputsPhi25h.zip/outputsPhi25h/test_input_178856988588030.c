
#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Please provide a filename as an argument.\n");
        return 1;
    }

    FILE *file = fopen(argv[1], "r");
    if (!file) {
        printf("Error: File not found or could not be opened.\n");
        return 1;
    }

    char line[100];
    while (fgets(line, sizeof(line), file)) {
        for (int i = 0; i < strlen(line); i++) {
            if (!isalpha(line[i])) {
                printf("%c is not an alphabet.\n", line[i]);
            }
        }
    }

    fclose(file);

    return 0;
}