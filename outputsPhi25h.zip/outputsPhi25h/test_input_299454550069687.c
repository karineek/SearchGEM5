
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
  // Define a structure for the current symbol
  struct int_curr_symbol {
    char *name;
    int value;
  }

  // Parse the input arguments to get the name and value of the current symbol
  if (argc == 2) {
    char *symbol_name = argv[1];
    int_curr_symbol.value = atoi(argv[2]);

    // Check if the input is a function call or not
    if (strcmp(symbol_name, "sum") == 0) {
      printf("The sum of %d and %d is %d.\n", argv[3], argv[4], argv[3] + argv[4]);
    } else if (strcmp(symbol_name, "diff") == 0) {
      printf("The difference between %d and %d is %d.\n", argv[3], argv[4], argv[1] - argv[2]);
    } else {
      printf("Invalid input. Please enter a valid function name followed by its arguments.\n");
    }

    // Apply Function Specialization to optimize the program
    if (argc == 3) {
      int_curr_symbol.value = argv[2];
    } else {
      printf("Invalid input. Please enter a valid function name followed by its arguments.\n");
    }

    return 0;
  } else {
    printf("Please enter a valid number of input arguments.\n");
    return 1;
  }
}