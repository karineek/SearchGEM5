
#include <stdio.h>
int main(int argc, char *argv[]) {
    int num;

    // Check if the command line arguments are valid (i.e., two or more)
    if (argc < 2) {
        printf("Usage: %s NUM\n", argv[0]);
        return 1;
    }

    // Read the second command line argument as an integer
    num = atoi(argv[1]);

    // Output the number to standard output
    printf("%d\n", num);

    // Return 0 to indicate success
    return 0;
}