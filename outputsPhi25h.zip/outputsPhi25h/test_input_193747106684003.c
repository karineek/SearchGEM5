
#include <stdio.h>

int main(int argc, char *argv[]) {
    int n;

    if (argc == 2) {
        n = atoi(argv[1]);
    } else {
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }

    // Calculate absolute value of the input
    n = abs(n);

    // Print the result to the console
    printf("The absolute value of %d is %d\n", n, n);

    return 0;
}