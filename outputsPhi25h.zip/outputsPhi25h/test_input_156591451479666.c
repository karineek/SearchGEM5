
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    int i;

    if (argc != 2) {
        printf("Usage: ./reverse_input input_file\n");
        return 1;
    }

    FILE *f = fopen(argv[1], "r");
    if (!f) {
        printf("Error: could not open input file.\n");
        return 1;
    }

    char line[256];
    while (fgets(line, sizeof(line), f)) {
        for (i = strlen(line) - 2; i >= 0; --i) {
            printf("%c", line[i]);
        }
        printf("\n");
    }

    fclose(f);
    return 0;
}