
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <cmath>

int main(int argc, char* argv[]) {
    int num1;
    double complex num2;

    if (argc != 4) {
        printf("Usage: %s <num1> <complex_expression>\n", argv[0]);
        return 1;
    }

    num1 = atoi(argv[1]);
    char complex_str[] = argv[2];

    if (sscanf(complex_str, "%.*lf%.*lfi", &num2.real, 1, &num2.imaginary, 1) != 2) {
        printf("Invalid complex expression!\n");
        return 1;
    }

    if (num1 % 2 == 0) {
        num2.real = -num2.real;
    }

    printf("Result: %g + %gi\n", num2.real, num2.imaginary);

    return 0;
}