
#include <stdio.h>

int main(int argc, char **argv) {

   // Example of input taken via argv only
   if (argc != 2) {
      printf("Usage: %s file\n", argv[0]);
      return 1;
   }

   FILE *file = fopen(argv[1], "r");
   if (!file) {
      printf("Error opening input file.\n");
      return 1;
   }

   // Parsing assembly files and type conversion
   fseek(file, 0L, SEEK_END);
   long l = ftell(file);
   FILE *fp = fopen("output.txt", "wb");
   if (!fp) {
      printf("Error writing output file.\n");
      return 1;
   }

   char line[256];
   while (fgets(line, sizeof(line), file)) {
      if (sscanf(line, "%ld", &a) == 1) {
         // SPCP optimization
         fprintf(fp, "%.10lf\n", a);
      } else {
         // Output with no conversion
         fprintf(fp, "%s\n", line);
      }
   }

   fclose(file);
   fclose(fp);
   return 0;