
#include <stdio.h>
int main(int argc, char**argv) {
    if (argc != 2) {
        printf("Usage: %s [filename]\n", argv[0]);
        return 1;
    }

    char *filename = argv[1];
    FILE* fp = fopen(filename, "r");
    if (!fp) {
        fprintf(stderr, "Cannot open file %s\n", filename);
        return 2;
    }

    int line_num = 0;
    while (fgets(line, sizeof(line), fp)) {
        printf("%d: %s\n", ++line_num, line);
    }

    fclose(fp);

    return 0;
}