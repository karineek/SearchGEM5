
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
// Function to allocate registers
void register_allocation(int num_registers) {
  static int *arr = malloc(sizeof(*arr)*num_registers);
  for (int i = 0; i < num_registers; ++i) {
    arr[i] = rand() % 1000000 + 1; // Generate random values to allocate registers
  }
}
// Function to generate code using the allocated registers
void code_generation(int *arr, int num_instructions) {
  for (int i = 0; i < num_instructions; ++i) {
    // Randomly select a register from the allocated registers
    int reg_index = rand() % num_registers;
    printf("%d\n", arr[reg_index]); // Use the selected register in an instruction
  }
}
// Function to generate random integers between 1 and 1000000 with a specified range
int rand_in_range(int min, int max) {
  return (rand() % (max - min + 1)) + min;
}
// Example program that uses the functions
int main() {
  // Input number of registers to allocate
  int num_registers = atoi(argv[1]);
  // Allocate registers and generate code
  register_allocation(num_registers);
  code_generation(arr, 10);
  return 0;
}