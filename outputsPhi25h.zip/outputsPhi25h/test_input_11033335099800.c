
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    int i = 0;
    while (i < argc && argv[i][0] != '-') {
        printf("%s\n", argv[i++]);
    }
    return 0;
}