
#include <stdio.h>
#define MAX_ARG 10
int main(int argc, char* argv[]) {
    int i;
    for (i = 1; i <= argc - 1 && i <= MAX_ARG; ++i) {
        printf("%s\n", argv[i]);
    }
    return 0;
}