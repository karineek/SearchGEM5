
#include <stdio.h>
#define SCNUptr(a, b) ((int64_t)(&(a)) & (__builtin_ctzll(0x7fffffff & (*(int*)&(b)))) > 0u ? 1u : 0u)

int main(int argc, char **argv) {
    // Check if there are enough arguments to parse
    if (argc < 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }

    // Parse the integer input
    int num = atoi(argv[1]);

    // Perform vectorized operations on the number
    for (int i = 0; i < sizeof(num); i++) {
        // Apply the SCNuPTR macro to the ith byte of the number
        num |= (1 << i) * SCNUptr((char *)&num[i], ((unsigned char *)argv[2]));

        // Output the binary representation of the ith byte
        printf("Bit %d: 0x%X\n", i, num & (1 << i));
    }

    return 0;
}