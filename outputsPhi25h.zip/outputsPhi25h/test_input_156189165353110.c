
#include <stdio.h>
int main(int argc, char **argv) {
    int a, b;
    if (argc != 3) {
        printf("Usage: %s <num1> <num2>\n", argv[0]);
        return 1;
    } else {
        a = atoi(argv[1]);
        b = atoi(argv[2]);
        int sum = a + b;
        int diff = a - b;
        int prod = a * b;
        int quotient = a / b;
        printf("Sum: %d\n", sum);
        printf("Difference: %d\n", diff);
        printf("Product: %d\n", prod);
        printf("Quotient: %d\n", quotient);
    }
    return 0;
}