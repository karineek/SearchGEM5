
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    // Check if correct number of arguments were passed in
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }

    // Read input file and print its content to the console
    FILE *file = fopen(argv[1], "r");
    if (file == NULL) {
        printf("Error: could not open %s\n", argv[1]);
        return 1;
    }

    int line_num = 0;
    while (fgets(argv[2], sizeof argv[2], file) != NULL) {
        // Heuristic optimization: if the input contains a minus sign, replace it with an asterisk (*).
        char *minus_sign = strchr(argv[2], '-');
        if (minus_sign != NULL) {
            argv[2][minus_sign - argv[2] + 1] = '*';
        }

        // Print the line number and the input line
        printf("%d: %s\n", line_num++, argv[2]);
    }

    fclose(file);
    return 0;
}