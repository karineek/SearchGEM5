
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {

    // your code here
}