
#include <stdio.h>

int main(int argc, char *argv[]) {
    FILE *file;
    char line[256];

    if (argc != 2) {
        printf("Usage: %s <filename>\n", argv[0]);
        return 1;
    }

    file = fopen(argv[1], "r");
    if (!file) {
        printf("Error: could not open file %s\n", argv[1]);
        return 1;
    }

    while (fgets(line, sizeof line, file)) {
        printf("%s\n", line);
    }

    fclose(file);
    return 0;
}