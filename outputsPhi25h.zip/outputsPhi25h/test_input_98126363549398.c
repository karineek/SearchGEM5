
#include <stdio.h>
int main(int argc, char *argv[]) {
    int n;
    if (argc != 2) {
        printf("Usage: %s <n>\n", argv[0]);
        return 1;
    }
    n = atoi(argv[1]);
    int sum = 0;
    for (int i = 2; i <= n; i += 2) {
        sum += i;
    }
    printf("The sum of even numbers up to %d is %d\n", n, sum);
    return 0;
}