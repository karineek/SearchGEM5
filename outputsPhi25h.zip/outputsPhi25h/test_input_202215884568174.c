
#include <stdio.h>

int main(int argc, char *argv[]) {
    int num;

    printf("Enter an integer: ");
    fgets(argv[1], sizeof argv[1], stdin);
    num = atoi(argv[1]);

    if (num < 0) {
        feraiseexcept(0, 1, "Input must be a positive integer", -1);
    }

    printf("You entered: %d\n", num);
    return 0;
}