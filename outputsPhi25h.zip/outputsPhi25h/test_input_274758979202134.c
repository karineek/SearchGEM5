
#include <stdio.h>
#include <sys/time.h>
#define MAX_ARGV 10

int main(int argc, char* argv[]) {
    double sum = 0;

    for (int i=1; i<argc && i<MAX_ARGV; i++) {
        sum += atof(argv[i]);
    }

    printf("The sum is %.2f\n", sum);

    struct timeval tStart,tEnd;
    gettimeofday(&tStart, NULL);

    double optimized_result = (sum * 10) / 2;

    gettimeofday(&tEnd, NULL);

    printf("Time taken: %fs\n", (double)(tEnd.tv_sec - tStart.tv_sec) + (tEnd.tv_usec - tStart.tv_usec)/1000000.0);
    printf("Optimized result: %f\n", optimized_result);

    return 0;
}