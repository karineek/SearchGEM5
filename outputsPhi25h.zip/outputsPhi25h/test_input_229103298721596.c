
#include <stdio.h>

int main(int argc, char *argv[]) {

    int a = atoi(argv[1]);
    int b = atoi(argv[2]);
    int c = atoi(argv[3]);

    printf("a=%d\n", a);
    printf("b=%d\n", b);
    printf("c=%d\n", c);

    return 0;
}