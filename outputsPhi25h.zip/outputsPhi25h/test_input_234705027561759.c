
#include <stdio.h>

int main(int argc, char* argv[]) {
  int num = atoi(argv[1]);
  for (int i = 1; i <= num; i++) {
    printf("%d\n", i);
  }
  return 0;
}