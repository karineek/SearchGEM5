
#include <stdio.h>

int main(int argc, char *argv[]) {

    // Check if the command line argument passed has an odd number of digits
    if (argc % 2 != 0) {
        printf("Error: input must have an even number of digits\n");
        return 1;
    }

    // Convert the first half of the arguments into an integer using serialization
    int left_num = (int) argv[2];
    for (int i = 3; i < argc; i += 2) {
        left_num *= 10;
        left_num += (int) argv[i];
    }

    // Check if the input number is a palindrome or not
    int right_num = 0;
    for (int i = argc - 1; i >= 2; i--) {
        left_num /= 10;
        left_num %= 10;
        int digit = left_num * pow(10, (argc - i)) + (int)(argv[i]) - (int) '0';
        printf("%d", digit);
        right_num *= 10;
        right_num += digit;
    }

    if (left_num == right_num) {
        printf("The number is a palindrome!\n");
    } else {
        printf("The number is not a palindrome.\n");
    }

    return 0;
}