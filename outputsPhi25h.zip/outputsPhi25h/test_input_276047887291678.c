
#include <stdio.h>
#include <stdlib.h>

void output_input() {
    char input[50];
    printf("Enter input (BASH): ");
    fgets(input, 50, stdin);
    if (strchr(input, '\n') != NULL) {
        input[strcspn(input, "\n")] = '\0';
    }
    printf("Input: %s", input);
}

int main(int argc, char *argv[]) {
    int i;

    output_input(); // Output: Enter input (BASH): bash
                   // Input: bash

    for (i = 1; i < argc; i++) {
        if (argv[i][0] == '-') {
            printf("Input: %s\n", argv[i]);
        } else {
            int x = atoi(argv[i]);
            if (x > 100) {
                printf("Input: %d\n", argv[i]);
            } else {
                printf("Input: %s\n", argv[i]);
            }
        }
    }

    return 0;
}