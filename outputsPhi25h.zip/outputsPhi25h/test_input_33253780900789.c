
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <ctype.h>

int main(int argc, char *argv[]) {
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "loop_optimizations.h")) {
            printf("%s\n", argv[i]);
        }
        if (!strcmp(argv[i], "middle_end.h")) {
            printf("%s\n", argv[i]);
        }
        if (!strcmp(argv[i], "currency_symbol.c")) {
            printf("%s\n", argv[i]);
        }
    }
    return 0;
}