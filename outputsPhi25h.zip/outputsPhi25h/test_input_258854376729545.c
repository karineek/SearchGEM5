
#include <stdio.h>

int main(int argc, char *argv[]) {
    // get first argument from command line as integer input
    int num = strtol(argv[1], NULL, 10);
    
    // perform addition of two integers
    printf("Addition: %d + %d = %d\n", num, argc - 1, num + argc - 1);
    
    // perform subtraction of two integers
    printf("Subtraction: %d - %d = %d\n", num, argc - 2, num - (argc - 2));
    
    // perform multiplication of two integers
    printf("Multiplication: %d * %d = %d\n", num, argc - 3, num * (argc - 3));
    
    // perform division of two integers
    if (argc > 4) {
        int divisor = strtol(argv[4], NULL, 10);
        printf("Division: %d / %d = %d\n", num, argc - 5, num / (divisor));
    } else {
        printf("Error: invalid input for division.\n");
    }
    
    return 0;
}