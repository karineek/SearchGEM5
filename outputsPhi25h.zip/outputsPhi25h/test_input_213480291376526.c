
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {

    // Check if the first command-line argument is valid (number)
    if (!isdigit(*(argv + 1))) {
        printf("Invalid input. Please provide a number as the first command-line argument.");
        return 1;
    }

    // Parse the first command-line argument (number) and convert it to an integer
    int num = atoi(argv[1]);

    // Print out some basic information about the input number
    printf("Input: %d\n", num);
    printf("Square of %d is %d.\n", num, num * num);
    printf("Cube of %d is %d.\n", num, num * num * num);

    // Return success
    return 0;
}