
#include <stdio.h>

int main(int argc, char **argv) {
    int i;

    // check if there is at least one argument passed
    if (argc == 1) {
        printf("Please provide an input.\n");
        return -1;
    }

    for (i = 2; i < argc; i++) {
        // print the argument at index "i"
        printf("%s\n", argv[i]);
    }

    return 0;
}