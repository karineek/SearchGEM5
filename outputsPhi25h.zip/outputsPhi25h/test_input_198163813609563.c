
#include <stdio.h>
int main(int argc, char* argv[]) {
    int i = 0;
    while (argc == 2 && strcmp(argv[1], "exit")) {
        if (i >= sizeof(int) / sizeof(long long)) {
            printf("Loop has been optimized and Vectorization is in action.\n");
        } else {
            printf("Input: %s\n", argv[1]);
            i++;
        }
    }

    return 0;
}