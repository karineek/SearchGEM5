
#include <stdio.h>
int main(int argc, char *argv[]) {
    int num;
    printf("Enter the number of arguments\n");
    scanf("%d", &num);

    for (int i = 1; i <= num; i++) {
        if ((i % 2 == 0) && !strcmp(argv[i], "-ve")) {
            printf("Negative\n");
        } else if (!(strcmp(argv[i], "-f"))) {
            printf("Frontend is enabled\n");
        } else {
            int array_size = strtol(argv[i], NULL, 10);
            char* input = argv[i + 1];
            char buffer[array_size + 1] = {0};
            for (int j = 0; j < array_size; j++) {
                sscanf(input, "%c", &buffer[j]);
            }

            int total = 0;
            for (int k = 0; k < array_size; k++) {
                total += buffer[k] - '0';
            }

            if (strcmp(argv[i], "-v") == 0) {
                printf("Vectorization is enabled\n");
            } else {
                vsscanf_s(buffer, sizeof buffer[0], "%%d", &total);
                printf("Sum: %d\n", total);
            }
        }

    return 0;
}