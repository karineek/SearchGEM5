
#include <stdio.h>
int main(void) {

	// input taken via argv only
	argv[1] = atoi(argv[1]);
	
	// Common Subexpression Elimination
	if (argv[1] % 2 == 0 && argv[2] > argv[1]) {
		printf("%d\n", argv[1] + argv[2]);
	} else {
		printf("Error: Invalid input.");
	}

	// Deals with binary formats
	char bin_str[16];
	scanf("%s", bin_str);

	int len = strlen(bin_str);
	for (int i = 0; i < len/2; ++i) {
		if (bin_str[2*i] == '1' && bin_str[2*i+1] == '0') {
			printf("Error: Invalid binary input.");
		} else if (bin_str[2*i] == '0' && bin_str[2*i+1] == '1') {
			printf("Error: Invalid binary input.");
		}
	}

	// int_fast8_t type
	int i = 0;
	while (i < 256) {
		if ((i & 1) == 0) {
			printf("0x%2.2X\n", i);
		} else {
			printf("0x%02X\n", i);
		}
		++i;
	}

	return 0;
}