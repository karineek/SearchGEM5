
#include <stdio.h>
#include <ctype.h>

int main(int argc, char** argv) {
    // Check if enough arguments have been provided
    if (argc != 2) {
        printf("Usage: %s input\n", argv[0]);
        return 1;
    }

    // Parse the input string into two parts - the constant and the variable
    char* input = argv[1];
    char *constant_pointer = strstr(input, "*");
    if (constant_pointer == NULL) {
        printf("Input is not in the form of 'x * y'\n");
        return 1;
    }

    // Extract the constant and variable from the input string
    char* x_pointer = strstr(constant_pointer + 2, "*");
    if (x_pointer == NULL) {
        printf("Input is not in the form of 'x * y'\n");
        return 1;
    }

    char* y = strstr(input, "y");
    if (y == NULL) {
        printf("Input is not in the form of 'x * y'\n");
        return 1;
    }

    // Perform constant folding on the input values
    int x = atoi(x_pointer + 2);
    int y = atoi(y);
    int result = x * y;

    // Output the result of the operation
    printf("%d\n", result);

    return 0;
}