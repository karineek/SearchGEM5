
#include <stdio.h>

int main(int argc, char *argv[]) {

    int length = 0;
    if (argc > 1) {
        for (int i = 2; i <= argc; i++) {
            if (strlen(argv[i]) > length) {
                length = strlen(argv[i]);
            }
        }
    }

    printf("Maximum length of command-line arguments is %d\n", length);

    return 0;
}