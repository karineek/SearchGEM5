
#include <stdio.h>
int main(int argc, char** argv) {
    if (argc != 2) {
        printf("Usage: %s [number]\n", *argv);
        return 1;
    }
    long long num = atol(argv[1]);
    if (num == 0) {
        printf("Cannot divide by zero.\n");
        return 2;
    }
 
    int is_even = ((num & 1) == 0);
    if (is_even) {
        printf("Number is even.\n");
    } else {
        printf("Number is odd.\n");
    }
 
    long long prime = num;
    while (prime % 2 == 0) {
        num /= 2;
        prime /= 2;
    }
 
    if (is_even) {
        printf("The number is composite.\n");
    } else {
        printf("Number is prime.\n");
    }
 
    return 0;
}