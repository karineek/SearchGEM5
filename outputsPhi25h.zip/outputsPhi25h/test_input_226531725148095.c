
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {

    // Check if the command line arguments are valid inputs for the program
    if (argc != 3) {
        printf("Error: Invalid number of arguments\n");
        return 1;
    }

    double num1 = atof(argv[1]); // Convert the first argument to a double type
    char op = argv[2][0]; // Get the operator from the second argument as a single character
    double num2 = atof(argv[3]); // Convert the third argument to a double type

    // Perform the calculation based on the operator
    switch (op) {
        case '+':
            printf("The result is: %lf\n", num1 + num2);
            break;
        case '-':
            printf("The result is: %lf\n", num1 - num2);
            break;
        case '*':
            printf("The result is: %lf\n", num1 * num2);
            break;
        case '/':
            if (num2 == 0) { // Check for division by zero
                printf("Error: Division by zero\n");
                return 1;
            }
            printf("The result is: %lf\n", num1 / num2);
            break;
        default:
            printf("Error: Invalid operator\n");
            return 1;
    }

    // Print a message indicating the end of the program
    printf("Thank you for using the calculator. Have a nice day!\n");

    return 0;
}