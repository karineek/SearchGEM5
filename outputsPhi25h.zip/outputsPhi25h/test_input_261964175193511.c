
#include <stdio.h>
int main(int argc, char *argv[]) {

   // Check if enough arguments are passed in
   if (argc != 2) {
      printf("Please provide an input value using the format: input_value\n");
      return 1;
   }

   // Get the input value from argv[1] and print it to the console
   char input_str[100];
   strncpy(input_str, argv[1], sizeof(input_str));

   printf("Input: %s\n", input_str);

   // Return 0 to indicate success
   return 0;
}