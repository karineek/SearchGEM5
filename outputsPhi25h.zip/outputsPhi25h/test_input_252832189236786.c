
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int num1;
    int num2;
    printf("Enter two numbers to add: ");
    scanf("%d %d", &num1, &num2);

    if (isxdigit(argv[0][0]) && isxdigit(argv[1][0])) {
        int sum = num1 + num2;
        printf("The sum of %d and %d is %d\n", num1, num2, sum);
    } else {
        printf("Please enter two numbers.\n");
    }

    return 0;
}