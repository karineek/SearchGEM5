
#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]) {
    int n;
    n = atoi(argv[1]); // Read the first argument as an integer
    if (n > 100) {
        printf("Input is out of range\n");
    } else {
        for (int i = 0; i < n; ++i) { // Loop through the input
            if (*(argv[1] + i) == 'a') { // Check if a character is encountered
                printf("Found 'a'\n");
            } else {
                continue; // Skip the character and move on to the next one
            }
        }
    }
    return 0;
}