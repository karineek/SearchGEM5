
#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]) {
    int i;
    for (i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "switch") == 0) { // check if the command is switch
            printf("Argument %d: '%s\n', %s\n", i, argv[i], argv[++i]); // output arguments for switch statement
        }
    }
    return 0;
}