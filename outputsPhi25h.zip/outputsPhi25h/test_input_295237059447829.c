
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    int i;
    char** pointers = (char**) malloc((argc + 1) * sizeof(*pointers));
    if (!pointers) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    // Assign argv[0] to the filename variable, and rest of args to pointers
    char* filename = malloc(strlen(argv[0]) + strlen(argv[1]) + 3);
    if (!filename) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    strcat(filename, argv[0]);
    strcat(filename, "__FILE__.");
    filename = malloc(strlen(argv[1]) + 2);
    if (!filename) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    strcat(filename, argv[1]);
    filename = malloc(strlen("Hello World!") + 3);
    if (!filename) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    strcat(filename, "Hello World!\0");

    // Assign argv[2:] to pointers with appropriate size and memory location for each variable
    for (i = 2; i < argc; i++) {
        char* var_name = malloc(strlen(argv[i]) + 1);
        if (!var_name) {
            printf("Memory allocation failed.\n");
            return 1;
        }

        strcpy(var_name, argv[i]);
        pointers[i] = &var_name;
    }

    // Dynamically allocate memory for variable size objects and assign addresses to pointers
    char* var1 = malloc(strlen("Hello") + 1);
    if (!var1) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    strcpy(var1, "Hello");

    char* var2 = malloc(strlen("World") + 1);
    if (!var2) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    strcpy(var2, "World");

    // Print the filename and variable names
    printf("Filename: %s\n", filename);
    for (i = 0; i < argc; i++) {
        printf("Variable name: %s, value: %s\n", pointers[i]->name, *pointers[i]);
    }

    // Free the allocated memory and return 0
    for (i = 0; i < argc; i++) {
        free(pointers[i]);
    }

    free(filename);
    return 0;
}