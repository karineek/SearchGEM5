
#include <stdio.h>
#include <string.h>
#include <math.h>

// function to reverse a string
void reverse(char *str) {
    int len = strlen(str);
    for (int i = 0; i < len / 2; i++) {
        // swap characters at ith and length - 1th position
        char temp = str[i];
        str[i] = str[len - i - 1];
        str[len - i - 1] = temp;
    }
}

int main(int argc, char **argv) {
    // read the input from argv[1]
    if (argc != 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    // open the input file for reading
    FILE *in = fopen(argv[1], "r");
    if (!in) {
        printf("Error: could not open input file\n");
        return 1;
    }

    // read the content of the input file and split it into words
    char *words[100];
    int i = 0;
    while (fscanf(in, "%99s", words[i]) == 1) {
        i++;
    }

    // reverse the order of the words
    for (int j = 0; j < i / 2; j++) {
        char temp[100];
        strcpy(temp, words[j]);
        strcpy(words[j], words[i - 1 - j]);
        strcpy(words[i - 1 - j], temp);
    }

    // print the reversed words
    for (int j = 0; j < i; j++) {
        printf("%s ", words[j]);
    }
    printf("\n");

    // close the input file
    fclose(in);

    return 0;