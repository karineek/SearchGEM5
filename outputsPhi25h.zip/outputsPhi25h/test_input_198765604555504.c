
#include <stdio.h>

int main(int argc, char** argv) {
  int n;

  if (argc != 2) {
    printf("Usage: %s <integer>\n", *argv[0]);
    return 1;
  }

  n = atoi(argv[1]);

  printf("The square of %d is %d.\n", n, n*n);

  return 0;
}