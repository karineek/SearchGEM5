
int main(int argc, char *argv[]) {
    // access first command line argument (program name)
    std::string program_name = argv[0];
    
    // access second command line argument (first argument)
    int value1 = atoi(argv[1]);
    
    // print output
    std::cout << "Program name: " << program_name << std::endl;
    std::cout << "First argument as integer: " << value1 << std::endl;
    return 0;
}