
#include <stdio.h>
int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s input\n", argv[0]);
        return 1;
    }
    int num = atoi(argv[1]);
    for (int i = 0; i < num; i++) {
        printf("%d\n", i);
    }
    return 0;
}