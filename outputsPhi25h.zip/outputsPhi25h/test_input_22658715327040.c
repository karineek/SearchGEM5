
#include <stdio.h>
int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }

    FILE *file = fopen(argv[1], "r");
    if (!file) {
        printf("Error opening file: %s\n", argv[1]);
        return 1;
    }

    while (fscanf(file, "%d", &num) == 1) {
        fprintf(stdout, "%.2f\n", num);
    }

    fclose(file);
    return 0;
}