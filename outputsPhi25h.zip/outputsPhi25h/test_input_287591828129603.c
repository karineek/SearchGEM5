
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // Perform Memory Optimizations by allocating memory dynamically
    int num_input = strtol(argv[1], NULL, 10);
    char* input_str = (char*) malloc(num_input * sizeof(char));

    for (int i = 0; i < num_input; i++) {
        scanf("%c", &input_str[i]);
    }

    // Perform Deals with binary formats by converting input to ASCII and then printing it as a string
    printf("ASCII representation: %s\n", argv[1]);
    printf("ASCII representation of input: %s\n", input_str);

    return 0;
}