
#include <stdio.h>
int main() {
    // Check if enough arguments are provided
    if (argc != 3) {
        printf("Usage: %s <input-file> <output-file>\n", __FILE__);
        return 1;
    }

    // Open input and output files
    FILE* in = fopen(argv[1], "r");
    FILE* out = fopen(argv[2], "w");

    if (in == NULL) {
        printf("Error: Could not open input file\n");
        return 1;
    }

    // Read from input file and write to output file
    while (fgets(input, 100, in)) {
        fputs("Output: " + input, out);
    }

    // Close input and output files
    fclose(in);
    fclose(out);

    return 0;
}