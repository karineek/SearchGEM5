
#include <stdio.h>
int main(int argc, char *argv[]) {
    int num = atoi(argv[1]);
    if (num % 2 == 0) {
        printf("Even number\n");
    } else {
        printf("Odd number\n");
    }
    return 0;
}