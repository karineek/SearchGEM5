
#include <stdio.h>
#define MAX_ARGS 5
int main(int argc, char** argv) {

    // check if the correct number of arguments is passed
    if (argc != 2 || atoi(argv[1]) == 0) {
        printf("Error: incorrect number of arguments\n");
        return 1;
    }

    // create an array to store the input values
    int arr[MAX_ARGS];

    // read in each argument as a value for an index in the array
    for (int i = 0; i < MAX_ARGS; ++i) {
        if (scanf("%d", &arr[i]) != 1) {
            printf("Error: invalid input\n");
            return 1;
        }
    }

    // loop through the array and perform some operations
    for (int i = 0; i < MAX_ARGS; ++i) {
        if (arr[i] >= 10) {
            arr[i] *= 2;
        } else if (arr[i] % 2 == 0) {
            arr[i] /= 2;
        } else {
            arr[i] = -1;
        }
    }

    // check if any of the values are negative, and print an error message if so
    for (int i = 0; i < MAX_ARGS; ++i) {
        if (arr[i] < 0) {
            printf("Error: negative value detected\n");
            return 1;
        }
    }

    // print the resulting array
    for (int i = 0; i < MAX_ARGS; ++i) {
        if (arr[i] == -1) {
            printf("Invalid input: %d\n", arr[i]);
            return 1;
        } else {
            printf("%d ", arr[i]);
        }
    }

    // print a newline character to end the output
    printf("\n");

    return 0;
}