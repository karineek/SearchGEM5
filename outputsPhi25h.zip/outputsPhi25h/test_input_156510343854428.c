

Example Input (BASH): 