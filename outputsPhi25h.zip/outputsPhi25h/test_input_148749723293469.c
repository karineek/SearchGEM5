
#include <stdio.h>
int main(int argc, char *argv[]) {

    // Get input from command line
    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);

    // Perform subtraction and print result
    int diff = num1 - num2;
    printf("%d\n", diff);

    return 0;
}