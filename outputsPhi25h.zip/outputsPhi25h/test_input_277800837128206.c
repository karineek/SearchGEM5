
#include <stdio.h>
int main(int argc, char **argv) {
    // Example of a program that reads user input using argv
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }

    // Read the filename from command line arguments
    char *filename = argv[1];

    // Open the file for reading
    FILE* fp = fopen(filename, "r");
    if (fp == NULL) {
        perror("Error opening file: ");
        return 2;
    }

    // Read the contents of the file into a string buffer
    char *buffer = malloc(1024*sizeof(*buffer));
    if (buffer == NULL) {
        perror("Error allocating memory");
        return 3;
    }

    fread(buffer, sizeof(*buffer), 1024, fp);
    buffer[strcspn(buffer, "\0")] = '\0'; // remove trailing newline character

    // Close the file
    fclose(fp);

    // Print the contents of the file to standard output
    printf("Contents of %s:\n", filename);
    puts(buffer);

    return 0;
}