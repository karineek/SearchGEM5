
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {

    // Check if we are running this program from a C shell (i.e., not directly)
    if (strcmp("/bin/bash", argv[0]) == 0) {
        // If so, read input from the command line and print it out to the console
        char input[1024];
        fgets(input, sizeof(input), stdin);
        printf("You entered: %s\n", input);
    } else {
        // Otherwise, just run the program normally (i.e., without any shell interaction)
        printf("Running program with command line arguments: %s\n", argv[1]);

        int i;
        for (i = 2; i < argc; i++) {
            // Check if this argument is a number (i.e., an input)
            int num = atoi(argv[i]);

            // If so, print it out to the console
            printf("Input #%d: %d\n", i - 2, num);
        }
    }

    return 0;
}