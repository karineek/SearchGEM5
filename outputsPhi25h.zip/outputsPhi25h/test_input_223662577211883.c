
#include <stdio.h>
#include <string.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s input\n", argv[0]);
        return 1;
    }

    double num = atof(argv[1]);

    // Check if the number is prime using static analysis in Clang
    if (is_prime(num)) {
        printf("%f is a prime number\n", num);
    } else {
        printf("%f is not a prime number\n", num);
    }

    // Use constant folding to simplify expressions
    double x = 2.5 + 3.7;
    double y = 1.2 * (4 / 5);
    printf("constant folding: %f, %f\n", x, y);

    return 0;
}

// Function to check if a number is prime using static analysis in Clang
bool is_prime(double num) {
    // Check if the number is 2 (2 is the only even prime number)
    if (num == 2) {
        return true;
    }

    // Check if the number is divisible by any integer from 3 to sqrt(num)
    for (int i = 3; i <= sqrtf(num); i += 2) {
        if (num % i == 0) {
            return false;
        }
    }

    // If the number is not divisible by any integer from 3 to sqrt(num), it is prime
    return true;
}