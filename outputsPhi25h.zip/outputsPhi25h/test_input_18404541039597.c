
#include <stdio.h>
#include <string.h>

/* Function to check if a character is digit */
bool is_digit(char c) {
    return c >= '0' && c <= '9';
}

int main(int argc, char *argv[]) {

    // Check the number of command line arguments passed to the program. If there are less than 3 arguments, an error message will be displayed and the program will terminate.
    if (argc < 3) {
        printf("Error: Please provide at least two input files as arguments\n");
        return 1;
    }

    // Initialize variables for the first file name, second file name and third file name.
    char *file1 = argv[1];
    char *file2 = argv[2];
    char *file3 = argv[3];

    // Open the first file for reading.
    FILE* fp1 = fopen(file1, "r");
    if (!fp1) {
        printf("Error: Cannot open file %s\n", file1);
        return 1;
    }

    // Open the second file for reading.
    FILE* fp2 = fopen(file2, "r");
    if (!fp2) {
        printf("Error: Cannot open file %s\n", file2);
        return 1;
    }

    // Open the third file for reading.
    FILE* fp3 = fopen(file3, "r");
    if (!fp3) {
        printf("Error: Cannot open file %s\n", file3);
        return 1;
    }

    // Read the contents of each file into arrays.
    char *line1 = fgets(line, sizeof(line), fp1);
    char *line2 = fgets(line, sizeof(line), fp2);
    char *line3 = fgets(line, sizeof(line), fp3);

    // Close the files.
    fclose(fp1);
    fclose(fp2);
    fclose(fp3);

    // Create a function to check if a character is uppercase.
    bool is_uppercase(char c) {
        return (c >= 'A' && c <= 'Z');
    }

    // Function for the rintf() method.
    int rintf(char *line, char *output) {
        // Initialize a counter variable to keep track of the number of uppercase letters found in the line.
        int count = 0;

        // Loop through each character in the line.
        for (int i = 0; i < strlen(line); i++) {
            char c = line[i];
            if (is_uppercase(c)) {
                count++;
            }
        }

        // Open the output file for writing.
        FILE* fp = fopen(output, "w");
        if (!fp) {
            printf("Error: Cannot open output file %s\n", output);
            return 1;
        }

        // Write the number of uppercase letters found in the line to the output file.
        fprintf(fp, "%d\n", count);

        // Close the output file.
        fclose(fp);
    }

    return 0;
}