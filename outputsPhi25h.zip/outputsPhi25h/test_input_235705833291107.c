
#include <stdio.h>

int main(int argc, char **argv) {
    int n = 0;

    if (argc != 2) {
        printf("Usage: %s input\n", argv[0]);
        return 1;
    }

    n = atoi(argv[1]);

    for (int i = 0; i < n; i++) {
        printf("%d\n", i);
    }

    return 0;
}