
#include <stdio.h>
#include <string.h>

int main(int argc, char** argv) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s input file", argv[0]);
        return 1;
    }

    char* filename = argv[1];
    char buffer[1024];

    FILE* in_file = fopen(filename, "rb");
    if (in_file == NULL) {
        fprintf(stderr, "Error opening file: %s\n", filename);
        return 1;
    }

    // Read input data into buffer
    int i = 0;
    while (fread(buffer, sizeof(char), 1024, in_file) == 1024) {
        fwrite(&i, sizeof(int), 1, stdout);
    }

    // Close input file and return success
    fclose(in_file);
    return 0;
}