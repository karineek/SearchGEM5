
#include <iostream>
#include <string>
using namespace std;

int main(int argc, char* argv[]){

    if(argc == 2){
        string input = argv[1];

        // bitwise assignment (|=)
        for (int i = 0; i < input.size(); i++){
            if(input[i] == '0'){
                input[i] |= 1;
            }
            else if(input[i] == '1'){
                input[i] ^= 1;
            }

        }

        cout << "Input: " << input << endl;
        return 0;
    } else {
        cout << "Error: Invalid number of arguments" << endl;
        return 1;
    }