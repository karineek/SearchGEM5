
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

void dead_code_elimination(int n, int* arr) {
    for (int i = 0; i < n - 1; i++) {
        if (arr[i] == 0 && arr[i + 1] > 0) {
            *arr = *arr & ~1;
        } else if (arr[i] < 0 && arr[i + 1] < 0) {
            arr[i] &= ~-1;
        } else if (arr[i] == -1 || arr[i + 1] == 1) {
            *arr = 0;
            break;
        }
    }
}

int main(int argc, char** argv) {
    int n = (argc > 1) ? atoi(argv[1]) : 0;
    bool input_flag = false;
    if (argc >= 3 && strcmp(argv[2], "input") == 0) {
        n = (int)strtol(argv[3], NULL, 10);
        input_flag = true;
    }

    int* arr = calloc(n, sizeof(int));

    for (int i = 0; i < n && !input_flag; ++i) {
        if (argc >= 4) {
            *arr += atoi(argv[4]);
        } else {
            arr[i] = stdin.get();
        }
    }

    if (!input_flag) {
        printf("Input required\n");
        return 1;
    }

    dead_code_elimination(n, arr);

    for (int i = 0; i < n; ++i) {
        if (arr[i] > 0) {
            printf("%d\n", arr[i]);
        } else {
            printf("0\n");
        }
    }

    return 0;
}