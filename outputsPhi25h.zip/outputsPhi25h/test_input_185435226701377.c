
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {

    // Loop Optimizations
    for (int i = 0; i < argc - 1; i++) {
        printf("%s\n", argv[i]);
    }

    return 0;
}