
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char* argv[]) {

  // Check if the program has been called correctly with arguments
  if (argc != 2) {
    fprintf(stderr, "Usage: %s <filename>\n", argv[0]);
    return 1;
  }

  // Open the file specified by the filename argument for reading
  FILE* fp = fopen(argv[1], "r");
  if (fp == NULL) {
    perror("Error opening file: %s\n", argv[1]);
    return 1;
  }

  // Read the contents of the file and store them in a string
  char* str = malloc(strlen(argv[1]) + 1);
  if (str == NULL) {
    perror("Error allocating memory for string");
    return 1;
  }
  fread(str, sizeof(char), strlen(argv[1]), fp);

  // Free the allocated memory when done with it
  free(str);

  // Return 0 to indicate success
  return 0;
}