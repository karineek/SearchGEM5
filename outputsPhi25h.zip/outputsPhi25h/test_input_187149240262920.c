
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    char buffer[255];

    for (int i = 1; i < argc; i++) {
        strncpy(buffer, argv[i], 255);
        printf("Input: %s\n", buffer);
    }

    printf("Output: Hello World\n");

    return 0;
}