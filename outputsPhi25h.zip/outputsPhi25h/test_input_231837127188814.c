
#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]) {

    // Check if the first argument is -w or -W and ignore it (if any) to avoid warnings.
    if (argc == 2 && strcmp(argv[1], "-w") != 0) {
        argv[2] = NULL; // Set the second argument to NULL to ignore it.
    }

    int num = atoi(argv[2]); // Convert the third argument (if any) to an integer.

    if (num > 0 && strlen(argv[1]) > 0) {
        printf("The input is: %s\n", argv[1]); // Print the first argument.
    } else {
        printf("Invalid input!\n"); // Print an error message if the input is not valid.
    }

    return 0;
}