
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {

  int num;

  if (argc > 1) {
    num = atoi(argv[1]);
  } else {
    printf("Please enter a number as input.\n");
  }

  double square_root = sqrtf((double)num);

  printf("The square root of %d is: %g\n", num, square_root);

  return 0;
}