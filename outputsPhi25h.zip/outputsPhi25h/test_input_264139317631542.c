
#include <stdio.h>
#include <sys/time.h>
#include <dirent.h>
#include <string.h>

int main(int argc, char **argv) {

    int a = atoi(argv[1]);
    int b = atoi(argv[2]);
    int c = atoi(argv[3]);
    int d = atoi(argv[4]);
    int e = atoi(argv[5]);
    int f = atoi(argv[6]);
    int g = atoi(argv[7]);

    // Using register allocation to optimize memory usage
    printf("The result is: %d\n", a * b + c - d / e)

    return 0;