
#include <stdio.h>

int main(int argc, char *argv[]) {

    int i;

    for (i = 1; i <= strlen(argv[1]); i++) {
        printf("%c", argv[1][i-1]);
    }

    return 0;
}