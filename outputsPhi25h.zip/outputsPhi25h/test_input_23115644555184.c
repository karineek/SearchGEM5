
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {

    int num;

    if (argc != 2) {
        printf("Please provide one argument as input number.");
        return 1;
    }

    num = atoi(argv[1]);

    if (num < 0 || num > ULLONG_MAX) {
        printf("Input must be a number between 0 and ULONGN.Max!");
        return 2;
    }

    printf("%d\n", num);

    return 0;