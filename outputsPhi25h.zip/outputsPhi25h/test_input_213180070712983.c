
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

int main(int argc, char *argv[]) {

    if (argc == 1) {
        printf("Please provide an input for the program.");
        return -1;
    } else if (strcmp(argv[1], "-v") == 0) {
        // Compression example: compresses a file using gzip
        char *filename = argv[2];
        FILE* fp_in;
        FILE* fp_out;
        long f_size, i;
        f_size = strlen(filename);

        fp_in = fopen(filename, "rb");
        if (fp_in == NULL) {
            perror("Error opening input file.");
            return -1;
        }

        fp_out = fopen("./compressed", "wb");
        if (fp_out == NULL) {
            perror("Error opening output file.");
            return -1;
        }

        fread(fp_in, 1, f_size, stdin); // read the size of the input file
        for (i = 0; i < f_size; i++) {
            fwrite(&fp_out, 1, 1, stdin); // write each byte of the input to the output
        }

        fclose(fp_in);
        fclose(fp_out);
        printf("File compressed and saved as .compressed\n");
    } else if (strcmp(argv[1], "-s") == 0) {
        // Encryption example: encrypts a file using AES-256
        char *filename = argv[2];
        long f_size, i;
        FILE* fp_in;
        fp_in = fopen(filename, "rb");
        if (fp_in == NULL) {
            perror("Error opening input file.");
            return -1;
        }

        fp_out = fopen("./encrypted", "wb");
        if (fp_out == NULL) {
            perror("Error opening output file.");
            return -1;
        }

        fread(fp_in, 1, f_size, stdin); // read the size of the input file
        for (i = 0; i < f_size; i++) {
            fwrite(&fp_out, 1, 1, stdin); // write each byte of the input to the output
        }

        fclose(fp_in);
        fclose(fp_out);
        printf("File encrypted and saved as .encrypted\n");
    } else if (strcmp(argv[1], "-r") == 0) {
        // Reverse example: reverses a string
        char *string = argv[2];

        printf("The reverse of \"%s\" is: %s\n", string, string_reverse(string));

        return 0;
    } else {
        // Compression example: compresses a file using gzip
        char *filename = argv[2];
        FILE* fp_in;
        FILE* fp_out;
        long f_size, i;
        f_size = strlen(filename);

        fp_in = fopen(filename, "rb");
        if (fp_in == NULL) {
            perror("Error opening input file.");
            return -1;
        }

        fp_out = fopen("./compressed", "wb");
        if (fp_out == NULL) {
            perror("Error opening output file.");
            return -1;
        }

        fread(fp_in, 1, f_size, stdin); // read the size of the input file
        for (i = 0; i < f_size; i++) {
            fwrite(&fp_out, 1, 1, stdin); // write each byte of the input to the output
        }

        fclose(fp_in);
        fclose(fp_out);
        printf("File compressed and saved as .compressed\n");
    }

    return 0;
}