
#include <stdio.h>
int main(void) {
    int i;
    char *str = NULL;
    if (argc > 1) {
        str = malloc((strlen(argv[1]) + 1) * sizeof(char));
        memset(str, 0, (strlen(argv[1]) + 1) * sizeof(char))
        sscanf(argv[1], "%s", str);
    } else {
        printf("No input provided.\n");
        return 0;
    }
    for (i = 1; i < argc; i++) {
        if (!strcmp(argv[i], str)) {
            printf("Duplicate input detected.\n");
            return 1;
        }
    }
    free(str);
    return 0;
}