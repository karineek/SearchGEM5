
#include <stdio.h>

int main(int argc, char *argv[]) {

    // Check if there are at least 2 arguments provided (i.e. input file name)
    if (argc < 2) {
        printf("Error: Please provide an input file name\n");
        return 1;
    }

    // Open the input file and read its contents
    FILE *fp = fopen(argv[1], "r");
    if (fp == NULL) {
        printf("Error: Could not open input file\n");
        return 1;
    }

    // Read each line from the input file and print it to the console
    while (fgets(line, sizeof(line), fp)) {
        printf("%s\n", line);
    }

    // Close the input file
    fclose(fp);

    return 0;
}