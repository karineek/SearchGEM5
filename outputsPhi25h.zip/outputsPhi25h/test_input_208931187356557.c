
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <limits.h>

int cse(void) {
    // function to perform common subexpression elimination
    return 0;
}

int main() {
    // input from command line using argv
    char* argv[] = {"input_file", "output_file"};
    FILE* fp;

    if (sscanf(argv[1], "%s", fp) != 1 || sscanf(argv[2], "%s", fp) != 1) {
        printf("Invalid input.\n");
        return 1;
    }

    int n, i, j, k, l, m, x, y, z;

    // open the input file and read its contents
    if ((fp = fopen(argv[1], "r")) == NULL) {
        printf("Error opening file.\n");
        return 1;
    }

    fscanf(fp, "%d", &n);
    for (i = 0; i < n; i++) {
        // read the next line of input and split it into tokens
        char* line = fgets(fp, 100, argv[1]);
        if (line == NULL) {
            printf("Error reading file.\n");
            return 1;
        }
        char* tokens = strtok(line, " ");

        for (j = 0; j < i; j++) {
            int x = atoi(tokens);
            y = atoi(strtok(NULL, " "));
            z = atoi(strtok(NULL, " "));

            if (i == j) {
                // if the current line is identical to a previous line, skip it
                continue;
            }

            int a = x + y;
            int b = x - y;
            int c = x * y;
            int d = x / y;

            if (a == b) {
                // if the first two values are equal, replace them with their sum and product
                x = a + z;
                y = b + z;
            } else if (b == c) {
                // if the second two values are equal, replace them with their difference and quotient
                x = b - x;
                y = d * y;
            } else if (c == a) {
                // if the first and third values are equal, replace them with their sum and product
                x = c + z;
                y = c / y;
            } else if (d == b) {
                // if the second and fourth values are equal, replace them with their difference and quotient
                x = d - x;
                y = c * y;
            }

            if (x > INT_MAX || x < INT_MIN) {
                printf("Error: input out of range.\n");
                return 1;
            }

            // output the modified line to the output file
            fprintf(fp, "%d %d %d", x, y, z);
        }

        tokens = strtok(NULL, " ");
    }

    // close the input and output files
    fclose(fp);
    return 0;
}