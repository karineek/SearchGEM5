
#include <stdio.h>

int main(int argc, char *argv[]) {
    // check for valid number of arguments provided
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }

    // open file and read input data
    FILE *file = fopen(argv[1], "r");
    if (file == NULL) {
        printf("Error: File not found.\n");
        return 1;
    }

    // read input data and process it in the program
    char *input = fgets(argv[1], 100, file);
    if (input == NULL) {
        printf("Error: File reading failed.\n");
        return 1;
    }

    // make use of memory optimizations in the program
    fseek(file, 0L, SEEK_END);
    size_t fileSize = ftell(file);
    FILE *tempFile = fopen("temp.txt", "w");
    fseek(file, fileSize - 1, SEEK_SET);
    fwrite(&input[strcspn(input, "\n")], strlen(input), 1, tempFile);
    fclose(tempFile);

    // close input file and output file
    fclose(file);
    return 0;
}