
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    // Check if the correct number of arguments is passed
    if (argc != 3) {
        fprintf(stderr, "Usage: %s input_file output_file\n", argv[0]);
        return 1;
    }

    // Open the input and output files for reading and writing
    FILE *input = fopen(argv[1], "r");
    FILE *output = fopen(argv[2], "w");

    // Check if the files were opened successfully
    if (input == NULL || output == NULL) {
        fprintf(stderr, "Could not open file(s).\n");
        return 1;
    }

    // Read the input file line by line and write to the output file
    while (fgets(input_line, sizeof input_line, input)) {
        // Check if there is any data in the buffer
        if (strlen(input_line) == 0) continue;

        // Output the line as it is
        fprintf(output, "%s\n", input_line);
    }

    // Close the files
    fclose(input);
    fclose(output);

    return 0;
}