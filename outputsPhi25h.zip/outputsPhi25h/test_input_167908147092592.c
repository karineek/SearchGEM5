
#include <stdio.h>

int main(void) {
    // Input is taken via argv only, so the user can pass any number of arguments as input
    int n;
    if (argc > 1) {
        n = atoi(argv[1]);
    } else {
        printf("Please provide an integer argument.\n");
        return 1;
    }

    // Memory-to-Register Promotion
    int i = 0;
    while (i < n) {
        printf("%d ", ++i);
    }

    return 0;