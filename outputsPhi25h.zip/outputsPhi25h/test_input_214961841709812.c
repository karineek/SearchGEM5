
#include <stdio.h>
int main(int argc, char**argv) {
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }
    char* file = argv[1];
    FILE* fp = fopen(file, "r");
    if (fp == NULL) {
        printf("Error: %s: cannot open file\n", file);
        return 1;
    }
    char c;
    while ((c = fgetc(fp)) != EOF) {
        if (isalpha(c)) {
            printf("%c", c);
        }
    }
    fclose(fp);
    return 0;
}