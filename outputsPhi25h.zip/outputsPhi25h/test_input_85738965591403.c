
#include <stdio.h>

int main(int argc, char **argv) {
    // Check for valid command-line arguments
    if (argc != 2) {
        printf("Usage: %s <message>\n", argv[0]);
        return 1;
    }

    // Get the message from command-line argument
    char *message = argv[1];

    // Print the message to stdout
    printf("You entered: %s\n", message);

    return 0;
}