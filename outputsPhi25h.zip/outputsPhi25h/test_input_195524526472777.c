
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
  if (argc != 2) {
    printf("Usage: %s input\n", argv[0]);
    return 1;
  }

  char str[] = argv[1];
  size_t len = strlen(str);

  // Loop-invariant code motion optimization
  for (int i = 0; i < len; i++) {
    if (str[i] == 'a') {
      printf("%c\n", str[i]);
    } else {
      fprintf_s(stdout, "Not an a character.\n");
    }
  }

  // Backend optimization
  if (strcmp(str, "hello") == 0) {
    printf("Hello world!\n");
  } else {
    fprintf_s(stdout, "%s is not hello.\n", str);
  }

  return 0;
}