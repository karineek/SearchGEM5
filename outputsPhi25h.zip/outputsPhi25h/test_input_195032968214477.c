
#include <stdio.h>
#include <stdlib.h>

#define MAX_CHARS 20

int main(int argc, char** argv) {

  // check if number of arguments is correct
  if (argc != 3) {
    fprintf(stderr, "Usage: %s <input.llvm> <output.cc>\n", argv[0]);
    return 1;
  }

  // read in LLVM IR file and extract code section
  char* input_file = argv[1];
  FILE* fp = fopen(input_file, "r");
  if (fp == NULL) {
    perror("Could not open input file.");
    return 1;
  }

  // extract code section and perform constant folding
  char* code = malloc(MAX_CHARS);
  fgets(code, MAX_CHARS, fp);
  int length = strlen(code);
  for (int i = 0; i < length; i++) {
    if (isdigit(code[i])) {
      // perform constant folding on number in string
      code[i] -= '0';
    }
  }

  // write output to file
  char* output_file = argv[2];
  FILE* fp2 = fopen(output_file, "w");
  if (fp2 == NULL) {
    perror("Could not open output file.");
    return 1;
  }

  // write code to output file
  printf("#include <stdio.h>\n%s", code);
  fprintf(fp2, "int main() {\n%s}\n}\n", code);

  // close files
  fclose(fp);
  fclose(fp2);

  return 0;
}