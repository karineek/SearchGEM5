
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    int n;
    if (argc == 2) {
        n = atoi(argv[1]);
    } else {
        printf("Usage: %s <n>\n", argv[0]);
        return 1;
    }

    int array[] = {1, 2, 3, 4, 5};

    for (int i = 0; i < n; i++) {
        printf("%d\n", array[i]);
    }

    // Perform scalar optimization with SCNoFAST identifier prefix
    int sum = 0;
    for (int i = 0; i < n; i++) {
        if (array[i] % 2 == 0) {
            array[i] *= 2;
            sum += array[i];
        } else {
            array[i] /= 2;
            sum -= array[i];
        }
    }

    printf("Sum: %d\n", sum);

    return 0;
}