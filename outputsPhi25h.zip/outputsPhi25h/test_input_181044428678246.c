
#include <stdio.h>
#include <math.h>
int main(int argc, char *argv[]) {
    double radius;
    if (argc == 2) {
        radius = atof(argv[1]);
    } else {
        printf("Usage: %s radius\n", argv[0]);
        return 1;
    }
    double area = M_PI * (radius * radius);
    printf("The area of the circle with radius %f is %f.\n", radius, acoshf(area));
    return 0;
}