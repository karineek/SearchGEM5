
#include <stdio.h>

int main(int argc, char** argv) {

    if (argc != 2) {
        printf("Usage: %s input\n", *argv[0]);
        return 1;
    }

    int num = atoi(argv[1]);

    // Whole Program Analysis
    int sum = 0;
    for (int i = 0; i < num; i++) {
        sum += i;
    }

    printf("Sum of the first %d numbers is: %d\n", num, sum);

    // Handles machine code generation
    char code[4] = {0};
    code[0] = '1';
    code[1] = '2';
    code[2] = '3';
    printf("Machine code: %s\n", code);

    // Modfl function
    int mod(int num) {
        return num%3;
    }

    printf("Mod of 4 is: %d\n", mod(4));

    return 0;
}