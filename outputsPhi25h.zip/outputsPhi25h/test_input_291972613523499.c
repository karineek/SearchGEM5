
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    // Check for valid number of arguments
    if (argc != 3) {
        printf("Error: Invalid number of arguments\n");
        return 1;
    }

    // Extract the input numbers from the command line arguments
    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);

    // Perform common subexpression elimination optimization
    for (int i = 1; i <= num2; i++) {
        if (num1 % i == 0) {
            printf("%d is a factor of %d\n", i, num1);
        }
    }

    // Print the output
    printf("Common subexpression elimination optimization complete.\n");

    return 0;
}