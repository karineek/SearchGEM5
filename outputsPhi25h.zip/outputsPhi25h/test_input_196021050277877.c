
#include <stdio.h>

int main(int argc, char *argv[]) {
    int n;

    if (argc != 2) {
        printf("Usage: %s <n>\n", argv[0]);
        return 1;
    }

    n = atoi(argv[1]);
    int factorial = 1;

    for (int i = 2; i <= n; i++) {
        factorial *= i;
    }

    printf("Factorial of %d is: %d\n", n, factorial);

    return 0;
}