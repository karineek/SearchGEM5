
#include <stdio.h>

int main(int argc, char *argv[]) {
  int n;
  if (argc != 2) {
    printf("Usage: %s integer\n", argv[0]);
    return 1;
  }

  n = atoi(argv[1]);
  for (int i = 1; i <= sqrt(n); i++) {
    if (n % i == 0) {
      printf("%d ", i);
      if (i != n / i) {
        printf("%d ", n / i);
      }
    }
  }

  return 0;
}