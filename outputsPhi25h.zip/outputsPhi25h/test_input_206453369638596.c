
#include <stdio.h>
#include <stdarg.h>

int main(int argc, char* argv[]) {

  // Initialize the program's namespace argument count (N) and
  // maximum number of arguments allowed for the program (M).
  int N = 0;
  int M = -1;

  // Loop through all the arguments in the given program.
  for (int i=1; i<argc; i++) {

    // If an argument is a numeric type, increase N and update M if it's larger.
    switch (strtok(argv[i], ",")) {
      case '\0':
        break;
      default:
        N++;
        if (M < N) M = N;
    }
  }

  // Print the program's namespace argument count and maximum number of arguments.
  printf("Program has %d arguments and can handle up to %d arguments\n", N, M);

  return 0;
}