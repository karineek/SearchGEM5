
#include <stdio.h>
#include <locale.h>

int main(int argc, char** argv) {
    printf("Hello world!\n");

    // loop-invariant code motion optimization using gcc
    char *line = malloc(strlen(argv[1]) + 1);
    if (line == NULL) {
        return 1;
    }
    strcpy(line, argv[1]);

    // localtime function
    struct tm *localTime = localtime(&tm);
    printf("Local time: %d/%d/%d %H:%M:%S\n", localTime->tm_mon, localTime->tm_mday, localTime->tm_year,
    localTime->tm_hour, localTime->tm_min, localTime->tm_sec);

    // prints the line with all included files and their directories in the program's directory
    for (int i = 0; i < argc - 1; i++) {
        char *fileName = argv[i + 2];
        char *directory = ".";
        while (*directory) {
            directory++;
        }

        if (strcmp(fileName, ".clang") == 0 || strcmp(fileName, ".gcc") == 0) {
            printf("%s\n", directory);
        }
    }

    free(line);

    return 0;
}