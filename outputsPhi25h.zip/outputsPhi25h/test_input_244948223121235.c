
#include <stdio.h>
#include <math.h>
int main(int argc, char* argv[]) {
    double x = atof(argv[1]); //Convert string to float value
    printf("The square of %f is: %f\n", x, pow(x, 2)); //Constant folding on 'pow' function
    return 0;
}