
#include <stdio.h>
#include <sys/argc.h>

int main(int argc, char* argv[]) {
    printf("Input: %s\n", argv[1]); // printing the first argument as input

    return 0;
}