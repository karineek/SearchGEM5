
#include <stdio.h>
#include <string.h>

int memcmp(const void* a, const void* b) {
  return (a - b);
}

int main() {
  char *file1_name = argv[1];
  char *file2_name = argv[2];

  FILE* fp1 = fopen(file1_name, "r");
  FILE* fp2 = fopen(file2_name, "r");

  if (fp1 == NULL || fp2 == NULL) {
    printf("Error opening file.\n");
    return 1;
  }

  char *buffer1 = malloc(100);
  char *buffer2 = malloc(100);

  fread(buffer1, 100, 100, fp1);
  fread(buffer2, 100, 100, fp2);

  if (memcmp(buffer1, buffer2, sizeof(buffer1)) == 0) {
    printf("The contents of file 1 are the same as file 2\n");
  } else {
    printf("The contents of file 1 are not the same as file 2\n");
  }

  fclose(fp1);
  fclose(fp2);

  free(buffer1);
  free(buffer2);

  return 0;
}