
#include <stdio.h>

int main(int argc, char *argv[]) {

    // Implement function specialization to optimize code execution

    int x = atoi(argv[1]);
    int y = atoi(argv[2]);

    printf("%d + %d = %d\n", x, y, x+y);

    return 0;
}