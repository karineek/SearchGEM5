
#include <stdio.h>
#include <string.h>

int main(int argc, char** argv) {

  // loop optimization example
  int i;
  for (i = 0; i < 10; i++) {
    printf("%d\n", i);
  }
  
  // collection of optimization passes example
  char s[100];
  strcpy(s, argv[1]); // copy input string to s
  printf("%s\n", s);
  
  // strcat_s example
  char c[] = "Hello, ";
  char d[10] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j' };
  for (int i = 0; i < strlen(d); i++) {
    c[0] = d[i]; // copy individual characters to c
  }
  printf("%s\n", c);

  return 0;
}