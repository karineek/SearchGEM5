
#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]) {
    // Check if the number of arguments provided is at least 2 (for input)
    if (argc >= 3) {
        char input_str[256];

        // Get the first argument as the input string and convert it to uppercase using strtoupper() function
        strncpy(input_str, argv[1], sizeof(input_str));
        input_str[strcspn(argv[1], "\0")] = '\0'; // Remove the null character at the end of the string

        printf("Input: %s\n", input_str);
        strcat(input_str, " (Uppercase)\n");
        printf("Output: %s\n", input_str);

        return 0;
    } else {
        // If less than 2 arguments provided, print an error message
        printf("Error: Please provide at least 2 arguments (input and output filename)\n");
        return 1;
    }
}