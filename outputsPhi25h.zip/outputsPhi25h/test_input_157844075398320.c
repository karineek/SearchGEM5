
#include <stdio.h>

int main(int argc, char *argv[]) {
  int i;

  // Get the number of arguments passed to the program
  if (argc > 1) {
    printf("The number of arguments: %d\n", argc - 1);
  } else {
    printf("You need to pass at least one argument.\n");
  }

  // Get user input from the command line arguments using argv[1]
  for (i = 2; i < argc; i++) {
    int value;

    if (sscanf(argv[i], "%d", &value) != 1) {
      printf("Invalid input format. Please enter an integer.\n");
    } else {
      // Print the user input
      printf("You entered: %d\n", value);
    }
  }

  return 0;
}