
$ gcc -Wall main.c -o executable
$ ./executable input_file.txt