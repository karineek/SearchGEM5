
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {

	// Get input string from command line argument
	char input_str[] = argv[1];

	// Initialize array to store integer values
	int arr[10];

	// Convert input string to integer array using sscanf()
	for (int i = 0; i < strlen(input_str); i++) {
		sscanf(input_str + i, "%d", &arr[i]);
	}

	// Perform operations on the array
	for (int i = 0; i < sizeof(arr) / sizeof(*arr); i++) {
		arr[i] = arr[i] * 2; // double each element of the array
	}

	// Print output array
	for (int i = 0; i < sizeof(arr) / sizeof(*arr); i++) {
		printf("%d ", arr[i]);
	}

	return 0;
}