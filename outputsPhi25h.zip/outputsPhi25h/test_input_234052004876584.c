
#include <stdio.h>

int main(int argc, char *argv[]) {
    //Promote memory to register using memory_order_

    int i;

    for (i = 0; i < sizeof argv / sizeof argv[0]; i++) {
        printf("argv[%d]: %s\n", i, argv[i]); //Reads LLVM IR and memory_order_.
    }

    return 0;
}