
#include <stdio.h>
int main(int argc, char* argv[]) {
    printf("Enter a number: ");
    int num;
    scanf("%d", &num);
    if (argc == 2) {
        printf("You entered %d\n", atoi(argv[1]));
    } else {
        printf("Please enter a number as an argument.\n");
    }
    return 0;