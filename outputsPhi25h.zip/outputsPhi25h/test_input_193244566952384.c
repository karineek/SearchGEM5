
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    // Check if enough arguments are provided
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }

    // Read the file and remove any whitespace from the contents
    FILE *f = fopen(argv[1], "r");
    char buffer[100];
    while (fgets(buffer, sizeof(buffer), f) != NULL) {
        sscanf(buffer, "%[^\t\n]", argv[1]);
        if (strspn(argv[1], "\t\n") == 0 && strlen(argv[1]) > 1) {
            // Remove leading or trailing whitespace from input
            argv[1] = strcspn(argv[1], "\t\n");
        }
        printf("%s", argv[1]);
    }

    // Close the file and exit with an error code if there was an issue reading the input file
    fclose(f);
    return 0;
}