
#include <stdio.h>

int main(int argc, char *argv[]) {
    // Check for target architecture
    if (strcmp(argv[1], "x86") == 0) {
        int a = atoi(argv[2]);
        int b = atoi(argv[3]);

        // Common subexpression elimination
        int result = (a & b) + (a | b);

        printf("%d\n", result);
    } else if (strcmp(argv[1], "arm") == 0) {
        char c = argv[2];
        char d = argv[3];

        // Common subexpression elimination
        int result = (c & d) + (c | d);

        printf("%c\n", result);
    } else {
        printf("Invalid target architecture. Please provide either 'x86' or 'arm'.\n");
    }

    return 0;
}