
#include <stdio.h>
#include <math.h>

int main(int argc, char* argv[]) {

  // Initializing the variables
  int n;
  double x;
  int y = 0;

  // Reading input from the command line arguments
  if (argc != 2) {
    printf("Usage: %s <number>\n", argv[0]);
    return 1;
  }

  n = atoi(argv[1]);

  // Performing a loop optimization using the powl function
  for (int i = 0; i < n; ++i) {
    x = pow(2, i);
    y += x;
  }

  // Printing the output
  printf("Output: %.2f\n", y);

  return 0;
}