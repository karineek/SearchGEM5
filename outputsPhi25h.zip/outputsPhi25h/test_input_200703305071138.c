
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAX_LINE 1000
void inline(char* s, int i) {
    s[i] = '\0';
}
int main(int argc, char** argv) {
    // read input from command line arguments
    char* inputFileName = argv[1];
    int length;
    if (argc != 3) {
        printf("Usage: %s <input file name> <output file name>\n", argv[0]);
        return 1;
    }
    length = strlen(argv[2]);
    char* outputFileName = malloc(strlen(argv[2]) + 2);
    strcpy(outputFileName, argv[2] + "." + argv[3])
    // open input and output files
    FILE* inpFile = fopen(inputFileName, "r");
    FILE* outFile = fopen(outputFileName, "w");
    if (inpFile == NULL || outFile == NULL) {
        printf("Error: could not open file\n");
        return 1;
    }
    // read input from file
    fseek(inpFile, 0, SEEK_END);
    long lineSize = ftell(inpFile);
    char* buffer = malloc(lineSize + 1);
    if (buffer == NULL) {
        printf("Error: could not allocate memory\n");
        return 1;
    }
    fseek(inpFile, 0, SEEK_SET);
    while ((fgets(buffer, lineSize, inpFile)) != NULL) {
        // remove newline character from input string
        strcpy(buffer, strstr(buffer, "\n") + 1);
        // convert input string to integer array
        int* nums = malloc(sizeof(int) * (strlen(buffer) / 2));
        if (nums == NULL) {
            printf("Error: could not allocate memory\n");
            return 1;
        }
        char* end = buffer + strlen(buffer);
        for (int i = 0; i < strlen(end) / 2; i++) {
            nums[i] = atoi(&buffer[2 * i]);
        }
        // output integer array to console
        for (int i = 0; i < strlen(end) / 2; i++) {
            printf("%d ", nums[i]);
        }
        fputc('\n', outFile);
    }
    // close input and output files
    fclose(inpFile);
    fclose(outFile);
    return 0;
}