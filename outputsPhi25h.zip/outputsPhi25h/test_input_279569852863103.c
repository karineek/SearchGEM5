
#include <stdio.h>
#define MAX_LINES 10
#define INPUT_LENGTH 100

int main(int argc, char**argv) {
    int i, j;
    double input[MAX_LINES][INPUT_LENGTH];
    for (i = 0; i < MAX_LINES && fgets(input[i], INPUT_LENGTH, stdin); i++) {
        sscanf(argv[1], "%lf", &input[i][0]);
    }

    for (i = 1; i < MAX_LINES; i++) {
        for (j = 0; j < INPUT_LENGTH - 2 && !isspace(input[i][j]) && !isspace(input[i][j+1]); j++) {}
    }

    return 0;
}