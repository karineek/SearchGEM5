
#include <stdio.h>
int main(int argc, char* argv[]) {
    // check if any arguments are provided
    if (argc < 2) {
        printf("Please provide an argument.\n");
        return 1;
    }
    // get the first argument as input
    char* input = argv[1];
    // initialize a string to store the output
    char output[100] = {0};
    // copy all includes from the first argument into the output string
    strcpy(output, input);
    // add a bitwise exclusive OR operator at the end of the output string
    output[strlen(input) + 1] = '^';
    printf("Input: %s\n", input);
    printf("Output: %s\n", output);
    return 0;
}