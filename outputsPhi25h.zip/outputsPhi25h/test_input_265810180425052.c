
#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]) {
    // Get input from command line argument
    if (argc != 2) {
        printf("Error: Please provide only one argument\n");
        return 1;
    }

    char* input = argv[1];

    // Print out the input as a string using strcpy function
    char output[256] = {0};
    strcpy(output, input);
    printf("Input: %s\n", input);
    printf("Output: %s\n", output);

    return 0;
}