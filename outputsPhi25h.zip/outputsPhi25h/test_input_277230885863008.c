
# Get number of elements from command line argument
num_elements = int(sys.argv[1])

# Loop through each element
for i in range(1, num_elements + 1):
    # Take input from user and store it in a variable
    input_str = input("Enter number {}: ".format(i))

    # Convert string to integer and store it in a list
    num_list.append(int(input_str))

# Print the list of numbers
print(num_list)