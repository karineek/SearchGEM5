
#include <stdio.h>
#include <ctype.h>
#define MAXC 1024

int main(int argc, char **argv) {
    int i;
    if (argc != 2) {
        printf("Usage: %s INPUT\n", argv[0]);
        return 1;
    }
    char input[MAXC];
    fgets(input, MAXC, stdin);
    for (i = 0; i < strlen(input) && isspace(input[i]); ++i) {}
    if (strcmp(argv[1], 'exit') == 0) {
        return 0;
    }
    input[strcspn(input, "\r\n")] = 0; // remove CR/LF characters at end of line
    for (i = 0; input[i] != '\0'; i++) {
        if (!isalnum(input[i])) {
            fprintf(stderr, "Invalid character %c in input.\n", input[i]);
            return 1;
        }
        printf("%c", input[i]);
    }
    printf("\n");
    return 0;
}