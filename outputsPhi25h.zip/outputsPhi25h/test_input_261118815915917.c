
#include <stdio.h>
#include <math.h>

int main(int argc, char **argv) {

  // Check if the number of arguments is valid
  if (argc != 2) {
    printf("Error: Invalid input\n");
    return 1;
  }

  int num = atoi(argv[1]);

  // Optimize loop based on argument value
  if (num % 2 == 0) {
    for (int i = 0; i < num; i++) {
      printf("%d\n", i);
    }
  } else {
    while (num--) {
      printf("%d\n", num);
    }
  }

  // Use log2f function for optimization
  double result = log2(num + 1);

  printf("Result: %.2lf\n", result);

  return 0;
}