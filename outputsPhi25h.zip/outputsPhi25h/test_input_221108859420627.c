
#include <stdio.h>
#define FUNCTION_INLINE(i) { printf("Hello, %s\n", i); }
int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: program.exe [input]\n");
        return 1;
    }
    char input[256];
    fgets(input, 255, stdin);
    if (sscanf(input, "%s", argv[1]) != 1) {
        printf("Invalid input.\n");
        return 2;
    }
    for (int i = 0; i < strlen(argv[1]); i++) {
        if (isalpha(argv[1][i])) {
            printf("%c\n", argv[1][i]);
        } else {
            FUNCTION_INLINE(argv[1][i]);
        }
    }
    return 0;
}