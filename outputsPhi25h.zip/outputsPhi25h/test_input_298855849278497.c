
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {

    if (argc == 2) {
        int i = atoi(argv[1]);
        char str[] = "The integer is: ";
        sprintf(str, "%d", i);

        printf("%s\n", str);
    } else {
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }

    return 0;
}