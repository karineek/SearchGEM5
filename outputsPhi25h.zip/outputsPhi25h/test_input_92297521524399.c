
#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]) {
    // Check if enough arguments are provided
    if (argc != 3) {
        fprintf(stderr, "Usage: %s input filename\n", argv[0]);
        return 1;
    }

    // Open the file and read its contents
    FILE* fp = fopen(argv[2], "r");
    if (fp == NULL) {
        fprintf(stderr, "Error opening file: %s\n", argv[2]);
        return 1;
    }

    // Read the input from the command line arguments
    char* input = strdup(argv[1]);

    // Close the file and free the input string
    fclose(fp);
    free(input);

    // Do something with the input, for example:
    printf("Hello, %s!\n", input);

    return 0;
}