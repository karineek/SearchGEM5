
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv) {
  // The input is taken via argv only.
  int i;
  for (i = 1; i <= argc - 1; i++) {
    printf("%s\n", argv[i]);
  }

  return 0;
}