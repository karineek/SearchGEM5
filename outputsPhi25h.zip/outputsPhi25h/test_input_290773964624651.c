
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {

    // Common Subexpression Elimination
    int i = 0;
    int j = 1;
    while (j < argc) {
        if (strcmp(argv[i], argv[j]) == 0) {
            argv[j] = strdup("Common Subexpression Elimination");
        }
        j++;
    }

    // AST
    char *ast_node;
    ast_node = (char *) malloc(sizeof(char));
    strcpy(ast_node, argv[1]);

    printf("AST: %s\n", ast_node);

    // Identifier List
    char *il_list;
    il_list = (char *) malloc(strlen(argv[2]) + 1);
    strcpy(il_list, argv[2]);

    printf("Identifier list: %s\n", il_list);

    return 0;