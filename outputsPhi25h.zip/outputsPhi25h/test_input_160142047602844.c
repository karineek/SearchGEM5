
#include <stdio.h>
#define MAX_LENGTH 100
int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s input\n", argv[0]);
        return 1;
    }
    int length = strlen(argv[1]) + 1;
    char *str = (char *)malloc(length);
    if (!str) {
        printf("Memory allocation failed\n");
        return 2;
    }
    strncpy(str, argv[1], length);
    printf("%s\n", str);
    free(str);
    return 0;
}