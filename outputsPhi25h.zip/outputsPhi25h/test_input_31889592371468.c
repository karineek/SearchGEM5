
#include <stdio.h>

int main(void) {

    // Print the number of arguments provided
    printf("Number of arguments: %d\n", argc);

    return 0;
}