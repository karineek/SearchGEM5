
#include <stdio.h>
#include <stdlib.h>
#define MAX_INPUT 10

int main(int argc, char *argv[]) {
    int n = atoi(argv[1]); // convert the first argument to an integer
    for (int i = 2; i < argc && i <= MAX_INPUT; i++) {
        if (atoi(argv[i]) == -1) {
            break; // exit the loop if an invalid input is given
        }
        printf("Input %d: %s\n", i, argv[i]); // print the current input and its value
    }
    return 0;
}