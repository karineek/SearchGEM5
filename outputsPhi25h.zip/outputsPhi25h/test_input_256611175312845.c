
#include <stdio.h>

int main(int argc, char *argv[]) {
	// Read input from command line arguments
	if (argc != 2) {
		printf("Usage: %s <input_file>\n", argv[0]);
		return 1;
	}

    FILE* fp = fopen(argv[1], "r"); // open the input file for reading
    if (fp == NULL) {
		perror("Error opening file.");
		return 1;
    }

    // Read binary data from the input file and print it to stdout
    while (!feof(fp)) {
        fread(&data, sizeof(unsigned char), 1, fp);
        printf("%x\n", data);
    }

    // Close the input file
    fclose(fp);

    // Print a message to the console indicating that reading is complete
    printf("Reading from %s completed.\n", argv[1]);

    return 0;
}