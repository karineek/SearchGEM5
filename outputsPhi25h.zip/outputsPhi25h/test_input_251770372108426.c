
#include <stdio.h>
#include <stdlib.h>
int main(int argc, char *argv[]) {
    // convert string input to integer using lrint() function
    if (argc > 1) {
        int num = lrint(argv[1]);
        printf("The number is: %d\n", num);
    } else {
        printf("Usage: program <integer>\n");
    }
    return 0;
}