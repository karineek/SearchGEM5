
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "specialization_functions.h"
int main(int argc, char* argv[]) {
    // Parse command-line arguments
    if (argc != 2) {
        printf("Usage: %s <file>\n", argv[0]);
        return 1;
    }
    char* file_name = argv[1];
    // Read input from command-line arguments or a file
    FILE* fp = fopen(file_name, "r");
    if (!fp) {
        printf("Error: could not open %s for reading\n", file_name);
        return 1;
    }
    // Read input from the file and perform floating-point classification functions
    float x = 0.0;
    while (fscanf(fp, "%f", &x) == 1) {
        double y = specialization_functions(x);
        printf("Input: %f\n", x);
        printf("Output: %f\n", y);
    }
    // Close the file and return 0 if successful
    fclose(fp);
    return 0;