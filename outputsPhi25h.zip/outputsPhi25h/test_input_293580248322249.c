
#include <stdio.h>
#include <string.h>

int main(int argc, char** argv) {
    if (argc == 2) {
        char* string1 = argv[1];
        char* string2 = "This is a test";
        int length;

        length = strncmp(string1, string2, strlen(string2));
        if (length == 0) {
            printf("The strings are the same\n");
        } else {
            printf("The strings are different\n");
        }

        return 0;
    } else {
        printf("Invalid input. Please enter two strings to compare.\n");
        return 1;
    }
}