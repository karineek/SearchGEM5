
#include <stdio.h>

int main(int argc, char* argv[]) {

    int num; // Declare an integer variable 'num'

    if (argc == 2) { // Check if the number of arguments is equal to 2
        num = atoi(argv[1]); // Convert the second argument from string to integer
    } else {
        printf("Usage: %s <number>\n", argv[0]); // Print an error message if there is not enough arguments
        return 1; // Exit with a status code of 1 (error)
    }

    int sum = 0; // Declare a variable 'sum' and initialize it to 0

    while (num > 0) { // While the number is greater than 0
        sum += num % 10; // Add the last digit of the number to the sum
        num /= 10; // Remove the last digit from the number
    }

    printf("The sum of the digits in %d is %d.\n", argv[1], sum); // Print the output message with the original and final values of 'num' and 'sum'

    return 0; // Exit with a status code of 0 (success)
}