
#include <stdio.h>

int main(int argc, char *argv[]) {

    if (argc != 2) {
        printf("Error: Please provide an input argument.");
        return 1;
    }

    double num1 = strtof(argv[1], NULL);
    double num2 = strtof(argv[1], NULL);
    double quotient, remainder;

    quotient = num1 / num2;
    lldiv_t div = lddiv(&num1, &num2);
    // Allocating registers for the division.
    int a = div.quot;
    int b = (div.rem) * 10 + (div.quo >> 2);

    printf("The quotient is %f\n", quotient);
    printf("The remainder is %ld\n", remainder);
    printf("The quotient in binary is 0b%llx, and the remainder in binary is 0b%llx.\n", b, a);

    return EXIT_SUCCESS;
}