
#include <stdio.h>
int main(int argc, char *argv[]) {
    // Use strlen to get the size of the input string (which is the command line argument) in bytes
    int input_size = strlen(argv[1]);
    printf("Input string size: %d bytes\n", input_size);
    return 0;
}