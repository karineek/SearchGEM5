
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {
    // check if the number of arguments is correct
    if (argc != 2) {
        printf("Usage: %s filename\n", *argv[0]);
        return 1;
    }

    // open the file and read its contents
    FILE* f = fopen(argv[1], "r");
    if (f == NULL) {
        printf("Error: cannot open %s\n", argv[1]);
        return 2;
    }

    char line[256];
    while (fgets(line, sizeof line, f)) {
        // print the contents of the file
        printf("%s\n", line);
    }

    fclose(f);

    return 0;
}