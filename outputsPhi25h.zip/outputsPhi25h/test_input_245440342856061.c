
#include <stdio.h>
#include "asm.h"

int main(int argc, char** argv) {
    if (argc != 2) {
        printf("Usage: %s input_file\n", argv[0]);
        return 1;
    }

    // Load the program's header files using function specialization
    if (load_header(argv[1])) {
        printf("Header loaded successfully.\n");
    } else {
        printf("Error loading header.\n");
        return 1;
    }

    // Generate machine code using asm.h
    if (asm_generate(argv[1])) {
        printf("Machine code generated successfully.\n");
    } else {
        printf("Error generating machine code.\n");
        return 1;
    }

    // Include a static_assert statement for error checking
    static_assert(input == argv[2], "Invalid input. Please provide two command line arguments.");

    printf("Input: %s\n", argv[1]);
    return 0;
}