
#include <stdio.h>

int main(int argc, char** argv) {
    // Check if enough arguments are passed to the program
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <input file>\n", argv[0]);
        return 1;
    }

    // Open the input file in read mode
    FILE* infile = fopen(argv[1], "r");
    if (infile == NULL) {
        perror("Failed to open input file");
        return 1;
    }

    // Read the contents of the input file and print it to the console
    char buffer[BUFFER_SIZE];
    while (fread(buffer, sizeof(char), BUFFER_SIZE, infile) == BUFFER_SIZE) {
        fprintf(stdout, "%s\n", buffer);
    }

    // Close the input file
    fclose(infile);

    return 0;
}