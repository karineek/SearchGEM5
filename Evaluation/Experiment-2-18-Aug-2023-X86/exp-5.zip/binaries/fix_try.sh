echo 'TEST '
./00124.c.o 1
echo 'TEST '
./00164.c.o 1
echo 'TEST '
./00179.c.o 1
echo 'TEST '
./00180.c.o 1
echo 'TEST '
./20000113-1.c.o 1
echo 'TEST '
./20000217-1.c.o 1
echo 'TEST '
./20000227-1.c.o 1
echo 'TEST '
./20000313-1.c.o 1
echo 'TEST '
./20000412-1.c.o 1
echo 'TEST '
./20000412-4.c.o 1
echo 'TEST '
./20000412-5.c.o 1
echo 'TEST '
./20000412-6.c.o 1
echo 'TEST '
./20000419-1.c.o 1
echo 'TEST '
./20000422-1.c.o 1
echo 'TEST '
./20000511-1.c.o 1
echo 'TEST '
./20000519-1.c.o 1
echo 'TEST '
./20000523-1.c.o 1
echo 'TEST '
./20000528-1.c.o 1
echo 'TEST '
./20000622-1.c.o 1
echo 'TEST '
./20000706-2.c.o 1
echo 'TEST '
./20000706-3.c.o 1
echo 'TEST '
./20000706-4.c.o 1
echo 'TEST '
./20000706-5.c.o 1
echo 'TEST '
./20000715-2.c.o 1
echo 'TEST '
./20000717-1.c.o 1
echo 'TEST '
./20000717-2.c.o 1
echo 'TEST '
./20000717-3.c.o 1
echo 'TEST '
./20000717-5.c.o 1
echo 'TEST '
./20001009-2.c.o 1
echo 'TEST '
./20001017-2.c.o 1
echo 'TEST '
./20001024-1.c.o 1
echo 'TEST '
./20001027-1.c.o 1
echo 'TEST '
./20001108-1.c.o 1
echo 'TEST '
./20010118-1.c.o 1
echo 'TEST '
./20010518-1.c.o 1
echo 'TEST '
./20010520-1.c.o 1
echo 'TEST '
./20010605-2.c.o 1
echo 'TEST '
./20010711-1.c.o 1
echo 'TEST '
./20010925-1.c.o 1
echo 'TEST '
./20011109-1.c.o 1
echo 'TEST '
./20011114-1.c.o 1
echo 'TEST '
./20020107-1.c.o 1
echo 'TEST '
./20020213-1.c.o 1
echo 'TEST '
./20020219-1.c.o 1
echo 'TEST '
./20020225-2.c.o 1
echo 'TEST '
./20020314-1.c.o 1
echo 'TEST '
./20020320-1.c.o 1
echo 'TEST '
./20020503-1.c.o 1
echo 'TEST '
./20020506-1.c.o 1
echo 'TEST '
./20020508-2.c.o 1
echo 'TEST '
./20020614-1.c.o 1
echo 'TEST '
./20020619-1.c.o 1
echo 'TEST '
./20020716-1.c.o 1
echo 'TEST '
./20020805-1.c.o 1
echo 'TEST '
./20020904-1.c.o 1
echo 'TEST '
./20020916-1.c.o 1
echo 'TEST '
./20021010-2.c.o 1
echo 'TEST '
./20021119-1.c.o 1
echo 'TEST '
./20021127-1.c.o 1
echo 'TEST '
./20021204-1.c.o 1
echo 'TEST '
./2003-08-20-FoldBug.c.o 1
echo 'TEST '
./20030105-1.c.o 1
echo 'TEST '
./20030117-1.c.o 1
echo 'TEST '
./20030128-1.c.o 1
echo 'TEST '
./20030209-1.c.o 1
echo 'TEST '
./20030221-1.c.o 1
echo 'TEST '
./20030501-1.c.o 1
echo 'TEST '
./20030821-1.c.o 1
echo 'TEST '
./20030914-1.c.o 1
echo 'TEST '
./20031011-1.c.o 1
echo 'TEST '
./20031211-1.c.o 1
echo 'TEST '
./20031211-2.c.o 1
echo 'TEST '
./20031216-1.c.o 1
echo 'TEST '
./20040302-1.c.o 1
echo 'TEST '
./20040313-1.c.o 1
echo 'TEST '
./20040409-1w.c.o 1
echo 'TEST '
./20040409-2w.c.o 1
echo 'TEST '
./20040411-1.c.o 1
echo 'TEST '
./20040423-1.c.o 1
echo 'TEST '
./20040625-1.c.o 1
echo 'TEST '
./20040805-1.c.o 1
echo 'TEST '
./20041019-1.c.o 1
echo 'TEST '
./20041113-1.c.o 1
echo 'TEST '
./2005-07-17-INT-To-FP.c.o 1
echo 'TEST '
./20050107-1.c.o 1
echo 'TEST '
./20050119-2.c.o 1
echo 'TEST '
./20050124-1.c.o 1
echo 'TEST '
./20050613-1.c.o 1
echo 'TEST '
./20050826-1.c.o 1
echo 'TEST '
./20061031-1.c.o 1
echo 'TEST '
./20071011-1.c.o 1
echo 'TEST '
./20071030-1.c.o 1
echo 'TEST '
./20071205-1.c.o 1
echo 'TEST '
./20071211-1.c.o 1
echo 'TEST '
./20071220-1.c.o 1
echo 'TEST '
./20080117-1.c.o 1
echo 'TEST '
./20080408-1.c.o 1
echo 'TEST '
./20080529-1.c.o 1
echo 'TEST '
./20081112-1.c.o 1
echo 'TEST '
./20081117-1.c.o 1
echo 'TEST '
./20090814-1.c.o 1
echo 'TEST '
./20091229-1.c.o 1
echo 'TEST '
./20100805-1.c.o 1
echo 'TEST '
./20100827-1.c.o 1
echo 'TEST '
./20101011-1.c.o 1
echo 'TEST '
./20101013-1.c.o 1
echo 'TEST '
./20111227-1.c.o 1
echo 'TEST '
./20120919-1.c.o 1
echo 'TEST '
./20140622-1.c.o 1
echo 'TEST '
./20141125-1.c.o 1
echo 'TEST '
./20170401-2.c.o 1
echo 'TEST '
./20180131-1.c.o 1
echo 'TEST '
./900409-1.c.o 1
echo 'TEST '
./920612-1.c.o 1
echo 'TEST '
./920711-1.c.o 1
echo 'TEST '
./920721-1.c.o 1
echo 'TEST '
./920728-1.c.o 1
echo 'TEST '
./920730-1.c.o 1
echo 'TEST '
./921029-1.c.o 1
echo 'TEST '
./921218-1.c.o 1
echo 'TEST '
./930126-1.c.o 1
echo 'TEST '
./930603-1.c.o 1
echo 'TEST '
./930603-2.c.o 1
echo 'TEST '
./930603-3.c.o 1
echo 'TEST '
./930630-1.c.o 1
echo 'TEST '
./930718-1.c.o 1
echo 'TEST '
./930725-1.c.o 1
echo 'TEST '
./931004-1.c.o 1
echo 'TEST '
./931004-11.c.o 1
echo 'TEST '
./931004-5.c.o 1
echo 'TEST '
./931004-7.c.o 1
echo 'TEST '
./931004-9.c.o 1
echo 'TEST '
./931110-2.c.o 1
echo 'TEST '
./941015-1.c.o 1
echo 'TEST '
./941031-1.c.o 1
echo 'TEST '
./950426-1.c.o 1
echo 'TEST '
./950503-1.c.o 1
echo 'TEST '
./950511-1.c.o 1
echo 'TEST '
./950605-1.c.o 1
echo 'TEST '
./950607-2.c.o 1
echo 'TEST '
./950621-1.c.o 1
echo 'TEST '
./950714-1.c.o 1
echo 'TEST '
./951115-1.c.o 1
echo 'TEST '
./960215-1.c.o 1
echo 'TEST '
./960218-1.c.o 1
echo 'TEST '
./960321-1.c.o 1
echo 'TEST '
./960513-1.c.o 1
echo 'TEST '
./960608-1.c.o 1
echo 'TEST '
./960909-1.c.o 1
echo 'TEST '
./961122-1.c.o 1
echo 'TEST '
./961213-1.c.o 1
echo 'TEST '
./980424-1.c.o 1
echo 'TEST '
./980505-2.c.o 1
echo 'TEST '
./980526-3.c.o 1
echo 'TEST '
./980707-1.c.o 1
echo 'TEST '
./980929-1.c.o 1
echo 'TEST '
./981001-1.c.o 1
echo 'TEST '
./990106-1.c.o 1
echo 'TEST '
./990106-2.c.o 1
echo 'TEST '
./990324-1.c.o 1
echo 'TEST '
./990525-1.c.o 1
echo 'TEST '
./990811-1.c.o 1
echo 'TEST '
./990827-1.c.o 1
echo 'TEST '
./990923-1.c.o 1
echo 'TEST '
./991016-1.c.o 1
echo 'TEST '
./AtomicOps.c.o 1
echo 'TEST '
./StructModifyTest.c.o 1
echo 'TEST '
./align-3.c.o 1
echo 'TEST '
./bf-pack-1.c.o 1
echo 'TEST '
./bf-sign-2.c.o 1
echo 'TEST '
./bitfld-1.c.o 1
echo 'TEST '
./divcmp-2.c.o 1
echo 'TEST '
./divcmp-4.c.o 1
echo 'TEST '
./divconst-3.c.o 1
echo 'TEST '
./floatunsisf-1.c.o 1
echo 'TEST '
./loop-10.c.o 1
echo 'TEST '
./loop-12.c.o 1
echo 'TEST '
./loop-2c.c.o 1
echo 'TEST '
./loop-3.c.o 1
echo 'TEST '
./loop-3b.c.o 1
echo 'TEST '
./loop-5.c.o 1
echo 'TEST '
./loop-7.c.o 1
echo 'TEST '
./loop-ivopts-2.c.o 1
echo 'TEST '
./mayalias-1.c.o 1
echo 'TEST '
./memcpy-1.c.o 1
echo 'TEST '
./mod-1.c.o 1
echo 'TEST '
./ms_struct-bitfield-init.c.o 1
echo 'TEST '
./multdi-1.c.o 1
echo 'TEST '
./nest-stdar-1.c.o 1
echo 'TEST '
./nestfunc-3.c.o 1
echo 'TEST '
./pr20100-1.c.o 1
echo 'TEST '
./pr22061-3.c.o 1
echo 'TEST '
./pr22429.c.o 1
echo 'TEST '
./pr22493-1.c.o 1
echo 'TEST '
./pr23047.c.o 1
echo 'TEST '
./pr24141.c.o 1
echo 'TEST '
./pr25125.c.o 1
echo 'TEST '
./pr27260.c.o 1
echo 'TEST '
./pr27364.c.o 1
echo 'TEST '
./pr27671-1.c.o 1
echo 'TEST '
./pr28651.c.o 1
echo 'TEST '
./pr29156.c.o 1
echo 'TEST '
./pr29695-1.c.o 1
echo 'TEST '
./pr29797-2.c.o 1
echo 'TEST '
./pr31072.c.o 1
echo 'TEST '
./pr31136.c.o 1
echo 'TEST '
./pr31169.c.o 1
echo 'TEST '
./pr31605.c.o 1
echo 'TEST '
./pr33669.c.o 1
echo 'TEST '
./pr33779-1.c.o 1
echo 'TEST '
./pr33779-2.c.o 1
echo 'TEST '
./pr34070-1.c.o 1
echo 'TEST '
./pr34099-2.c.o 1
echo 'TEST '
./pr34099.c.o 1
echo 'TEST '
./pr34154.c.o 1
echo 'TEST '
./pr34982.c.o 1
echo 'TEST '
./pr35800.c.o 1
echo 'TEST '
./pr36038.c.o 1
echo 'TEST '
./pr37125.c.o 1
echo 'TEST '
./pr37931.c.o 1
echo 'TEST '
./pr38048-1.c.o 1
echo 'TEST '
./pr38422.c.o 1
echo 'TEST '
./pr39240.c.o 1
echo 'TEST '
./pr39501.c.o 1
echo 'TEST '
./pr41395-1.c.o 1
echo 'TEST '
./pr41463.c.o 1
echo 'TEST '
./pr42154.c.o 1
echo 'TEST '
./pr43783.c.o 1
echo 'TEST '
./pr44683.c.o 1
echo 'TEST '
./pr44852.c.o 1
echo 'TEST '
./pr44858.c.o 1
echo 'TEST '
./pr45262.c.o 1
echo 'TEST '
./pr46909-1.c.o 1
echo 'TEST '
./pr47299.c.o 1
echo 'TEST '
./pr48809.c.o 1
echo 'TEST '
./pr48814-2.c.o 1
echo 'TEST '
./pr48973-1.c.o 1
echo 'TEST '
./pr48973-2.c.o 1
echo 'TEST '
./pr49161.c.o 1
echo 'TEST '
./pr49186.c.o 1
echo 'TEST '
./pr49281.c.o 1
echo 'TEST '
./pr50865.c.o 1
echo 'TEST '
./pr51023.c.o 1
echo 'TEST '
./pr51466.c.o 1
echo 'TEST '
./pr52209.c.o 1
echo 'TEST '
./pr52286.c.o 1
echo 'TEST '
./pr54937.c.o 1
echo 'TEST '
./pr55137.c.o 1
echo 'TEST '
./pr56799.c.o 1
echo 'TEST '
./pr56837.c.o 1
echo 'TEST '
./pr56899.c.o 1
echo 'TEST '
./pr57124.c.o 1
echo 'TEST '
./pr57131.c.o 1
echo 'TEST '
./pr57344-1.c.o 1
echo 'TEST '
./pr57344-4.c.o 1
echo 'TEST '
./pr57861.c.o 1
echo 'TEST '
./pr57876.c.o 1
echo 'TEST '
./pr57877.c.o 1
echo 'TEST '
./pr58364.c.o 1
echo 'TEST '
./pr58387.c.o 1
echo 'TEST '
./pr58943.c.o 1
echo 'TEST '
./pr59358.c.o 1
echo 'TEST '
./pr59413.c.o 1
echo 'TEST '
./pr60960.c.o 1
echo 'TEST '
./pr61375.c.o 1
echo 'TEST '
./pr63843.c.o 1
echo 'TEST '
./pr65170.c.o 1
echo 'TEST '
./pr65215-2.c.o 1
echo 'TEST '
./pr66187.c.o 1
echo 'TEST '
./pr66940.c.o 1
echo 'TEST '
./pr67929_1.c.o 1
echo 'TEST '
./pr68143_1.c.o 1
echo 'TEST '
./pr68250.c.o 1
echo 'TEST '
./pr68532.c.o 1
echo 'TEST '
./pr68624.c.o 1
echo 'TEST '
./pr68648.c.o 1
echo 'TEST '
./pr69320-3.c.o 1
echo 'TEST '
./pr69320-4.c.o 1
echo 'TEST '
./pr70222-1.c.o 1
echo 'TEST '
./pr70429.c.o 1
echo 'TEST '
./pr70460.c.o 1
echo 'TEST '
./pr7284-1.c.o 1
echo 'TEST '
./pr77767.c.o 1
echo 'TEST '
./pr78378.c.o 1
echo 'TEST '
./pr78586.c.o 1
echo 'TEST '
./pr78622.c.o 1
echo 'TEST '
./pr79450.c.o 1
echo 'TEST '
./pr81555.c.o 1
echo 'TEST '
./pr81556.c.o 1
echo 'TEST '
./pr82954.c.o 1
echo 'TEST '
./pr83269.c.o 1
echo 'TEST '
./pr83298.c.o 1
echo 'TEST '
./pr83477.c.o 1
echo 'TEST '
./pr84169.c.o 1
echo 'TEST '
./pr85156.c.o 1
echo 'TEST '
./pr85169.c.o 1
echo 'TEST '
./pr85582-3.c.o 1
echo 'TEST '
./pr86231.c.o 1
echo 'TEST '
./pr86844.c.o 1
echo 'TEST '
./pr87053.c.o 1
echo 'TEST '
./pr89826.c.o 1
echo 'TEST '
./printf-1.c.o 1
echo 'TEST '
./restrict-1.c.o 1
echo 'TEST '
./simd-1.c.o 1
echo 'TEST '
./simd-2.c.o 1
echo 'TEST '
./simd-6.c.o 1
echo 'TEST '
./string-opt-18.c.o 1
echo 'TEST '
./struct-aliasing-1.c.o 1
echo 'TEST '
./struct-ini-3.c.o 1
echo 'TEST '
./switch-1.c.o 1
echo 'TEST '
./usmul.c.o 1
echo 'TEST '
./va-arg-14.c.o 1
echo 'TEST '
./va-arg-20.c.o 1
echo 'TEST '
./va-arg-23.c.o 1
echo 'TEST '
./vrp-5.c.o 1
echo 'TEST '
./vrp-6.c.o 1
echo 'TEST '
./vrp-7.c.o 1
echo 'TEST '
./widechar-2.c.o 1
echo 'TEST '
./zero-struct-2.c.o 1
echo 'TEST '
