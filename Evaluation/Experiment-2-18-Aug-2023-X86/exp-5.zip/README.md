mkdir /home/ubuntu/experiment-5/
cp exp-5.zip /home/ubuntu/experiment-5/
cd /home/ubuntu/experiment-5/
unzip exp-5.zip
