// Modification timestamp: 2023-08-04 14:10:12
// Original Source: https://github.com/c-testsuite/c-testsuite/blob/master/tests/single-exec/00097.c

int main(int argc, char *argv[]) {
    return 0;
}
