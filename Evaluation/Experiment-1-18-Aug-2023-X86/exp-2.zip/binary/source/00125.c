// Modification timestamp: 2023-08-04 14:14:26
// Original Source: https://github.com/c-testsuite/c-testsuite/blob/master/tests/single-exec/00125.c

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    printf("hello world\n");
    return 0;
}
