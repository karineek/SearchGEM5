// Modification timestamp: 2023-08-04 13:52:08
// Original Source: https://github.com/c-testsuite/c-testsuite/blob/master/tests/single-exec/00060.c
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    /*
        multiline
        comment
    */
    return 0;
}
