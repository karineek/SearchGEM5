
// Modification timestamp: 2023-08-04 15:07:17
// Original Source: https://github.com/c-testsuite/c-testsuite/blob/master/tests/single-exec/00001.c

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    return 0;
}
