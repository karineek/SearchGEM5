// Modification timestamp: 2023-08-04 14:20:04
// Original Source: https://github.com/c-testsuite/c-testsuite/blob/master/tests/single-exec/00128.c

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int a;
    unsigned b;
    char c;
    signed char d;
    unsigned char e;
    long f;
    unsigned long g;
    long long h;
    unsigned long long i;
    short j;
    unsigned short k;

    if (argc != 2) {
        printf("Usage: %s <value>\n", argv[0]);
        return 1;
    }

    a = atoi(argv[1]);

    a = b;
    a = c;
    a = d;
    a = e;
    a = f;
    a = g;
    a = h;
    a = i;
    a = j;
    a = k;

    b = a;
    b = c;
    b = d;
    b = e;
    b = f;
    b = g;
    b = h;
    b = i;
    b = j;
    b = k;

    c = a;
    c = b;
    c = d;
    c = e;
    c = f;
    c = g;
    c = h;
    c = i;
    c = j;
    c = k;

    d = a;
    d = b;
    d = c;
    d = e;
    d = f;
    d = g;
    d = h;
    d = i;
    d = j;
    d = k;

    e = a;
    e = b;
    e = c;
    e = d;
    e = f;
    e = g;
    e = h;
    e = i;
    e = j;
    e = k;

    f = a;
    f = b;
    f = c;
    f = d;
    f = e;
    f = g;
    f = h;
    f = i;
    f = j;
    f = k;

    g = a;
    g = b;
    g = c;
    g = d;
    g = e;
    g = f;
    g = h;
    g = i;
    g = j;
    g = k;

    h = a;
    h = b;
    h = c;
    h = d;
    h = e;
    h = f;
    h = g;
    h = i;
    h = j;
    h = k;

    i = a;
    i = b;
    i = c;
    i = d;
    i = e;
    i = f;
    i = g;
    i = h;
    i = j;
    i = k;

    j = a;
    j = b;
    j = c;
    j = d;
    j = e;
    j = f;
    j = g;
    j = h;
    j = i;
    j = k;

    k = a;
    k = b;
    k = c;
    k = d;
    k = e;
    k = f;
    k = g;
    k = h;
    k = j;
    k = i;

    return 0;
}
