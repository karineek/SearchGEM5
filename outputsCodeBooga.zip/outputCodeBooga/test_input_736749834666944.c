
#include <stdio.h>
#include <stdlib.h>
#include <stdatomic.h>
#include <omp.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program <integer1> <integer2>\n");
        return -1;
    }
    
    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);
    
    atomic_uint sum;
    atomic_init(&sum, 0);
    
    #pragma omp parallel for reduction(+:num1) // Loop fusion optimization using OpenMP
    for (int i = 0; i < num1 * num2; ++i) {
        atomic_fetch_add(&sum, 1);
    }
    
    printf("The sum is %u\n", sum);
    return 0;
}