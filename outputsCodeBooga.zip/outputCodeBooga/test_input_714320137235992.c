
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int x;
    int y;
} Point;

int main(int argc, char* argv[]){
    if(argc != 3){
        printf("Usage: %s <x-coordinate> <y-coordinate>\n", argv[0]);
        return 1;
    }

    int x = atoi(argv[1]);
    int y = atoi(argv[2]);

    Point p;
    p.x = x;
    p.y = y;

    printf("Point(%d, %d)\n", p.x, p.y);
    
    return 0;
}