
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int *num1;
    int *num2;
    
    if (argc != 3) {
        printf("Usage: %s num1 num2\n", argv[0]);
        return 1;
    }

    num1 = malloc(sizeof(int));
    num2 = malloc(sizeof(int));

    *num1 = atoi(argv[1]);
    *num2 = atoi(argv[2]);

    printf("Sum: %d\n", *num1 + *num2);
    
    free(num1);
    free(num2);
    return 0;
}