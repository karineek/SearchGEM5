
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input_string>\n", argv[0]);
        return -1;
    }

    const char* input = argv[1];
    int length = strlen(input);

    for (int i = 0; i < length; ++i) {
        printf("Character %d: %c\n", i, input[i]);
    }
    
    return 0;
}