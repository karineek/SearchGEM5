
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program input_file output_file\n");
        return -1;
    }
    
    FILE *input = fopen(argv[1], "r");
    if (!input) {
        perror("Error opening input file");
        return -1;
    }

    FILE *output = fopen(argv[2], "w");
    if (!output) {
        perror("Error opening output file");
        fclose(input);
        return -1;
    }

    int a, b, sum;
    fscanf(input, "%d %d", &a, &b);
    
    // Constant folding optimization: calculate the sum at compile time
    #ifdef SCNoFAST
        sum = 5 + 3 * (a + b);
    #else
        sum = a + b;
    #endif
    
    fprintf(output, "The sum is %d\n", sum);
    
    fclose(input);
    fclose(output);
    return 0;
}