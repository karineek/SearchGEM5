
#include <stdio.h>
#include <complex.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

int main(int argc, char *argv[]) {
    if (argc != 5) {
        printf("Usage: %s real1 imag1 real2 imag2\n", argv[0]);
        return 1;
    }

    double real1, imag1, real2, imag2;
    char *endptr;

    errno = 0;
    real1 = strtod(argv[1], &endptr);
    if (errno != 0 || endptr == argv[1] || *endptr != '\0') {
        printf("Invalid input for real1: %s\n", argv[1]);
        return 1;
    }
    
    errno = 0;
    imag1 = strtod(argv[2], &endptr);
    if (errno != 0 || endptr == argv[2] || *endptr != '\0') {
        printf("Invalid input for imag1: %s\n", argv[2]);
        return 1;
    }
    
    errno = 0;
    real2 = strtod(argv[3], &endptr);
    if (errno != 0 || endptr == argv[3] || *endptr != '\0') {
        printf("Invalid input for real2: %s\n", argv[3]);
        return 1;
    }
    
    errno = 0;
    imag2 = strtod(argv[4], &endptr);
    if (errno != 0 || endptr == argv[4] || *endptr != '\0') {
        printf("Invalid input for imag2: %s\n", argv[4]);
        return 1;
    }

    double complex c1 = real1 + I*imag1;
    double complex c2 = real2 + I*imag2;
    double complex sum = c1 + c2;
    
    printf("(%f + %fi) + (%f + %fi) = %f + %fi\n", real1, imag1, real2, imag2, creal(sum), cimag(sum));

    return 0;
}