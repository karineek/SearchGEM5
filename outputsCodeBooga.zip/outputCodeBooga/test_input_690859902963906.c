
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>

void abort_handler_s(int sig) {
    printf("Error: signal %d\n", sig);
    exit(1);
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input>\n", argv[0]);
        return 1;
    }

    // Register abort_handler_s as the SIGABRT signal handler
    signal(SIGABRT, abort_handler_s);
    
    char *input = argv[1];

    if (strlen(input) == 0) {
        raise(SIGABRT); // Trigger abort_handler_s on empty input
    } else {
        printf("Input: %s\n", input);
    }
    
    return 0;
}