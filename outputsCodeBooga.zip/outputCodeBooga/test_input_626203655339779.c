
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./program <input_string>\n");
        return 1;
    }

    // Allocate memory for the input string and copy it to avoid modifying the original argv pointer
    char *input = malloc(strlen(argv[1]) + 1);
    strcpy(input, argv[1]);

    // Perform some operations on the input string (e.g., convert to uppercase)
    for (int i = 0; i < strlen(input); i++) {
        input[i] = toupper((unsigned char) input[i]);
    }

    printf("Original input: %s\n", argv[1]);
    printf("Modified input: %s\n", input);

    // Free allocated memory to avoid memory leaks
    free(input);

    return 0;
}