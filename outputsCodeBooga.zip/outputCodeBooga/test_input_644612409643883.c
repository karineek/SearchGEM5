
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[]) {
    // Check if the input is valid
    if (argc != 3) {
        printf("Usage: %s start_num end_num\n", argv[0]);
        return 1;
    }

    int start = atoi(argv[1]);
    int end = atoi(argv[2]);

    if (start > end) {
        printf("Start number should be less than or equal to the end number.\n");
        return 1;
    }

    // Calculate the sum of all even numbers in the given range
    int sum = 0;
    clock_t start_time = clock();
    for (int i = start; i <= end; ++i) {
        if (i % 2 == 0) {
            sum += i;
        }
    }
    clock_t end_time = clock();

    double time_taken = ((double)(end_time - start_time)) / CLOCKS_PER_SEC;
    printf("Sum of even numbers from %d to %d: %d\n", start, end, sum);
    printf("Time taken: %.2f seconds\n", time_taken);

    return 0;
}