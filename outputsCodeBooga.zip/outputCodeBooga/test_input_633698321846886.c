
#include <stdio.h>
#include <float.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s number\n", argv[0]);
        return 1;
    }
    
    double x = atof(argv[1]);
    int exponent = FLT_MAX_EXP + 1; // Exponent of the maximum float value
    double max_value = pow(2, exponent) - 1; // Maximum float value
    
    if (x > max_value) {
        printf("The input number %lf is too large.\n", x);
    } else {
        printf("The input number %lf is within the range of float values.\n", x);
    }
    
    return 0;
}