
#include <stdio.h>
#include <math.h>

float parse_arg(const char *str) {
    return strtof(str, NULL);
}

int main(int argc, char **argv) {
    if (argc != 3) {
        printf("Usage: %s <number1> <number2>\n", argv[0]);
        return 1;
    }

    float num1 = parse_arg(argv[1]);
    float num2 = parse_arg(argv[2]);
    
    float result = copysign(num1, num2);

    printf("copysign(%f, %f) = %f\n", num1, num2, result);
    return 0;
}