
#include <stdio.h> // for fopen, fputc, fclose
#include <stdlib.h> // for atoi, EXIT_FAILURE

int main(int argc, char* argv[]) {
    if (argc != 3) {
        printf("Usage: %s input output\n", argv[0]);
        return EXIT_FAILURE;
    }

    FILE *input = fopen(argv[1], "r");
    if (!input) {
        perror("fopen input");
        return EXIT_FAILURE;
    }

    FILE *output = fopen(argv[2], "w");
    if (!output) {
        perror("fopen output");
        fclose(input);
        return EXIT_FAILURE;
    }

    int c;
    while ((c = fgetc(input)) != EOF) {
        fputc(c, output);
    }

    fclose(output);
    fclose(input);
    return 0;
}