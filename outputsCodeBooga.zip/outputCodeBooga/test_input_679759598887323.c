
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }

    int n = atoi(argv[1]);
    int sum_odd = 0, sum_even = 0;
    
    for (int i = 1; i <= n; i++) {
        if (i % 2 != 0) {
            sum_odd += i;
        } else {
            sum_even += i;
        }
    }

    printf("Sum of odd numbers: %d\n", sum_odd);
    printf("Sum of even numbers: %d\n", sum_even);

    return 0;
}