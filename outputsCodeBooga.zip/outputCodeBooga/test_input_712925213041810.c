
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <immintrin.h> // include header for AVX intrinsics

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <vector size> <scalar>\n", argv[0]);
        return -1;
    }

    int n = atoi(argv[1]); // get vector size from command line argument
    float scalar = (float)atof(argv[2]); // get scalar value from command line argument

    if (n % 8 != 0) {
        printf("Error: Vector size must be a multiple of 8 for AVX!\n");
        return -1;
    }

    float *a = (float*)_mm_malloc(n*sizeof(float), 32); // allocate aligned memory for vector a
    float *b = (float*)_mm_malloc(n*sizeof(float), 32); // allocate aligned memory for vector b
    float *c = (float*)_mm_malloc(n*sizeof(float), 32); // allocate aligned memory for result vector c

    // initialize vectors a and b with some values
    for (int i = 0; i < n; i++) {
        a[i] = i + 1.0f;
        b[i] = i * 2.0f;
    }

    // perform vector addition using AVX intrinsics
    __m256 avx_scalar = _mm256_set1_ps(scalar); // broadcast scalar value to all elements of a AVX register
    for (int i = 0; i < n; i += 8) {
        __m256 avx_a = _mm256_load_ps(&a[i]); // load 8 float values from a into an AVX register
        __m256 avx_b = _mm256_load_ps(&b[i]); // load 8 float values from b into an AVX register
        __m256 avx_c = _mm256_add_ps(avx_a, avx_b); // perform element-wise addition of a and b
        avx_c = _mm256_mul_ps(avx_c, avx_scalar); // multiply each element in c by the scalar value
        _mm256_store_ps(&c[i], avx_c); // store result back into memory
    }

    // print results
    printf("Vector a: ");
    for (int i = 0; i < n; i++) {
        printf("%f ", a[i]);
    }
    printf("\n");

    printf("Vector b: ");
    for (int i = 0; i < n; i++) {
        printf("%f ", b[i]);
    }
    printf("\n");

    printf("Result vector c: ");
    for (int i = 0; i < n; i++) {
        printf("%f ", c[i]);
    }
    printf("\n");

    // demonstrate the use of name function from string.h library
    char str[] = "Automatic Vectorization and General LLVM analysis passes";
    printf("String length: %zu\n", strlen(str)); // get length of string using strlen from <string.h>
    printf("Name: %s\n", name(str)); // pass string to a function that returns the same string, just for demonstration purposes

    _mm_free(a);
    _mm_free(b);
    _mm_free(c);

    return 0;
}