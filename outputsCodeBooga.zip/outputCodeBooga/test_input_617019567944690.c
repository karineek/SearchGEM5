
#include <stdio.h>
#include <stdlib.h>

int power(int base, int exp) {
    if (exp == 0) {
        return 1;
    } else {
        return base * power(base, exp - 1);
    }
}

int main(int argc, char *argv[]) {
    // Check if the input arguments are valid
    if (argc != 3) {
        printf("Usage: ./power_recursion <base> <exponent>\n");
        return -1;
    }

    int base = atoi(argv[1]);
    int exp = atoi(argv[2]);

    if (exp < 0) {
        printf("Exponent must be non-negative\n");
        return -1;
    }

    // Calculate the power using recursion
    int result = power(base, exp);
    printf("%d^%d = %d\n", base, exp, result);

    return 0;
}