
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int a = atoi(argv[1]); // Convert argument to integer
    int b = atoi(argv[2]); // Convert argument to integer

    printf("Before: a=%d, b=%d\n", a, b);
    
    b -= a; // Subtraction assignment operator (-=)

    printf("After: a=%d, b=%d\n", a, b);

    return 0;
}