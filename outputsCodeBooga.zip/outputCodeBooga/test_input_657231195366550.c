
#include <stdio.h>
#include <stdlib.h>

// Function prototypes for specialized functions
int square_even(int num);
int square_odd(int num);

// Generic function to calculate the square of a number
int square(int num) {
    printf("\rCalculating square of %d...", num); // Use \r to overwrite the previous output
    return num * num;
}

// Specialized functions for even and odd numbers
int square_even(int num) {
    return num * (num - 2);
}
int square_odd(int num) {
    return num * (num - 1);
}

int main(int argc, char* argv[]) {
    if (argc != 2) { // Check for correct number of arguments
        printf("Usage: %s <integer>", argv[0]);
        return 1;
    }

    int num = atoi(argv[1]); // Convert input to integer
    int result;

    if (num % 2 == 0) { // Check if number is even or odd
        result = square_even(num);
    } else {
        result = square_odd(num);
    }

    printf("\rThe square of %d is %d.\n", num, result); // Use \r to overwrite the previous output
    return 0;
}