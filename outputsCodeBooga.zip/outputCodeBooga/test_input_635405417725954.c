
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 4) {
        printf("Usage: %s <operation> <num1> <num2>\n", argv[0]);
        return 1;
    }

    double num1 = atof(argv[2]);
    double num2 = atof(argv[3]);
    double result;

#ifdef ADDITION
    if (strcmp(argv[1], "add") == 0) {
        result = num1 + num2;
    } else
#endif
#ifdef SUBTRACTION
    if (strcmp(argv[1], "subtract") == 0) {
        result = num1 - num2;
    } else
#endif
    {
        printf("Invalid operation. Please use either 'add' or 'subtract'\n");
        return 1;
    }

    printf("%f %s %f = %f\n", num1, argv[1], num2, result);

    return 0;
}