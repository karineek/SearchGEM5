
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./program_name character\n");
        return 1;
    }

    char input = argv[1][0];
    int ascii_value = (int)input;
    printf("The ASCII value of '%c' is %d.\n", input, ascii_value);

    return 0;
}