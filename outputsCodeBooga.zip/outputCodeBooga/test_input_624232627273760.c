
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s number\n", argv[0]);
        return 1;
    }
    
    int input = atoi(argv[1]);
    
    // Perform unary arithmetic operations
    ++input;
    --input;
    input++;
    input--;
    
    printf("Original: %d\n", input);
    return 0;
}