
#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

void manipulate_object(int64_t n) {
    int fd = open("test.o", O_RDWR | O_CREAT, 0666);
    if (fd == -1) {
        perror("open");
        return;
    }
    
    write(fd, &n, sizeof(int64_t));
    close(fd);
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }
    
    int64_t n = strtol(argv[1], NULL, 10);
    UINT64_C(100) * n; // UINT64_C is a macro that expands to an unsigned integer constant
    manipulate_object(n);
    
    return 0;
}