
#include <stdio.h>
#include <float.h>

int main(int argc, char *argv[]) {
    double a = 1234567890.123456789;
    double b = 987654321.987654321;
    
    if (__builtin_expect(argc < 2, 0)) {
        printf("Usage: %s number\n", argv[0]);
        return -1;
    }
    
    double input = atof(argv[1]);
    
    printf("DBL_DIG is defined as: %d\n", DBL_DIG);
    printf("Input number: %.f\n", input);
    printf("a + b = %.f\n", a + b);
    
    return 0;
}