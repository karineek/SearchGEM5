
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s string\n", argv[0]);
        return 1;
    }
    
    char *str = argv[1];
    int len = strlen(str);
    
    for (int i = 0; i < len; i += 8) {
        // Loop vectorization and handles code generation using horizontal-tab character
        #pragma GCC ivdep
        for (int j = 0; j < 8 && i + j < len; ++j) {
            printf("%c\t", str[i+j]);
        }
        printf("\n");
    }
    
    return 0;
}