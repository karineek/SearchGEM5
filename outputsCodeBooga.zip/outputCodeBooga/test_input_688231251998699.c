
#include <stdio.h>
#include <stdlib.h>
#include <float.h>

#define MAX(x, y) (((x) > (y)) ? (x) : (y))
#define MIN(x, y) (((x) < (y)) ? (x) : (y))

typedef enum {
    SMALLER_TYPE,
    COMMON_TYPE
} TypeChoice;

double common_real_type(TypeChoice choice, double x, double y);
float specialize_for_float(TypeChoice choice, float x, float y);
long double specialize_for_long_double(TypeChoice choice, long double x, long double y);

int main(int argc, char *argv[]) {
    if (argc != 4) {
        printf("Usage: %s <choice> <x> <y>\n", argv[0]);
        return -1;
    }

    TypeChoice choice = atoi(argv[1]) == SMALLER_TYPE ? SMALLER_TYPE : COMMON_TYPE;
    double x = atof(argv[2]), y = atof(argv[3]);

    if (x > FLT_MAX || y > FLT_MAX) {
        printf("Specializing for long double...\n");
        long double result = specialize_for_long_double(choice, x, y);
        printf("%Lf\n", result);
    } else if (x > DBL_MAX || y > DBL_MAX) {
        printf("Specializing for float...\n");
        float result = specialize_for_float(choice, x, y);
        printf("%f\n", result);
    } else {
        printf("Using default type...\n");
        double result = common_real_type(choice, x, y);
        printf("%lf\n", result);
    }

    return 0;
}

double common_real_type(TypeChoice choice, double x, double y) {
    switch (choice) {
        case SMALLER_TYPE:
            return MIN(x, y);
        case COMMON_TYPE:
            return MAX(x, y);
    }
}

float specialize_for_float(TypeChoice choice, float x, float y) {
    switch (choice) {
        case SMALLER_TYPE:
            return MIN(x, y);
        case COMMON_TYPE:
            return MAX(x, y);
    }
}

long double specialize_for_long_double(TypeChoice choice, long double x, long double y) {
    switch (choice) {
        case SMALLER_TYPE:
            return MIN(x, y);
        case COMMON_TYPE:
            return MAX(x, y);
    }
}