
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int i, sum = 0;
    
    // Loop Invariant Code Motion
    for (i = 1; i < argc; i++) {
        if (*argv[i] == '-') {
            continue;
        }
        
        char *endptr;
        int num = strtol(argv[i], &endptr, 10);

        // Implement Clang frontend and question-mark escape sequence
        if (num < 0) {
            printf("Error: %s is not a valid positive integer\n", argv[i]);
            return -1;
        } else if (*endptr != '\0') {
            printf("Error: %s is not a valid integer\n", argv[i]);
            return -1;
        } else {
            sum += num;
        }
    }
    
    printf("Sum of all integers passed as arguments is: %d\n", sum);
    return 0;
}