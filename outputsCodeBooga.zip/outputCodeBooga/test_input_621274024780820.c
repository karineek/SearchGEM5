
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <immintrin.h> // For AVX2 intrinsics

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input_string>\n", argv[0]);
        return 1;
    }

    const char *input = argv[1];
    int len = strlen(input);
    int i;

    // Ensure the length is divisible by 8 for AVX2 vectorization
    if (len % 8 != 0) {
        printf("Error: input length must be divisible by 8\n");
        return 1;
    }

    __m256i vmask_lowercase = _mm256_setr_epi8(
         'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r',
         's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 0,  0,  0,  0,  0,  0,  0,  0,  0,  0
    );
    __m256i vmask_uppercase = _mm256_setr_epi8(
         'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
         'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 0,  0,  0,  0,  0,  0,  0,  0,  0,  0
    );
    __m256i vzero = _mm256_set1_epi8(0);

    for (i = 0; i < len; i += 32) {
        // Load 32 characters into an AVX2 register
        __m256i vinput = _mm256_loadu_si256((__m256i *)(input + i));

        // Use the ANDNOT operation to filter out non-alphabetic characters
        __m256i vfiltered_lowercase = _mm256_andnot_si256(_mm256_cmpeq_epi8(vinput, vmask_uppercase), vinput);
        __m256i vfiltered_uppercase = _mm256_andnot_si256(_mm256_cmpeq_epi8(vinput, vmask_lowercase), vinput);

        // Check if any lowercase characters are present
        __m256i vcheck_lowercase = _mm256_cmpgt_epi8(vfiltered_lowercase, vzero);
        if (_mm256_movemask_epi8(vcheck_lowercase)) {
            printf("Lowercase characters found!\n");
            break;
        }

        // Check if any uppercase characters are present
        __m256i vcheck_uppercase = _mm256_cmpgt_epi8(vfiltered_uppercase, vzero);
        if (_mm256_movemask_epi8(vcheck_uppercase)) {
            printf("Uppercase characters found!\n");
            break;
        }
    }

    return 0;
}