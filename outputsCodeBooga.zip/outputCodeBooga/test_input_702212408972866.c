
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program dividend divisor\n");
        return 1;
    }

    int dividend = atoi(argv[1]);
    int divisor = atoi(argv[2]);

    if (divisor == 0) {
        printf("Division by zero is not allowed.\n");
        return 1;
    }

    // Constant Folding: calculate the result during compile time
    int quotient = dividend / divisor;
    int remainder = dividend % divisor;

    if (remainder != 0 && ((dividend < 0) ^ (divisor < 0)) ^ (remainder < 0)) {
        // FE_TOWARDZERO: round the result towards zero
        quotient -= 1;
    }

    printf("The integer division of %d and %d is %d with a remainder of %d.\n", dividend, divisor, quotient, remainder);

    return 0;
}