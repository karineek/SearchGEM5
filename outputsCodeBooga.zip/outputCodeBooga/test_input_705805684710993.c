
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// Function to square a number
float square(float x) {
    return x * x;
}

// Specialized function to square an integer
float square_int(int x) {
    return x * x;
}

int main(int argc, char **argv) {
    // Check if there is only one argument provided
    if (argc != 2) {
        printf("Usage: ./program <number>\n");
        return 1;
    }

    float num = strtof(argv[1], NULL);

    // Check if the number is an integer
    if (ceilf(num) == floorf(num)) {
        int x = (int)num;
        printf("The square of %d (as integer) is: %d\n", x, square_int(x));
    } else {
        // If the number is a float or double, call the regular square function
        printf("The square of %.2f is: %.2f\n", num, square(num));
    }

    return 0;
}