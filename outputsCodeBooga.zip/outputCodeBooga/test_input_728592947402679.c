
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Please provide exactly one argument.\n");
        return 1;
    }
    
    int n = atoi(argv[1]);
    if (n <= 0) {
        printf("Argument should be a positive integer.\n");
        return 1;
    }

    long long sum_of_squares = 0;
    for (int i = 1; i <= n; i++) {
        int square = i * i;
        sum_of_squares += square;
    }
    
    printf("Sum of squares of first %d natural numbers is: %lld\n", n, sum_of_squares);
    return 0;
}