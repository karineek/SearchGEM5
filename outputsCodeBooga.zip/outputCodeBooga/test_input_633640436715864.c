
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <locale.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s string\n", argv[0]);
        return 1;
    }
    
    setlocale(LC_ALL, ""); // Set the locale according to the user's environment
    
    const char *input = argv[1];
    mbstate_t state;
    memset(&state, 0, sizeof(mbstate_t)); // Initialize the state object
    
    size_t len = strlen(input);
    wchar_t *wstr = malloc((len + 1) * MB_LEN_MAX * sizeof(wchar_t)); // Allocate memory for the wide string
    if (!wstr) {
        perror("malloc");
        return 1;
    }
    
    size_t wlen = mbsrtowcs(wstr, &input, len + 1, &state); // Convert input to wide string
    if (wlen == (size_t)-1) {
        perror("mbsrtowcs");
        return 1;
    }
    
    printf("Wide string: ");
    for (size_t i = 0; i < wlen; ++i) {
        putwchar(wstr[i]);
    }
    putwchar('\n');
    
    free(wstr); // Free the allocated memory
    return 0;
}