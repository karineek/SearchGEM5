
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <wctype.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <character-set> <input-string>\n", argv[0]);
        return EXIT_FAILURE;
    }

    const wchar_t *wstr = L"";
    mbstowcs((wchar_t *)&wstr, argv[2], strlen(argv[2]) + 1);
    wctype_t charset = wctype(argv[1]);

    for (const wchar_t *p = wstr; *p != L'\0'; p++) {
        if (iswctype(*p, charset)) {
            printf("%lc is in the %s character set.\n", *p, argv[1]);
        } else {
            printf("%lc is not in the %s character set.\n", *p, argv[1]);
        }
    }

    return EXIT_SUCCESS;
}