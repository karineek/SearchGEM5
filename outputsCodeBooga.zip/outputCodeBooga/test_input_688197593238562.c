
#include <stdio.h>
#include <stdlib.h>
#include <stdnoreturn.h>
#include <string.h>
#include <errno.h>

// _Noreturn function example
void error(const char *msg) {
    perror(msg);
    exit(1);
}

int main(int argc, char *argv[]) {
    // Check if there is at least one argument
    if (argc < 2) {
        fprintf(stderr, "Usage: %s input_file\n", argv[0]);
        return 1;
    }

    FILE *input = fopen(argv[1], "r");
    if (!input) {
        error("fopen");
    }

    // Read file contents into a buffer
    char *buffer = NULL;
    size_t bufsize = 0;
    while (getline(&buffer, &bufsize, input) != -1);

    fclose(input);

    if (ferror(input)) {
        error("getline");
    }

    // Print the file contents and free the buffer
    printf("%s", buffer);
    free(buffer);

    return 0;
}