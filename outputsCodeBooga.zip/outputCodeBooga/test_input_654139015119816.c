
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s num\n", argv[0]);
        return 1;
    }

    int input = atoi(argv[1]);
    int square = input * input;
    
#ifdef _MIN
    if (square < 10) {
        printf("Small square: %d\n", square);
    } else {
        printf("Large square: %d\n", square);
    }
#else
    printf("Square: %d\n", square);
#endif
    
    return 0;
}