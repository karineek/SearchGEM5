
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int isunordered(double x, double y) {
    return (x != x || y != y);
}

void swap(double *a, double *b) {
    double temp = *a;
    *a = *b;
    *b = temp;
}

int partition(double arr[], int low, int high) {
    double pivot = arr[high];  
    int i = (low - 1); 

    for (int j = low; j <= high - 1; j++) {
        if (isunordered(arr[j], pivot)) {
            swap(&arr[++i], &arr[j]);
        }
    }
    swap(&arr[i + 1], &arr[high]);
    return (i + 1);
}

void quickSort(double arr[], int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input_numbers>\n", argv[0]);
        return -1;
    }
    
    int n = strlen(argv[1]);
    double arr[n];

    for (int i = 0; i < n; i++) {
        if (sscanf(&argv[1][i], "%lf", &arr[i]) != 1) {
            printf("Invalid input.\n");
            return -1;
        }
    }

    quickSort(arr, 0, n - 1);

    for (int i = 0; i < n; i++) {
        printf("%lf ", arr[i]);
    }
    
    printf("\n");
    return 0;
}