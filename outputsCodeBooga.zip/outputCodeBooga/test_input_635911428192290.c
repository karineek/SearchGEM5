
#include <stdio.h>
#include <stdlib.h>
#include <immintrin.h> // for SIMD (vectorization) operations

// Function to convert a double value to string
void double_to_string(double num, char *str) {
    __m128d vec_num = _mm_set_sd(num);
    __m128i vec_index = _mm_setr_epi32(0, 1, 2, 3);
    __m128i vec_radix = _mm_set1_epi32(10);
    __m128d vec_zero = _mm_setzero_pd();
    __m128i vec_is_negative = _mm_setzero_si128();
    
    // Check if the number is negative
    if (_mm_comilt_sd(vec_num, vec_zero)) {
        num *= -1;
        vec_is_negative = _mm_set1_epi32('-');
    }
    
    for (int i = 0; i < 20; i++) { // maximum of 20 digits for double precision
        __m128d vec_integer_part, vec_fractional_part, vec_digit;
        
        // Extract integer and fractional parts of the number
        vec_integer_part = _mm_cvtepi32_pd(_mm_cvtpd_epi32(vec_num));
        vec_fractional_part = _mm_sub_sd(vec_num, vec_integer_part);
        
        // Multiply fractional part by 10 and extract the integer digit
        vec_digit = _mm_cvtepi32_pd(_mm_cvttpd_epi32(_mm_mul_sd(vec_fractional_part, vec_radix)));
        
        // Store the digit in the string
        str[i] = _mm_cvtsi128_si32(_mm_add_epi32(vec_is_negative, _mm_shuffle_epi8((__m128i) vec_digit, _mm_setr_epi8(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0))) + '0';
        
        // Update the number for next iteration
        vec_num = _mm_mul_sd(vec_fractional_part - vec_digit, vec_radix);
    }
    
    str[20] = '\0'; // null terminate the string
}

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <double>\n", argv[0]);
        return 1;
    }
    
    double num = atof(argv[1]);
    char str[21]; // maximum of 20 digits for double precision plus null character
    double_to_string(num, str);
    
    printf("String representation: %s\n", str);
    return 0;
}