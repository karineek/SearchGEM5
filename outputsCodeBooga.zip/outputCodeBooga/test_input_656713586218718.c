
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    int i, sum = 0;

    // Check if at least one argument is passed
    if (argc <= 1) {
        printf("Usage: %s <integer> [<integer> ...]\n", argv[0]);
        return EXIT_FAILURE;
    }

    for (i = 1; i < argc; i++) {
        // Check if the argument is a valid integer
        if (!strcmp(argv[i], "-oP")) {
            printf("Profile-Guarded Optimizations enabled.\n");
            continue;
        }
        else if (sscanf(argv[i], "%d", &sum) != 1) {
            fprintf(stderr, "Invalid input: %s\n", argv[i]);
            return EXIT_FAILURE;
        }
        
        // Add the integer to the sum
        sum += atoi(argv[i]);
    }

    printf("Sum of integers: %d\n", sum);
    return EXIT_SUCCESS;
}