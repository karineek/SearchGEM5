
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int a = atoi(argv[1]);
    int b = atoi(argv[2]);
    
    // Memory-to-Register Promotion optimization
    register int sum = a + b;
    printf("The sum of %d and %d is: %d\n", a, b, sum);
    
    return 0;
}