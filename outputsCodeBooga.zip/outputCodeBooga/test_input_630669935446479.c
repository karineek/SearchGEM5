
#include <stdio.h>
#include <stdlib.h>
#include "llvm-c/Core.h"
#include "llvm-c/Analysis.h"

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }
    
    int input = atoi(argv[1]);
    LLVMModuleRef mod = LLVMModuleCreateWithName("my_module");
    LLVMTypeRef int32_type = LLVMInt32Type();
    LLVMValueRef square, add;

    // Create main function and basic block
    LLVMValueRef main_func = LLVMAddFunction(mod, "main", LLVMFunctionType(int32_type, NULL, 0, false));
    LLVMBasicBlockRef entry_block = LLVMAppendBasicBlock(main_func, "entry");

    // Create builder for main function
    LLVMBuilderRef builder = LLVMCreateBuilder();
    LLVMPositionBuilderAtEnd(builder, entry_block);

    // Declare input variable and load value from argv[1]
    LLVMValueRef input_var = LLVMBuildAlloca(builder, int32_type, "input");
    LLVMValueRef input_val = LLVMConstInt(int32_type, input, true);
    LLVMBuildStore(builder, input_val, input_var);
    LLVMValueRef load_input = LLVMBuildLoad(builder, input_var, "load_input");

    // Square the input value using constant folding optimization
    LLVMValueRef two = LLVMConstInt(int32_type, 2, true);
    square = LLVMBuildMul(builder, load_input, load_input, "square");
    LLVMAddInstrAttribute(square, LLVMGetLastInstruction(builder), LLVMGetEnumAttributeKindForName("foldable", 7), LLVMCreateStringAttribute("true", 4));

    // Add 5 to the squared value
    LLVMValueRef five = LLVMConstInt(int32_type, 5, true);
    add = LLVMBuildAdd(builder, square, five, "add");

    // Print intermediate values in hexadecimal format
    printf("Input: %x\n", input);
    printf("Squared: %x\n", LLVMConstIntGetZExtValue(LLVMConstantExprGetValueOperand(square)));
    printf("Result: %x\n", LLVMConstIntGetZExtValue(LLVMConstantExprGetValueOperand(add)));

    // Return the result
    LLVMBuildRet(builder, add);
    
    // Clean up and exit
    LLVMDisposeBuilder(builder);
    return 0;
}