
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <index>\n", argv[0]);
        return 1;
    }

    int index = atoi(argv[1]);

    const char* strings[] = {"hello", "world", "this", "is", "a", "test"};
    size_t num_strings = sizeof(strings) / sizeof(strings[0]);

    if (index >= 0 && index < num_strings) {
        printf("%s\n", strings[index]);
    } else {
        printf("Invalid index.\n");
    }

    return 0;
}