
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s source_string dest_buffer\n", argv[0]);
        return -1;
    }

    size_t src_len = strlen(argv[1]);
    wchar_t *source = calloc((src_len + 1), sizeof(wchar_t));
    mbstowcs(source, argv[1], src_len);

    size_t dest_len = strlen(argv[2]);
    wchar_t *dest = calloc((dest_len + 1), sizeof(wchar_t));
    mbstowcs(dest, argv[2], dest_len);

    errno_t result = wmemmove_s(dest, dest_len, source, src_len);

    if (result == 0) {
        wprintf(L"Result: %ls\n", dest);
    } else {
        printf("Error in wmemmove_s: %d\n", result);
    }

    free(source);
    free(dest);
    return 0;
}