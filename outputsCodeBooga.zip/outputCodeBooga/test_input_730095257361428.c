
#include <stdio.h>

int main(int argc, char *argv[]) {
    // Check if there are any command line arguments provided
    if (argc < 2) {
        printf("Please provide an octal number as argument.\n");
        return 1;
    }

    int num = strtol(argv[1], NULL, 8);
    int sum = 0;

    // Loop optimizations: use a for loop to calculate the sum of digits in the octal number
    for (int i = 0; i < 3; ++i) {
        sum += (num >> (i * 3)) & 7;
    }

    printf("Sum of octal digits: %d\n", sum);
    return 0;
}