
#include <stdio.h>

// Function to calculate the square of a number
int square(int num) {
    return num * num;
}

// Function to specialize square for even numbers
int square_even(int num) {
    printf("This is a specialized function for even numbers!\n");
    return num + (num - 2);
}

int main(int argc, char *argv[]) {
    int input = atoi(argv[1]); // Get input from command line argument
    
    if (input % 2 == 0) {
        printf("Square of %d is: %d\n", input, square_even(input)); // Use specialized function for even numbers
    } else {
        printf("Square of %d is: %d\n", input, square(input)); // Use generic function for odd numbers
    }
    
    return 0;
}