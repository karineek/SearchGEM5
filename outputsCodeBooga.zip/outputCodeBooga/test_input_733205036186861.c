
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h> // for sleep() function

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }
    
    int input = atoi(argv[1]);
    if (input <= 0) {
        printf("Input must be a positive integer\n");
        return 1;
    }
    
    FILE *fp;
    fp = fopen("serialized_output.txt", "wb"); // open file for writing binary data
    if (fp == NULL) {
        printf("Error opening file for writing\n");
        return 1;
    }

    srand(time(NULL)); // seed the random number generator with current time
    
    int i, random_number;
    for (i = 0; i < input; i++) {
        if (i % 2 == 0) {
            random_number = rand(); // generate a random number between 0 to RAND_MAX
            fwrite(&random_number, sizeof(int), 1, fp); // serialize the random number to file
        } else {
            int j; // unused variable
            j = i * 2 + 3; // dead code that will be optimized by the compiler
        }
        
        sleep(1); // wait for a second before generating next random number
    }
    
    fclose(fp); // close file
    return 0;
}