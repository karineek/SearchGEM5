
#include <stdio.h>
#include <stdarg.h>

int main(int argc, char *argv[]) {
    if (argc != 4) {
        printf("Usage: ./program num1 num2 num3\n");
        return -1;
    }
    
    int a = atoi(argv[1]);
    int b = atoi(argv[2]);
    int c = atoi(argv[3]);
    
    int sum = a + b + c;
    int product = a * b * c;
    int difference = a - b - c;
    
    char format[] = "%d + %d + %d = %d\n%d * %d * %d = %d\n%d - %d - %d = %d\n";
    
    va_list args;
    va_start(args, format);
    vprintf(format, args, a, b, c, sum, a, b, c, product, a, b, c, difference);
    va_end(args);
    
    return 0;
}