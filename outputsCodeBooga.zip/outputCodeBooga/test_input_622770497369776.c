
#include <stdio.h>
#include <stdatomic.h>
#include <inttypes.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <value1> <value2>\n", argv[0]);
        return -1;
    }

    atomic_uint_fast16_t num1, num2;
    
    num1 = strtoumax(argv[1], NULL, 10);
    num2 = strtoumax(argv[2], NULL, 10);

    printf("Before addition: num1=%"PRIuFAST16", num2=%"PRIuFAST16"\n", num1, num2);
    
    atomic_fetch_add_explicit(&num1, num2, memory_order_relaxed);

    printf("After addition: num1=%"PRIuFAST16"\n", num1);

    return 0;
}