
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input_string>\n", argv[0]);
        return 1;
    }

    int len = strlen(argv[1]);
    for (int i = 0; i < len; i++) {
        if ('a' <= argv[1][i] && argv[1][i] <= 'z') {
            printf("%c is a lowercase letter.\n", argv[1][i]);
        } else {
            printf("%c is not a lowercase letter.\n", argv[1][i]);
        }
    }

    return 0;
}