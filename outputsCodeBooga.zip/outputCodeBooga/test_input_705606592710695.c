
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#define _IOLBF 1 // Enable line buffering mode for stdio

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s \"expression\"\n", argv[0]);
        return 1;
    }

    int i = 0, num1, num2, result = 0;
    char op;
    while (argv[1][i] != '\0') {
        if (isdigit(argv[1][i])) {
            num1 = argv[1][i++] - '0'; // Get the first number

            // Skip white spaces
            while (isspace(argv[1][i])) i++;

            op = argv[1][i++]; // Get the operator (+ or -)

            // Skip white spaces
            while (isspace(argv[1][i])) i++;

            num2 = argv[1][i++] - '0'; // Get the second number

            // Perform the operation and store in result
            switch (op) {
                case '+': result += num1; break;
                case '-': result -= num1; break;
                default: printf("Invalid operator\n"); return 1;
            }
        } else {
            i++; // Skip non-digit characters
        }
    }
    printf("Result: %d\n", result);
    return 0;
}