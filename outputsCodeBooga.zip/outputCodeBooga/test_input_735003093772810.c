
#include <stdio.h>
#include <threads.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./program seconds\n");
        return 1;
    }

    long duration = strtol(argv[1], NULL, 10);
    if (duration <= 0) {
        printf("Invalid input. Please enter a positive integer.\n");
        return 1;
    }

    struct timespec delay;
    delay.tv_sec = duration / 10000;
    delay.tv_nsec = (duration % 10000) * 10000000;

    thrd_sleep(&delay, NULL);
    printf("Slept for %ld seconds.\n", duration);

    return 0;
}