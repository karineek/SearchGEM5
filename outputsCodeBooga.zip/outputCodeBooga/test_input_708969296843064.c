
#include <stdio.h>
#include <stdlib.h>

// Function prototype
int square(int num);

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }
    
    int input = atoi(argv[1]); // Convert command line argument to integer
    int result = square(input);

    printf("%d squared is %d\n", input, result);
    return 0;
}

// Function definition
int square(int num) {
    return num * num;
}