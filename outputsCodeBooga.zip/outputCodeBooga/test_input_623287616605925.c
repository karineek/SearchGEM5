
#include <stdio.h>
#include <stdarg.h>

void print_args(int num, ...) {
    va_list args;
    int i;
    va_start(args, num);
    for (i = 0; i < num; i++) {
        printf("%d ", va_arg(args, int));
    }
    putchar('\n');
    va_end(args);
}

int main(int argc, char *argv[]) {
    if (argc > 1) {
        int num = atoi(argv[1]);
        print_args(num, 10, 20, 30, 40, 50); // example of using __VA_ARGS__
    } else {
        printf("No arguments provided\n");
    }
    return 0;
}