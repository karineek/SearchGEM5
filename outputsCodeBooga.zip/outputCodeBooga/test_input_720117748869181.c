
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <assert.h>

int main(int argc, char *argv[]) {
    assert(argc == 2);
    
    time_t input_time = strtol(argv[1], NULL, 10);
    struct tm *tm_info = localtime(&input_time);
    
    printf("The day of the week is: %s\n", (char *)tm_wday[tm_info->tm_wday]);
    
    return 0;
}