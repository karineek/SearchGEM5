
#include <stdio.h>
#include <stdlib.h>

// Recursive function to calculate the factorial of a number
int factorial(int n) {
    if (n == 0 || n == 1) {
        return 1;
    } else {
        // Memory-to-register promotion optimization: Instead of using a local variable, we directly return the result of calling the function recursively.
        return n * factorial(n - 1);
    }
}

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: ./factorial <number>\n");
        exit(1);
    }
    
    int number = atoi(argv[1]);
    if (number < 0) {
        printf("Error: Number must be non-negative.\n");
        exit(1);
    }
    
    // Call the recursive function to calculate the factorial of the input number
    int result = factorial(number);
    printf("Factorial of %d is %d\n", number, result);
    
    return 0;
}