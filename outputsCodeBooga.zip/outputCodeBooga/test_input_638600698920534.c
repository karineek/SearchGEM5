
#include <stdio.h>
#include <stdatomic.h>
#include <stdint.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s num1 num2\n", argv[0]);
        return 1;
    }

    uintmax_t a = strtoumax(argv[1], NULL, 10);
    uintmax_t b = strtoumax(argv[2], NULL, 10);
    atomic_uintmax_t sum;
    atomic_init(&sum, 0);

    #pragma omp parallel for
    for (uintmax_t i = 0; i < a + b; ++i) {
        uintmax_t value = i % 2 ? a : b;
        atomic_fetch_add_explicit(&sum, value, memory_order_relaxed);
    }

    printf("Sum: %ju\n", atomic_load_explicit(&sum, memory_order_seq_cst));

    return 0;
}