
#include <stdio.h>
#include <math.h>

double sum(int n) {
    if (n <= 0) {
        return 0;
    } else {
        return n + sum(n - 1);
    }
}

int main(int argc, char *argv[]) {
    int input_num = atoi(argv[1]);
    
    if (isnan(input_num)) {
        printf("Invalid input\n");
        return 1;
    } else if (input_num <= 0) {
        printf("Input must be a positive integer\n");
        return 1;
    } else {
        double result = sum(input_num);
        printf("The sum of all positive integers less than or equal to %d is %.0lf\n", input_num, result);
        return 0;
    }
}