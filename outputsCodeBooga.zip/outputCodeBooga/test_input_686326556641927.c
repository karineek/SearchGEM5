
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[]) {
    // Check if there's at least one argument
    if (argc < 2) {
        printf("Please provide an input value.\n");
        return -1;
    }
    
    // Convert the first argument to an integer
    int num = strtol(argv[1], NULL, 10);
    
    // Perform constant folding optimization
    int result = (num * 2) + 3;
    
    // Print the input and output values in binary format
    printf("Input: %d (%s)\n", num, argv[1]);
    printf("Output: %d (%s)\n", result, "0b");
    for (int i = 31; i >= 0; i--) {
        printf("%d", ((result >> i) & 1));
    }
    
    // Get the current time using timespec_get and print it
    struct timespec tp;
    if (timespec_get(&tp, TIME_UTC) != 0) {
        printf("\nCurrent time: %ld.%09ld\n", tp.tv_sec, tp.tv_nsec);
    } else {
        perror("Error getting current time");
    }
    
    return 0;
}