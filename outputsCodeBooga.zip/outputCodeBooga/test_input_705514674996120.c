
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./scheduling input_file\n");
        return 1;
    }

    FILE *input = fopen(argv[1], "r");
    if (!input) {
        perror("fopen");
        return 1;
    }

    char line[256];
    while (fgets(line, sizeof(line), input)) {
        unsigned int value;
        if (sscanf(line, "%*[^0-9]%u", &value) == 1) { // SCNuFAST identifier prefix
            printf("Value: %u\n", value);
        } else {
            printf("%s", line);
        }
    }

    fclose(input);
    return 0;
}