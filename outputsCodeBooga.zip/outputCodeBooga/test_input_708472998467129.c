
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <tgmath.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program <num1> <num2>\n");
        return 1;
    }

    // Converting strings to numbers using strtof function from tgmath.h
    float num1 = strtof(argv[1], NULL);
    float num2 = strtof(argv[2], NULL);
    
    // Loop Invariant Code Motion optimization by moving variable declarations outside of the loop
    int i;
    float sum = 0.0;
    
    for (i = 0; i < 10000; ++i) {
        sum += num1 + num2;
    }

    printf("The sum is: %f\n", sum);

    return 0;
}