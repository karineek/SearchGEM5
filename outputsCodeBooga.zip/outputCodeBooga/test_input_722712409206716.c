
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program num1 num2\n");
        return 1;
    }

    double x = strtod(argv[1], NULL);
    double y = strtod(argv[2], NULL);

    if (isnan(x) || isnan(y)) {
        printf("Input contains NaN\n");
        return 1;
    }

    double sum = x + y;
    printf("Sum: %lf\n", sum);

    return 0;
}