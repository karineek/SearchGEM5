
#include <stdio.h>
#include <stdlib.h>

void exit_handler(void)
{
    printf("Exiting...\n");
}

int main(int argc, char *argv[])
{
    int num;

    if (argc != 2) {
        fprintf(stderr, "Usage: %s <number>\n", argv[0]);
        return EXIT_FAILURE;
    }

    num = atoi(argv[1]);
    at_quick_exit(exit_handler);
    int square = num * num;

    printf("The square of %d is: %d\n", num, square);

    return EXIT_SUCCESS;
}