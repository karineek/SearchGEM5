
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int id;
    char name[100];
} Employee;

inline static void print_employee(Employee e) {
    printf("ID: %d\n", e.id);
    printf("Name: %s\n", e.name);
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program <employee_id> <employee_name>\n");
        return 1;
    }
    
    Employee e = {.id = atoi(argv[1]), .name = argv[2]};
    print_employee(e);
    return 0;
}