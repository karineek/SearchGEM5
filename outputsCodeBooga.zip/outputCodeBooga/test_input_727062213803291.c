
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s N\n", argv[0]);
        return 1;
    }
    
    int n = atoi(argv[1]);
    double sum_of_squares = 0;
    for (int i = 1; i <= n; i++) {
        sum_of_squares += pow(i, 2);
    }

    printf("Sum of squares from 1 to %d: %.f\n", n, sum_of_squares);
    
    return 0;
}