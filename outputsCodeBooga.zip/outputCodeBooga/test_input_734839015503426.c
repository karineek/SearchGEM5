
#include <stdio.h>
#include <stdlib.h>
#include <stdatomic.h>
#include <stdint.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s start_number end_number\n", argv[0]);
        return 1;
    }

    int64_t start = atoll(argv[1]);
    int64_t end = atoll(argv[2]);

    if (start > end) {
        printf("Start number should be less than or equal to the end number.\n");
        return 1;
    }

    atomic_uint_fast32_t sum = 0;

    #pragma omp parallel for reduction(+:sum)
    for (int64_t i = start; i <= end; ++i) {
        atomic_fetch_add(&sum, i);
    }

    printf("Sum from %lld to %lld is %u\n", start, end, sum);

    return 0;
}