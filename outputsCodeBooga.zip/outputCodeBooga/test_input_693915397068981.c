
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s n\n", argv[0]);
        return 1;
    }
    
    int n = atoi(argv[1]);
    int sum = 0;
    
    for (int i = 1; i <= n; ++i) {
        // The following line is the loop-invariant code: it can be moved outside of the loop
        int square = i * i;
        
        // Perform Loop Invariant Code Motion optimization by moving the above line out of the loop
        sum += square;
    }
    
    printf("The sum of squares from 1 to %d is: %d\n", n, sum);
    
    return 0;
}