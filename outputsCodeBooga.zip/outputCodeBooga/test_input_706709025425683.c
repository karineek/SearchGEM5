
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./program <integer>\n");
        return 1;
    }
    
    int num = atoi(argv[1]);
    int neg_num = -num;
    
    printf("Negation of %d is %d\n", num, neg_num);
    
    return 0;
}