
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input>\n", argv[0]);
        return 1;
    }
    
    int input = atoi(argv[1]);
    time_t currentTime = time(NULL);
    struct tm *localTime = localtime(&currentTime);
    
    if (localTime->tm_hour < 12) {
        printf("Good morning, the input is %d\n", input);
    } else {
        printf("Good afternoon, the input is %d\n", input);
    }
    
    return 0;
}