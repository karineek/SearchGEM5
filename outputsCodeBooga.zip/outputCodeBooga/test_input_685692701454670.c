
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s input_file\n", argv[0]);
        exit(1);
    }

    FILE *input = fopen(argv[1], "r");
    if (!input) {
        perror("Error opening file");
        exit(1);
    }

    wchar_t buffer[1024];
    while (fgetws(buffer, sizeof(buffer), input)) {
        fputws(buffer, stdout);
    }

    fclose(input);
    return 0;
}