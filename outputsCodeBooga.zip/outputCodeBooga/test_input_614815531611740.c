
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s number\n", argv[0]);
        return 1;
    }
    
    double num = atof(argv[1]);
    long double sqrt_num = csqrtl(num);
    printf("Square root of %.2f is %.2Lf\n", num, sqrt_num);

    return 0;
}