
#include <stdio.h> // Header file for input/output operations
#include <stdlib.h> // Header file for memory management and common utilities
#include <limits.h> // Header file for defining some implementation-defined values
#include <assert.h> // Header file for assertions
#include <stdarg.h> // Header file for variable arguments
#include <string.h> // Header file for string operations

int main(int argc, char *argv[]) {
    if (argc != 2) { // Check if exactly one argument is provided
        printf("Usage: %s <integer>\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    int input = strtol(argv[1], NULL, 10); // Convert the string input to integer using base 10
    if (input >= INT_MAX || input <= INT_MIN) { // Check if the input is within the range of an int
        printf("Input out of range.\n");
        return EXIT_FAILURE;
    }
    
    printf("Hexadecimal representation: %X\n", input); // Convert and print the integer in hexadecimal format using %X specifier
    return EXIT_SUCCESS;
}