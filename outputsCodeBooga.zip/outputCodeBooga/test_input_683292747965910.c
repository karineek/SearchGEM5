
#include <stdio.h>
#include <stdlib.h>
#include <limits.h> // For UINT_MAX
#include <omp.h>    // For OpenMP support

int main(int argc, char **argv) {
    if (argc != 3) {
        printf("Usage: ./program <vector size>\n");
        return -1;
    }

    int N = atoi(argv[1]);
    unsigned int *a = malloc(N * sizeof(unsigned int));
    unsigned int *b = malloc(N * sizeof(unsigned int));

    // Initialize the vectors with random values up to UINT_MAX
    for (int i = 0; i < N; ++i) {
        a[i] = rand() % UINT_MAX;
        b[i] = rand() % UINT_MAX;
    }

    unsigned int sum = 0;

#pragma omp simd reduction(+:sum)
    for (int i = 0; i < N; ++i) {
        sum += a[i] * b[i];
    }

    printf("Sum of products: %u\n", sum);

    free(a);
    free(b);
    return 0;
}