
#include <stdio.h>
#include <stdarg.h>

int vsnwprintf_s(wchar_t *str, size_t sizeOfBuffer, size_t count, const wchar_t *format, va_list args);

int main(int argc, char* argv[]) {
    if (argc < 3) {
        printf("Usage: %s <output_file> <input1> [<input2>...]\n", argv[0]);
        return -1;
    }
    
    FILE *fp = fopen(argv[1], "w");
    if (fp == NULL) {
        printf("Error: Unable to open file %s\n", argv[1]);
        return -2;
    }

    for (int i = 2; i < argc; ++i) {
        wchar_t buffer[100];
        va_list args;
        va_start(args, argv[i]);
        vsnwprintf_s(buffer, sizeof(buffer), _TRUNCATE, L"%ls", args);
        fwprintf(fp, L"Argument %d: %ls\n", i - 1, buffer);
        va_end(args);
    }
    
    fclose(fp);
    return 0;
}