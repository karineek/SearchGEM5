
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s num1 num2\n", argv[0]);
        return 1;
    }

    int a = atoi(argv[1]);
    int b = atoi(argv[2]);
    int sum = 0;
    
    for (int i = 0; i < 10; ++i) {
        // LICM: this expression is loop-invariant and can be moved outside the loop
        int c = a + b;
        
        printf("Loop iteration %d\n", i);
        sum += c * i;
    }
    
    printf("Sum: %d\n", sum);

    return 0;
}