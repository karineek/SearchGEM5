
#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <number1> <number2>\n", argv[0]);
        return EXIT_FAILURE;
    }

    uint64_t num1 = strtoull(argv[1], NULL, 10);
    uint64_t num2 = strtoull(argv[2], NULL, 10);
    uint64_t sum = num1 + num2;
    
    printf("The sum of %"PRIuPTR" and %"PRIuPTR" is: %"PRIuPTR"\n", num1, num2, sum);
    
    return EXIT_SUCCESS;
}