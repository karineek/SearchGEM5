
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int i;
    long sum = 0;
    for (i = 1; i < argc; i++) {
        sum += strtol(argv[i], NULL, 10);
    }
    printf("Sum: %ld\n", sum);
    return 0;
}