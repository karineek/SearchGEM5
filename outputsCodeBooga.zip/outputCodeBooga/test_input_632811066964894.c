
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>

double next_toward_zero(double x) {
    if (x > 0.0) {
        return nextafter(x, -DBL_MAX);
    } else if (x < 0.0) {
        return nextafter(x, DBL_MAX);
    } else {
        return x;
    }
}

int main(int argc, char *argv[]) {
    int i;
    double num;
    
    for (i = 1; i < argc; i++) {
        sscanf(argv[i], "%lf", &num);
        printf("Next representable number towards zero from %lf: %lf\n", num, next_toward_zero(num));
    }
    
    return 0;
}