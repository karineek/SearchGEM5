
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }

    int num, sum = 0;
    sscanf(argv[1], "%d", &num);
    
    for (int i = 1; i <= num; i++) {
        sum += i * i;
    }

    printf("Sum of squares: %d\n", sum);
    return 0;
}