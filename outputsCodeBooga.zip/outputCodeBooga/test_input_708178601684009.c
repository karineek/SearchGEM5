
#include <stdio.h>
#include <stdlib.h>

// Function declarations
double sum_floats(float *arr, int size);
int sum_ints(int *arr, int size);

int main(int argc, char **argv) {
    if (argc != 3) {
        printf("Usage: %s <data type> <numbers...>\n", argv[0]);
        return 1;
    }

    // Check data type
    if (!strcmp(argv[1], "int")) {
        int size = argc - 2;
        int arr[size];
        for (int i = 0; i < size; i++) {
            arr[i] = atoi(argv[i + 2]);
        }
        printf("Sum: %d\n", sum_ints(arr, size));
    } else if (!strcmp(argv[1], "float")) {
        int size = argc - 2;
        float arr[size];
        for (int i = 0; i < size; i++) {
            arr[i] = atof(argv[i + 2]);
        }
        printf("Sum: %.2f\n", sum_floats(arr, size));
    } else {
        printf("Invalid data type. Please use 'int' or 'float'\n");
    }

    return 0;
}

// Function definitions
double sum_floats(float *arr, int size) {
    double sum = 0;
    for (int i = 0; i < size; i++) {
        sum += arr[i];
    }
    return sum;
}

int sum_ints(int *arr, int size) {
    int sum = 0;
    for (int i = 0; i < size; i++) {
        sum += arr[i];
    }
    return sum;
}