
#include <stdio.h>
#include <stdlib.h>
#include <math.h> // Include math library for ceil function

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }
    
    double input = atof(argv[1]); // Convert the string argument to a double
    double result = ceil(input); // Use ceil function from math library to round up the number
    
    printf("Ceil of %f is: %f\n", input, result);
    
    return 0;
}