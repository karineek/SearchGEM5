
#include <stdio.h>
#include <stdlib.h>
#include <stdatomic.h>
#include <pthread.h>

_Atomic long long long sum = 0;

void *calc_sum(void *arg) {
    int start = *((int *) arg);
    int end = start + 100; // Assuming each thread processes 100 integers in the array
    for (int i = start; i < end && i < 1000; i++) {
        atomic_fetch_add(&sum, array[i]);
    }
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s num_threads\n", argv[0]);
        return 1;
    }

    int num_threads = atoi(argv[1]);
    pthread_t threads[num_threads];
    int i;

    // Initialize the array with some integers
    for (i = 0; i < 100; i++) {
        array[i] = i + 1;
    }

    // Create and launch threads to calculate sum of array segments
    for (i = 0; i < num_threads; i++) {
        pthread_create(&threads[i], NULL, calc_sum, &i);
    }

    // Wait for all threads to finish
    for (i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }

    printf("Sum: %lld\n", sum);

    return 0;
}