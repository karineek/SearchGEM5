
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <safe_str_lib.h>

int main(int argc, char *argv[]) {
    errno_t rc;
    size_t len;
    int myerrno = 0;
    
    if (argc < 2) {
        printf("Usage: %s error-number [error-number]...\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    for (int i = 1; i < argc; ++i) {
        myerrno = atoi(argv[i]);
        rc = strerrorlen_s(NULL, 0, len, myerrno);
        
        if (rc != EOK && rc != ESNOSPC) {
            printf("Error getting length of error string for %d: %s\n", myerrno, strerror(rc));
            continue;
        }
        
        char errstr[len + 1];
        rc = strerrorlen_s(errstr, len + 1, &len, myerrno);
        
        if (rc != EOK) {
            printf("Error getting error string for %d: %s\n", myerrno, strerror(rc));
            continue;
        }
        
        printf("%d: %s\n", myerrno, errstr);
    }
    
    return EXIT_SUCCESS;
}