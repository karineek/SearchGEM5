
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <wchar.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input_string>\n", argv[0]);
        return 1;
    }

    setlocale(LC_ALL, "");

    mbstate_t state = {};
    wchar_t wc;
    int length = strlen(argv[1]);
    for (int i = 0; i < length;) {
        size_t retval = mbtowc(&wc, argv[1] + i, MB_CUR_MAX);
        
        if (retval == (size_t)-1 || retval == (size_t)-2) {
            printf("Invalid multibyte sequence encountered!\n");
            return 1;
        } else if (retval == 0) {
            break;
        } else {
            i += retval;
            printf("%lc", wc);
        }
    }

    putchar('\n');
    return 0;
}