
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>

int main(int argc, char *argv[]) {
    int sum = 0;
    size_t i;
    for (i = 1; i < argc; ++i) {
        long num = strtol(argv[i], NULL, 10);
        if ((num > INT_MAX || num < INT_MIN)) {
            fprintf(stderr, "Error: number %ld is out of range for int type.\n", num);
            return 1;
        }
        sum += (int)num;
    }
    printf("Sum = %d\n", sum);
    return 0;
}