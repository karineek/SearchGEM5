
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s operand1 operand2\n", argv[0]);
        return -1;
    }
    
    int op1 = atoi(argv[1]);
    int op2 = atoi(argv[2]);
    int result = op1 + op2; // Constant folding optimization: this operation is performed at compile time
                         // if both operands are constants
    
    printf("The sum of %d and %d is %d\n", op1, op2, result);
    return 0;
}