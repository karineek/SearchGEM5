
#include <stdio.h>
#include <stdlib.h>

inline int add(int a, int b) { //Inline function declaration
    return a + b;
}

int main(int argc, char *argv[]) { //Main function with command line arguments
    if (argc != 3) { //Checking for valid number of input arguments
        printf("Usage: %s num1 num2\n", argv[0]);
        return -1;
    }
    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);
    int sum = add(num1, num2); //Calling the inline function
    
    __asm__( //Inline Assembly block to print the result
        "movl $0, %%eax\n\t"
        "movl %0, %%ebx\n\t"
        "movl $1, %%eax\n\t"
        "int $0x80\n\t"
        : /* no output */
        : "r" (sum) //Input to the inline assembly code
    );
    
    return 0;
}