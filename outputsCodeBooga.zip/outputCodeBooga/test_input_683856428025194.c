
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <llvm-c/Core.h>
#include <llvm-c/BitWriter.h>

LLVMModuleRef parse_ir_from_buffer(char *buf, int size) {
    LLVMDiagnosticRef diag;
    return LLVMParseIRInContext(kLLVMContext, buf, size, &diag);
}

int main(int argc, char *argv[]) {
    // Check if the input argument is provided
    if (argc < 2) {
        printf("Please provide an input string.\n");
        return -1;
    }

    // Constant folding example: calculating the sum of two numbers
    int a = 5, b = 3;
    int sum = a + b; // Constant folding will be applied by the compiler to this expression.
    printf("Sum of %d and %d is %d.\n", a, b, sum);

    // Reads LLVM IR example: reading an LLVM module from a file
    FILE *file = fopen(argv[1], "rb");
    if (!file) {
        printf("Failed to open the input file.\n");
        return -1;
    }

    fseek(file, 0L, SEEK_END);
    int size = ftell(file);
    rewind(file);

    char *buf = (char *)malloc(size + 1);
    if (!buf) {
        printf("Failed to allocate memory.\n");
        return -1;
    }

    fread(buf, 1, size, file);
    buf[size] = '\0';
    fclose(file);

    LLVMModuleRef mod = parse_ir_from_buffer(buf, size);
    if (!mod) {
        printf("Failed to parse the input module.\n");
        return -1;
    }

    free(buf);

    // Exercise memchr function: finding a character in a string
    char str[] = "Hello, world!";
    char ch = ',';
    char *result = (char *)memchr(str, ch, sizeof(str) - 1);
    if (result != NULL) {
        printf("Found '%c' at position %ld.\n", ch, result - str);
    } else {
        printf("Failed to find '%c'.\n", ch);
    }

    LLVMDisposeModule(mod);
    return 0;
}