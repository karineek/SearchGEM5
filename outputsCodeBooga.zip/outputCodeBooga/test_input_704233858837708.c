
#include <stdio.h>
#include <stdlib.h>

inline int add(int a, int b) {
    return a + b;
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        printf("Usage: %s num1 num2\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    int a, b;
    sscanf(argv[1], "%d", &a);
    sscanf(argv[2], "%d", &b);

    printf("Sum: %d\n", add(a, b));

    return 0;
}