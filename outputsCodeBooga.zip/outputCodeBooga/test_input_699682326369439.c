
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./program conversion_rate\n");
        return 1;
    }

    double dollars = atof(argv[1]);
    double rate = 0.89; // conversion rate EUR to USD, as of May 13th, 2022
    double euros = dollars * rate;

    printf("%f dollars is equal to %f euros.\n", dollars, euros);

    return 0;
}