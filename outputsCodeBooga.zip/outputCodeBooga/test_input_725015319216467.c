
#include <stdio.h>
#include <math.h>

float round_to_two_decimal(float num) {
    return roundf(num * 100.0f) / 100.0f;
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: %s float_number\n", argv[0]);
        return -1;
    }

    float num = atof(argv[1]);
    float rounded_num = round_to_two_decimal(num);
    printf("%.2f rounded to two decimal places is: %.2f\n", num, rounded_num);

    return 0;
}