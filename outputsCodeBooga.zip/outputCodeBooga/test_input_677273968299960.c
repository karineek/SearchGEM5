
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s input_file\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    FILE *input = fopen(argv[1], "r");
    if (input == NULL) {
        perror("fopen");
        return EXIT_FAILURE;
    }

    char buffer[BUFSIZ];
    while (fgets(buffer, sizeof(buffer), input)) {
        printf("%s", buffer);
    }
    
    fclose(input);
    return EXIT_SUCCESS;
}