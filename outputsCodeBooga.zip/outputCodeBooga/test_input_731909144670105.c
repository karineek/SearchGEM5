
#include <stdio.h> // For printf function
#include <stdlib.h> // For exit function
#include <assert.h> // For assert macro

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <number>\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    int input = atoi(argv[1]); // Convert string to integer
    
    assert (input >= 0 && input <= 10); // Check if the input is within range [0, 10]
    
    printf("Input number: %d\n", input);
    
    return EXIT_SUCCESS;
}