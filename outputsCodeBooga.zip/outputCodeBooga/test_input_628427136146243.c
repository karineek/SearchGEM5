
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program <string1> <string2>\n");
        return -1;
    }
    
    char *str1 = argv[1];
    char *str2 = argv[2];

    int len1 = strlen(str1);
    int len2 = strlen(str2);
    int total_length = len1 + len2 + 1; // +1 for null terminator

    char *result = (char *) malloc(total_length * sizeof(char));
    
    struct timeval start, end;
    gettimeofday(&start, NULL);
    
    int i;
    #pragma omp parallel for simd
    for (i=0; i<len1; ++i) {
        result[i] = str1[i];
    }

    #pragma omp parallel for simd
    for (i=0; i<len2; ++i) {
        result[len1+i] = str2[i];
    }
    
    result[total_length-1] = '\0'; // null terminator
    
    gettimeofday(&end, NULL);
    double time_taken = (end.tv_sec - start.tv_sec) * 1e6 + (end.tv_usec - start.tv_usec);
    printf("Concatenation took %f microseconds.\n", time_taken);

    printf("Result: %s\n", result);
    
    free(result);

    return 0;
}