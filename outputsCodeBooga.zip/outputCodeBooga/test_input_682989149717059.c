
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h> // For tolower function
#include <math.h> // For sqrt function

// Function to calculate the square root of a number
inline float inline_sqrt(float x) {
    return sqrt(x);
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./program <number>\n");
        exit(1);
    }
    
    // Convert the input string to a float using conversion specifier %f
    float num = atof(argv[1]);
    
    // Calculate and print the square root of the number, also using conversion specifier %f
    printf("Square root of %f is %f\n", num, inline_sqrt(num));
    
    return 0;
}