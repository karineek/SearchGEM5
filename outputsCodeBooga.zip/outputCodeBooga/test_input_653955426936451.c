
#include <stdio.h>

// Define a structure to represent a point in 2D space
typedef struct {
    int x;
    int y;
} Point;

// Function for calculating the distance between two points using function inlining
static inline float distance(Point p1, Point p2) {
    return (float) sqrt((p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2.y) * (p1.y - p2.y));
}

int main(int argc, char **argv) {
    // Check if there are enough arguments provided
    if (argc != 5) {
        printf("Usage: %s <x1> <y1> <x2> <y2>\n", argv[0]);
        return 1;
    }

    // Create two points using compound literals and calculate the distance between them
    Point p1 = (Point) {.x = atoi(argv[1]), .y = atoi(argv[2])};
    Point p2 = (Point) {.x = atoi(argv[3]), .y = atoi(argv[4])};
    float dist = distance(p1, p2);

    printf("Distance between (%d, %d) and (%d, %d) is %.2f\n", p1.x, p1.y, p2.x, p2.y, dist);
    return 0;
}