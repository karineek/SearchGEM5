
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <number1> <number2>\n", argv[0]);
        return 1;
    }

    long long int num1 = strtoll(argv[1], NULL, 10);
    long long int num2 = strtoll(argv[2], NULL, 10);

    long long int sum = 0;
    for (int i = 0; i < num1; ++i) {
        sum += i;
    }

    for (int i = 0; i < num2; ++i) {
        sum -= i * 2;
    }

    printf("The result is: %lld\n", sum);

    return 0;
}