
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

int main(int argc, char *argv[]) {
    // Check if there are enough arguments
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return -1;
    }

    int num = atoi(argv[1]);

    signal(SIGINT, SIG_IGN); // Ignore SIGINT (Ctrl+C) signals using SIG_IGN macro

    for (int i = 0; i < num * 2; i++) {
        if (i % 2 == 0) { // Dead code elimination: this block will be optimized out since it's unreachable
            printf("%d is even\n", i);
        }
    }

    for (int i = 1; i <= num; i++) {
        if (i % 2 == 0) {
            printf("%d is even\n", i);
        } else {
            printf("%d is odd\n", i);
        }
    }

    return 0;
}