
#include <stdio.h>
#include <stdatomic.h>
#include <stdlib.h>
#include <threads.h>

atomic_int_least64_t counter = 0;

int increment(void *arg) {
    int n = *((int *) arg);
    for (int i = 0; i < n; i++) {
        atomic_fetch_add(&counter, 1);
    }
    return 0;
}

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <integer value>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    int n = atoi(argv[1]);
    thrd_t threads[2];

    for (int i = 0; i < 2; i++) {
        thrd_create(&threads[i], increment, &n);
    }

    for (int i = 0; i < 2; i++) {
        thrd_join(threads[i], NULL);
    }

    printf("Counter: %lld\n", atomic_load(&counter));
    return 0;
}