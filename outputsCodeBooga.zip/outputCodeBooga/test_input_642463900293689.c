
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>

// tanh type-generic macro
#define TANH(X) _Generic((X), \
        float: tanhf, \
        double: tanh, \
        long double: tanhl \
    )(X)

// Instruction Scheduling optimization (loop unrolling)
#define LOOP_UNROLLING_FACTOR 4

float calculate_tanh_with_loop(double x) {
    float result = x;
    float sum = x;
    float term = x * x;
    int i, sign = -1;
    
    for (i = 3; i < 1000000 / LOOP_UNROLLING_FACTOR; i += LOOP_UNROLLING_FACTOR) {
        sum += term * (sign *= -1);
        result += term / (2 * i + 1);
        
        #pragma unroll
        for (int j = 0; j < LOOP_UNROLLING_FACTOR - 1; ++j) {
            term *= x * x;
            sum += term * (sign *= -1);
            result += term / (2 * i + 2 + j);
        }
    }
    
    return result / sum;
}

float calculate_tanh_without_loop(double x) {
    float result = x;
    float numerator = x * x;
    float denominator = 1.0;
    int i, sign = -1;
    
    for (i = 3; i < 100000 / LOOP_UNROLLING_FACTOR; i += LOOP_UNROLLING_FACTOR) {
        #pragma unroll
        for (int j = 0; j < LOOP_UNROLLING_FACTOR; ++j) {
            denominator *= 2 * i + 1 + j;
            result += numerator / denominator;
            
            sign *= -1;
            numerator *= x * x;
        }
    }
    
    return TANH(result);
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printf("Please provide a number as an input.\n");
        return 1;
    }
    
    double x = strtod(argv[1], NULL);
    float result_with_loop = calculate_tanh_with_loop(x);
    float result_without_loop = calculate_tanh_without_loop(x);
    
    printf("Tanh with loop: %f\n", result_with_loop);
    printf("Tanh without loop: %f\n", result_without_loop);
    printf("Built-in tanh: %f\n", TANH(x));
    
    return 0;
}