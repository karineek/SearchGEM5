
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return -1;
    }

    int fd = open(argv[1], O_RDONLY);
    if (fd < 0) {
        perror("open");
        return -1;
    }

    off_t file_size;
    struct stat st;
    if (fstat(fd, &st) < 0) {
        perror("fstat");
        close(fd);
        return -1;
    }
    file_size = st.st_size;

    char *buf = malloc(file_size);
    if (!buf) {
        printf("Memory allocation failed\n");
        close(fd);
        return -1;
    }

    ssize_t bytes_read = read(fd, buf, file_size);
    if (bytes_read != file_size) {
        perror("read");
        free(buf);
        close(fd);
        return -1;
    }

    // Vectorized operation: add 5 to each byte in the buffer
    for (int i = 0; i < file_size; ++i) {
        buf[i] += 5;
    }

    // Read LLVM IR from the buffer
    printf("LLVM IR:\n%s\n", buf);

    // Use fseek to move the file pointer back to the start of the file
    if (lseek(fd, 0, SEEK_SET) < 0) {
        perror("lseek");
        free(buf);
        close(fd);
        return -1;
    }

    // Write the modified buffer back to the file
    ssize_t bytes_written = write(fd, buf, file_size);
    if (bytes_written != file_size) {
        perror("write");
        free(buf);
        close(fd);
        return -1;
    }

    printf("File updated successfully\n");

    free(buf);
    close(fd);
    return 0;
}