
#include <stdio.h>
#include <stdlib.h>
#include <x86intrin.h> // for __builtin_ia32_addps

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <vector1> <vector2>\n", argv[0]);
        return 1;
    }
    
    float v1[4], v2[4], result[4];
    
    // Parse the input vectors from command-line arguments
    for (int i = 0; i < 4; ++i) {
        if (sscanf(argv[1] + i * 6, "%f,%f,%f,%f", &v1[i], &v2[i]) != 1 || sscanf(argv[2] + i * 6, "%f,%f,%f,%f", &v1[i+4], &v2[i+4]) != 1) {
            printf("Invalid input format. Expected comma-separated floats.\n");
            return 1;
        }
    }
    
    // Perform the vector addition using __builtin_ia32_addps
    __m128 vec1 = _mm_setr_ps(v1[0], v1[1], v1[2], v1[3]);
    __m128 vec2 = _mm_setr_ps(v2[0], v2[1], v2[2], v2[3]);
    __m128 sum = _mm_add_ps(vec1, vec2);
    
    // Store the result back to an array and print it
    _mm_storeu_ps(result, sum);
    printf("Result: %.2f,%.2f,%.2f,%.2f\n", result[0], result[1], result[2], result[3]);
    
    return 0;
}