
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <angle in degrees>\n", argv[0]);
        return 1;
    }

    float angle = atof(argv[1]);
    float radian_angle = angle * M_PI / 180.0f;
    float cosine_value = cosf(radian_angle);

    printf("The cosine of %.2f degrees is: %f\n", angle, cosine_value);
    return 0;
}