
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return -1;
    }
    
    int x = atoi(argv[1]); // convert input to integer
    
    // Dead code that will be eliminated by the compiler's optimizations
    if (x == 0) {
        printf("Dead code\n");
    }
    
    // Core LLVM Intermediate Representation (IR) manipulation
    int y = x * 2;
    
    // Exercise symbols in C
    char symbol[100];
    sprintf(symbol, "Symbol: %d", y);
    
    printf("%s\n", symbol);
    
    return 0;
}