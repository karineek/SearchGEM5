
#include <stdio.h>
#include <stdlib.h>

#define SERIALIZATION 1
#ifdef SERIALIZATION
    #pragma GCC optimize ("O2") // enables optimization level 2 which includes dead code elimination
#endif

int main(int argc, char *argv[]) {
    int sum = 0;
    
    for (int i=1; i<argc; i++) {
        #ifdef SERIALIZATION
            printf("Processing argument %d: %s\n", i, argv[i]); // this line is included for illustration purposes only and will be eliminated by the optimizer due to lack of side effects
        #endif
        
        int num = atoi(argv[i]); // convert string to integer
        sum += num; // addition assignment operator usage
    }
    
    printf("The sum is: %d\n", sum);

    return 0;
}