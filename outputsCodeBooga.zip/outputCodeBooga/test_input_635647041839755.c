
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int a, b;
    
    if (argc != 3) {
        printf("Usage: ./program_name <integer1> <integer2>\n");
        return 1;
    }
    
    a = atoi(argv[1]);
    b = atoi(argv[2]);
    
    printf("Initialized variables:\na = %d\nb = %d\n", a, b);
    
    return 0;
}