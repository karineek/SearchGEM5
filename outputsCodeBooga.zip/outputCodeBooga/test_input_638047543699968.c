
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s num1 num2\n", argv[0]);
        return 1;
    }
    
    long double a = strtold(argv[1], NULL);
    long double b = strtold(argv[2], NULL);
    long double result = a * b;
    
    printf("Result: %.6Lf\n", result);
    
    return 0;
}