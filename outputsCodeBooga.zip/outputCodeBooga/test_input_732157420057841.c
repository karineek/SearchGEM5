
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define trunc(X) _Generic((X), \
    char: (char)X, \
    int: (int)X, \
    float: (int)(X), \
    double: (int)(X) \
)

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }
    
    double num = strtod(argv[1], NULL);
    int truncated_num = trunc(num);
    
    printf("Truncated value of %lf is: %d\n", num, truncated_num);
    
    return 0;
}