
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// Interprocedural Optimization utility function to calculate factorial of a number
unsigned long long int factorial(int n) {
    if (n <= 1) return 1;
    return n * factorial(n - 1);
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: ./program <number>\n");
        return 1;
    }
    
    int number = atoi(argv[1]);
    unsigned long long int fact = factorial(number);
    
    // Use remquo to compute both the quotient and remainder of two numbers
    double a = 5.0, b = 2.0;
    double quot, rem;
    remquo(a, b, &quot, &rem);
    
    printf("Factorial of %d: %llu\n", number, fact);
    printf("%f / %f = %.1f with remainder %.1f\n", a, b, quot, rem);
    return 0;
}