
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int a;
    float b;
    char c[10];
} my_struct;

my_struct serialize(int a, float b, char* c) {
    my_struct result = {a, b};
    strncpy(result.c, c, 9); // Copy up to 9 characters and append null terminator
    return result;
}

void deserialize(my_struct s, int *a, float *b, char **c) {
    *a = s.a;
    *b = s.b;
    *c = malloc(strlen(s.c)+1); // Allocate space for string + null terminator
    strcpy(*c, s.c);
}

void print_struct(my_struct s) {
    printf("a: %d\nb: %.2f\nc: %s\n", s.a, s.b, s.c);
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: program <integer> <float>\n");
        return 1;
    }
    
    int a = atoi(argv[1]);
    float b = atof(argv[2]);
    my_struct s = serialize(a, b, "example"); // Inline function call
    print_struct(s); // Inline function call

    char *c;
    deserialize(s, &a, &b, &c); // Inline function call
    printf("Deserialized: a=%d, b=%.2f, c=%s\n", a, b, c);
    free(c);
    
    return 0;
}