
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s hex_number base\n", argv[0]);
        return 1;
    }

    long int num = strtol(argv[1], NULL, 16);
    if (errno == ERANGE) {
        perror("strtol");
        return 2;
    }

    int base = atoi(argv[2]);
    switch (base) {
        case 2:
        case 8:
        case 16:
            break;
        default:
            printf("Invalid base. Only 2, 8 and 16 are allowed.\n");
            return 3;
    }

    char *result = malloc(sizeof(char) * 100); // allocate memory for the result string
    int i = 0;
    while (num != 0) {
        result[i++] = "0123456789ABCDEF"[num % base]; // convert and store each digit in result
        num /= base;
    }
    result[i--] = '\0'; // add null terminator at the end of the string

    for (int j = 0; j <= i/2; j++) {
        char temp = result[j];
        result[j] = result[i-j];
        result[i-j] = temp; // reverse the string to get correct order
    }

    printf("Converted number: %s\n", result);
    free(result);
    return 0;
}