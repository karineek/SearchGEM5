
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <locale.h>

double convert_to_double(const wchar_t *str) {
    double result;
    wchar_t *endptr;
    setlocale(LC_ALL, "");
    result = wcstod(str, &endptr);
    return result;
}

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }
    
    wchar_t *input = (wchar_t*) malloc((strlen(argv[1]) + 1) * sizeof(wchar_t));
    mbstowcs(input, argv[1], strlen(argv[1]) + 1);
    
    double result = convert_to_double(input);
    printf("Converted value: %.2f\n", result);
    
    free(input);
    return 0;
}