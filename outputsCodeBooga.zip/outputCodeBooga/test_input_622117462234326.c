
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    int i, sum = 0;

    if (argc != 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }

    for (i = 0; i < atoi(argv[1]); ++i) {
        sum += i;
    }

    printf("The sum of the first %d integers is: %d\n", atoi(argv[1]), sum);

    return 0;
}