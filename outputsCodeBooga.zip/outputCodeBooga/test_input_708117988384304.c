
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input_value>\n", argv[0]);
        return 1;
    }
    
    int input = atoi(argv[1]);
    
    if (input > 10) {
        printf("Input is greater than 10.\n");
    } else {
        printf("Input is less than or equal to 10.\n");
    }
    
    return 0;
}