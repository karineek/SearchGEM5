
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include <assert.h>
#include <string.h>

int main(int argc, char* argv[]) {
    assert(argc == 3);
    
    int n = atoi(argv[1]);
    int m = atoi(argv[2]);
    
    int A[n], B[n], C[n];
    
    for (int i=0; i<n; i++) {
        A[i] = rand() % m;
        B[i] = rand() % m;
    }
    
    struct timeval start, end;
    gettimeofday(&start, NULL);
    
    for (int i=0; i<n; i++) {
        C[i] = A[i] + B[i];
    }
    
    gettimeofday(&end, NULL);
    
    long seconds  = end.tv_sec  - start.tv_sec;
    long useconds = end.tv_usec - start.tv_usec;
    
    printf("Time taken: %ld seconds, %ld microseconds\n", seconds, useconds);
    
    for (int i=0; i<n; i++) {
        printf("%d + %d = %d\n", A[i], B[i], C[i]);
    }
    
    return 0;
}