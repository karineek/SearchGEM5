
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

double log1pl(double x) {
    return log(1.0 + x);
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: ./program <float_value>\n");
        return -1;
    }

    double input = strtod(argv[1], NULL);
    double result = log1pl(input);

    printf("Result: %.6f\n", result);

    return 0;
}