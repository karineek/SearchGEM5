
#include <stdio.h>
#include <string.h>
#include <wchar.h>
#include <locale.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <multibyte_character>\n", argv[0]);
        return 1;
    }
    
    setlocale(LC_ALL, "");
    
    mbstate_t state = {0};
    size_t len = mbrlen(argv[1], strlen(argv[1]), &state);
    
    if (len == (size_t)-2) {
        printf("Incomplete multibyte character\n");
    } else if (len == (size_t)-1) {
        printf("Invalid multibyte character\n");
    } else {
        printf("Multibyte character length: %zu\n", len);
    }
    
    return 0;
}