
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./dead_code_elimination <integer1> <integer2>\n");
        return 0;
    }

    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);
    int sum;

    // Dead Code Elimination: This code will be removed by the compiler during optimization
    if (num1 > 100) {
        printf("Number 1 is greater than 100\n");
    } else {
        printf("Number 1 is not greater than 100\n");
    }

    // Using fwscanf_s to read integers from command-line arguments and calculate their sum
    fwscanf_s(argv[1], "%d", &num1);
    fwscanf_s(argv[2], "%d", &num2);
    sum = num1 + num2;

    printf("Sum of %d and %d is: %d\n", num1, num2, sum);
    return 0;
}