
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return -1;
    }

    int num = atoi(argv[1]);
    
    // Decrement operators
    while (num > 0) {
        num--;
        printf("%d\n", num);
    }

    // Increment and decrement operators
    for (int i = 0; i < 5; ++i) {
        printf("%d ", i++);
        printf("%d\n", i--);
    }
    
    return 0;
}