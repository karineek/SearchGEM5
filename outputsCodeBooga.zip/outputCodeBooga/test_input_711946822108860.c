
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]) {
    double x;
    
    if (argc != 2) {
        printf("Usage: %s number\n", argv[0]);
        return 1;
    }

    x = atof(argv[1]);

    // Dead code elimination example
    if (x > 10) { // This condition will never be true because of the following optimization
        printf("x is greater than 10\n");
    } else {
        printf("x is less than or equal to 10\n");
    }

    // exp2l example
    double result = exp2(x);
    printf("exp2(%f) = %f\n", x, result);
    
    return 0;
}