
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv) {
    if (argc < 3) {
        printf("Usage: %s input1 input2\n", argv[0]);
        return 1;
    }
    
    const char *input1 = argv[1];
    const char *input2 = argv[2];
    
    if (strcmp(input1, "<::") == 0) {
        printf("Input1 is <::\n");
    } else {
        printf("Input1 is %s\n", input1);
    }
    
    if (strcmp(input2, "test") == 0) {
        printf("Input2 is test\n");
    } else {
        printf("Input2 is %s\n", input2);
    }
    
    return 0;
}