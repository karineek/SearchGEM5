
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s number\n", argv[0]);
        return 1;
    }

    intmax_t input = strtoimax(argv[1], NULL, 10);
    printf("Input as intmax_t: %" PRIdMAX "\n", input);
    return 0;
}