
#include <stdio.h>
#include <stdlib.h>
#include <stdalign.h> // Header file for aligned_alloc function
#include <assert.h>  // Header file for assert macro

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program <num1> <num2>\n");
        return -1;
    }

    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);

    // Common Subexpression Elimination optimization
    int multiplied = num1 * num2;

    // Allocate aligned memory using aligned_alloc function
    void* aligned_mem = aligned_alloc(alignof(max_align_t), sizeof(int));
    assert(aligned_mem != NULL && "Failed to allocate memory!");

    int* multiplied_ptr = (int*)aligned_mem;
    *multiplied_ptr = multiplied;

    printf("Multiplication result: %d\n", *multiplied_ptr);
    printf("Sum of the multiplication result and num1: %d\n", *multiplied_ptr + num1);

    free(aligned_mem);

    return 0;
}