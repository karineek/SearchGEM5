
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program exponent base\n");
        return 1;
    }

    double exponent = atof(argv[1]);
    double base = atof(argv[2]);

    for (int i = 0; i < 10; ++i) {
        base *= ldexp(base, exponent);
    }

    printf("%f\n", base);
    return 0;
}