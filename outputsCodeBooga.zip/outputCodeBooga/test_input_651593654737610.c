
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <format string>\n", argv[0]);
        return 1;
    }
    
    time_t currentTime = time(NULL);
    struct tm *localTime = localtime(&currentTime);
    
    char buffer[256];
    strftime(buffer, sizeof(buffer), argv[1], localTime);
    printf("Current time: %s\n", buffer);

    return 0;
}