
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main(int argc, char *argv[]) {
    int input;
    
    if (argc != 2) {
        printf("Please enter one integer argument.\n");
        return 1;
    }

    input = atoi(argv[1]);

    if (input < INT_MIN) {
        printf("Input is smaller than the minimum value of an int.\n");
        return 1;
    } else if (input > INT_MAX) {
        printf("Input is larger than the maximum value of an int.\n");
        return 1;
    }

    int min = input;

    for (int i = 2; i < argc; ++i) {
        int num = atoi(argv[i]);
        
        if (num < INT_MIN || num > INT_MAX) {
            printf("Invalid integer argument: %s\n", argv[i]);
            return 1;
        }

        if (num < min) {
            min = num;
        }
    }

    printf("The minimum value is: %d\n", min);
    return 0;
}