
#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s number\n", argv[0]);
        return 1;
    }
    
    double input_number = atof(argv[1]);
    double result = pow(input_number, LDBL_MIN_10_EXP);
    
    printf("Result: %.20f\n", result);
    
    return 0;
}