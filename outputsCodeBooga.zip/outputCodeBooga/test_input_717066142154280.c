
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

void add_arrays(int32_t *restrict a, int32_t *restrict b, int32_t *restrict result, size_t n) {
    for (size_t i = 0; i < n; ++i) {
        result[i] = a[i] + b[i];
    }
}

int main(int argc, char **argv) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <array1> <array2>\n", argv[0]);
        return EXIT_FAILURE;
    }

    size_t n = strlen(argv[1]) / sizeof(int32_t); // Assuming the input arrays are space separated integers
    
    int32_t *a = (int32_t *) malloc(n * sizeof(int32_t));
    int32_t *b = (int32_t *) malloc(n * sizeof(int32_t));
    int32_t *result = (int32_t *) malloc(n * sizeof(int32_t));
    
    if (!a || !b || !result) {
        fprintf(stderr, "Failed to allocate memory\n");
        return EXIT_FAILURE;
    }

    sscanf(argv[1], "%d %d %d %d %d %d %d %d %d %d %d %d", a, a+1, a+2, a+3, a+4, a+5, a+6, a+7, a+8, a+9);
    sscanf(argv[2], "%d %d %d %d %d %d %d %d %d %d %d", b, b+1, b+2, b+3, b+4, b+5, b+6, b+7, b+8, b+9);

    add_arrays(a, b, result, n);

    printf("Result: ");
    for (size_t i = 0; i < n; ++i) {
        printf("%d ", result[i]);
    }
    printf("\n");

    free(a);
    free(b);
    free(result);
    
    return EXIT_SUCCESS;
}