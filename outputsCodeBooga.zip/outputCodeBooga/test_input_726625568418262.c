
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input_string>\n", argv[0]);
        return 1;
    }

    // Memory Optimization: Using pointers instead of array to store input string
    char *input = argv[1];

    // Assembly and Bitcode: Printing the memory address of the variable
    printf("Memory Address of Input String: %p\n", (void *)&input);

    // Exercise getwchar(): Reading character by character from input string using getwchar()
    int c;
    while ((c = getwchar()) != EOF) {
        if (c == '\n') break;
        printf("Character: %c\n", c);
    }

    return 0;
}