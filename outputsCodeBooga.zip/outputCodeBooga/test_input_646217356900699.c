
#include <stdio.h> // for printf
#include <stdlib.h> // for exit
#include <pthread.h> // for pthread functions and data types

// define a function to be run in each thread
void* thread_func(void *arg) {
    int value = *((int*) arg); // get the input argument as an integer value
    printf("Thread %ld: received value %d\n", pthread_self(), value); // print thread ID and value

    // create a thread-specific storage key using tss_create
    pthread_key_t key;
    if (pthread_key_create(&key, NULL) != 0) {
        perror("Error creating TSS key");
        exit(1);
    }

    // set the value for this thread's key
    if (pthread_setspecific(key, &value) != 0) {
        perror("Error setting TSS value");
        exit(1);
    }

    // get the value for this thread's key and print it
    int* tss_value = pthread_getspecific(key);
    printf("Thread %ld: retrieved value %d from TSS\n", pthread_self(), *tss_value);

    return NULL; // exit the thread
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printf("Usage: %s <integer value>\n", argv[0]);
        exit(1);
    }

    int input_value = atoi(argv[1]); // convert the first argument to an integer

    pthread_t thread; // create a new thread
    if (pthread_create(&thread, NULL, thread_func, &input_value) != 0) {
        perror("Error creating thread");
        exit(1);
    }

    // wait for the thread to finish
    pthread_join(thread, NULL);

    return 0;
}