
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./program \"input_string\"\n");
        return -1;
    }

    char input[256];
    strcpy(input, argv[1]); // copy the command line argument to input array
    int len = strlen(input);

    int i = 0;
    while (i < len) {
        if (input[i] == 'a') { // scalar optimization: only compare once per iteration
            printf("Found 'a'\n");
            i++; // increment by 1 instead of 2 to improve performance
        } else {
            i += 2; // increment by 2 to skip every other character
        }
    }
    
    return 0;
}