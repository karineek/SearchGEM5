
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef enum {ADD, SUBTRACT, MULTIPLY, DIVIDE} OPERATION;

int perform_operation(int a, int b, OPERATION op) {
    switch (op) {
        case ADD:
            return a + b;
        case SUBTRACT:
            return a - b;
        case MULTIPLY:
            return a * b;
        case DIVIDE:
            if (b != 0) {
                return a / b;
            } else {
                printf("Error: Division by zero.\n");
                exit(1);
            }
    }
}

int main(int argc, char *argv[]) {
    if (argc < 4) {
        printf("Usage: %s <num1> <num2> <operation>\n", argv[0]);
        printf("<operation> can be 'add', 'subtract', 'multiply', or 'divide'.\n");
        return 1;
    }
    
    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);
    
    OPERATION op;
    if (strcmp(argv[3], "add") == 0) {
        op = ADD;
    } else if (strcmp(argv[3], "subtract") == 0) {
        op = SUBTRACT;
    } else if (strcmp(argv[3], "multiply") == 0) {
        op = MULTIPLY;
    } else if (strcmp(argv[3], "divide") == 0) {
        op = DIVIDE;
    } else {
        printf("Error: Invalid operation.\n");
        return 1;
    }
    
    int result = perform_operation(num1, num2, op);
    printf("%d %s %d = %d\n", num1, argv[3], num2, result);
    
    return 0;
}