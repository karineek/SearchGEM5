
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#include <tgmath.h>

// _Imaginary_I macro definition
#define _Imaginary_I (__extension__ 1.0iF)

void print_usage() {
    printf("Usage: ./program input\n");
}

double utility_function(double x) {
    return sqrt(x);
}

int main(int argc, char *argv[]) {
    // Check for correct number of arguments
    if (argc != 2) {
        print_usage();
        exit(1);
    }
    
    double input = atof(argv[1]);
    
    // Compute and print the square root of the input using utility function
    double result = utility_function(input);
    printf("Square root of %f: %f\n", input, result);
    
    // Calculate imaginary part of a complex number using _Imaginary_I macro
    double real_part = 3.0;
    double imag_part = 4.0 * _Imaginary_I;
    double complex c = real_part + imag_part;
    printf("Imaginary part of (%f + %fi): %f\n", creal(c), cimag(c), cimag(c));
    
    return 0;
}