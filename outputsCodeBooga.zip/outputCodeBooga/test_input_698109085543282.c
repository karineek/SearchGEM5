
#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

void vector_add(int n, float *__restrict__ a, float *__restrict__ b, float *__restrict__ c) {
    #pragma omp simd
    for (int i = 0; i < n; ++i) {
        c[i] = a[i] + b[i];
    }
}

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <n>\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    int n = atoi(argv[1]);
    float *a = (float *) malloc(n * sizeof(float));
    float *b = (float *) malloc(n * sizeof(float));
    float *c = (float *) malloc(n * sizeof(float));
    
    for (int i = 0; i < n; ++i) {
        a[i] = i + 1.0f;
        b[i] = i * 2.0f;
    }
    
    vector_add(n, a, b, c);
    
    for (int i = 0; i < n; ++i) {
        printf("%f + %f = %f\n", a[i], b[i], c[i]);
    }
    
    free(a);
    free(b);
    free(c);
    
    return EXIT_SUCCESS;
}