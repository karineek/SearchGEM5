
#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

// Type-generic macro for adding two values of different types
#define ADD(a, b) _Generic((a), \
    int: add_int, \
    double: add_double \
)(a, b)

int add_int(int a, int b) {
    return a + b;
}

double add_double(double a, double b) {
    return a + b;
}

// Summation algorithm using a serial loop
int sum_serial(const void *data, size_t n, size_t elem_size) {
    int sum = 0;
    const char *ptr = data;
    for (size_t i = 0; i < n; ++i) {
        sum = ADD(sum, *(int *)(ptr + i * elem_size));
    }
    return sum;
}

// Summation algorithm using a parallel loop with OpenMP
#ifdef _OPENMP
int sum_parallel(const void *data, size_t n, size_t elem_size) {
    int sum = 0;
    const char *ptr = data;
    #pragma omp parallel for reduction(+:sum)
    for (size_t i = 0; i < n; ++i) {
        sum = ADD(sum, *(int *)(ptr + i * elem_size));
    }
    return sum;
}
#endif

// Main function to run the program with input from argv
int main(int argc, char **argv) {
    if (argc < 3) {
        fprintf(stderr, "Usage: %s algorithm array_size\n", argv[0]);
        return EXIT_FAILURE;
    }

    const char *algorithm = argv[1];
    size_t n = atoi(argv[2]);

    int *array = malloc(n * sizeof(int));
    if (!array) {
        perror("malloc");
        return EXIT_FAILURE;
    }

    // Initialize the array with some values
    for (size_t i = 0; i < n; ++i) {
        array[i] = i + 1;
    }

    int (*sum_func)(const void *, size_t, size_t);
    if (!strcmp(algorithm, "serial")) {
        sum_func = sum_serial;
    } else if (!strcmp(algorithm, "parallel") && omp_get_num_procs() > 1) {
        sum_func = sum_parallel;
    } else {
        fprintf(stderr, "Invalid algorithm: %s\n", algorithm);
        return EXIT_FAILURE;
    }

    int sum = sum_func(array, n, sizeof(int));
    printf("Sum: %d\n", sum);

    free(array);
    return EXIT_SUCCESS;
}