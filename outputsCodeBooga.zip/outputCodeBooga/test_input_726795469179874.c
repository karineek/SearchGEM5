
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input_string>\n", argv[0]);
        return 1;
    }
    
    // Perform memory optimization using format flag
    int len = strlen(argv[1]);
    char *input = (char *) malloc((len + 1) * sizeof(char));
    if (input == NULL) {
        printf("Memory allocation failed.\n");
        return 1;
    }
    
    // Copy the input string to the dynamically allocated memory
    strncpy(input, argv[1], len);
    input[len] = '\0';

    // Print the input string using format flag for optimization
    printf("Input: %s\n", input);

    free(input);
    return 0;
}