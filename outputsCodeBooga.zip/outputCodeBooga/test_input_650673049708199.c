
#include <stdio.h>
#include <stdlib.h>

int multiply(int x, int y) {
    register int result = 0;
    __func__; // This keyword is used to get the name of the current function
    for (register int i = 0; i < y; i++) {
        result += x;
    }
    return result;
}

int main(int argc, char **argv) {
    if (argc != 3) {
        printf("Usage: %s <integer1> <integer2>\n", argv[0]);
        exit(1);
    }
    
    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);
    
    printf("%d * %d = %d\n", num1, num2, multiply(num1, num2));
    
    return 0;
}