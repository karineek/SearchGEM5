
#include <stdio.h>
#include <math.h>

// scalbn type-generic macro
#define scalbn(X, Y) _Generic((X), \
    float: scalbnf, \
    double: scalbn, \
    long double: scalbnl \
)(X, Y)

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <base> <exponent>\n", argv[0]);
        return 1;
    }
    
    double base = atof(argv[1]);
    int exponent = atoi(argv[2]);
    
    // Perform memory optimization using scalbn type-generic macro
    printf("Result: %f\n", scalbn(base, exponent));

    return 0;
}