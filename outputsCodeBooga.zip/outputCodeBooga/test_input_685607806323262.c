
#include <stdio.h>
#include <stdint.h>
#include <stdatomic.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program operand1 operand2\n");
        return 1;
    }

    int64_t op1 = strtoll(argv[1], NULL, 10);
    int64_t op2 = strtoll(argv[2], NULL, 10);
    
    // Constant folding optimization example:
    int64_t result = (op1 + op2) * 3 - 5;
    printf("Result of ((%ld + %ld) * 3 - 5): %ld\n", op1, op2, result);

    // atomic_int_least16_t example:
    atomic_int_least16_t counter = 0;
    for (int i = 0; i < 10000; ++i) {
        atomic_fetch_add(&counter, 1);
    }
    printf("Value of atomic counter: %d\n", atomic_load(&counter));
    
    return 0;
}