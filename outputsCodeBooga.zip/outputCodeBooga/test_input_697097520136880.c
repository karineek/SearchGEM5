
#include <stdio.h>
#include <fenv.h>
#include <math.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }
    
    double x = atof(argv[1]); // convert input string to double
    fenv_t env;           // environment variable for handling floating-point exceptions
    int ret;             // return value of function feholdexcept

    ret = feholdexcept(&env);  // store current FP exception state and disable exceptions
    if (ret != 0) {
        perror("feholdexcept");
        exit(EXIT_FAILURE);
    }

    double result = sqrt(x * x + x * x) / (x + x); // common subexpression: x*x occurs twice

    ret = fesetenv(&env);           // restore FP exception state to the one stored in env
    if (ret != 0) {
        perror("fesetenv");
        exit(EXIT_FAILURE);
    }

    printf("Result: %.16f\n", result);

    return 0;
}