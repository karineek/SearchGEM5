
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s binary_number\n", argv[0]);
        return 1;
    }

    unsigned long num = strtoul(argv[1], NULL, 2); // convert binary number to decimal from command line argument
    int bit_mask = 3; // binary: 11, for checking if the two least significant bits are set

    if ((num & bit_mask) == bit_mask) {
        printf("The two least significant bits of %lu (in binary: %s) are set.\n", num, argv[1]);
    } else {
        printf("The two least significant bits of %lu (in binary: %s) are not set.\n", num, argv[1]);
    }

    return 0;
}