
#include <stdio.h>
#include <stdlib.h>
#include <stdalign.h>
#include <string.h>
#include <stdint.h>
#include <immintrin.h> // For SIMD intrinsics

// Function to calculate the maximum value in an array of integers using SSE instructions
intmax_t max_sse(const int *arr, size_t n) {
    alignas(alignof(max_align_t)) intmax_t max = arr[0];
    __m128i *simd_arr = (__m128i*)__builtin_assume_aligned(arr, 16);
    
    for (size_t i = 0; i < n / 4; i++) {
        __m128i simd_max = _mm_max_epi32(_mm_loadu_si128(&simd_arr[i]), _mm_set1_epi32(INT_MIN));
        intmax_t temp_max = (intmax_t)_mm_extract_epi32(simd_max, 0);
        max = temp_max > max ? temp_max : max;
    }
    
    for (size_t i = n / 4 * 4; i < n; i++) {
        max = arr[i] > max ? arr[i] : max;
    }
    
    return max;
}

int main(int argc, char **argv) {
    if (argc <= 1) {
        printf("Usage: %s num1 num2 ...\n", argv[0]);
        return 1;
    }
    
    int *arr = malloc((argc - 1) * sizeof(int));
    for (int i = 1; i < argc; i++) {
        arr[i-1] = atoi(argv[i]);
    }
    
    intmax_t max = max_sse(arr, argc - 1);
    printf("Max value: %jd\n", (intmax_t)max);
    
    free(arr);
    return 0;
}