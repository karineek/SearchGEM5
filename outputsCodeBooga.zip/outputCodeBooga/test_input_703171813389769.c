
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

unsigned long long factorial(int n) {
    if (n <= 1) {
        return 1;
    }
    return n * factorial(n - 1);
}

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <number>\n", argv[0]);
        quick_exit(EXIT_FAILURE);
    }
    
    int n = atoi(argv[1]);
    if (n <= 1) {
        fprintf(stderr, "Error: Input must be greater than 1\n");
        quick_exit(EXIT_FAILURE);
    }
    
    unsigned long long result = factorial(n);
    printf("Factorial of %d is %llu\n", n, result);
    
    return EXIT_SUCCESS;
}