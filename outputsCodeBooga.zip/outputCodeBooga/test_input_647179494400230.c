
gcc -o program program program.c -pthread
./program "Hello World"