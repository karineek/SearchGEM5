
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <integer value>\n", argv[0]);
        return EXIT_FAILURE;
    }

    int input = atoi(argv[1]);
    atomic_int a = ATOMIC_VAR_INIT(input);
    int loaded_value = atomic_load_explicit(&a, memory_order_seq_cst);
    
    printf("Input value: %d\n", input);
    printf("Loaded value: %d\n", loaded_value);

    return EXIT_SUCCESS;
}