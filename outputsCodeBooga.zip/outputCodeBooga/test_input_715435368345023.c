
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./program <number>\n");
        return -1;
    }
    
    int number = atoi(argv[1]); // Convert input string to integer
    int square = number * number; // Calculate the square using scalar optimization
    printf("Square of %d is %d\n", number, square);
    
    return 0;
}