
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    // Check if the number of arguments is valid (should be 3)
    if (argc != 3) {
        printf("Invalid number of arguments.\n");
        return 1;
    }
    
    // Convert the command line arguments to integers
    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);

    // Check if the numbers are equal using Sparse Conditional Constant Propagation optimizations
    if (num1 == num2) {
        printf("The numbers are equal.\n");
    } else {
        printf("The numbers are not equal.\n");
    }
    
    return 0;
}