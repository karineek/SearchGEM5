
#include <stdio.h>
#include <inttypes.h>

static inline uint64_t multiply(uint32_t x, uint32_t y) {
    return (uint64_t)x * (uint64_t)y;
}

int main(int argc, char **argv) {
    if (argc != 3) {
        printf("Usage: %s <num1> <num2>\n", argv[0]);
        return 1;
    }

    uint32_t num1 = atoi(argv[1]);
    uint32_t num2 = atoi(argv[2]);

    uint64_t result = multiply(num1, num2);

    printf("The result of %" PRIuFAST32 " * %" PRIuFAST32 " is %" PRIuFAST64 "\n", num1, num2, result);

    return 0;
}