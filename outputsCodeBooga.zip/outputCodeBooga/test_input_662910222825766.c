
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {
    float x = atof(argv[1]);
    int n = atoi(argv[2]);
    
    printf("Result: %f\n", scalbnf(x, n));
    return 0;
}