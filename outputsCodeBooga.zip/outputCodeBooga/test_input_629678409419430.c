
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <errno.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input_text>\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    wchar_t *wstr = L"";
    mbstate_t state = {};
    size_t len = strlen(argv[1]) + 1;
    char *mbstr = (char *)malloc(len);

    // Convert wide string to multibyte string using wcrtomb_s
    for (size_t i = 0; i < len; ++i) {
        wstr[i] = argv[1][i];
        size_t ret = 0;
        errno_t err = wcrtomb_s(&ret, mbstr + i, len - i, wstr[i], &state);
        if (err != 0) {
            perror("wcrtomb_s");
            return EXIT_FAILURE;
        }
    }

    printf("Input: %s\n", argv[1]);
    printf("Output: %s\n", mbstr);
    
    free(mbstr);
    return EXIT_SUCCESS;
}