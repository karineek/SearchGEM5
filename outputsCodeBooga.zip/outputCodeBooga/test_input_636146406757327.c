
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    int sum = 0;
    
    if (argc == 1) {
        printf("No arguments provided.\n");
        return 1;
    }
    
    for (int i = 1; i < argc; i++) {
        char *endptr;
        int num = strtol(argv[i], &endptr, 10);
        
        if (*endptr != '\0') {
            printf("Invalid argument: %s\n", argv[i]);
            continue;
        }
        
        sum += num;
    }
    
    printf("Sum of arguments: %d\n", sum);
    return 0;
}