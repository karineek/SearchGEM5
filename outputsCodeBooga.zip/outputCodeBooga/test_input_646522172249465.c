
#include <stdio.h>
#include <stdarg.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        return -1;
    }
    
    int num;
    int result = vswscanf(argv[1], "%d", &num);
    
    if (result != 1) {
        printf("Invalid input\n");
        return -1;
    }
    
    char str_num[20];
    snprintf(str_num, sizeof(str_num), "%d", num);
    
    printf("String representation: %s\n", str_num);
    
    return 0;
}