
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./pgocosh <iterations>\n");
        return -1;
    }

    int iterations = atoi(argv[1]);
    double x = 0.5;

    for (int i = 0; i < iterations; ++i) {
        x += cosh(x);
    }

    printf("Result: %f\n", x);

    return 0;
}