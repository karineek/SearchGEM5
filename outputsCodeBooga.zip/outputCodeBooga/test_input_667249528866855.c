
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <number>\n", argv[0]);
        return 1;
    }

    char *endptr;
    float f = strtof(argv[1], &endptr);

    if (*endptr == '\0') {
        printf("%s is a valid floating point number.\n", argv[1]);
    } else {
        printf("%s is not a valid floating point number, so it must be an integer.\n", argv[1]);
    }

    return 0;
}