
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s [number]\n", argv[0]);
        return 1;
    }

    int n = atoi(argv[1]);
    int i, sum = 0;

    for (i = 0; i < n; i++) {
        sum += i * i;
    }

    printf("Sum of squares: %d\n", sum);

    sleep(5); // wait for 5 seconds
    return 0;
}