
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }

    int num = strtol(argv[1], NULL, 10);

    if (errno == ERANGE || endptr == argv[1] || *endptr != '\0') {
        printf("Invalid input\n");
        return 1;
    }

    if (num < 0) {
        printf("%d is negative.\n", num);
    } else if (num > 0) {
        printf("%d is positive.\n", num);
    } else {
        printf("Zero is neither positive nor negative.\n");
    }

    return 0;
}