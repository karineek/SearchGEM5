
#include <stdio.h>
#include <stdlib.h>
#include <stdatomic.h>
#include <threads.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <optimization_flag> <atomic_value>\n", argv[0]);
        return EXIT_FAILURE;
    }

    int optimization_flag = atoi(argv[1]);
    int atomic_value = atoi(argv[2]);

    if (optimization_flag == 1) {
        // Enable Profile-Guided Optimization
        printf("Profile-Guided Optimization is enabled\n");
    } else {
        // Disable Profile-Guided Optimization
        printf("Profile-Guided Optimization is disabled\n");
    }

    atomic_int a = ATOMIC_VAR_INIT(atomic_value);

    int loaded_value = atomic_load_explicit(&a, memory_order_relaxed);
    printf("The value loaded atomically is: %d\n", loaded_value);

    return EXIT_SUCCESS;
}