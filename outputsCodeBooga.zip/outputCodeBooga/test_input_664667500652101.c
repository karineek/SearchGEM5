
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }
    
    long double num = strtold(argv[1], NULL);
    long double sqrt_num = csqrtl(num);
    
    printf("Square root of %Lf: %Lf\n", num, sqrt_num);
    
    return 0;
}