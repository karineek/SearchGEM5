
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double fahrenheit_to_celsius(double f) {
    return (f - 32) * 5 / 9;
}

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: ./converter <temperature_in_fahrenheit>\n");
        return 1;
    }
    
    double fahrenheit = atof(argv[1]);
    double celsius = fahrenheit_to_celsius(fahrenheit);
    printf("%.2f Fahrenheit is %.2f Celsius\n", fahrenheit, celsius);

    return 0;
}