
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <immintrin.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s vector_size input_array\n", argv[0]);
        return -1;
    }

    int vec_size = atoi(argv[1]);
    if (vec_size <= 0 || vec_size > 8) {
        printf("Vector size should be between 1 and 8.\n");
        return -1;
    }

    char *input = argv[2];
    int len = strlen(input);
    if (len % vec_size != 0) {
        printf("Input length should be a multiple of vector size.\n");
        return -1;
    }

    __m256i *vecs = (__m256i *) malloc(len / vec_size * sizeof(__m256i));
    for (int i = 0; i < len; i += vec_size) {
        char buffer[9] = {0};
        strncpy(buffer, input + i, vec_size);
        __m256i v = _mm256_set1_epi8(*buffer); // This line triggers automatic vectorization
        memcpy(vecs + i / vec_size, &v, sizeof(__m256i));
    }

    for (int i = 0; i < len / vec_size; ++i) {
        __m256i v = vecs[i];
        char buffer[32];
        _mm256_storeu_si256((__m256i *)buffer, v); // This line handles LLVM bitcode
        printf("%s\n", buffer);
    }

    free(vecs);
    return 0;
}