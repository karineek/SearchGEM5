
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <loop_iteration_count> <space_flag>\n", argv[0]);
        return 1;
    }
    
    int iteration_count = atoi(argv[1]);
    char *space_flag = argv[2];

    for (int i = 0; i < iteration_count; i++) {
        printf("Iteration %d\n", i);
        
        if (strcmp(space_flag, "true") == 0) {
            printf("\n");
        }
    }
    
    return 0;
}