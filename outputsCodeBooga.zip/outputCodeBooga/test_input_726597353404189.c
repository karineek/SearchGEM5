
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

char* doubleToString(double num) {
    char *result;
    int length = snprintf(NULL, 0, "%f", num);
    result = malloc((length + 1) * sizeof(char));
    snprintf(result, length + 1, "%f", num);
    return result;
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printf("Usage: %s double_number\n", argv[0]);
        return -1;
    }
    double input = atof(argv[1]);
    char *output = doubleToString(input);
    printf("String representation of %f is %s\n", input, output);
    free(output);
    return 0;
}