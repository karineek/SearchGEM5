
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <x86intrin.h> // for SSE intrinsics

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <length> <repeat>\n", argv[0]);
        return -1;
    }

    int len = atoi(argv[1]);
    int repeat = atoi(argv[2]);

    float *a = (float*)_mm_malloc(len * sizeof(float), 32);
    float *b = (float*)_mm_malloc(len * sizeof(float), 32);
    float *c = (float*)_mm_malloc(len * sizeof(float), 32);

    for (int i = 0; i < len; i++) {
        a[i] = i + 1;
        b[i] = len - i;
    }

    for (int r = 0; r < repeat; r++) {
        for (int i = 0; i < len; i += 8) {
            __m256 av = _mm256_loadu_ps(a + i);
            __m256 bv = _mm256_loadu_ps(b + i);
            __m256 cv = _mm256_mul_ps(av, bv);
            _mm256_storeu_ps(c + i, cv);
        }
    }

    for (int i = 0; i < len; i++) {
        printf("c[%d] = %f\n", i, c[i]);
    }

    _mm_free(a);
    _mm_free(b);
    _mm_free(c);

    return 0;
}