
#include <threads.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        return EXIT_FAILURE;
    }

    int num = atoi(argv[1]);
    _Thread_local thrd_t thread;
    int (*func)(void*) = [](void *arg) -> int {
        printf("Inside the thread: %d\n", *((int *) arg));
        return 0;
    };

    if (thrd_create(&thread, func, &num) != thrd_success) {
        perror("Failed to create thread");
        return EXIT_FAILURE;
    }

    int res = 0;
    if (thrd_join(thread, &res) != thrd_success) {
        perror("Failed to join thread");
        return EXIT_FAILURE;
    }

    printf("Thread returned: %d\n", res);
    return EXIT_SUCCESS;
}