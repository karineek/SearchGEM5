
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s start end\n", argv[0]);
        return 1;
    }
    
    int start = atoi(argv[1]);
    int end = atoi(argv[2]);
    
    if (start > end) {
        int temp = start;
        start = end;
        end = temp;
    }
    
    long long sum = 0;
    for (int i = start; i <= end; ++i) {
        sum += (long long) pow(i, 2);
    }
    
    printf("Sum of squares from %d to %d: %lld\n", start, end, sum);
    return 0;
}