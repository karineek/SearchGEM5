
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <errno.h>

unsigned long convert_to_ulong(const wchar_t *str, wchar_t **endptr) {
    errno = 0;
    char *locale = setlocale(LC_ALL, "C");
    if (locale == NULL) {
        perror("setlocale");
        exit(EXIT_FAILURE);
    }

    unsigned long result = wcstoul(str, endptr, 10);
    
    if (errno != 0) {
        perror("wcstoul");
        exit(EXIT_FAILURE);
    }
    
    return result;
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s STRING\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    wchar_t *input = (wchar_t*)argv[1];
    wchar_t *endptr;
    unsigned long converted = convert_to_ulong(input, &endptr);
    
    printf("Converted string: %lu\n", converted);
    return 0;
}