
#include <stdio.h>
#include <stdatomic.h>
#include <stdlib.h>
#include <stdint.h>
#include <assert.h>

_Atomic int result = 0;

void calculate_popcount(uint32_t n) {
    if (__builtin_constant_p(n)) {
        result += __builtin_popcount(n);
    } else {
        int count = 0;
        while (n != 0) {
            count += n & 1;
            n >>= 1;
        }
        atomic_fetch_add(&result, count);
    }
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }

    uint32_t n = strtoul(argv[1], NULL, 0);
    calculate_popcount(n);
    
    int final_result = atomic_load(&result);
    printf("The number of set bits in %u is: %d\n", n, final_result);

    return 0;
}