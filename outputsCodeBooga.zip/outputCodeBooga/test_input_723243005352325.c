
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <float.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <magnitude> <sign>\n", argv[0]);
        return EXIT_FAILURE;
    }

    long double magnitude = strtold(argv[1], NULL);
    long double sign = strtold(argv[2], NULL);

    if (isnanl(magnitude) || isnanl(sign)) {
        printf("Error: NaN value provided.\n");
        return EXIT_FAILURE;
    }

    long double result = copysignl(magnitude, sign);
    printf("%Lg\n", result);

    return EXIT_SUCCESS;
}