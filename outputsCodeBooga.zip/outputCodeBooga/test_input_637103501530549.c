
#include <stdio.h>
#include <stdlib.h>

int add(int a, int b) {
    return a + b;
}

int add_specialized(int a, int b) __attribute__((always_inline));
int add_specialized(int a, int b) {
    return a; // When b is 0, simply return a instead of adding
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <num1> <num2>\n", argv[0]);
        exit(1);
    }

    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);

    if (num2 == 0) {
        printf("%d + %d = %d\n", num1, num2, add_specialized(num1, num2));
    } else {
        printf("%d + %d = %d\n", num1, num2, add(num1, num2));
    }

    return 0;
}