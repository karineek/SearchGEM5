
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// typedef declaration for a custom data type
typedef struct {
    int x;
    int y;
} Point;

int main(int argc, char *argv[]) {
    // Check if the input is valid
    if (argc != 3) {
        printf("Usage: ./program <x> <y>\n");
        return 1;
    }

    // Convert the input strings to integers
    int x = atoi(argv[1]);
    int y = atoi(argv[2]);

    // Create a Point structure and initialize it with the input values
    Point p = {x, y};

    // Print the sum of the coordinates
    printf("The sum of (%d, %d) is: %d\n", x, y, x + y);

    return 0;
}