
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <wchar.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s NUMBER\n", argv[0]);
        return 1;
    }

    wchar_t *endptr;
    unsigned long long number = wcstoull(argv[1], &endptr, 10);
    
    if (*endptr != '\0') {
        printf("Invalid input: %s\n", argv[1]);
        return 2;
    }

    printf("%" PRIuMAX "\n", number);
    return 0;
}