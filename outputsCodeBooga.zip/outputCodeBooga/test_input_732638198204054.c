
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

int add(int a, int b) {
    return a + b;
}

int multiply(int c, int d) {
    return c * d;
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        printf("Usage: %s <num1> <num2>\n", argv[0]);
        exit(1);
    }

    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);
    
    printf("Addition: %d\n", add(num1, num2));
    printf("Multiplication: %d\n", multiply(num1, num2));

    return 0;
}