
#include <stdio.h>
#include <inttypes.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }

    uint64_t input = strtoull(argv[1], NULL, 10);
    printf("The input number is: %" PRIuFAST64 "\n", input);
    return 0;
}