
#include <stdio.h>
#include <stdbool.h>
#include <ctype.h>

// Macro to check if a given value is an integer
#define IS_INTEGER(value) (((value) == ((int)(value))) ? true : false)

// Macro to check if a given value is a float
#define IS_FLOAT(value) (((value) != ((int)(value)) && (value) == ((float)(value)) ? true : false)

// Macro to check if a given value is a double
#define IS_DOUBLE(value) (((value) != ((int)(value) && (value) != ((float)(value)) && (value) == ((double)(value)) ? true : false)

int main(int argc, char *argv[]) {
    if(argc < 2){
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }
    
    double input = atof(argv[1]);
    
    if(IS_INTEGER(input)){
        printf("%s is an integer\n", argv[1]);
    } else if (IS_FLOAT(input)){
        printf("%s is a float\n", argv[1]);
    } else if (IS_DOUBLE(input)){
        printf("%s is a double\n", argv[1]);
    } else {
        printf("Invalid number: %s\n", argv[1]);
    }
    
    return 0;
}