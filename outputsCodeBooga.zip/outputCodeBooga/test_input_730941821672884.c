
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

int main(int argc, char *argv[]) {
    int sum = 0;
    for (int i = 1; i < argc; ++i) {
        // Check if argument is an integer
        if (!isdigit(*argv[i])) {
            printf("Invalid input: %s\n", argv[i]);
            continue;
        }
        
        int num = atoi(argv[i]);
        sum += num;
    }
    
    printf("Sum of all integers: %d\n", sum);
    return 0;
}