
#include <stdio.h>
#include <stdlib.h>
#include <complex.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s a+bi c+di\n", argv[0]);
        return 1;
    }

    double real1, imag1, real2, imag2;
    sscanf(argv[1], "%lf%*[+-]%lfi", &real1, &imag1); // input format: a+bi
    sscanf(argv[2], "%lf%*[+-]%lfi", &real2, &imag2); // input format: c+di

    _Complex double complex_num1 = real1 + imag1 * _Complex_I;
    _Complex double complex_num2 = real2 + imag2 * _Complex_I;

    printf("Input: %s + %s\n", argv[1], argv[2]);

    _Complex double sum = complex_num1 + complex_num2;
    _Complex double diff = complex_num1 - complex_num2;
    _Complex double prod = complex_num1 * complex_num2;
    _Complex double quot = complex_num1 / complex_num2;

    printf("Sum: %f + %fi\n", creal(sum), cimag(sum));
    printf("Difference: %f + %fi\n", creal(diff), cimag(diff));
    printf("Product: %f + %fi\n", creal(prod), cimag(prod));
    printf("Quotient: %f + %fi\n", creal(quot), cimag(quot));

    return 0;
}