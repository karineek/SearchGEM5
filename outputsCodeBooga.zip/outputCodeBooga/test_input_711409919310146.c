
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "localization_header.h" // Custom localization header

int main(int argc, char **argv) {
    int n = atoi(argv[1]); // Get array size from command line argument
    int *arr = (int*) malloc(n * sizeof(int));
    for (int i = 0; i < n; i++) arr[i] = rand() % 100 + 1; // Fill array with random numbers between 1 and 100

    int sum = 0;
    clock_t start = clock();
    for (int i = 0; i < n; i++) {
        sum += arr[i]; // Loop to vectorize
    }
    clock_t end = clock();

    printf("Sum: %d\n", sum);
    printf("Time taken: %.6f seconds\n", (double)(end - start) / CLOCKS_PER_SEC);
    free(arr);

    // Call function from localization header
    print_localized_string();
    return 0;
}