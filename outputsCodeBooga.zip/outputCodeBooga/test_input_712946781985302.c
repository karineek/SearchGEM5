
#include <stdio.h>
#include <x86intrin.h> // For SSE intrinsics

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s num1 num2\n", argv[0]);
        return -1;
    }

    double a = atof(argv[1]);
    double b = atof(argv[2]);

    // Load the input values into SSE registers
    __m128d va = _mm_set1_pd(a);
    __m128d vb = _mm_set1_pd(b);

    // Square each value using SSE multiplication instruction (vmulpd)
    __m128d square_a = _mm_mul_pd(va, va);
    __m128d square_b = _mm_mul_pd(vb, vb);

    // Add the squared values using SSE addition instruction (vaddpd)
    __m128d sum = _mm_add_pd(square_a, square_b);

    // Store the result back to memory and print it
    double result[2];
    _mm_storeu_pd(result, sum);

    printf("The sum of squares is: %f\n", result[0]);

    return 0;
}