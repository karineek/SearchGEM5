
#include <stdio.h>
#include <stdlib.h>
#include <stdatomic.h>
#include <inttypes.h>

atomic_ushort sum(atomic_ushort a, atomic_ushort b) {
    return a + b;
}

int main(int argc, char **argv) {
    if (argc != 3) {
        printf("Usage: ./program <num1> <num2>\n");
        exit(EXIT_FAILURE);
    }
    
    atomic_ushort num1 = strtoul(argv[1], NULL, 10);
    atomic_ushort num2 = strtoul(argv[2], NULL, 10);
    
    printf("Sum: %" PRIuFAST16 "\n", sum(num1, num2));
    
    return EXIT_SUCCESS;
}