
#include <stdio.h>
#include <stdbool.h>
#include <inttypes.h>
#include <stdlib.h>

// function to check if a number is even or odd
bool is_even(int_least8_t num) {
    return (num % 2 == 0);
}

// function to calculate the sum of all command line arguments
int_least8_t calculate_sum(int argc, char *argv[]) {
    int_least8_t sum = 0;
    for (int i = 1; i < argc; i++) {
        sum += atoi(argv[i]);
    }
    return sum;
}

// main function
int main(int argc, char *argv[]) {
    int_least8_t sum = calculate_sum(argc, argv);
    bool even = is_even(sum);

    printf("The sum of the input numbers is: %" PRId8 "\n", sum);
    if (even) {
        printf("The sum is even.\n");
    } else {
        printf("The sum is odd.\n");
    }
    
    return 0;
}