
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <wchar.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s string1 string2\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    setlocale(LC_ALL, ""); // Use user's default locale for sorting rules

    wchar_t *wstr1 = mbstowcs(NULL, argv[1], 0);
    if (wstr1 == NULL) {
        perror("mbstowcs");
        return EXIT_FAILURE;
    }

    wchar_t *wstr2 = mbstowcs(NULL, argv[2], 0);
    if (wstr2 == NULL) {
        perror("mbstowcs");
        free(wstr1);
        return EXIT_FAILURE;
    }

    int result = wcscoll(wstr1, wstr2);
    
    if (result < 0) {
        printf("%ls is less than %ls\n", wstr1, wstr2);
    } else if (result > 0) {
        printf("%ls is greater than %ls\n", wstr1, wstr2);
    } else {
        printf("%ls is equal to %ls\n", wstr1, wstr2);
    }
    
    free(wstr1);
    free(wstr2);

    return EXIT_SUCCESS;
}