
// Program to calculate natural logarithm of a given number
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {
    double x;
    
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }
    
    // Convert the input string to a double value
    sscanf(argv[1], "%lf", &x);

    if (x <= 0) {
        printf("Error: Input must be a positive number.\n");
        return 1;
    }

    // Calculate natural logarithm using clogl function
    double result = clogl(x);

    printf("The natural logarithm of %f is %f\n", x, result);
    
    return 0;
}