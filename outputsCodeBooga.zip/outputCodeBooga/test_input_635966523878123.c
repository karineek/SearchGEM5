
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program <num1> <num2>\n");
        return 1;
    }

    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);

    // Common Subexpression Elimination example
    int sum = num1 + num2;
    int diff = num1 - num2;
    printf("Sum: %d, Difference: %d\n", sum, diff);

    // INT_LEASTN_MIN macro example
    int min_int8 = INT_LEAST8_MIN;
    int min_int16 = INT_LEAST16_MIN;
    int min_int32 = INT_LEAST32_MIN;
    printf("Minimum values for INT_LEAST8: %d, INT_LEAST16: %d, INT_LEAST32: %d\n", min_int8, min_int16, min_int32);

    return 0;
}