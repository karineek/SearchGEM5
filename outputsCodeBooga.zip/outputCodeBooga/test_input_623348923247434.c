
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <locale.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s string\n", argv[0]);
        return 1;
    }

    setlocale(LC_ALL, "");
    wchar_t *input = (wchar_t *)argv[1];
    size_t len = wcslen(input);
    
    for (size_t i = 0; i < len - 1; ++i) {
        for (size_t j = i + 1; j < len; ++j) {
            if (towlower(input[i]) == towlower(input[j])) {
                printf("Loop fusion optimization detected: %lc\n", input[i]);
            }
        }
    }
    
    for (size_t i = 0; i < len - 1; ++i) {
        for (size_t j = i + 1; j < len; ++j) {
            if (input[i] == input[j]) {
                printf("Object file manipulation: %lc\n", input[i]);
            }
        }
    }
    
    return 0;
}