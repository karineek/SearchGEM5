
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s number\n", argv[0]);
        return 1;
    }
    
    double x = strtod(argv[1], NULL);
    double y = tanh(x);
    printf("%f\n", y);
    return 0;
}