
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// Type-generic pow macro
#define POW(x, y) _Generic((y), \
    int: (int)pow((double)(x), (double)(y)), \
    float: powf(x, y), \
    double: pow(x, y))

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <base> <exponent>\n", argv[0]);
        return 1;
    }

    double base = atof(argv[1]);
    int exponent_int = atoi(argv[2]);
    float exponent_float = (float)atof(argv[2]);
    
    // Common Subexpression Elimination example
    double result = POW(base, exponent_int);
    printf("The power of %.2f raised to %d is: %.2f\n", base, exponent_int, result);
    
    result = POW(base, exponent_float);
    printf("The power of %.2f raised to %.2f is: %.2f\n", base, exponent_float, result);

    return 0;
}