
#include <stdio.h>
#include <ctype.h>

int main() {
    char argv[1024], input[1024];
    int i = 0, j = 0;
    
    printf("Enter a BASH command (without quotes): ");
    scanf("%s", &argv[i]);
    
    while (!feof(stdin)) {
        if (*(argc + j) == '\n') {
            input[j] = '\0';
            i = 0;
            break;
        } else if (isspace(*(argc + j))) {
            continue;
        } else {
            input[j++] = *(argc + j);
        }
    }
    
    printf("Enter a BASH command: ");
    scanf("%s", &argv[i]);
    
    return 0;
}