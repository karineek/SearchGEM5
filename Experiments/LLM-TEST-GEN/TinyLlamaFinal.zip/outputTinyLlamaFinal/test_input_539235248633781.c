
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "solver.h"

int main(int argc, char **argv) {
    int n, k, result, i, j;
    double min, max_sum = 0.0;
    char a[100] = "";
    
    if (argc != 3) {
        fprintf(stderr, "Usage: %s N K\n", argv[0]);
        return EXIT_FAILURE;
    } else if (atoi(argv[2]) < 1 || atoi(argv[2]) > n) {
        fprintf(stderr, "Invalid value for N or K\n");
        exit(EXIT_FAILURE);
    } else {
        n = atoi(argv[2]);
        k = atoi(argv[1]);
        
        if (n <= 0 || k <= 0) {
            fprintf(stderr, "Invalid value for N or K\n");
            exit(EXIT_FAILURE);
        } else if (k > n) {
            fprintf(stderr, "K is greater than N\n");
            exit(EXIT_FAILURE);
        } else if (k == 1 && n <= 2) {
            printf("BASH problem with input via argv only: %d, %d\n", n, k);
            return EXIT_SUCCESS;
        }
    }
    
    if (n < k || k < min(n, max(k))) {
        fprintf(stderr, "K is greater than N but not smaller than the minimum possible value for both input values\n");
        return EXIT_FAILURE;
    } else {
        printf("BASH problem with input via argv only: %d, %d\n", n, k);
    }
    
    min = 0.0;
    max_sum = max(min_sum, 0.0);
    
    for (i = 1; i <= k; i++) {
        if (min > max_sum) {
            break;
        } else if (max_sum < min + 1e-9) {
            min = max_sum;
        }
        
        for (j = 1; j <= n - k + i; j++) {
            strcpy(a, argv[0]);
            
            for (i = 0; I < j; i++) {
                a[i] = tolower((int) a[i]);
            }
            
            result = solver(atoi(argv[1]), atoi(argv[2]), atoi(argv[3]));
            if (result != -1) {
                min_sum += result;
            } else if (result < 0) {
                fprintf(stderr, "Invalid value for N or K\n");
                exit(EXIT_FAILURE);
            } else {
                printf("BASH problem with input via argv only: %d, %d, %d\n", n, k, result);
            }
        }
    }
    
    return EXIT_SUCCESS;
}