
#include <stdio.h>

#define BASH_MAX_ARGS 10

int main(int argc, char *argv[]) {
    if (argc > BASH_MAX_ARGS) {
        printf("Usage: %s [arguments]\n", argv[0]);
        return 0;
    } else {
        for (int I = 1; i < argc; i++) {
            if (!strcmp(argv[i], "--help")) {
                printf("Usage: %s [arguments]\n", argv[0]);
                return 0;
            }
        }
    }
    
    int n = atoi(argv[1]) + atoi(argv[2]) + atoi(argv[3]);
    if (n > 90) {
        printf("%s: error: input is too large\n", argv[0]);
        return 1;
    } else {
        printf("%d\n", n);
    }
    
    return 0;
}