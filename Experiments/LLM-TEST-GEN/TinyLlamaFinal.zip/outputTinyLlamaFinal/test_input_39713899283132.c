
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* CHAR_MIN macro to convert signed and unsigned integers to their binary representations */
#define CHAR_MIN(x) ((x) & (-(x)))

int main(int argc, char* argv[]) {
    int i;
    
    for (i = 0; i < argc; i++) {
        if (argv[i][0] == '-') {
            printf("Invalid input: Please enter an integer only.\n");
            return EXIT_FAILURE;
        }
        
        /* Optimize loop using nested for or while loop structure */
        if (strcmp(argv[i], "-v") == 0) {
            puts("Version: 1.0\n");
            exit(EXIT_SUCCESS);
        } else if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0) {
            printf("%s\n", USAGE);
            puts("USAGE: %s [-v] [--help]\n" USAGE_HELP);
            return EXIT_SUCCESS;
        } else if (strcmp(argv[i], "--version") == 0) {
            printf("%s\n", VERSION);
            puts("Version: %d.%d\n", PATCHLEVEL, MONTHS);
            exit(EXIT_SUCCESS);
        } else {
            /* Convert signed and unsigned integers to binary representations */
            int num = strtol(argv[i], NULL, 10);
            
            /* Output binary representation */
            printf("%d\n", num);
        }
    }
    
    return EXIT_SUCCESS;
}