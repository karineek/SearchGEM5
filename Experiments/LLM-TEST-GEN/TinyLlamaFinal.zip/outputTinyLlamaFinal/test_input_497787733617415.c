
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

typedef void (*thread_t)(void*);

int main(int argc, char**argv) {
    if (argc != 2) {
        fprintf(stderr,"Usage: %s filename\n", argv[0]);
        exit(1);
    }
    
    FILE *input = fopen(argv[1], "r");
    char buffer[4096];
    if (!input) {
        perror("Failed to open file");
        return 1;
    }
    size_t size = fread(buffer, 1, sizeof(buffer), input);
    
    pthread_t tid;
    pthread_create(&tid, NULL, (void *(*)(void*))thread_fn, &input);
    
    int ret = pthread_join(tid, NULL);
    fclose(input);
    
    if (!ret) {
        perror("Failed to join thread");
        exit(1);
    }
    
    return 0;
}

void *thread_fn(void* input) {
    char buffer[4096];
    FILE *input_ = (FILE *)input;
    while (fread(buffer, 1, sizeof(buffer), input_) != 0) {}
    
    fclose(input);
}