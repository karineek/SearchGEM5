
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s [command]\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    switch (strcmp(argv[1], "help")) {
        case 0:
            printf("Here are some examples of BASH commands:\n\n");
            printf("  1. echo 'hello world'\n"
                   "  2. echo 'whoami'                     # current user name\n"
                   "  3. echo 'ls -l /home/*'                # list contents of home directory with extension.\n"
                   "  4. echo 'date > /tmp/log'              # write date to file in current directory.\n"
                   "  5. echo 'grep 'hello world' /path/to/*' # grep for 'hello world' and print its matching line(s).\n"
                   "  6. echo 'time -a | awk '{print $8}'' # time command with args, convert to seconds, extract last word.\n"
                   "  7. echo 'sort /path/to/*.txt | awk '{print $1}'' # sort file(s) by first field, replace commas with spaces.\n"
                   "  8. echo 'echo $USER'                     # get current user name.\n\n"
            ;
            
            return EXIT_SUCCESS;
        
        default:
            fprintf(stderr, "%s: unknown command %s\n", argv[0], argv[1]);
            return EXIT_FAILURE;
    }
}