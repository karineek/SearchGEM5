
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    int a = atoi(argv[1]);
    int b = atoi(argv[2]);
    int max_value;
    
    if (a > b) {
        max_value = a;
    } else {
        max_value = b;
    }
    
    printf("%d is the maximum value between %d and %d.\n", max_value, a, b);
    
    return 0;
}