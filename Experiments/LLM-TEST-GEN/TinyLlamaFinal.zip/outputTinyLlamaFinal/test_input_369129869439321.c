
#include <stdio.h>
#include <stdlib.h>
#define MAXLINE 1024

int main(int argc, char *argv[]) {
    FILE *fp;
    int line = 0, col = 0;
    char buffer[MAXLINE];
    char linebuf[MAXLINE][256];
    char *lineptr;
    
    if (argc != 3 || argv[1] == NULL) {
        printf("Usage: %s <input.bsh> [output.txt]\n", argv[0]);
        return 1;
    }
    fp = fopen(argv[1], "r");
    if (!fp) {
        perror("Error: Cannot open input file\n");
        return 2;
    }
    
    while (fgets(buffer, sizeof(buffer), fp)) {
        line++; // incrementing the line counter
        col = 0; // resetting the column counter
        
        for (lineptr = buffer; *lineptr != '\0'; lineptr++) {
            if (*lineptr == '!') { // found a comment line
                line++; // incrementing the line counter again
                col = 0; // resetting the column counter again
                continue;
            } else if ((*lineptr >= 'a' && *lineptr <= 'z') ||
                        (*lineptr >= 'A' && *lineptr <= 'Z') ||
                        (*lineptr == '\t')) { // found a whitespace or tab line
                col++; // incrementing the column counter again
            } else if (*lineptr == '\n') {
                line--; // decrementing the line counter again
            } else if (!isspace(*lineptr)) { // found a non-space character
                printf("Error: Cannot parse input file\n");
                return 3;
            }
        }
        
        sprintf(linebuf[++line - 1], "%d %d", line, col);
        if (col > 0) { // check for non-empty lines
            fputs(linebuf[line - 1], stdout);
        } else {
            printf("Error: Cannot parse input file\n");
            return 3;
        }
    }
    
    fclose(fp);
    
    return 0;
}