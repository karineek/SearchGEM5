
#include <stdio.h>

int main() {
    int c;
    
    while ((c = getchar()) != EOF) {
        if ('a' <= c && c <= 'z') {
            printf("%c", c);
        } else {
            puts("Error: input not in alphabet.\n");
        }
    }
    
    return 0;
}