
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        exit(1);
    }

    FILE *file = fopen(argv[1], "r");
    if (!file) {
        perror("Failed to open file");
        exit(1);
    }

    fseek(file, 0, SEEK_END);
    long size = ftell(file);
    rewind(file);
    
    char *buffer = malloc(size + 1);
    if (!buffer) {
        perror("Failed to allocate buffer");
        exit(1);
    }

    fread(buffer, 1, size, file);

    fclose(file);
    free(buffer);

    printf("Read %ld bytes from file\n", (long) size);

    return 0;
}