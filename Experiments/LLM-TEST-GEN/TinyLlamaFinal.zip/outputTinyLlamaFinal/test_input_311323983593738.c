
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // Read arguments from commandline
    if (argc < 2) {
        printf("Usage: %s [file] [arguments]\n", argv[0]);
        return 1;
    }
    
    // Define variables to store input file name, and output file name
    char input_filename[512];
    char output_filename[512];
    
    // Set up command line arguments (including file names)
    for (int I = 0; I < argc; i++) {
        if (i > 1 && strcmp(argv[i], "-h") == 0) {
            printf("Usage: %s [file] [arguments]\n", argv[0]);
            return 0;
        }
        
        sprintf(input_filename, "%s%d.txt", argv[i], ++i);
        sprintf(output_filename, "%s%d.out", argv[i], ++i);
    }
    
    // Read input file and store as string array
    int input_file = 0;
    char *input_line = NULL;
    for (int I = 0; ; i++) {
        sprintf(input_filename, "%s%d.txt", argv[i], ++i);
        
        // Read input file as string array
        FILE *file = fopen(input_filename, "r");
        if (!file) {
            printf("Failed to open input file %s\n", input_filename);
            return 1;
        }
        
        // Set input file index
        input_file = i;
        
        // Read line and store as string array
        while (fgets(input_line, sizeof(input_line), file)) {
            int I = strlen(input_filename);
            sprintf(output_filename, "%s%d.out", argv[i], ++i);
            
            // Write line to output file
            FILE *output_file = fopen(output_filename, "w");
            if (!output_file) {
                printf("Failed to open output file %s\n", output_filename);
                return 1;
            }
            fputs(input_line, output_file);
            
            // Close input and output files
            if (i != input_file) {
                fclose(input_file);
                input_file = i;
            }
        }
        
        // Clean up input file handle
        fclose(file);
    }
    
    return 0;
}