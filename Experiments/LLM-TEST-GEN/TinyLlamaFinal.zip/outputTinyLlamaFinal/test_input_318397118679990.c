
#include <stdio.h>
#include <stdlib.h> // For exit function

int main() {
    int argc;
    char *argv[10]; // Maximum 9 arguments allowed
    argv[0] = "arg"; // First argument is reserved for executable name
    argc = sizeof(argv) / sizeof(char*); // Calculate number of args
    if (argc > 1) {
        for (int I = 0; I < argc; i++) {
            printf("%s\n", argv[i]); // Print arguments
        }
        exit(EXIT_SUCCESS); // Call exit function to terminate the program
    } else {
        printf("Error: Invalid number of arguments\n");
        return 1;
    }
}