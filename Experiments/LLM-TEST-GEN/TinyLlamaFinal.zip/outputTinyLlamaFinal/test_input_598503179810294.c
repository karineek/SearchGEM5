
#include <stdio.h>
#include <stdlib.h> // For exit() function
#include "profilegui.h" // This is the library that exposes Profile-Guiided instrumentation

int main(int argc, char *argv[]) {
    int pid;
    if (argc != 2) {
        printf("Usage: %s <pid>\n", argv[0]);
        exit(1);
    }
    
    pid = atoi(argv[1]);

    // This function triggers SCNx, which will call the callback function specified in "profile_callback"
    profile_trigger(pid);

    return 0;
}