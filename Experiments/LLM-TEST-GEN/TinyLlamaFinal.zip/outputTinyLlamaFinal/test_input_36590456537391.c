
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Expected a single argument: input file\n");
        return EXIT_FAILURE;
    }
    
    char filename[100];
    strcpy(filename, argv[1]);
    
    FILE *input = fopen(filename, "r");
    if (!input) {
        fprintf(stderr, "Error opening input file: %s\n", filename);
        return EXIT_FAILURE;
    }
    
    int n = 0;
    while (fscanf(input, "%d", &n) == 1 && n > 0) {
        printf("%.20g ", cacosh(n));
        n++; // skip over next input
    }
    fclose(input);
    
    return EXIT_SUCCESS;
}