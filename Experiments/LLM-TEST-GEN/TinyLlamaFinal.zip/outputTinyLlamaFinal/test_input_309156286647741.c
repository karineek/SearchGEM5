
#include <stdio.h> /* for printf */

int main(int argc, char **argv) {
    int a = 10;
    float b = 2.5f;
    
    if (argc == 3 && !strcmp(argv[1], "BASH")) {
        printf("Input: %s\n", argv[2]);
        
        /* Inliner Heuriests */
        a = inline_heuristics(a);
        b = inline_heuristics(b);
        
        printf("Inline results: %d %f\n", a, b);
    } else {
        printf("Usage: BASH <input>\n");
        return 1; /* exit program */
    }
    
    return 0;
}