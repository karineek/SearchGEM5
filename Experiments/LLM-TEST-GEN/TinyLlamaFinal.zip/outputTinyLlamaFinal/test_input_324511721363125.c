
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_ARG 30

int main(int argc, char* argv[]) {
    // Get input and check validity
    if (argc > MAX_ARG) {
        printf("Error: Too many arguments.\n");
        return 1;
    } else {
        for (int I = 0; I < argc; i++) {
            if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) {
                printf("Usage: %s [options] [args...]\n", argv[0]);
                printf("\nOptions:\n");
                printf("-h\tPrint this help.\n");
                printf("-H\trestore options to be used by BASH.\n");
            } else if (!strcmp(argv[i], "-H") || !strcmp(argv[i], "--store")) {
                // Store options in memory for replay later (for example)
                puts("Options stored. Use -h or --help to restore them.");
            } else if (!strcmp(argv[i], "--no-store") || !strcmp(argv[i], "-nosh")) {
                // Clear options from memory (to clear memory cache)
                memset(&argv[i][0], 0, sizeof(char)*MAX_ARG);
            } else if (!strcmp(argv[i], "--store-args") || !strcmp(argv[i], "-s")) {
                // Store args (separated by space) for replay later (for example)
                char* storeArgs = malloc(MAX_ARG * sizeof(char));
                int I;
                for (I = 0; I < argc; i++) {
                    if (!strcmp(argv[i], "--help") || !strcmp(argv[i], "-h")) {
                        storeArgs[i] = '?';
                    } else if (!strcmp(argv[i], "--store") || !strcmp(argv[i], "-s")) {
                        // Store options in memory for replay later (for example)
                        puts("Options stored. Use -h or --help to restore them.");
                    } else if (!strcmp(argv[i], "--no-store") || !strcmp(argv[i], "-nosh")) {
                        // Clear options from memory (to clear memory cache)
                        memset(&storeArgs[0], 0, sizeof(char)*MAX_ARG);
                    } else if (!strcmp(argv[i], "--args=")) {
                        for (int j = I+1; j < argc; j++) {
                            storeArgs[j-I-1] = argv[j][0];
                        }
                    } else {
                        printf("Error: Invalid option.\n");
                        return 1;
                    }
                }
                // Clear memory cache
                free(storeArgs);
            } else {
                printf("Error: Unknown option. Exiting.\n");
                return 1;
            }
        }
        puts("Command line arguments processed.\n");
        system(argv[0]);
    }
    return 0;
}