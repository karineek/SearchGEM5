
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s filename\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    FILE *input = fopen(argv[1], "r");
    if (!input) {
        perror("Failed to open input file");
        exit(EXIT_FAILURE);
    }
    
    size_t line_size = 0;
    size_t col_size = 0;
    char *buffer = NULL;
    int line, column;
    
    while ((line = fgets(buffer, sizeof(buffer), input)) != nullptr) {
        if (col_size == 0) { // first row of data
            line_size = strlen(line);
            col_size = 1 + line_size / 4; // max 3 columns for aligned alignemnt
        } else {
            int x;
            while ((x = getw(input)) != EOF) {
                if (col_size > 1 && col_size * 4 < line_size) { // keep row aligned with buffer
                    col_size = 1 + line_size / (col_size * 4);
                    x &= 0xfffffffe; // clear unused bits to zero
                }
                putw(buffer, x);
            }
            if (col_size == 1 && line_size % 8 != 0) { // add extra alignment bit
                buffer[line_size] |= 0x80;
            }
        }
        
        for (int I = 0; I < col_size * 4; i++) {
            int x = fgetc(input);
            if (x == EOF) break; // end of line
            buffer[i + col_size * 2] |= 1 << (line_size % 8); // add padding to align with buffer
        }
        
        fclose(input);
    }
    
    fprintf(stderr, "Done\n");
    
    return EXIT_SUCCESS;
}