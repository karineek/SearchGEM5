
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s [<args>]\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    system(argv[1]);
    
    return 0;
}