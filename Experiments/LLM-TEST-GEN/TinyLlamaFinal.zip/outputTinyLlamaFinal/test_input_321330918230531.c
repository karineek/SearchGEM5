
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>  // for getopt() macro

int main(int argc, char *argv[]) {
    int opt;
    const char *input = "Hello world!";

    // Check if input is empty or not
    if (argc == 1) {
        fprintf(stderr, "Error: Input argument is required.\n");
        return EXIT_FAILURE;
    } else if (argv[1][0] != '!') {
        fprintf(stderr, "Error: Invalid input type. Please specify a valid string.\n");
        return EXIT_FAILURE;
    }

    // Getopt() macro will be used to parse command line arguments and get options and values
    int opt_index = 1; // Index of the next option (in this case, '!')
    struct option long_options[] = {
        {"input", READ_ONLY, &input, 0},
        {"help", NO_OPTION, NULL, 0},
        {NULL, 0, NULL, 0} // Terminate array with a NULL pointer
    };

    int option_index = 0;
    int c;
    while ((c = getopt_long(argc, argv, "hi:", long_options, &option_index)) != -1) {
        switch (c) {
            case 'i': // Option to specify input string
                strncpy(input, optarg, sizeof(input));
                break;
            case 'h': // Flag indicating help option
                fprintf(stderr, "Usage: %s [OPTION]...\n", argv[0]);
                fputs("    -i <string>\n", stderr);
                fputs("    --help\n", stderr);
                return EXIT_SUCCESS; // Exit with success status
            default:  // Invalid option
                fprintf(stderr, "Error: Invalid option %c.\n", c);
                return EXIT_FAILURE; // Exit with failure status
        }
    }

    if (optind != optarg) {
        fprintf(stderr, "Error: Invalid input argument.\n");
        return EXIT_FAILURE;
    }

    int result = system(input);
    if (result < 0) {
        perror("system() failed");
        return EXIT_FAILURE;
    } else {
        printf("Executed successfully with %d bytes copied.\n", result);
    }

    return EXIT_SUCCESS; // Exit with success status
}