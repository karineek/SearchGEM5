
#include <stdio.h>

#include "llvm/Target/TargetData.h"

int main(int argc, char *argv[]) {
    // Read LLVM IR and ++ (plus-plus punctuator) from args[1]
    const char *filename = argv[1];
    
    llvm::raw_fd_ostream os(stdout, filename);
    llvm::TargetData *td = llvm::getGlobalTargetData();
    os << td->getRegisterInfo()->getRegAllocInfo() << std::endl;
    
    return 0;
}