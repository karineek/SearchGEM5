
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int distance_inches;

    if (argc == 2 && strcmp(argv[1], "--help") != 0) {
        printf("Usage: %s [options] infile\n", argv[0]);
        printf("Options:\n");
        printf("--help                Display this help message.\n");
        return 0;
    }

    if (argc == 1 || strcmp(argv[1], "--help") != 0) {
        fputs("Input Format: infile\n", stderr);
        printf("Infile contains two columns separated by space:\n");
        printf("\t- Distance in inches\n");
        return EXIT_SUCCESS;
    }

    /* Read distance from input */
    if (!(distance_inches = atoi(readline(NULL))) || distance_inches < 0) {
        fprintf(stderr, "Invalid input: expected positive integer, but got %d.\n", distance_inches);
        return EXIT_FAILURE;
    }
    
    /* Generate example */
    if (!distance_inches) {
        fputs("Input is empty.\n", stderr);
        return EXIT_SUCCESS;
    }
    printf("Example: Distance in inches %d\n", distance_inches);
    
    return EXIT_SUCCESS;
}