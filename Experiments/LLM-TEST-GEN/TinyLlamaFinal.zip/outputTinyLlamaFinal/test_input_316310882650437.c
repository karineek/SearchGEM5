
#include <stdio.h>
#include <ctype.h>
#include "bash.h"

// C function to handle command execution
void execute(int argc, char **argv) {
    execvp("bash", (char **)argv);
}

int main(int argc, char *argv[]) {
    if (argc < 2 || argc > 3) { // error checking for command line args
        printf("Error: Incorrect number of arguments. Expected 1 to 3\n");
        return EXIT_FAILURE;
    }
    switch (argv[1][0]) {
    case '+': // if + is given, then do a "+" command
        execute(argc - 1, argv);
        break;
    case '-': // if - is given, then do an "-" command
        execute(argc - 1, argv);
        break;
    default:
        printf("Error: Unknown option. Use '+' or '-' as options\n");
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}