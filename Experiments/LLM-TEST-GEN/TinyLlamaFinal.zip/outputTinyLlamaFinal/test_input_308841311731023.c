
#include <stdio.h>
#include "thread.h"

// Memory-to-Register Promotion optimizations
void* thread_local_function(void* arg) {
    printf("%s\n", __func__);
    return arg;
}

int main() {
    pthread_t tid;
    
    // Create a new thread with the `pthread_create` function and store the result in `tid` variable.
    if(pthread_create(&tid, NULL, thread_local_function, (void*)0x12345678) != 0){
        printf("Error: pthread_create failed\n");
        return -1;
    }
    
    // Wait for the new thread to finish.
    if(pthread_join(tid, NULL) != 0){
        printf("Error: pthread_join failed\n");
        return -1;
    }
    
    // Print out the result of the function call.
    printf("%s\n", __func__);
    
    return 0;
}