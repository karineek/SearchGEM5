
#include <stdio.h> /* includes printf(), scanf() */

/* functions */
void execute_command(char *command);
int count_occurrences(char *str, char *pattern);
int main(int argc, char **argv) {
    char buffer[1024];
    if (argc == 2 && strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "--help") == 0) {
        printf("Usage: %s [command]\n", argv[0]);
        return 0;
    } else if (argc != 2 && !strcmp(argv[1], "-d") || strcmp(argv[1], "--debug")) {
        puts("Please specify a command to execute.");
        return 1;
    }
    /* execute the user's input */
    printf("Enter a command to run: ");
    fgets(buffer, sizeof(buffer), stdin);
    if (buffer[0] == '\n') {
        buffer[0] = '\0';
    }
    char *command_ptr = strdup(buffer);
    execute_command(command_ptr);
    return 0;
}

/* function to execute a command */
void execute_command(char *command) {
    printf("Executing: %s\n", command);
    puts("");
    int ret = system(command);
    if (ret != 0) {
        perror("system() failed!");
        exit(1);
    }
}

/* function to count occurrences of pattern */
int count_occurrences(char *str, char *pattern) {
    int count = 0;
    while (*str != '\0') {
        int index = strrchr(str, ' ');
        if (index == NULL) {
            return -1;
        }
        /* pattern matches? */
        if (*((index + 1) - str) == 0 && strcmp(pattern, "*") != 0) {
            ++count;
        }
        str = index + 1;
    }
    return count;
}