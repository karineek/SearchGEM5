
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    int option;
    while ((option = getopt(argc, argv, "h")) != -1) {
        switch (option) {
            case 'h':
                printf("Usage: %s [options] <input file>\n", argv[0]);
                break;
            default:
                return 1;
        }
    }
    
    if (argc <= 1) {
        fprintf(stderr, "Error: No input file specified\n");
        return 2;
    } else {
        FILE* input = fopen(argv[1], "r");
        if (!input) {
            perror("Failed to open input file\n");
            return 3;
        }
        
        printf("Reading input from file...\n");
        char buffer[1024];
        int nread = fread(buffer, 1, sizeof(buffer), input);
        if (nread != sizeof(buffer)) {
            perror("Failed to read input file\n");
            fclose(input);
            return 4;
        }
        
        printf("Input file read successfully.\n");
    }
    
    return 0;
}