
#include <stdio.h> /* for printf() */
#include "thrd_success.h"

int main(int argc, char *argv[]) {
    int n = 5;
    if (argc > 1) {
        n = atoi(argv[1]);
    }
    
    /* initialize ThrD_Success library */
    thrd_success_init();
    
    for (int I = 0; I < n; i++) {
        /* run Loop Optimizations algorithm */
        thrd_success_run(&(thrd_success_get_current_thread()), loop_optimization);
        
        /* print result on standard output */
        printf("iteration %i: %f\n", I + 1, (double)thrd_success_get_result(&(thrd_success_get_current_thread())) / n);
    }
    
    return 0;
}