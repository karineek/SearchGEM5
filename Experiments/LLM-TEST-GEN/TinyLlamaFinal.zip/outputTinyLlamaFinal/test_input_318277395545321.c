
#include <stdio.h>
#include "statiq_analyzer/statiq_analyzer.h" // Load StatiQ Analyzer library

int main(void) {
  int num_args = 2; // Expecting two arguments (input file name and output filename)
  const char *filename1, *filename2 = NULL; // File names to process
  
  if (num_args != 2) {
    fprintf(stderr, "Usage: %s [<filename1> <filename2>]\n", argv[0]);
    return 1;
  }
  
  filename1 = strdup(argv[1]); // Allocate memory for input file name (copy from argv)
  
  if (filename2 == NULL) {
    filename2 = strdup("stdout"); // If second arg is not specified, use default output as stdout
  } else {
    filename2 = strdup(argv[2]); // If second arg specified, allocate memory for output file name (copy from argv)
  }
  
  if (filename1 == NULL || filename2 == NULL) {
    fprintf(stderr, "Error: Invalid input file names\n");
    free(filename1); // Free allocated memory for first input file name
    free(filename2); // Free allocated memory for second input file name
    return 1;
  }
  
  StatiQAnalysisState analysis_state = statiq_analyze(&argc, argv); // Analyze the input files using StatiQ
  
  if (analysis_state.errors > 0) { // Errors found during analisys
    fprintf(stderr, "Error: %s\n", analysis_state.error_message); // Report error message
    free(filename1); // Free allocated memory for input file name
    free(filename2); // Free allocated memory for second input file name
    return 1;
  } else if (analysis_state.warnings > 0) { // Warnings found during analisys
    fprintf(stderr, "Warning: %s\n", analysis_state.warning_message); // Report warning message
  } else { // No errors or warnings found during analisys
    FILE *output = NULL; // File handle to write output to (stdout)
    
    if (filename2 == stdout) { // If second arg is not specified, use default stdout
      output = stdout;
    } else { // If second arg specified, allocate memory for output file name (copy from argv)
      output = fopen(filename2, "w"); // Open output file for writing
    }
    
    if (output == NULL) { // Handle error handling of open file for writing
      fprintf(stderr, "Error: Could not open output file\n"); // Report error message
      free(filename1); // Free allocated memory for input file name
      free(filename2); // Free allocated memory for second input file name
      return 1;
    }
    
    // Generate output data based on analysis results (if no errors)
    if (!analysis_state.errors && !analysis_state.warnings) {
      FILE *input = NULL; // File handle to read input from (stdin)
      
      if (filename1 == stdout) { // If first arg is not specified, use default stdout
        input = stdin;
      } else { // If first arg specified, allocate memory for input file name (copy from argv)
        input = fopen(filename1, "r"); // Open input file for reading
      }
      
      if (input == NULL) { // Handle error handling of open file for reading
        fprintf(stderr, "Error: Could not open input file\n"); // Report error message
        free(filename1); // Free allocated memory for input file name
        free(filename2); // Free allocated memory for second input file name
        return 1;
      }
      
      FILE *output = NULL; // File handle to write output to (stdout)
      
      if (filename2 == stdout) { // If second arg is not specified, use default stdout
        output = stdout;
      } else { // If second arg specified, allocate memory for output file name (copy from argv)
        output = fopen(filename2, "w"); // Open output file for writing
      }
      
      if (output == NULL) { // Handle error handling of open file for writing
        fprintf(stderr, "Error: Could not open output file\n"); // Report error message
        free(filename1); // Free allocated memory for input file name
        free(filename2); // Free allocated memory for second input file name
        return 1;
      }
      
      int I = 0, j = 0; // Indexes to loop through input data (both files)
      
      while (!feof(input)) { // Loop through all lines in the input files and process them
        // Get next line from input file (if not EOF)
        if (!feof(input)) {
          int K = fscanf(input, "%s", filename1[i++]); // Read one line from input file
          
          if (K != 0) { // If line is not empty, process it and write to output file
            for (j = 0; j < I && j < K; j++) { // Loop through all lines in input file (both files) and write data to output file
              int L = fscanf(output, "%s", filename2[j++]); // Read one line from output file
              
              if (L != 0) { // If line is not empty, process it and write to output file
                for (k = 0; k < j && k < K; k++) { // Loop through all lines in input file (both files) and write data to output file
                  fputs(filename1[i++], output); // Write line from input file to output file
                  fputc(' ', output); // Add newline character
                  fputs(filename2[j++], output); // Write line from output file to output file
                }
              }
            }
          } else { // If line is empty, ignore it and continue processing both files
            I = j;
          }
        }
      }
      
      fclose(input); // Close input file for reading
      fclose(output); // Close output file for writing
    } else if (analysis_state.errors > 0 || analysis_state.warnings > 0) { // Errors found during analisys
      FILE *error = NULL; // File handle to write error messages to
      
      if (!strcmp(filename1, stdout)) { // If first arg is not specified, use default stdout (stdout)
        error = stdout; // Set file handle for output messages
      } else if (!strcmp(filename2, stdout)) { // If second arg is not specified, use default stdout (stdout)
        error = stdout; // Set file handle for output messages
      } else { // If first or second args specified, allocate memory for error message and file handle
        error = fopen("error.log", "w"); // Open log file for writing
      }
      
      if (error == NULL) { // Handle error handling of open log file for writing
        fprintf(stderr, "Error: Could not create error log file\n"); // Report error message
        free(filename1); // Free allocated memory for input file name
        free(filename2); // Free allocated memory for second input file name
        return 1;
      }
      
      FILE *output = NULL; // File handle to write output to (stdout)
      
      if (filename2 == stdout) { // If second arg is not specified, use default stdout (stdout)
        output = stdout; // Set file handle for output messages
      } else { // If second arg specified, allocate memory for output message and file handle
        output = fopen("output.log", "w"); // Open log file for writing
      }
      
      if (output == NULL) { // Handle error handling of open log file for writing
        fprintf(stderr, "Error: Could not create output log file\n"); // Report error message
        free(filename1); // Free allocated memory for input file name
        free(filename2); // Free allocated memory for second input file name
        return 1;
      }
      
      int I = 0, j = 0; // Indexes to loop through input data (both files)
      
      while (!feof(input)) { // Loop through all lines in the input files and process them
        // Get next line from input file (if not EOF)
        if (!feof(input)) {
          int K = fscanf(input, "%s", filename2[j++]); // Read one line from input file
          
          if (K != 0) { // If line is not empty, process it and write to output file
            for (k = 0; k < j && k < K; k++) { // Loop through all lines in the input file (both files) and write data to output file
              int L = fscanf(output, "%s", filename1[i++]); // Read one line from output file
              
              if (L != 0) { // If line is not empty, process it and write to output file
                for (l = 0; l < j && l < K; l++) { // Loop through all lines in the input file (both files) and write data to output file
                  fputs(filename1[i++], output); // Write line from input file to output file
                  fputc(' ', output); // Add newline character
                  fputs(filename2[j++], output); // Write line from output file to output file
                }
              } else { // If line is empty, ignore it and continue processing both files
                I = j;
              }
            }
          } else { // If line is empty, ignore it and continue processing both files
            I = j;
          }
        }
      }
      
      fclose(input); // Close input file for reading
      fclose(error); // Close log file for writing
    }
  } catch (...) {
    if (input != stdout) { // If input was specified, close output files too
      fclose(output);
      fclose(error);
    }
    
    if (!strcmp(filename1, stdout)) { // If first or second args specified, free memory for error message and file handles
      free(filename1);
      free(filename2);
    }
  } catch (...) {
    fprintf(stderr, "Error: %s\n", strerror(errno)); // Report unexpected error to user
  }
  
  return 0;
}