
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int I = 0;
    
    while (I < argc) {
        printf("Input %d: ", ++i);
        
        if (argc <= i) {
            puts("Error: Input number greater than program arguments.");
            return -1;
        }
        
        printf("%s\n", argv[i]);
    }
    
    return 0;
}