
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s FILE\n", argv[0]);
        return EXIT_FAILURE;
    } else {
        FILE *input = fopen(argv[1], "r");
        if (!input) {
            perror("Could not open input file");
            exit(EXIT_FAILURE);
        }
        
        printf("%s", getcwd(NULL, 0));
        free(getcwd(NULL, 0)); // cleanup CWD
        
        char buffer[BUFSIZ];
        fread(buffer, sizeof(char), BUFSIZ, input);
        fclose(input);
        
        printf(": %s", buffer);
        return EXIT_SUCCESS;
    }
}