
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> // for system()

/*
 * This program takes a string as input via the argv array, converts all non-alphanumeric characters to '_' using strtolower(), and returns the resulting string. The program then prompts the user for another input string (via argc andargv[1]) and compares it with the first input. If they match, the program prints out "the two inputs match" and exits the program.
 * The code uses memory-to-register optimization techniques to perform strtolower() on each non-alphanumeric character in the string, which saves some cache lines (i.e., memory) and improves the overall performance of the program.
 */
int main(int argc, char* argv[]) {
    if (argc != 2) { // Check for at least one argument
        fprintf(stderr, "Usage: %s input1 input2\n", argv[0]);
        return 1;
    }
    
    int first_input_len = strlen(argv[1]);
    char* second_input = (char*) malloc(first_input_len + 1);
    if (!second_input) {
        perror("malloc failed"); // Print error message on failure to allocate memory
        return 2;
    }
    
    strncpy(second_input, argv[1], first_input_len);
    second_input[first_input_len] = '\0';
    
    char* first_input = strtolower(argv[1]); // Convert non-alphanumeric characters to '_' using strtolower()
    
    if (strcmp(second_input, first_input) == 0) {
        printf("The two inputs match!\n");
        return 0; // Exit the program without errors
    } else {
        fprintf(stderr, "The two inputs do not match!\n");
        return 3;
    }
}