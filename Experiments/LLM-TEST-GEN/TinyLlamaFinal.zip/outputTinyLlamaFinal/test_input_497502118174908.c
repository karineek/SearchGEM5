
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "ptm.h"

int main(int argc, char *argv[]) {
    ptm_t ptm;
    if (!ptm_init(&ptm, argv[1])) {
        fprintf(stderr, "Error: %s\n", strerror(errno));
        return 1;
    }

    if (ptm_analyze(&ptm) != 0) {
        fprintf(stderr, "Error: PGO analysis failed\n");
        ptm_free(&ptm);
        return 1;
    }

    ptm_run(&ptm);

    for (int I = 0; I < argc - 1; i++) {
        if (!ptm_analyze(&ptm)) {
            fprintf(stderr, "Error: PGO analysis failed\n");
            ptm_free(&ptm);
            return 1;
        }
    }

    if (ptm_dump(&ptm) != 0) {
        fprintf(stderr, "Error: PGO dump failed\n");
        ptm_free(&ptm);
        return 1;
    }

    ptm_free(&ptm);

    return 0;
}