
#include <math.h> // Needed to use pow(x,y) with fixed-point arithmetic
#include <stdlib.h> // For exit()
#include "inline_ratios_llvm.h" // Include LLVM's optimizations and passes

// Macro FLT_MAX returns the maximum floating point value. It is defined as a constant in float.h header file
#define FLT_MAX 1.7976931348623157e+308 // This defines the maximum floating point value for signed int or unsigned long long

// Main function (BASH shell script) that calls the inline ratios of absolute values
main() {
  float a, b;
  char result[1024]; // Maximum length for result buffer
  char *errmsg = "Error: Input argument is not valid.";
  
  // Check if input arguments are correct. If none, exit with error message and return.
  if (argc < 3) {
    printf("%s\n", errmsg);
    exit(1);
  }
  
  // Parse input arguments
  for (int I = 1; I <= argc; i++) {
    char *arg = argv[i]; // Get first argument (name of file or directory)
    
    if (!strcmp(arg, "-")) { // Handle - argument (input file name)
      // Check if input file exists and is readable. If not, exit with error message and return.
      int fd = open(argv[++i], O_RDONLY | O_CLOEXEC); // Open input file for reading
      
      if (fd < 0) {
        printf("%s\n", strerror(errno));
        exit(1);
      }
    
      // Calculate the absolute value of each line in the input file and write to output buffer.
      do {
        b = fread(&a, sizeof(float), 1, stdin);
        if (b == 0) {
          printf("%s\n", strerror(errno)); // Handle input stream error
          exit(1);
        }
        if (!fwrite(result, sizeof(char), 1, stdout)) {
          printf("%s\n", strerror(errno)); // Handle output buffer write error
          exit(1);
        }
      } while (b > 0);
      
      close(fd); // Close input file descriptor
    } else if (!strcmp(arg, "-a")) { // Handle - argument (output file name)
      char *filename = argv[++i]; // Get output file name (without .out extension)
    
      // Check if output file exists and is writable. If not, exit with error message and return.
      int fd = creat(filename, 0644); // Create output file for writing
      
      if (fd < 0) {
        printf("%s\n", strerror(errno)); // Handle output file creation error
        exit(1);
      }
    
      // Calculate the absolute value of each line in the input file and write to output buffer.
      do {
        b = fread(&a, sizeof(float), 1, stdin);
        if (b == 0) {
          printf("%s\n", strerror(errno)); // Handle input stream error
          exit(1);
        }
        if (!fwrite(result, sizeof(char), 1, stdout)) {
          printf("%s\n", strerror(errno)); // Handle output buffer write error
          exit(1);
        }
      } while (b > 0);
      
      close(fd); // Close output file descriptor
    } else if (!strcmp(arg, "-")) { // Handle - argument (input directory name)
      char *dir = argv[++i]; // Get input directory name (without leading '/')
    
      // Check if input directory exists and is readable. If not, exit with error message and return.
      int fd = opendir(dir);
      
      if (fd < 0) {
        printf("%s\n", strerror(errno)); // Handle input directory creation error
        exit(1);
      }
    
      // Calculate the absolute value of each line in the input directory and write to output buffer.
      do {
        b = dirent(&a, NULL, &d); // Read a file entry (i.e. Name, last modified time, and access time)
        if (!b) {
          printf("%s\n", strerror(errno)); // Handle input directory read error
          exit(1);
        }
        if (!fwrite(result, sizeof(char), 1, stdout)) {
          printf("%s\n", strerror(errno)); // Handle output buffer write error
          exit(1);
        }
      } while (b);
      
      closedir(fd); // Close input directory descriptor
    } else if (!strcmp(arg, ".")) { // Handle - argument (input file name)
      char *filename = argv[++i]; // Get input file name (without leading '.' character)
    
      // Check if input file exists and is readable. If not, exit with error message and return.
      int fd = open(filename, O_RDONLY | O_CLOEXEC); // Open input file for reading
      
      if (fd < 0) {
        printf("%s\n", strerror(errno)); // Handle input file read error
        exit(1);
      }
    
      // Calculate the absolute value of each line in the input file and write to output buffer.
      do {
        b = fread(&a, sizeof(float), 1, stdin);
        if (b == 0) {
          printf("%s\n", strerror(errno)); // Handle input stream error
          exit(1);
        }
        if (!fwrite(result, sizeof(char), 1, stdout)) {
          printf("%s\n", strerror(errno)); // Handle output buffer write error
          exit(1);
        }
      } while (b > 0);
      
      close(fd); // Close input file descriptor
    } else {
      printf("Error: Input argument is not valid.\n");
      exit(1);
    }
  
  }
}