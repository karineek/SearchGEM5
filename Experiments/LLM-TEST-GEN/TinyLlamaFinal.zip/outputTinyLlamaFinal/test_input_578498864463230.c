
#include <stdio.h>

int main() {
    int num = atoi(argv[1]);
    
    if (num <= LLONG_MIN) {
        printf("Invalid input\n");
        return 0;
    }
    
    for (int I = 1; I * I <= num; i++) {
        int product = num / I;
        
        if (product == num) {
            printf("%d^%d = %d\n", num, i, product);
        } else {
            printf("Error: Improper input\n");
        }
    }
    
    return 0;
}