
#include <stdio.h>
#include <stdlib.h>
#include "llvm/IR/Module.h"

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s file\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    // Load the LLVM IR from a file
    llvm::LLVMContext* context = new llvm::LLVMContext();
    llvm::LLVMOpt::DiagOpts options(llvm::DiagOpts::Default);
    llvm::LLVMContext::DiagnosticEngine& diags = context->getDiagnostics();
    
    // Create the module
    std::string file_name = argv[1];
    auto module = llvm::readSmallFileToString<std::string>(file_name, options);
    
    if (module.empty()) {
        printf("Error: %s\n", file_name.c_str());
        return EXIT_FAILURE;
    }
    
    // Create the IR Builder
    llvm::IRBuilder<> builder(module);
    
    // Get the function with the given name and arguments
    auto func = builder.getFunction("main");
    
    if (func == nullptr) {
        printf("Error: Could not find main function\n");
        return EXIT_FAILURE;
    }
    
    // Get the argument types
    const std::vector<llvm::Type*> arg_types(func->arg_begin(), func->arg_end());
    
    // Find the argument names and their types
    std::string args = "";
    for (auto I : arg_types) {
        auto name = llvm::dyn_cast<llvm::FunctionArgAttr>(I->getAttribute("name"))->getValue();
        args += " " + name;
        
        auto type = I->getType()->getMetadata("type");
        if (type.isNull() || type.getKind() != llvm::MetadataKind::LLVMInt8) {
            printf("Warning: Unsupported argument type %s\n", type ? type->getAsString().c_str() : "null");
        }
    }
    
    // Print usage information and exit
    printf("Usage: %s %s\n", argv[0], args.empty() ? "" : " [" + args + "] ");
    return EXIT_FAILURE;
}