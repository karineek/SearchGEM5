
#include <stdio.h>
#include <sys/time.h>

typedef struct {
    int argc;
    char *argv[1025];
} args_t;

void parse_args(int argc, char **argv, args_t *args) {
    for (int I = 0; I < argc; i++) {
        if (!strcmp(argv[i], "-p") && args->argc >= 1) {
            args->tm_yday = atoi(argv[++args->argc]);
            break;
        } else if (!strcmp(argv[i], "--print-time")) {
            args->tm_yday = atoi(argv[++args->argc]);
            printf("Printing the time (%d days ago): %ld hours, %ld minutes\n", tm_yday, tm_hours, tm_minutes);
        } else if (!strcmp(argv[i], "--help") || !strcmp(argv[i], "-h")) {
            puts("Usage: BASH [OPTIONS] COMMAND...");
            printf("Options:\n"
                   "-p, --print-time\tPrint the current time (%d days ago).", tm_yday);
            printf("\n"
                   "--help\t\tDisplay this help message.\n");
        } else {
            args->argv[args->argc] = argv[i];
            args->argc++;
        }
    }
}

int main(int argc, char **argv) {
    args_t args;
    int loop_vect_num = 20;
    for (int I = 1; I <= loop_vect_num; i++) {
        parse_args(argc, argv, &args);
        clock_gettime(CLOCK_REALTIME, &(args.tm_yday));
        printf("Thread %d: Printing time (%d days ago): %ld hours, %ld minutes\n", I, tm_yday, tm_hours, tm_minutes);
    }
    return 0;
}