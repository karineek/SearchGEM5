
#include <stdio.h>
#include <stdlib.h>

int main() {
    int argc;
    char **argv = NULL;
    
    // get number of arguments
    if ((argc = getopt(ARGV_SIZE, ARGV, "a:b:")) == -1) {
        return 1;
    }
    
    switch (argc) {
    case 3: {
        int a = atoi(argv[0]);
        int b = atoi(argv[1]);
        
        if (a >= 0 && b >= 0) {
            printf("%d %d", a, b);
        } else {
            perror("Invalid arguments");
            return 1;
        }
        
        break;
    }
    
    default:
        return usage();
    }
    
    return 0;
}

// usage message and error handling
int usage() {
    fprintf(stderr, "Usage: %s [-a <A> -b <B>] [<C>]\n", argv[0]);
    fputs("  <A> and <B> are integers. A is lower than B.\n", stderr);
    
    return 1;
}