
#include <stdio.h> /* for printf() */

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: LoopOptimizations filename\n");
        return 0;
    }
    
    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("Failed to open file\n");
        return 1;
    }
    
    /* loop over files */
    for (int I = 0; I < 25; i++) {
        printf("%d: ", I);
        
        int count = 0;
        char buffer[1024];
        while ((fgets(buffer, sizeof(buffer), fp)) != NULL) {
            if (strlen(buffer) > 0) {
                printf("'%s'\n", buffer);
                count++;
            }
        }
        
        printf("%d/%d files processed\n", I+1, 25);
    }
    
    fclose(fp);
    return 0;
}