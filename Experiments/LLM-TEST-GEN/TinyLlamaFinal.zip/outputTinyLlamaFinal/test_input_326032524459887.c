
#include <stdio.h>

int main(void) {
    int argc, i;
    char *argv[10]; // max 9 arguments

    argv[0] = "hello"; // first argument is the program name
    argc = 1;

    for (i=0; I < argc && I < 10; i++) {
        if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) {
            printf("Usage: %s [-h] [<args>...]\n", argv[0]);
            return 0; // exit with success (0) code
        } else if (!strcmp(argv[i], "-t") || !strcmp(argv[i], "--trace")) {
            printf("Trace: %s\n", argv[++i]);
        } else if (!strcmp(argv[i], "-c") || !strcmp(argv[i], "--compiler")) {
            printf("Compiler: %s\n", argv[++i]);
        } else if (i < 10) {
            fprintf(stderr, "Invalid argument: \"%s\"\n", argv[i]); // print error message for non-existant arguments
            return 1; // exit with error (1) code
        }
    }

    if (!argc) {
        fprintf(stderr, "%s: missing program name argument(s)\n", argv[0]);
        return 1;
    }

    return 0;
}