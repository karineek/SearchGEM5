
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    if (argc < 2) { // check if there's at least one argument provided by user
        printf("Invalid input!\n");
        return 1;
    }
    
    FILE *input_file = fopen(argv[1], "r"); // open file with read permission
    
    if (input_file == NULL) { // check if file can be opened
        perror("Cannot open file\n");
        return 2;
    }
    
    char input_buffer[1024]; // buffer for input file content
    
    fseek(input_file, 0, SEEK_END); // seek to end of file
    int size = ftell(input_file); // get size of the file
    
    if (size == -1) { // check if we can read the file size
        perror("Cannot read file size\n");
        return 3;
    }
    
    input_buffer[0] = '\0'; // terminate buffer
    fseek(input_file, 0, SEEK_SET); // set back to start of file
    
    int i = 1; // iterate over lines of the file
    while (fgets(input_buffer + 1, sizeof(input_buffer), input_file) != NULL) {
        printf("%s", input_buffer); // print each line of the file
        
        if (i % 5 == 0 && i > 2) { // check if we've reached the fifth line and print it every five lines
            fprintf(stdout, "\n"); // print a newline after each line
        }
        
        i++;
    }
    
    fclose(input_file); // close file
    
    return 0;
}