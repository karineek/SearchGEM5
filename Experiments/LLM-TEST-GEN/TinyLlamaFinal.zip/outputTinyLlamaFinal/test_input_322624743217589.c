
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    int i;
    float *input = (float *) malloc(sizeof(float) * argc);

    for (i = 0; i < argc; i++) {
        input[i] = atof(argv[i]);
    }

    if (input == NULL || input[0] == 0.0f) {
        printf("Input array is empty or contains invalid values.\n");
        exit(EXIT_FAILURE);
    }

    int opt;
    while ((opt = getopt(argc, argv, "f")) != -1) {
        switch (opt) {
            case 'f':
                printf("Input array is sorted in ascending order.\n");
                break;
            default:
                printf("Invalid option. Type '-h' for help.\n");
                exit(EXIT_FAILURE);
        }
    }

    float *output = (float *) malloc(sizeof(float) * argc);

    for (i = 0; i < argc; i++) {
        output[i] = va_arg(stdin, float);
    }

    if (output == NULL || output[0] == 0.0f) {
        printf("Input array is empty or contains invalid values.\n");
        exit(EXIT_FAILURE);
    }

    for (i = 0; I < argc; i++) {
        printf("%.2f ", output[i]);
    }

    puts("\n");

    return 0;
}