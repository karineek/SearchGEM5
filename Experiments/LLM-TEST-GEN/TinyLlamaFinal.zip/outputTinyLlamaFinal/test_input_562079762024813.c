
#include <stdio.h>

int main() {
    int a, b;
    
    // Get input from argv only (exclude the "whole program" or the name of the executable)
    if (argc < 2 || strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "--help") == 0) {
        printf("Usage: %s [-h] [options]\n", argv[0]);
        return 0;
    }
    
    // Process arguments and validate input values
    while (1) {
        if ((a = getchar()) == EOF) break;
        switch (a) {
            case 'h':
                puts("Usage: %s [-h] [options]\n", argv[0]);
                return 0;
            case '?':
                printf("%s\n", argv[0]);
                puts("This program calculates the factorial of a given number.\n");
                puts("Usage: %s [-h] [options]\n", argv[0]);
                return 0;
        }
    }
    
    // Check if input is valid and handle invalid inputs appropriately
    while (1) {
        switch ((b = getchar())) {
            case EOF:
                puts("Error: Could not read input.\n");
                return 1;
            case '\0':
                printf("%s\n", "Error: Invalid input.\n");
                puts("Please enter a valid number (excluding the 'e' character).\n");
                if (!strcmp(argv[1], "-h") || !strcmp(argv[1], "--help")) {
                    return 0;
                } else {
                    printf("Usage: %s [-h] [options]\n", argv[0]);
                    return 1;
                }
            default:
                while (b != 'e' && b != '-') {
                    if (!isdigit(b)) {
                        puts("Error: Invalid input.\n");
                        printf("%s\n", "Please enter a valid number (excluding the 'e' character).\n");
                        return 1;
                    } else b = getchar();
                }
                if (!strcmp(argv[1], "-h") || !strcmp(argv[1], "--help")) {
                    printf("Usage: %s [-h] [options]\n", argv[0]);
                    return 0;
                } else break;
        }
    }
    
    // Calculate the factorial of a given number using recursion
    int fact(int n) {
        if (n <= 1) {
            printf("%s\n", "Error: Invalid input.\n");
            return 1;
        } else {
            fact(n - 1); // Recursive call, call with -1 for n and add 1
            return n * fact(n - 1);
        }
    }
    
    printf("%s\n", "Calculating factorial...");
    fact(a); // Call with user input as argument to calculate the factorial of a given number.
    return 0;
}