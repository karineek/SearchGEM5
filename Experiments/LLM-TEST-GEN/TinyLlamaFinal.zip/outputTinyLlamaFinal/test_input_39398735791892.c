
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    int pid = getpid();
    
    char argv0[] = "./a.out"; // input file name
    char argv1[] = "/usr/bin/bash"; // command to execute (e.g. /bin/bash)
    
    char *argv[2] = {argv0, argv1};
    
    execvp(argv[0], argv); // attempt to execute the input program with arguments
    return 0;
}