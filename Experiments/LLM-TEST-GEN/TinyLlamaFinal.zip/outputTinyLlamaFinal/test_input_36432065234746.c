
#include <stdio.h>

int main() {
    int a, b;
    double sum = 0.0;
    
    printf("Enter two integers to calculate their sum (press enter for default): ");
    fscanf(stdin, "%d %d", &a, &b);
    if (b == EOF || !(a > 0 && b > 0)) {
        printf("Invalid input. Please try again.\n");
        return -1;
    } else {
        sum = a + b;
        printf("%f", sum);
    }
    
    return 0;
}