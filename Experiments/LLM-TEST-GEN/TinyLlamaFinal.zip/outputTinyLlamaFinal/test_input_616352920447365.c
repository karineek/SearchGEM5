
#include <stdio.h> /* required by the standard C library */
#include <stdlib.h> /* required by the standard C library */

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s input_file\n", argv[0]);
        return 1;
    }

    FILE *input = fopen(argv[1], "r"); /* open file for reading */
    if (!input) {
        perror("Failed to open input file\n");
        return 2;
    }
    
    int c, line = 0, col = 0;
    char buffer[512];
    
    while ((c = fgetc(input)) != EOF) {
        buffer[col] = '\0'; /* clear buffer to prevent overflow */
        if (c == '\n') {
            line++;
            col = 0;
        } else {
            sprintf(&buffer[col], "%c", c); /* add character to buffer */
            col++;
        }
    }
    
    fclose(input);

    printf("Input file read successfully.\n");

    return 0;
}