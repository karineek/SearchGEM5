
#include <stdio.h>
#include <stdlib.h>

int main() {
    int argc;
    char **argv = (char **) malloc(sizeof(char *) * 2);
    
    /* Read the number of arguments */
    while((argc = getopt(argc, argv, "f")) != -1) {
        switch(argc) {
            case 0: // Empty argument
                break;
            case 1: {
                char arg[5]; // Number of arguments is stored in array
                snprintf(arg, sizeof(arg), "%d", atoi(optarg));
                argv[1] = (char *) malloc(strlen(arg) + 1);
                strcpy(argv[1], arg);
            } break;
        }
    }
    
    /* Check for invalid arguments */
    if(argc == 0) {
        printf("Error: No argument provided.\n");
        exit(EXIT_FAILURE);
    }
    
    /* Call the program with given arguments */
    system(argv[1]);
    
    return 0;
}