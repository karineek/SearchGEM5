
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

#define MEMORY_OPTS_MAX_SIZE 512 * 1024 // Maximum memory usage (in bytes)

int main(int argc, char* argv[]) {
    if (argc != 2 || strcmp(argv[1], "-h") == 0) {
        fprintf(stderr, "Usage: %s [options] <input>\n", argv[0]);
        return 1;
    }
    
    const char* input = argv[1];
    int i, j;
    double sum = 0.0;
    for (i = 0; i < atoi(argv[2]); ++i) {
        for (j = 0; j < atoi(argv[3]); ++j) {
            double val = rand() / RAND_MAX * MEMORY_OPTS_MAX_SIZE;
            sum += val;
        }
    }
    
    printf("Input: %s, max memory usage: %.2f MB\n", input, sum / (1024 * 1024.0));
    
    return 0;
}