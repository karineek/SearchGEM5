
#include <stdio.h>
#include "clang/AST.h"

int main(int argc, char **argv) {
    // Handle input from command line arguments
    if (argc != 2) {
        printf("Usage: %s <filename>\n", argv[0]);
        return -1;
    }
    
    ClangFrontendConfig config = createClangFrontendConfig();
    config.InputFile = argv[1]; // Take argument from command line

    // Run the frontend and print output to standard output
    ClangDriverResult result = runClangDriver(&config);

    if (result == Crashed) {
        printf("Frontend crashed, exiting\n");
        return 0;
    } else if (result != Success) {
        fprintf(stderr, "Frontend failed with code %d: %s\n", result, getClangDiag(config.Driver.Diagnostics));
        return -1;
    } else {
        printf("Frontend completed successfully\n");
    }
    
    return 0;
}