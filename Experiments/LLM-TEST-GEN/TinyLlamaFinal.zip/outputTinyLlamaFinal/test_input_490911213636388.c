
#include <stdio.h>
#include <stdlib.h>

#define MAX_ARGS 10 /* maximum number of arguments */

int main(void) {
    int n, argc;
    char **argv = malloc(MAX_ARGS * sizeof(char*)); /* allocate memory for argv array */

    if (argc < MAX_ARGS) { /* check for valid number of arguments */
        printf("Usage: %s [arguments]\n", argv[0]);
        return 1;
    } else {
        n = atoi(argv[1]) * atoi(argv[2]); /* multiply two numbers */
        argc -= MAX_ARGS + 1; /* reduce argument count */
        while (argc > 0) {
            argv[argc] = &argv[MAX_ARGS]; /* copy remaining arguments to new buffer */
            argc--;
        }
    }

    printf("Argv: %s %s\n", argv[0], argv[1]); /* print arguments with their corresponding values */

    exit(EXIT_SUCCESS); /* exit program successfully */
}