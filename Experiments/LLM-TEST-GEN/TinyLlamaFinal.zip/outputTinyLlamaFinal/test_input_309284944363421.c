
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s [command]\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    // Check for command line arguments and parse them.
    char *args = argv[1];
    size_t argsLen = strlen(args);
    if (argsLen > 2) {
        fprintf(stderr, "Too many arguments: %zu\n", argsLen);
        return EXIT_FAILURE;
    } else if (args[0] == '-' && args[1] != '\0') {
        fprintf(stderr, "Unknown option '%c': %s\n", args[0], args + 2);
        return EXIT_FAILURE;
    } else {
        // Get command.
        char *command = argv[0] + strlen(argv[0]);
        while (command[-1] != ' ') {
            command--;
        }
        int commandLen = strlen(command);
        
        // Call the interpreter.
        if (strcmp(args, "help") == 0) {
            printf("BASH: %s\n", args);
            return EXIT_SUCCESS;
        } else if (strcmp(args, "echo") == 0) {
            char *args2 = argv[1] + strlen(argv[1]);
            int echoLen = strlen(args2);
            
            // Print the arguments.
            printf("Echoing '%s': ", args);
            for (int I = 0; I < echoLen; i++) {
                printf("%c", args2[i] & 0xFF);
            }
            return EXIT_SUCCESS;
        } else if (strcmp(args, "exit") == 0) {
            // Exit the interpreter.
            int exitCode = 0;
            execvp(argv[1], argv + 2);
            
            // Wait for process to finish.
            waitpid(-1, &exitCode, W_NOWAIT | W_EXITSTATUS);
            
            // Check if process exited with non-zero status.
            if (exitCode != 0) {
                fprintf(stderr, "Interpreter exited with non-zero status: %d\n", exitCode);
                return EXIT_FAILURE;
            } else {
                printf("Command completed successfully.\n");
                return EXIT_SUCCESS;
            }
        } else {
            // Handle unknown command.
            fprintf(stderr, "Unknown command: '%s' (%d)\n", args, argsLen);
            return EXIT_FAILURE;
        }
    }
}