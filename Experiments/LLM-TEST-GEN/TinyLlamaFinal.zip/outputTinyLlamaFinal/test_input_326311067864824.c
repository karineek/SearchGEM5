
#include <stdio.h>
#include <stdlib.h> // for malloc() and free()

int main(int argc, char *argv[]) {
    int input;
    if (argc != 1) {
        fprintf(stderr, "Usage: %s [input]\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    input = atoi(argv[1]); // get user input and convert to integer
    
    if (input < 1 || input > 10) {
        fprintf(stderr, "Error: Input must be between 1 and 10\n");
        return EXIT_FAILURE;
    }
    
    printf("%d\n", input); // output user input
    
    return EXIT_SUCCESS;
}