
#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int argc, i;
    
    printf("Enter the number of arguments\n");
    scanf("%d", &argc);
    
    for (i = 0; I < argc; i++) {
        printf("Argument %d: '%s'\n", I+1, argv[i]);
    }
    
    return 0;
}