
#include <stdio.h> /* for printf */
#include "clang/Tooling/ClCompileTask.h"
#include "clang/Frontend/FrontendActions.h"
#include "clang/Frontend/CommandLine.h"

using namespace clang;
using namespace clang::tooling;

static const char *kOptionDescriptor = 
    "Optimize code for performance (PGO) and analyze the results (STATIC_ANALYSIS).";

int main(int argc, const char **argv) {
  SmallString<char> SourceFilePath;
  if (!clang::parseArgs(argc, argv, &SourceFilePath)) {
    fprintf(stderr, "Failed to parse command line arguments.\n");
    return EXIT_FAILURE;
  }
  
  // Load the file and create a frontend action for it.
  FrontendAction *FrontendAction = 
      CreateClangFrontendAction(SourceFilePath.data(), FrontEndDiagnostics);
  if (FrontendAction == nullptr) {
    fprintf(stderr, "Failed to create front-end action.\n");
    return EXIT_FAILURE;
  }
  
  CompilerInstance *CompilerInstance = 
      CreateFrontendActionsForCLANGOptions(ClangFrontEndDiagnostics, FrontendAction);
  if (CompilerInstance == nullptr) {
    fprintf(stderr, "Failed to create compiler instance.\n");
    return EXIT_FAILURE;
  }
  
  // Create the PGO tool.
  CompilerDriver *CompilerDriver =
      ClangTool::CreateClangFrontendDriver(FrontEndDiagnostics, FrontendAction);
  if (CompilerDriver == nullptr) {
    fprintf(stderr, "Failed to create compiler driver.\n");
    return EXIT_FAILURE;
  }
  
  // Create the command line options.
  clang::cl::ClCompileOptions Opts =
      ClangFrontendTool::CreateDefaultClangOptionsForDriver(CompilerDriver);
  Opts.getAsValueList()[1] = SourceFilePath.data();
  Opts.set(clang::cl::PosixSystemDependent, true);
  
  // Execute the command line options.
  return ClangTool<ClangFrontendAction>::Execute(CompilerDriver, &Opts);
}