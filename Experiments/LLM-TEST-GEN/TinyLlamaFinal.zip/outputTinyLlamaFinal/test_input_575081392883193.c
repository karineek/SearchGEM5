
#include <stdio.h>
#include <stdlib.h>
#include "scala/opt/scalarizations/scalarsort.h"

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s file\n", argv[0]);
        exit(-1);
    }
    
    const char *filename = argv[1];
    
    // Open file for reading
    FILE *f = fopen(filename, "r");
    if (!f) {
        perror("Error: Could not open file \"%s\"", filename);
        exit(-1);
    }
    
    // Initialize Scalarization tree with given file content
    size_t n = fread(&(scalarizations.tree), 1, sizeof(struct scalarization), f);
    if (n != sizeof(struct scalarization)) {
        perror("Error: Could not read scalarization tree");
        exit(-1);
    }
    
    // Initialize heap with input file data
    size_t n = read_input(scalarizations.heap, &(scalarizations.inputs), filename);
    if (n != sizeof(struct input)) {
        perror("Error: Could not read input file");
        exit(-1);
    }
    
    // Initialize heapify algorithm with given heap and inputs
    size_t root = 0;
    for (size_t I = 0; I < n; i++) {
        heapify(&(scalarizations.heap[root]), scalarizations.inputs, i);
    }
    
    // Perform Scalarization on the heap to compute optimal solutions
    for (size_t I = 1; I < n; i++) {
        if (!scalarize(&(scalarizations.heap[root]), &(scalarizations.inputs[i-1])) && !scalarize(&(scalarizations.heap[root]), &(scalarizations.inputs[i]))) {
            printf("Optimal Solution:\n");
            scalarization_print(&(scalarizations.outputs[i]), scalarizations.tree);
        } else if (scalarize(&(scalarizations.heap[root]), &(scalarizations.inputs[i-1])) && !scalarize(&(scalarizations.heap[root]), &(scalarizations.inputs[i]))) {
            printf("Optimal Solution with Duplicates:\n");
            scalarization_print(&(scalarizations.outputs[i]), scalarizations.tree);
        } else if (!scalarize(&(scalarizations.heap[root]), &(scalarizations.inputs[i])) && !scalarize(&(scalarizations.heap[root]), &(scalarizations.inputs[i]))) {
            printf("Optimal Solution with No Duplicates:\n");
            scalarization_print(&(scalarizations.outputs[i]), scalarizations.tree);
        }
    }
    
    // Free memory and return program status
    free_scalarization(&(scalarizations.heap));
    fclose(f);
    return 0;
}