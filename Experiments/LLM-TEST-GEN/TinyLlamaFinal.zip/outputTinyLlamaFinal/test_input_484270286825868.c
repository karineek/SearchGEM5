
#include <stdio.h>

void sinh(float x) {
    float y = sqrt(-x);
    printf("%f", y); // Calling the sinh function with a parameter of 0 and outputting the result
}

int main() {
    float x;
    printf("Enter a number: "); // Getting user input through command line argv[1]
    scanf("%f", &x); // Reading user input from argv and storing it in variable 'x'
    sinh(x); // Calling the sinh function with the user input as a parameter and outputting its result using printf()
    
    return 0;
}