
#include <stdio.h> /* for printf() */
#include <stdlib.h> /* for exit() */

int main(int argc, char *argv[]) {
    int n;
    
    if (argc != 2) {
        fprintf(stderr, "Usage: %s NUM\n", argv[0]);
        exit(1);
    }
    
    for (n = strtol(argv[1], NULL, 0); n >= 0; n -= abs(n)) {
        printf("%d ", n);
    }
    
    return 0;
}