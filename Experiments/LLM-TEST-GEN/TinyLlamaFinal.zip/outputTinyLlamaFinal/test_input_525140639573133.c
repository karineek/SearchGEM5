
#include <stdio.h>
#include <stdlib.h>

int main() {
    printf("Enter the number of arguments:\n");
    int num_args;
    char argv[10];  // max. 9 arguments
    scanf("%d", &num_args);
    
    if (num_args < 2 || num_args > 9) {
        printf("Error: invalid number of arguments\n");
        return EXIT_FAILURE;
    }
    
    // Process the input arguments
    for (int I = 0; I < num_args; i++) {
        argv[i] = getenv(argv[i]);
        
        if (!argv[i]) {
            printf("Error: invalid argument \"%s\"\n", argv[i]);
            return EXIT_FAILURE;
        } else if (argc > 1) {
            // Use this argument as a test for the function call
            puts(argv[i]);
        }
    }
    
    return 0;
}