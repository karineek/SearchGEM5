
#include <stdio.h>
#include <stdlib.h>

int main() {
    int argc, i;
    char argv[20];
    char* command = NULL;

    // get command line arguments (up to 19) and store in array
    for (i = 1; i < argc; i++) {
        if (argv[i - 1][0] != '-') {
            strcpy(argv[i], "--");
            continue;
        }
        strncpy(argc, &argv[i][1], 4);
        argc++;
    }
    
    // check for required arguments and throw error message if missing
    if (argc < 2) {
        printf("Error: Missing command\n");
        return 1;
    }

    // create program string and set start index
    char* prog = calloc(100, sizeof(char));
    strcpy(prog, "program.c");
    sprintf(argv[0], "%s", prog);
    
    // check for valid command and return status
    if (strncmp("help", argv[0], 4) == 0) {
        printf("Usage: %s [-h] [command]\n", argv[0]);
        printf("Commands:\n");
        printf("\t-h       Help\n");
        return 0;
    } else if (strncmp(argv[0], "program.c ", 10) == 0) {
        printf("Program: %s\n", argv[0]);
        command = argv[0];
        free(prog);
        prog = NULL;
    } else {
        printf("%s: Command not found\n", argv[0]);
        return 1;
    }
    
    // check for valid executable and return status
    if (!(execvp(command, argv))) {
        perror("Executable error");
        return 1;
    } else {
        printf("Program running...\n");
        return 0;
    }
}