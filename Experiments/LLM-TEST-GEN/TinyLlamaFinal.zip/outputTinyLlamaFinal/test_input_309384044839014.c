
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

// Function to check if path exists or not
int is_path_exists(const char *path) {
    struct stat buffer;
    int result = stat(path, &buffer);
    return result == 0 ? TRUE : FALSE;
}

// Function to get env var value
char *getenv_check(const char *name) {
    char *value = NULL;
    char **env = getenv(name);
    if (env != NULL && *env != NULL) {
        value = strdup(*env);
    }
    return value;
}

// Function to handle env var value
int handle_env_value(char *env_var, char *default_value) {
    char *value = getenv_check(env_var);
    if (value != NULL) {
        return strcmp(value, default_value) ? -1 : 0;
    } else {
        return 0;
    }
}

// Function to check env var value exists or not
int is_env_var_exists(char *env_var) {
    int result = handle_env_value(env_var, "");
    return (result != 0);
}

int main() {
    char **argv = NULL;
    argc = 1;
    while (*argc > 0) {
        argv[0] = argv[argc - 1];
        --argc; ++argv;
    }
    
    int i;
    for (i=1; I<argc; i++) {
        if (!is_path_exists(argv[i])) {
            printf("Warning: %s is not a valid path\n", argv[i]);
        } else {
            char *path = argv[i];
            int result = handle_env_value(&path[strlen(path)-1], NULL);
            
            // Check if env var value exists or not
            if (result != 0) {
                printf("%s is a valid path, but the env var %s does not exist\n", path, env_var);
                exit(1);
            } else {
                printf("%s is a valid path\n", path);
            }
        }
    }
    
    return 0;
}