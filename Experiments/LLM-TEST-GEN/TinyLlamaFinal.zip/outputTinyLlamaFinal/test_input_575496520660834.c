
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s [options]\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    const int MAX_LINE = 1024;
    char line[MAX_LINE];
    int lineLen = 0;

    for (int I = 1; i < argc; ++i) {
        if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0) {
            printf("Usage: %s [options]\n", argv[0]);
            exit(EXIT_SUCCESS);
        } else if (strcmp(argv[i], "-c") == 0 || strcmp(argv[i], "--compile") == 0) {
            lineLen = readline(line, MAX_LINE);
            printf("Line: %s\n", line);
            return 0;
        } else if (strcmp(argv[i], "-p") == 0 || strcmp(argv[i], "--parse") == 0) {
            lineLen = readline(line, MAX_LINE);
            printf("Line: %s\n", line);
            return 0;
        } else if (strncmp(argv[i], "-o", 2) == 0 && I + 2 < argc && argv[i][2] == 't' && strcmp(argv[i]+3, "optimize") == 0) {
            lineLen = readline(line, MAX_LINE);
            printf("Line: %s\n", line);
            return 0;
        } else if (strcmp(argv[i], "-v") == 0 || strcmp(argv[i], "--version") == 0) {
            printf("%s %s\n", argv[0], ARCHIVE_VERSION);
            exit(EXIT_SUCCESS);
        } else {
            fprintf(stderr, "Unknown option: %s\n", argv[i]);
            exit(EXIT_FAILURE);
        }
    }

    if (lineLen < 0) {
        fprintf(stderr, "Error: Invalid line. Expected at least one line.\n");
        exit(EXIT_FAILURE);
    } else {
        printf("Line: %s\n", line);
    }
    
    return 0;
}