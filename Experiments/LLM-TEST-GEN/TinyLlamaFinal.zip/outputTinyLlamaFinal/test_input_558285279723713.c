
#include <stdio.h>
#include <stdlib.h>

int main() {
    int argc;
    char **argv;
    
    argc = 2;
    argv = (char **) calloc(argc, sizeof(char *));
    
    argv[0] = strdup("bash"); // add BASH script to the argv array
    argv[1] = strdup("/usr/bin/bsh"); // add '/usr/bin/bsh' as executable
    
    if (argc <= 1) { // check if there is a BASH script and its executable path given on command line
        fprintf(stderr, "Error: no BASH script or executable provided\n");
        exit(EXIT_FAILURE);
    } else {
        argv[argc] = strdup("sh"); // add 'sh' as a terminal program
    
        if (0 == system(argv[0] + " " + argv[1])) {
            printf("%s\n", argv[0] + " " + argv[1]); // print the executed BASH script and its executable path
            exit(EXIT_SUCCESS);
        } else {
            fprintf(stderr, "Error: executing '%s' failed\n", argv[0] + " " + argv[1]);
            exit(EXIT_FAILURE);
        }
    }
    
    free(argv[0]); // free the BASH script name and path from the argv array
}