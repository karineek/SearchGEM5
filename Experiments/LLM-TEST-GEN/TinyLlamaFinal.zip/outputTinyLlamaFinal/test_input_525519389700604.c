
#include <stdio.h>
#include <stdlib.h>
#include "vectorize.h"  // this file contains the Vectorization macros
#include "cbrt.h"        // this file contains the cbRT macro
#define BASH_ARGS(n)       {int a[n], n; while (scanf("%d", &a[0]) && --n > 0) {;} printf("Error: too few arguments\n"); exit(1);}
#define BASH_REQDARGS 2