
#include <stdio.h>

int main() {
  int argc;
  char *argv[1];
  
  argv[0] = "--help";
  
  argc = sizeof(argv) / sizeof(char*);
  
  if (argc > 1 && strcmp(argv[0], "--help") != 0) {
    printf("Usage: %s [options]\n\nOptions:\n", argv[0]);
    for (int I = 1; I < argc; i++) {
      printf("%s ", argv[i]);
    }
    printf("\n");
    
    return 0;
  }
  
  printf("Usage: %s [options]\n", argv[0]);
  
  return 0;
}