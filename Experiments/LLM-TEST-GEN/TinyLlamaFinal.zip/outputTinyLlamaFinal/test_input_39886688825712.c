
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    if (argc != 2 || strcmp(argv[1], "help") == 0) {
        printf("Usage: %s [-f|-F] inputfile\n", argv[0]);
        return EXIT_FAILURE;
    } else if (strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "--help") == 0) {
        printf("Help: Print this message and exit.\n");
        return EXIT_SUCCESS;
    }
    
    char* input = argv[1];
    
    if (argc > 2) {
        fprintf(stderr, "Error: Too many arguments. Usage: %s [-f|-F] inputfile\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    FILE* file = fopen(input, "r");
    if (file == NULL) {
        perror("Error: Could not open input file\n");
        return EXIT_FAILURE;
    }
    
    if (feof(file)) {
        fprintf(stderr, "No input file provided. Usage: %s [-h|-f] inputfile\n", argv[0]);
        return EXIT_FAILURE;
    } else {
        fprintf(stdout, "Reading input from '%s'...\n", input);
    }
    
    // Calling Register Allocation and Collection of optimization passes here
    if (registerAlias(file)) {
        fclose(file);
        printf("Register Allocation optimized.\n");
    } else if (registerAll(file)) {
        fclose(file);
        printf("Collection of all optimizations optimized.\n");
    } else {
        fprintf(stderr, "Error: One or more passes failed. Usage: %s [-h|-f] inputfile\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    fclose(file);
    
    printf("Done.\n");
    return EXIT_SUCCESS;
}