
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    int option = 0;
    
    while (option <= 1 && !(argc == 2 || argc > 3)) { // catch invalid arguments
        printf("Error: Invalid argument\n");
        
        if (argc >= 2) {
            if (argv[1][0] != '-') {
                option = atoi(argv[1]);
            } else {
                switch (option) {
                    case 0: // print help message and exit program
                        printf("Usage: %s [options]\n", argv[0]);
                        printf("\t-h\tsame as help\n");
                        printf("\t-s\trerun only after all arguments are processed\n");
                        break;
                    case 1: // run application
                        exit(EXIT_SUCCESS);
                        break;
                    default:
                        printf("Error: Invalid option\n");
                        break;
                }
            }
        } else {
            printf("Error: No arguments provided\n");
        }
        
        printf("Enter your choice (1-4): ");
        fflush(stdout);
        
        if (!scanf("%d", &option)) { // check for valid input
            printf("Error: Invalid input\n");
            return EXIT_FAILURE;
        } else if (option <= 0 || option > 4) {
            printf("Error: Invalid choice\n");
            return EXIT_FAILURE;
        }
    }
    
    switch (option) {
        case 1: // run application
            exit(EXIT_SUCCESS);
            break;
        default:
            printf("Error: Invalid option\n");
            return EXIT_FAILURE;
    }
}