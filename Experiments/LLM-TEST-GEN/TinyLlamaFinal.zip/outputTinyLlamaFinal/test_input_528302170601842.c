
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Main function
int main(int argc, char *argv[]) {
    int i;
    FILE *fp;

    // Check if the number of arguments is 2 (program name) and > 0
    if (argc != 2 || argv[1][0] == '-') {
        printf("Error: invalid number of arguments\n");
        return -1;
    } else {
        // Open input file for reading
        fp = fopen(argv[1], "r");

        if (fp == NULL) {
            printf("Error: could not open file %s\n", argv[1]);
            return -2;
        }

        // Read the number of lines and skip blank lines
        while (fscanf(fp, "%d", &i) != EOF && i > 0) {
            printf("%d ", i);
            fscanf(fp, "\n");
        }

        // Close file
        if (feof(fp)) {
            printf("Error: input file empty\n");
        } else {
            printf("Input file has %d lines\n", i);
        }

        // Cleanup memory
        fclose(fp);
    }

    return 0;
}