
#include <stdio.h>
#include "mbrtoc16.h"

int main(void) {
    char *input = argv[1];
    int output_len;

    /* Input must be a single line of BASH */
    if (!input || !isspace(*input)) {
        fprintf(stderr, "Error: Invalid input\n");
        return 1;
    }

    output_len = mbrtoc16(input, strlen(input) + 1, (char *)"", 0);

    if (output_len == 0 || output_len > 256) {
        fprintf(stderr, "Error: Invalid output\n");
        return 1;
    }

    printf("%s\n", input + output_len);

    return 0;
}