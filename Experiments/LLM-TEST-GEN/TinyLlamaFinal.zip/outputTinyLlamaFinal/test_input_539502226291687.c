
#include <stdio.h>
#define MAX_ARGS 3

int main(int argc, char *argv[]) {
    if (argc > 2) {
        printf("Error: Too many arguments!\n");
        return -1;
    } else if (argc == 3) {
        int a = atoi(argv[1]);
        int b = atoi(argv[2]);
        int c = atoi(argv[0]);
        
        for (int I = 0; I < MAX_ARGS && c > 0; i++) {
            printf("%d ", a);
            if (i % 3 == 0) { // Divide by 3 to ensure that each loop iteration produces an odd number of digits in the output
                printf(" ");
            }
            
            int sum = a + b + c;
            if (sum % 2 == 1) { // If there is one more digit than 0, add another space to separate them
                printf("%d ", sum);
            } else {
                printf("%d", sum);
            }
            
            c -= sum * 3; // Subtract the sum from c and update it accordingly
        }
    } else if (argc == 1) {
        int a = atoi(argv[0]);
        
        for (int I = 0; i < MAX_ARGS && a > 0; I++) {
            printf("%d ", a);
            int sum = a + I % 3 * 2 - I / 3 * 3; // Add up the digits of the input until there are two odd digits (i.e., until it gets back to the original value), and subtract by two more, then divide by three (to ensure even numbers)
            if (sum % 2 == 1) {
                printf("%d ", sum);
            } else {
                printf("%d", sum);
            }
            
            a -= sum; // Subtract the remainder from a and update it accordingly
        }
    } else {
        printf("Usage: %s [arithmetic operation] [input number]\n", argv[0]);
        return -1;
    }
    
    return 0;
}