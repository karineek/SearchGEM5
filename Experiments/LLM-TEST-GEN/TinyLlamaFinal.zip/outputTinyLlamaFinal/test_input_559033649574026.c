
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>

#define MAX_PROCS 10 // maximum number of concurrent processes allowed to run simultaneously

int main(int argc, char **argv) {
    if (argc != 2 || !strcmp(argv[1], "-n")) return 0;
    
    int n = atoi(argv[1]);
    if (n < 1) printf("Invalid number of concurrent processes: must be > 0\n");
    else if (n % 2 != 0) printf("Number of concurrent processes must be evenly divisible by 2\n");
    else {
        int procs[MAX_PROCS]; // allocate memory for a vector of integers representing concurrent process IDs
        int p = 0;           // initialize index to 0
        
        while (p < n && p < MAX_PROCS) {
            procs[p] = p;       // assign each concurrent process ID as the current process's index
            ++p;               // increment its index to follow next process
        }
        printf("Maximum number of concurrent processes allowed is %d (%d)\n", n, n);
        
        if (argc == 3) {
            int pid = atoi(argv[2]);
            waitpid(pid, nullptr, WUNTRACED); // wait for the process to finish and output its exit status
            
            printf("Process %d finished with status %d\n", procs[pid], WEXITSTATUS(WSTOPPED));
        }
        
        int pid = -1;
        if (argc > 3 && !strcmp(argv[2], "-") || argv[2][0] == '-') { // process is specified with argument or stdin as input
            printf("Enter the number of processes to run: "); // prompt user for input
            
            while (true) {
                printf("Process ");
                
                // read input from standard input and convert it to integer
                int temp;
                if (!scanf("%d", &temp)) break;
                
                pid = temp;
                break;
            }
        }
        
        while (procs[pid] != -1) {
            printf("Process %d is still running\n", procs[pid]);
        }
    }
    
    return 0;
}