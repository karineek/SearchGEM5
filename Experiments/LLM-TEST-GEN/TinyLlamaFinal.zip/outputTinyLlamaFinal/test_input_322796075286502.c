
#include <stdlib.h> /* for malloc() */
#include <string.h>  /* for strlen() */
#include "tm_min.h"   /* tm_min macro for time-stamping code */

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <input> [options]\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    struct tm *now = localtime(&time(NULL)); /* get current time */
    char buf[1024];                /* buffer for output */
    const char *date = "%Y-%m-%d"; /* date format string */
    const char *time_format = "%a %b %d %H:%M:%S %Z %Y"; /* time format string */

    /* print current time */
    strftime(buf, sizeof(buf), date, now);
    printf("Current Time: %s\n", buf);

    /* check if program should be optimized */
    tm_min(&tm_mto_time);

    /* output input using the specified format */
    fprintf(stdout, "Input: [%s] ", argv[1]);
    fputs(buf, stdout);
    fputc('\n', stdout);

    /* run program with optimized MTO */
    return 0;
}