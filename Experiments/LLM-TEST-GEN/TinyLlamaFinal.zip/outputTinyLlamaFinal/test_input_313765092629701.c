
#include <stdio.h>
#include <stdlib.h>
#define SIZE 100

int main(int argc, char *argv[]) {
    int a[SIZE], b[SIZE], c[SIZE];
    FILE *f = fopen("input.txt", "r");
    if (!f) {
        printf("Unable to open input file\n");
        return 1;
    }
    
    for (int I = 0; I < SIZE; i++) {
        a[i] = fread(a + i, sizeof(int), SIZE, f);
        b[i] = atoll(argv[i]) * atoll(argv[i+1]);
    }
    
    for (int I = 0; I < SIZE; i++) {
        c[i] = a[i] + b[i];
    }
    
    fclose(f);
    
    printf("Output:\n");
    for (int I = 0; I < SIZE; i++) {
        printf("%d ", c[i]);
    }
    printf("\n");
    
    return 0;
}