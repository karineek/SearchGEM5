
#include <stdio.h>
#include "LLVM/IR/CFG.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/Module.h"

void print(const char *str) {
    printf("%s\n", str);
}

int main() {
    LLVMContext ctx;
    Module *module = nullptr;
    Function *fun = nullptr;

    // Create a function named "print" in the context specified by the ctx parameter
    fun = llvm::createFunction("print", module, LLVM_NEXT_INOUT_MEMORY);
    
    // Inline the print function to be called by LLVM IR code
    fun->getBasicBlocks()[0]->getBasicBlock()->addInliningInfo(1);
    
    // Create a function named "foo" in the same context (i.e., using the same module)
    fun = llvm::createFunction("foo", module, LLVM_NEXT_INOUT_MEMORY);
    
    // Call the foo function with arguments specified by the argv array passed as parameters to the main() function
    printf("%s\n", print(argv[1]));
    
    return 0;
}