
#include <stdio.h> // Include standard input/output library (printf())
#include <sys/types.h> // Include system types (struct stat)
#include <fcntl.h> // Include file control library (open() and F_GETFD())

// Function to print a line of text, including its newline
void printLine(const char* str) {
    printf("%s\n", str);
}

int main(int argc, char** argv) {
    // Process arguments (argv[1]: the input filename)
    if (argc < 2) {
        printf("Error: Invalid number of arguments.\n");
        return -1;
    }
    
    const char* inputFileName = argv[1]; // Input file name argument
    
    // Open the input file for reading
    int fd = open(inputFileName, O_RDONLY | O_LARGEFILE); // File descriptor (F_GETFD() + O_RDONLY)
    if (fd < 0) {
        perror("Error: Opening input file failed.\n");
        return -1;
    }
    
    // Get file attributes (including file size, file type, and time)
    struct stat st;
    int rc = fstat(fd, &st);
    if (rc < 0) {
        perror("Error: Fstat() failed.\n");
        return -1;
    }
    
    // Open the output file for writing
    int fdOutput = open("output.txt", O_CREAT | O_WRONLY, S_IRUSR | S_IWUSR); // File descriptor (O_CREAT + O_WRONLY)
    if (fdOutput < 0) {
        perror("Error: Creating output file failed.\n");
        return -1;
    }
    
    // Write all the lines of input to output file in parallel, with each line getting its own file descriptor
    size_t bufferSize = 4 * 1024; // Size of buffer (in bytes)
    for (ssize_t bytesRead = ::read(fd, buffer, bufferSize); bytesRead > -1; bytesRead = ::read(fd, buffer, bufferSize)) {
        printf("%s", buffer);
        int rc = write(fdOutput, buffer, bytesRead); // Write the buffer to output file descriptor (O_WRONLY)
        if (rc < 0) {
            perror("Error: Writing to output file failed.\n");
            return -1;
        }
    }
    
    // Close all files, and wait for any pending I/O operations to complete
    int rc = close(fd);
    if (rc < 0) {
        perror("Error: Closing input file failed.\n");
        return -1;
    }
    rc = close(fdOutput);
    if (rc < 0) {
        perror("Error: Closing output file failed.\n");
        return -1;
    }
    
    printf("Done.\n"); // Print a success message
    
    return 0;
}