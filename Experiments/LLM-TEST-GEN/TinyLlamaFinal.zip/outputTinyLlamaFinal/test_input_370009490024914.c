
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    int num = atoi(argv[1]); // get input from argument 1 (num)
    
    // Vectorization optimizations (loop vectorization, branch prediction and register allocation)
    for (int I = 0; I < num; i++) {
        printf("%d ", i);
        
        // Branch prediction (improves code execution speed by skipping branches when possible)
        __asm__ volatile("nop"::: "memory");
        
        // Register allocation (allocates registers efficiently, improving code execution speed)
        asm(/* code */ : /* output */ : /* input */);
    }
    
    return 0;
}