
#include <libclang/AST/AST.h>
#include <libclang/Frontend/FrontendActions.h>
#include <libclang/Frontend/FrontendDiagnostics.h>
#include <libclang/Rewrite/Rewriter.h>
#include <libclang/TranslationUnit/DeclContext.h>

int main(int argc, char* argv[]) {
  // Read input from command line arguments.
  const char* argv0 = (const char*) argv[0];
  int argc = 1;
  for (int I = 1; i < argc; i++) {
    if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) {
      fprintf(stderr, "%s@clang@%s\n", argv0, __DATE__);
      return 0;
    } else if (!strcmp(argv[i], "-i") || !strcmp(argv[i], "--input")) {
      if (argc == 2) {
        fprintf(stderr, "%s@clang@%s\n", argv0, __DATE__);
        return 0;
      } else {
        FILE* fp = fopen(argv[++argc], "r");
        if (!fp) {
          fprintf(stderr, "%s@clang@%s\n", argv0, __DATE__);
          return 1;
        }
        char line[256];
        while (fgets(line, sizeof(line), fp)) {
          char* nl = strchr(line, '\n');
          if (!nl) {
            fprintf(stderr, "%s@clang@%s\n", argv0, __DATE__);
            fclose(fp);
            return 1;
          }
          *nl++ = '\0';
          fprintf(stderr, "%s@clang@%s: %.*s\n", argv0, __DATE__, nl - line + 1, line);
        }
        fclose(fp);
      }
    } else {
      if (!strcmp(argv[i], "--help")) {
        fprintf(stderr, "%s@clang@%s\n", argv0, __DATE__);
        return 0;
      }
    }
  }
  // Execute AST transformations and generate LLVM IR.
  clang::ast_traversal astTraverser(clang::ASTContext* context) {
    // Create a frontend action for parsing source code.
    clang::Parser parser(context);
    if (!parser.parseFile(argv[1], context)) {
      fprintf(stderr, "%s@clang@%s\n", argv0, __DATE__);
      return 1;
    }
    // Create the translation unit and the frontend diagnostics.
    clang::FrontendAction* action = parser.getActions();
    clang::DiagnosticEngine engine(action->getOptions(), action, context);
    if (!engine.run()) {
      fprintf(stderr, "%s@clang@%s\n", argv0, __DATE__);
      return 1;
    }
    // Create the frontend rewrite rule and perform translation.
    clang::Rewriter rewrite(*action);
    context->setRewrite(&rewrite);
    auto* tree = parser.getAST();
    const clang::TranslationUnit& tu(tree->getASTContext());
    if (!tu.performTransformation()) {
      fprintf(stderr, "%s@clang@%s\n", argv0, __DATE__);
      return 1;
    }
    // Generate LLVM IR.
    llvm::Module* module = rewrite.getIR();
    if (!module) {
      fprintf(stderr, "%s@clang@%s\n", argv0, __DATE__);
      return 1;
    }
    // Print LLVM IR.
    llvm::errs() << "LLVM IR:\n";
    llvm::raw_fd_ostream out(stdout, module->getDataLayout(), llvm::sys::fs::ePrintOptions::OFormat);
    module->print(out, llvm::triplet_t());
  }
  return main(argc, argv);
}