
#include <stdio.h>  // for fopen, fread, fclose, puts
#include <stdlib.h> // for exit, malloc, free
#include <string.h> // for strlen

int main(int argc, char *argv[]) {
    FILE *file = fopen(argv[1], "r"); // Read File
    
    if (!file) {
        puts("Error: Input file not found.");
        return 0; // Exits program
    }
    
    int lineCount = 0, charCount = 0, ch = getc(file); // Count line and character count
    
    while (ch != EOF) {
        switch (ch) {
            case '\n':
                ++lineCount;
                break;
            
            case ' ':
                ++charCount;
                break;
            
            default: // Ignore non-letter characters
                putc(ch, file); // Print character to file
                ++charCount;
        }
        
        ch = getc(file);
    }
    
    fclose(file); // Close Input File
    
    puts("Line: %d\tCharacters: %d", lineCount, charCount);
    
    return 0;
}