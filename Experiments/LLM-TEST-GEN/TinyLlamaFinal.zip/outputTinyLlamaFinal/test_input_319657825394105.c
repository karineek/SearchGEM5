
#include <stdio.h>
#include <stdlib.h> // for malloc()
#include "scalbnf.h"

int main(int argc, char* argv[]) {
  int i, j;
  
  // Check if input file name is specified
  if (argc != 2) {
    printf("Error: expected filename as argument\n");
    return EXIT_FAILURE;
  }
  
  // Open input file for reading
  FILE* input = fopen(argv[1], "r");
  if (!input) {
    perror("Failed to open input file\n");
    exit(EXIT_FAILURE);
  }
  
  // Read input data from file and check for errors
  char buffer[256];
  while (fgets(buffer, sizeof(buffer), input) != NULL) {
    if (!isdigit(buffer[0]) && buffer[0] != '-') {
      printf("Error: non-numeric character in input\n");
      return EXIT_FAILURE;
    }
  }
  
  // Close input file and free allocated memory
  fclose(input);
  free(buffer);
  
  // Perform program execution
  if (argc == 3) {
    printf("Enter first number to find factorial of:\n");
    scanf("%d", &i);
    
    int factorial = fact_naive(i);
    
    printf("Factorial of %d is: %d\n", i, factorial);
  } else {
    printf("Invalid input file\n");
    return EXIT_FAILURE;
  }
  
  // Perform program execution
  if (argc != 2) {
    printf("Usage: %s filename [factorial of first number]\n", argv[0]);
  } else {
    printf("Enter second number to find factorial of:\n");
    scanf("%d", &j);
    
    int factorial = fact_naive(j);
    
    printf("Factorial of %d is: %d\n", j, factorial);
  }
  
  return EXIT_SUCCESS;
}