
#include <stdio.h>
#include <stdlib.h>
#define MAXLINE 1024

int main(int argc, char *argv[]) {
    int line_num = 0;
    FILE *fp;
    char line[MAXLINE];

    if (argc != 2) {
        fprintf(stderr, "Usage: %s <input file>\n", argv[0]);
        return 1;
    } else {
        fp = fopen(argv[1], "r");
        if (!fp) {
            perror("Failed to open input file.");
            return 2;
        }

        while (fgets(line, MAXLINE, fp) != NULL) {
            line_num++;
            printf("%s", line);
            puts(line);
        }

        fclose(fp);
    }

    return 0;
}