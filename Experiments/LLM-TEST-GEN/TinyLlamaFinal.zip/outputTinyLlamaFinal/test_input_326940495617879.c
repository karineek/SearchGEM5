
#include <stdio.h> /* Standard input/output headers */
#include <stdlib.h> /* Memory allocation headers */
#define BAHSH 1 /* Compiler specific defines */

/* Function prototypes (C99) */
int main(int argc, char *argv[]) {
    int a = atoi(argv[1]); /* Prompt for argument */
    printf("BASSH: %.2f\n", BASSH_Complex_Atan(a));
    return 0;
}