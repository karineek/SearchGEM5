
#include <stdio.h>
#include "optimization.h"
#include "frontend.h"
#include "atexit.h"

/*
   This program calculates the maximum value of a given binary function f(x,y) = max(x+y, y+x). The input is taken from the command line only.
*/
int main(int argc, char *argv[]) {
    int n, m;
    float (*f)(float, float);
    
    /* Parse input */
    if (argc > 1) {
        if (strcmp(argv[1], "-") == 0) { /* - for default value */
            f = &optimize_binary;
            n = atoi(argv[2]);
            m = atoi(argv[3]);
            fprintf(stderr, "maximum(%s,%d,%d)\n", argv[1], n, m);
        } else { /* non-default value */
            printf("Usage: %s - <binary function name> [<number of arguments>] [<input value>]\n", argv[0]);
            f = &optimize_function;
            n = atoi(argv[2]);
            m = atoi(argv[3]);
        }
    } else {
        printf("Usage: %s - <binary function name> [<number of arguments>] [default value for input] [optional value]\n", argv[0]);
        f = &optimize_function;
        n = atoi(argv[2]);
        m = atoi(argv[3]);
    }
    
    /* Optimization */
    float (*f_c)();
    float (*f_d)();
    if (n == 1 && m == 1) { /* single function for binary optimization */
        f_c = optimize_binary;
        f_d = &optimize_function;
        f(f_c, *argv);
    } else { /* multiple functions for binary and function optimization */
        if (n <= m) {
            f_c = optimize_binary;
            f_d = &optimize_function;
            float (*optimal)();
            if (!strcmp(argv[2], "default")) {
                optimal = &f_d;
            } else {
                fprintf(stderr, "Error: invalid number of arguments for binary function\n");
                return 1;
            }
            f(optimal, *argv);
        } else {
            f_c = optimize_binary;
            f_d = &optimize_function;
            float (*f)();
            if (!strcmp(argv[2], "default")) {
                f = &f_d;
            } else {
                printf("Error: invalid number of arguments for function optimization\n");
                return 1;
            }
            int i = 0, n_args = atoi(argv[3]);
            if (n_args > m) {
                fprintf(stderr, "Error: too many arguments for binary and function optimization\n");
                return 1;
            }
            float (*f_optimal)();
            if (!strcmp(argv[2], "-")) { /* default value */
                f_optimal = &f_d;
            } else {
                printf("Usage: %s <binary function name> [default value for input] [optional value]\n", argv[0]);
                f_optimal = &f_d;
                n_args++;
            }
            while (i < m && n <= m) {
                if (strcmp(argv[3], "default") != 0 || !n_args--) {
                    printf("Error: invalid number of arguments for function optimization\n");
                    return 1;
                }
                f(f_c, argv + i);
            }
            if (!strcmp(argv[2], "default")) {
                f = &f_d;
            } else {
                printf("Error: invalid number of arguments for binary function\n");
                return 1;
            }
            while (i < n && n <= m) {
                if (strcmp(argv[3], "default") != 0 || !n_args--) {
                    printf("Error: invalid number of arguments for binary function\n");
                    return 1;
                }
                f(f_c, argv + i);
            }
        }
    }
    
    /* AtExit */
    float (*f2)();
    if (m == 1 && n == 1) { /* single function for binary and function optimization */
        f2 = optimize_function;
        f(f2, *argv);
    } else if (n <= m) {
        fprintf(stderr, "Error: invalid number of arguments for binary function\n");
        return 1;
    } else {
        f2 = optimize_function;
        int i = 0, n_args = atoi(argv[3]);
        if (n_args > m) {
            fprintf(stderr, "Error: too many arguments for binary and function optimization\n");
            return 1;
        }
        float (*f)();
        if (!strcmp(argv[2], "-")) { /* default value */
            f = &f_d;
        } else {
            printf("Usage: %s <binary function name> [default value for input] [optional value]\n", argv[0]);
            f = &f_d;
            n_args++;
        }
        while (i < m && n <= m) {
            if (strcmp(argv[3], "default") != 0 || !n_args--) {
                printf("Error: invalid number of arguments for function optimization\n");
                return 1;
            }
            f(f2, argv + i);
        }
        if (!strcmp(argv[2], "default")) {
            f = &f_d;
        } else {
            printf("Error: invalid number of arguments for binary function\n");
            return 1;
        }
        while (i < n && n <= m) {
            if (strcmp(argv[3], "default") != 0 || !n_args--) {
                printf("Error: invalid number of arguments for binary function\n");
                return 1;
            }
            f(f2, argv + i);
        }
    }
    
    return 0;
}