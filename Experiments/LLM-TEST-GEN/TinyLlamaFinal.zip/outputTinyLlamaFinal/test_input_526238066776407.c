
#include <stdio.h> // Includes printf() and fprintf() functions
#include <unistd.h> // Includes getopt() function from the stdlib.h header file

int main(int argc, char *argv[]) {
    int opt;
    const char *program = "C program";
    int binary_format = 0, object_format = 0, profile_guipped = 1; // Define constants to indicate the options selected by user
    
    while ((opt = getopt(argc, argv, "p:b:o:f:")) != -1) {
        switch (opt) {
            case 'p':
                profile_guipped = 0; // Disable GUI instrumentation, use default behaviour of the compiler
                break;
            case 'b':
                binary_format = atoi(optarg); // Convert binary format to an integer, then store it in a variable
                if (binary_format < 1 || binary_format > 3) { // Check that the binary format is between 1 and 3
                    printf("Invalid binary format: must be between 1 and 3.\n");
                    return EXIT_FAILURE;
                }
                break;
            case 'o':
                object_format = atoi(optarg); // Convert object format to an integer, then store it in a variable
                if (object_format < 1 || object_format > 3) { // Check that the object format is between 1 and 3
                    printf("Invalid object format: must be between 1 and 3.\n");
                    return EXIT_FAILURE;
                }
                break;
            case 'f':
                profile_guipped = 0; // Disable GUI instrumentation, use default behaviour of the compiler
                break;
            case '?':
                printf("Usage: %s [options] <source file> ...\n", program);
                return EXIT_FAILURE; // Exit with error code if help option was selected by user
            default:
                printf("Invalid option: %c.\n", optopt);
                return EXIT_FAILURE; // Exit with error code if unrecognized option is selected by user
        }
    }
    
    int src_size = 0, dest_size = 0;
    for (int I = 0; I < argc; i++) {
        const char *src_name = argv[i];
        
        if (src_name[0] == '-' && src_name[-1] == 'p') { // Check that the binary format has been specified
            src_size = strtoul(optarg + 1, &endptr, 0); // Convert binary format to an integer, then store it in a variable and update the '+' sign
            if (*endptr != '+' && !isspace(*endptr)) { // Check that the '-' sign has been converted correctly
                printf("Invalid binary format: must be between -2 and 3.\n");
                return EXIT_FAILURE;
            }
        } else if (src_name[0] == '-' && src_name[-1] == 'b') { // Check that the object format has been specified
            src_size = strtoul(optarg + 1, &endptr, 10); // Convert object format to an integer, then store it in a variable and update the '+' sign
            if (*endptr != '+' && !isspace(*endptr)) { // Check that the '-' sign has been converted correctly
                printf("Invalid object format: must be between 1 and 3.\n");
                return EXIT_FAILURE;
            }
        } else {
            src_size = strtoul(optarg, &endptr, 0); // Convert filename to an integer, then store it in a variable and update the '+' sign
            if (*endptr != '+' && !isspace(*endptr)) { // Check that the '-' sign has been converted correctly
                printf("Invalid source file: must be between -2 and 3.\n");
                return EXIT_FAILURE;
            }
        }
        
        if (src_size == 0) {
            printf("%s: Invalid source file: cannot determine size of %s.\n", program, src_name); // Display an error message if the binary format or object format could not be determined for a non-existent source file
            return EXIT_FAILURE; // Exit with error code if input is invalid
        }
        
        dest_size = src_size * profile_guipped; // Calculate destination size based on source size and profile-guipped flag
        printf("%s: Destination size of %s (%d) at %" PRIu64 " (%.1f Gb) with %s guipping.\n", program, src_name, dest_size, static_cast<double>(dest_size) / 1024 * 1024 * 1024, profile_guipped ? " GUI" : "", argv[i] == -1 ? "main" : argv[i]); // Display output based on destination size and options selected
        
        src_size = dest_size; // Keep the same source size for the next input file in case it is used to calculate the destination size
    }
    
    if (src_size == 0) {
        printf("%s: Invalid source file: cannot determine destination size.\n", program); // Display an error message if the source file has no valid information to calculate the destination size for
        return EXIT_FAILURE; // Exit with error code if input is invalid
    }
    
    return EXIT_SUCCESS; // Exit successfully
}