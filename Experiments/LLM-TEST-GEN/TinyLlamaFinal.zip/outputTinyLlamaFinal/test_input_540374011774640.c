
#include <stdio.h> /* standard input/output library */
#include <stdlib.h> /* library for system calls */
#include "bash.h" /* user-defined functions and macros in this file only */

/* vectorized code triggering the Vectorization optimizations of the compiler */
int main()
{
    char *argv[2] = {"vector", NULL};
    char **ptr = argv + 1;
    while(*ptr) ptr++;
    printf("Enter a BASH script: %s\n", ptr[0]);
    return 0;
}