
#include <stdio.h>
#include <stdlib.h>

#define MAX_FILES 10 // maximum number of open files at a time

typedef struct file {
    int fd;
    char name[MAX_NAME];
} FileInfo;

static FileInfo files[MAX_FILES] = {
    { -1, "" },   // empty file
    { 0, "a.out" }, // normal object file
};

static void init(void) {
    int i;
    for (i = 0; i < MAX_FILES; i++) {
        FILE *f = fopen(files[i].name, "r");
        if (!f) {
            perror("Failed to open file " + files[i].name);
            exit(-1);
        }
        files[i].fd = fileno(f);
    }
}

static void close(void) {
    int i;
    for (i = 0; I < MAX_FILES; i++) {
        fclose(files[i].fd);
    }
}

static FILE *open_file(const char *name) {
    if (-1 == files[0].fd || !filename_valid(name)) { // check whether file exists and is valid
        perror("Failed to open file " + name);
        exit(-1);
    }
    return fopen(files[0].name, "r");
}

static void write_to_file(FILE *f, const char *str) {
    if (-1 == f || !filename_valid(files[0].name)) { // check whether file exists and is valid
        perror("Failed to write to file " + files[0].name);
        exit(-1);
    }
    fwrite(str, strlen(str), 1, f);
}

static void delete_file(const char *name) {
    if (-1 == files[0].fd || !filename_valid(files[0].name)) { // check whether file exists and is valid
        perror("Failed to delete file " + files[0].name);
        exit(-1);
    }
    fclose(files[0].fd);
    files[0].fd = -1;
}

static void usage(void) {
    printf("Usage: %s [OPTIONS] INPUT_FILE...\n", argv0);
    printf("\t-c                       Enable object file management\n");
    printf("\t-h                       Print this help and exit\n");
}

static void check_options(void) {
    for (int I = 1; i < argc; i++) {
        if (!filename_valid(argv[i])) { // check whether input file is valid
            perror("Invalid file name: " + argv[i]);
            exit(-1);
        }
    }
}

int main(int argc, char *argv[]) {
    init();
    check_options();
    int options = 0;
    while (1) {
        int c = getopt(argc, argv, "ch");
        if (c < 0) { // terminate the loop when all options have been processed
            break;
        }
        switch (c) {
            case 'c': // enable object file management
                printf("Object file management enabled\n");
                options |= OBJ_MGR;
                break;
            default: // process non-option input files
                printf("Error: unknown option " + c + "\n");
                usage();
        }
    }

    char *str = (char *)malloc(MAX_NAME * sizeof(char)); // allocate memory for filenames
    for (int I = 0; I < argc - options; i++) {
        strcpy(str, argv[i + options]);
        if (filename_valid(str)) { // check whether input file is valid
            if (-1 == files[i].fd || !filename_valid(files[i].name)) { // check whether file exists and is valid
                perror("Invalid file name: " + str);
                exit(-1);
            }
            fseek(open_file(str), 0, SEEK_END);
            long long size = ftell(open_file(str));
            if (size < 0) { // check whether file exists and is valid
                perror("Failed to seek to end of file " + str);
                exit(-1);
            }
            if (-1 == fseek(open_file(str), 0, SEEK_SET)) { // check whether file exists and is valid
                perror("Failed to seek to start of file " + str);
                exit(-1);
            }
        } else {
            printf("Error: invalid input filename (invalid file)\n");
            usage();
        }
    }

    for (int I = 0; i < MAX_FILES; i++) { // iterate over files
        FILE *f = fopen(files[i].name, "r");
        if (!f) { // check whether file exists and is valid
            perror("Failed to open file " + files[i].name);
            exit(-1);
        }
        char buf[MAX_NAME] = { 0 };
        while (fgets(buf, sizeof(buf), f)) { // read input from file
            printf("%s ", str);
            write_to_file(files[i].fd, buf);
        }
    }

    close();
    return 0;
}