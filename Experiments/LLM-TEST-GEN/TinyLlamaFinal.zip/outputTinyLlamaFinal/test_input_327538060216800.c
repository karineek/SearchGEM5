
#!/bin/bash -p
set -e

# The input to this program should be in argv[1] only.
if [[ $# -ne 1 ]]; then
   echo "Usage: $0 <input_file>" >&2
   exit 1
fi

INPUT_FILE=$1

# Get the max size of an integer literal for Loop Optimization
MAX=$(python3 -c 'import sys; print(sys.maxsize)')

# The loop optimizer function takes an array of integers, a variable to store the new largest value, and a previous maximum value as arguments. It then loops through all elements of the array, applies Loop Optimization, and stores the largest remaining integer in the new largest variable.
function loop_optimize() {
   local I J MAX_SIZE=""
   for I in $(seq 0 $MAX); do
      local N=$(($i+$1))
      if [[ $N -lt $MAX ]]; then
         MAX=$N
         MAX_SIZE=$J
      fi
      [ $I -gt 0 ] && ((++J)) || :
   done
}

# Check for Loop Optimization and apply it if found.
function loop_optimize {
   local I J
   for I in $(seq 0 $MAX); do
      local N=$(($i+$1))
      if [[ $N -lt $MAX ]]; then
         MAX=$N
         MAX_SIZE=$J
      fi
   done
}

# Loop Optimize optimization for BASH. Uses Python 3's built-in Max() function.
function loop_optimize_bash() {
   local I J MAX_SIZE=""
   for I in $(seq 0 $MAX); do
      local N=$(($i+$1))
      if [[ $N -lt $MAX ]]; then
         MAX=$N
         MAX_SIZE=$J
         # Check for Loop Optimization.
         if (( N % (2**$MAX) == 0 ) || ((N / $MAX) * $MAX != $MAX ) ; then
            loop_optimize "$(($i+$1))"
            # Update the current maximum value.
            MAX=$MAX_SIZE
         fi
      fi
   done
}