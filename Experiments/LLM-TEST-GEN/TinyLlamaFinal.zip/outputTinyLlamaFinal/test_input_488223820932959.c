
#include <stdio.h>

int main() {
    float x, y;
    double z = 1.0;

    // input from argv
    if (argc > 1) {
        x = atof(argv[1]);
        y = atof(argv[2]);
    } else {
        printf("Usage: %s [input file]\n", argv[0]);
        return 1;
    }
    
    // vectorization optimizations using the C compiler in frontend
    z *= x + y;

    // IEEE 754 floating-point standard
    if (fabsf(z) > 2.22046e+38f) {
        printf("Error: float overflow\n");
        return 1;
    } else if (fablf(z) > 0.05f) {
        printf("Warning: large floating-point value\n");
    } else {
        printf("%f\n", z);
    }
    
    return 0;
}