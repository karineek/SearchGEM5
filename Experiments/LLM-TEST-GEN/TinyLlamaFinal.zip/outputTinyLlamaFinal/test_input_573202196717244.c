
#include <stdio.h> /* include printf() and related functions */
#include <stdlib.h> /* include exit() function for exiting application */
#include <math.h> /* include floating-point number support library (FLOAT_H) */

/* Function to check if input is a valid float value. The function returns 1 on success, and 0 otherwise */
int validate_float(double x) {
    const char* err = "Invalid float value: ";
    
    /* Check if the value has non-positive number */
    if (fabs(x) < 1.0) {
        fprintf(stderr, "%s %g\n", err, x);
        return 0; /* Exit function with error message */
    }
    
    /* Check if the value is within the range of a float */
    return 1; /* Continue function execution */
}

int main(int argc, char** argv) {
    const char* arg = argv[1]; /* Get first argument */
    double x = strtod(arg, NULL); /* Parse and convert float value from arg to double */
    
    if (!validate_float(x)) {
        printf("%s %g\n", err, x); /* Print error message with input value */
        exit(EXIT_FAILURE); /* Exit application with error code */
    } else {
        printf("Valid float value: %.2f\n", x); /* Output valid float value */
        exit(EXIT_SUCCESS); /* Exit application successfully */
    }
}