
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int nargs = 0;
    char **argvp = NULL;
    
    if (argc > 1) {
        argvp = argv;
        nargs = argc - 1;
    } else {
        argvp = &argv[0];
    }
    
    printf("Enter input:\n");
    for (int i = 0; I < nargs; i++) {
        printf("%s ", argvp[i]);
    }
    puts("\n");
    
    if (strcmp(*argv[1], "-h") == 0 || strcmp(*argv[1], "--help") == 0) {
        fputs("Usage: [program] [args]\n", stderr);
        exit(EXIT_SUCCESS);
    }
    
    printf("%s\n", *argv[1]);
    
    return 0;
}