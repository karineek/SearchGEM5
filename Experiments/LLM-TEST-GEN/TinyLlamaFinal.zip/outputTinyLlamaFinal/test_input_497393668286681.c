
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include "../bin/clang-15.0.7/include/clang/Basic/Diagnostics.h"

int main(int argc, char** argv) {
    const char* input = (argc > 1) ? argv[1] : ""; // Get user input from BASH shell
    
    if (input == NULL || *input != '\0') {
        printf("Input must not be empty\n");
        return 1;
    }
    
    pgo_t* pgo = pgo_create(CLANG_SUPERKIND_CPU, CLANG_OPTION_PGO);
    if (pgo == NULL) {
        printf("Failed to create PGO context\n");
        return 1;
    }
    
    // Perform profile-guided optimization
    pgo_run(pgo, input, true);
    
    // Check if optimization was successful and print results
    if (pgo->success == true) {
        printf("Profile-Guided Optimization successful\n");
        for (int i = 0; i < pgo->results.size(); i++) {
            printf("%s ", pgo->results[i].name);
        }
    } else {
        printf("Profile-Guided Optimization failed\n");
    }
    
    // Free PGO context and return success/failure
    pgo_free(pgo);
    return 0;
}