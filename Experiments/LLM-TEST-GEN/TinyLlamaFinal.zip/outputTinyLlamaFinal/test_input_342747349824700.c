
#include <stdio.h> /* For printf() */
#include <string.h> /* For strtok_r() */

int main(int argc, char **argv)
{
    int c;
    char buffer[1024];

    while ((c = getchar()) != EOF && c != '\n') {
        if (c == '\b' || c == '\t') /* Ignore backspace and tab */
            putchar(c);
        else if (c == '\n') {
            buffer[0] = '\0';
            puts(buffer);
            buffer[0] = '\0'; /* Clear buffer */
        } else if (!strchr("0123456789", c)) {
            printf("Error: Invalid character '%c'\n", c); /* Error message for invalid input */
            return 1; /* Return 1 on error */
        } else {
            strcpy(buffer, argv[1]); /* Copy input to buffer */
        }
    }
    
    return 0; /* Exit program with success */
}