
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#define MAX_LINE_LENGTH 1024

// Function to read input from argv[1]
void readInput(char *argv[]) {
    FILE *inputFile;
    char buffer[MAX_LINE_LENGTH];
    
    inputFile = fopen(argv[1], "r");
    if (!inputFile) {
        printf("Error: Failed to open input file\n");
        exit(1);
    }
    
    // Read the entire line into a buffer
    while (fgets(buffer, MAX_LINE_LENGTH, inputFile)) {
        // Trim white spaces and tabs
        size_t len = strcspn(buffer, " \t\n");
        if (len > 0) {
            buffer[len] = '\0';
        } else {
            continue;
        }
        
        // Ignore empty lines or comments
        if (!strcmp(buffer, "#")) {
            continue;
        } else if (!isalpha(buffer[0])) {
            printf("Error: Line does not start with alphabet\n");
            exit(1);
        }
        
        // Parse assembly line into command and operands
        char *token = strtok(buffer, " ");
        while (token != NULL) {
            int opcode = atoi(token);
            if (!opcode) {
                printf("Error: Invalid opcode\n");
                exit(1);
            }
            
            // Remove leading and trailing spaces from operands
            char *operand = token + strspn(token, " \t\n");
            size_t operandLen = strcspn(operand, " \t\n");
            if (operandLen > MAX_LINE_LENGTH) {
                printf("Error: Operand is too long\n");
                exit(1);
            }
            
            // Append operand to command and modify token pointer
            strcat(token, operand);
            token = strtok(NULL, " ");
        }
        
        // Check if line contains valid instructions or comments
        if (strcmp(buffer, "#") == 0 || strchr(buffer, '\n')) {
            continue;
        } else {
            printf("Error: Line does not start with '#' or newline\n");
            exit(1);
        }
        
    }
    
    fclose(inputFile);
}