
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "llvm/ExecutionEngine/Orc/LLVMOrcRuntime.h"

const char *optimization_options[] = {
    "optlevel=2",
    NULL, // don't optimize further
};

int main(void) {
    char **argv;
    int nargs = 0;
    argv = getenv("argv");
    for (nargs = 1; nargs < argc; nargs++) {
        if (!strcmp(argv[nargs], "--help")) {
            printf("Usage: %s [OPTION]...\n", argv[0]);
            return 0;
        }
    }
    
    LLVMContext *context = llvm::createStandardContext();
    Orc::IRBuilder<> builder(context);
    
    int optlevel = 2;
    const char *optname = NULL;
    for (int I = 0; optimization_options[i] != NULL; i++) {
        if (!strcmp(optimization_options[i], "--optlevel")) {
            optlevel = atoi(argv[++nargs]);
            break;
        } else if (strcmp(optimization_options[i], "-" + tolower(argv[nargs-1]))) {
            optname = argv[nargs];
            nargs++;
        }
    }
    
    LLVMBasicBlockBuilder *bbb = builder.CreateIRBuilder();
    LLVMPointerValueBase *bb = bbb->GetInsertBlock()->back();
    
    const char *label_name = NULL;
    for (int I = 0; label_names[i] != NULL; i++) {
        if (!strcmp(label_names[i], optname)) {
            label_name = argv[nargs];
            break;
        }
    }
    
    bbb->SetInsertPoint(&builder.CreateLoad(builder.GetGlobal("g")));
    LLVMBasicBlockRef loop_block = builder.CreateSwitch(bb, NULL);
    LLVMPointerValueBase *label = builder.CreatePointerCast(bbb, bbb->getTarget().getIRBuilderTy());
    
    builder.SetInsertPoint(loop_block);
    bbb = builder.GetBasicBlock();
    bb = builder.CreateLoad(label);
    
    if (optlevel == 2) {
        builder.SetInsertPoint(&builder.CreateCall(Orc::IRBuilder<>::createLoopOptimize()));
        builder.SetInsertPoint(&builder.CreateLoad(builder.GetGlobal("g")));
        bb = builder.CreateSwitch(bb, NULL);
    } else if (optlevel == 1) {
        builder.SetInsertPoint(&builder.CreateCall(Orc::IRBuilder<>::createLoopOptimize()));
        builder.SetInsertPoint(&builder.CreateLoad(builder.GetGlobal("g")));
        bb = builder.CreateSwitch(bb, NULL);
    } else {
        builder.SetInsertPoint(&builder.CreateCall(Orc::IRBuilder<>::createLoopOptimize()));
        builder.SetInsertPoint(&builder.CreateLoad(builder.GetGlobal("g")));
        bb = builder.CreateSwitch(bb, NULL);
    }
    
    for (int I = 0; i < nargs; i++) {
        LLVMValueRef arg_ptr[2] = {
            builder.CreateLoad(&argv[i], "a"),
            builder.CreateLoad(&argv[i+1], "b")
        };
        
        if (optlevel == 1) {
            LLVMPointerValueBase *bb_label = bb->back();
            
            // Check for an already defined label, but only update the label value
            if (builder.CreateLoad(bb_label)) {
                builder.SetInsertPoint(&builder.CreateLoad(builder.GetGlobal("g")));
                bb_label = builder.CreateSwitch(bb, NULL);
                
                // Update the label value
                builder.SetInsertPoint(bb_label);
                bb->set_block(builder.CreateCall(Orc::IRBuilder<>::createLoopOptimize()));
            }
        } else if (optlevel == 2) {
            
            // Check for an already defined label, but only update the label value
            if (builder.CreateLoad(&label_name)) {
                LLVMPointerValueBase *bb_label = bb->back();
                
                // Update the label value
                builder.SetInsertPoint(&builder.CreateCall(Orc::IRBuilder<>::createLoopOptimize()));
                bb_label = builder.CreateSwitch(bb, NULL);
                
                // Update the label value
                builder.SetInsertPoint(bb_label);
                bb->set_block(builder.CreateLoad(&label_name));
            }
        } else {
            builder.SetInsertPoint(&builder.CreateCall(Orc::IRBuilder<>::createLoopOptimize()));
            
            // Update the label value
            LLVMPointerValueBase *bb_label = bb->back();
            
            // Update the label value
            builder.SetInsertPoint(bb_label);
            bb->set_block(builder.CreateSwitch(bb, NULL));
        }
        
        for (int I2 = 0; I2 < nargs; i++) {
            LLVMValueRef arg[4] = {
                builder.CreateLoad(&argv[i*2]),
                builder.CreateLoad(&argv[(i+1)*2]),
                arg_ptr[i],
                arg_ptr[i+1]
            };
            
            if (optlevel == 1) {
                // Check for an already defined label, but only update the label value
                LLVMPointerValueBase *bb_label = bb->back();
                
                // Update the label value
                builder.SetInsertPoint(&builder.CreateCall(Orc::IRBuilder<>::createLoopOptimize()));
                bb_label = builder.CreateSwitch(bb, NULL);
                
                // Update the label value
                builder.SetInsertPoint(bb_label);
                bb->set_block(builder.CreateLoad(&arg[0]));
            } else if (optlevel == 2) {
            
                // Check for an already defined label, but only update the label value
                LLVMPointerValueBase *bb_label = bb->back();
                
                // Update the label value
                builder.SetInsertPoint(&builder.CreateCall(Orc::IRBuilder<>::createLoopOptimize()));
                bb_label = builder.CreateSwitch(bb, NULL);
                
                // Update the label value
                builder.SetInsertPoint(bb_label);
                bb->set_block(builder.CreateLoad(&arg[0]));
            } else {
                builder.SetInsertPoint(&builder.CreateCall(Orc::IRBuilder<>::createLoopOptimize()));
                bb->set_block(builder.CreateSwitch(bb, NULL));
                
                // Update the label value
                LLVMPointerValueBase *bb_label = bb->back();
            
                // Update the label value
                builder.SetInsertPoint(bb_label);
                bb->set_block(builder.CreateLoad(&arg[0]));
            }
        }
        
        for (int I2 = 1; i < nargs; i++) {
            
            LLVMValueRef arg[4] = {
                builder.CreateLoad(&argv[(i*2)-1]),
                builder.CreateLoad(&argv[(i+1)*2-1]),
                arg_ptr[i],
                arg_ptr[i+1]
            };
            
            if (optlevel == 1) {
                // Check for an already defined label, but only update the label value
                LLVMPointerValueBase *bb_label = bb->back();
                
                // Update the label value
                builder.SetInsertPoint(&builder.CreateCall(Orc::IRBuilder<>::createLoopOptimize()));
                bb_label = builder.CreateSwitch(bb, NULL);
                
                // Update the label value
                builder.SetInsertPoint(bb_label);
                bb->set_block(builder.CreateLoad(&arg[0]));
            } else if (optlevel == 2) {
            
                // Check for an already defined label, but only update the label value
                LLVMPointerValueBase *bb_label = bb->back();
                
                // Update the label value
                builder.SetInsertPoint(&builder.CreateCall(Orc::IRBuilder<>::createLoopOptimize()));
                bb_label = builder.CreateSwitch(bb, NULL);
                
                // Update the label value
                builder.SetInsertPoint(bb_label);
                bb->set_block(builder.CreateLoad(&arg[0]));
            } else {
                builder.SetInsertPoint(&builder.CreateCall(Orc::IRBuilder<>::createLoopOptimize()));
                bb->set_block(builder.CreateSwitch(bb, NULL));
                
                // Update the label value
                LLVMPointerValueBase *bb_label = bb->back();
            
                // Update the label value
                builder.SetInsertPoint(bb_label);
                bb->set_block(builder.CreateLoad(&arg[0]));
            }
        }
    }
}