
#include <stdio.h>
#include "Cmplex.h"

int main() {
    // input is taken from argv only
    double x1 = 1.0;
    double x2 = 3.5;

    printf("x1 = %.2f, x2 = %.2f\n", x1, x2);

    return 0;
}