
#include <stdio.h>

int main(void) {
    int n = atoi(argv[0]); // get the number argument from argv
    printf("The input is %d\n", n);
    return 0;
}