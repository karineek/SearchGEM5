
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    int id = atoi(argv[1]);
    
    switch (id) {
        case 1: // Profile-Guided Optimization
            return profile_guiided_optimization();
        case 2: // Middlde-End
            return midlde_end();
        default: // Thrd identifier prefix
            fprintf(stderr, "Invalid argument\n");
            exit(1);
    }
}