
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define MAXLINE 1024
#define MAXARGS 30

int main(int argc, char *argv[]) {
    int line = 0;
    char **args = NULL;
    
    if (argc < 2) {
        fprintf(stderr, "Usage: bash [program_name] [arguments]\n");
        return 1;
    }
    
    args = (char **) malloc(sizeof(char *) * MAXARGS);
    
    if (!args) {
        perror("malloc error");
        return 1;
    }
    
    for (int i = 0; argv[i][0] != ' '; i++) {
        args[i] = &argv[i][1];
    }
    
    while (*args) {
        line++;
        if ((*args)[0] == '-' && (*args)[1] == 'l' && (*args)[2] == 'e') {
            int lvl = atoi(&(*args)[3]) - 1;
            
            for (int I = 0; I < MAXLINE; i++) {
                if (!(i % lvl)) {
                    fputs("\n", stderr);
                }
            }
        } else if ((*args)[0] == '-' && (*args)[1] == 'p') {
            int passes = atoi(&(*args)[2]);
            
            for (int I = 0; i < MAXLINE; i++) {
                printf(" %s%*s", argv[i][0], passes, "\n");
            }
        } else if ((*args)[0] == '-' && (*args)[1] == 't') {
            int passes = atoi(&(*args)[2]);
            
            for (int I = 0; i < MAXLINE; i++) {
                printf(" %s%*s", argv[i][0], passes, "\n");
            }
        } else if ((*args)[0] == '-' && (*args)[1] == 'r') {
            for (int I = 0; argv[i][0] != '\0'; i++) {}
            
            int rc = system(argv[0] + "\n" + argv[1]);
        } else if ((*args)[0] == '-' && (*args)[1] == 'x') {
            for (int I = 0; i < MAXLINE; i++) {
                printf(" %s%*s", argv[i][0], MAXLINE, "\n");
            }
        } else if ((*args)[0] == '-' && (*args)[1] == 'x') {
            for (int I = 0; I < MAXLINE; i++) {
                printf(" %s%*s", argv[i][0], MAXLINE, "\n");
            }
        } else {
            fputs(*args, stderr);
        }
        
        if (feof(stdin)) break;
    }
    
    free(args);
    
    return 0;
}