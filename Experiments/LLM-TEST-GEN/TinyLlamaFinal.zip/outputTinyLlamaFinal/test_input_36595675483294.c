
#include <stdio.h>

int main() {
    printf("Welcome to BASH!\n");
    return 0;
}