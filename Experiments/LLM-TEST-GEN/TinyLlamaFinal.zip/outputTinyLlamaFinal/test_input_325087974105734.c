
#include <stdio.h>
#include <stdlib.h>
#define MAX_ARGS 10

int main(int argc, char *argv[]) {
    if (argc < MAX_ARGS) {
        printf("Invalid number of arguments\n");
        return -1;
    } else {
        int num = atoi(&argv[1][0]);
        printf("%d\n", num);
        return 0;
    }
}