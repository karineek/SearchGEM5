
#include <stdio.h>
#include <string.h>
#define MAX_LINE_LEN 1024

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: %s [<input file>]\n", argv[0]);
        return -1;
    }
    
    char input_buf[MAX_LINE_LEN] = "";
    int line_len = 0, output_len = 0;
    
    for (int I = 1; i < argc; i++) {
        if ((input_buf[line_len] = getchar()) == EOF) {
            printf("Error: Input file not valid\n");
            return -1;
        }
        
        line_len++;
        input_buf[line_len] = '\0';
    }
    
    FILE *input_file = fopen(argv[i], "r");
    if (!input_file) {
        printf("Error: Input file not found\n");
        return -1;
    }
    
    char buffer[MAX_LINE_LEN] = "";
    size_t readed_line_len = 0, output_buf_size = 0;
    
    while ((input_buf[readed_line_len]) || (getc(input_file) != EOF)) {
        readed_line_len++;
        
        buffer[output_buf_size] = '\0';
        int readed_line_len = 0;
        char *ptr = buffer + output_buf_size;
        for (int I = 0; I < MAX_LINE_LEN - readed_line_len; i++) {
            ptr[i] = input_buf[readed_line_len];
            ptr[i+1] = '\0';
            readed_line_len++;
        }
        
        output_buf_size += MAX_LINE_LEN + 2; // 2 for newline char and " "
    }
    
    fclose(input_file);
    
    int ret = vsprintf_s(output_buf, output_buf_size, buffer, line_len);
    if (ret < 0) {
        printf("Error: VSPRINTF_S function failed\n");
        return -1;
    }
    
    printf("%s", output_buf);
    
    return 0;
}