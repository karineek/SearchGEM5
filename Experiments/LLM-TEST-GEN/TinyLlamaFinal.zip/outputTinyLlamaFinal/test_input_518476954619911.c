
#include <stdio.h>
#include <stdlib.h> // needed to call exit()
#include <unistd.h>  // needed for getpid()

int main(int argc, char *argv[]) {
    if (argc != 2) { // checks the number of arguments
        fprintf(stderr, "Usage: %s FILE\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    const int MAX_LINE_LENGTH = 1024;
    char filename[MAX_LINE_LENGTH]; // buffer to store file path
    
    strcpy(filename, argv[1]); // copy the filename
    
    FILE *inputFile;
    if ((inputFile = fopen(filename, "r")) == NULL) {
        perror("Failed to open file\n");
        exit(EXIT_FAILURE);
    }
    
    char line[MAX_LINE_LENGTH]; // buffer to store input line
    int lineCount = 0;
    while (fgets(line, MAX_LINE_LENGTH, inputFile) != NULL) {
        ++lineCount;
        
        // check for comments and lines starting with a #
        if (line[0] == '#') {
            continue;
        }
        
        // trim spaces at beginning and end of line to get only the data
        const char *start = strstr(line, " ");
        const char *end = strstr(start + 1, " ");
        if (start == NULL || end == NULL) { // input line does not start or end with spaces
            continue;
        }
        
        // parse the input line as a command to execute
        int commandIndex = -1; // index of the first command in the line
        const char *commandStart = start + 1; // starting position of the first command in the line
        for (int I = 0; I < lineCount; i++) {
            if (line[i] == ' ') { // end of a command
                commandIndex++;
                break;
            }
            
            // check if the current character is the next command's start position and increment the index if it is
            if (commandStart[0] == line[i]) {
                while (commandStart[0] != ' ') {
                    commandIndex++;
                    --commandStart;
                }
                break;
            }
        }
        
        // check if the current command is a "command" command and execute it if so
        const char *commandEnd = start + (commandIndex < 0 ? -1 : commandIndex);
        if (commandIndex >= 0 && strncmp(commandStart, "command ", 5) == 0 && strncasecmp(commandEnd, " ", 2) == 0) {
            const char *arguments = start + 5; // skip the "command " and arguments spaces after them
            while (strstr(arguments, " ") != NULL || *arguments == '\0') { // skip unrecognized arguments and skip empty ones
                arguments++;
            }
            
            // call the command's function with specified arguments
            if (*arguments == '\0') { // no arguments
                const char *commandName = argv[1] + 3; // name of the executable file (i.e., argv[1])
                execv(filename, argv);
            } else { // non-empty arguments
                const char *commandArgs = arguments + 2; // start position after arguments
                while (*commandArgs != '\0') { // skip remaining arguments and convert them to lowercase for sorting
                    commandArgs++;
                }
                
                printf("Command: %s\nArguments: %s\n", argv[1], commandArgs);
                system(commandName);
            }
        }
        
        // check if the input line is empty and exit the program if so
        if (lineCount == 0) {
            break;
        }
    }
    
    return 0;
}