
#include <stdio.h>
#include <stdlib.h>
#include "scaparser.h"
#include "swcompact.h"

// Input is taken from argv only, returns C program and example input
int main(int argc, char **argv) {
    // Parse the arguments
    if (argc != 2) {
        printf("Usage: %s [options] filename\n", argv[0]);
        return EXIT_FAILURE;
    }

    // Define input file and output file names
    char filename[] = argv[1];

    // Define Scalaroptimizations options (defaults are commented out)
    const int debuglevel = 0;
    const unsigned short maxcalls = 256;
    const double tol = 1e-9;
    const unsigned int maxiter = 20;

    // Open input file for parsing (using `fopen`)
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        printf("Error: Could not open input file '%s'.\n", filename);
        return EXIT_FAILURE;
    }

    // Parse input and create `scaparser` (optimizer) structure
    struct scaper *scapi = scaper_new(filename, debuglevel, maxcalls, tol, maxiter);
    if (!scapi) {
        printf("Error: Could not create Scalaroptimizations optimizer.\n");
        return EXIT_FAILURE;
    }

    // Parse input and create `sca` (solver) structure
    struct sca *scapi = scaper_new_sca(scapi, filename);
    if (!scapi) {
        printf("Error: Could not create Scalaroptimizations solver.\n");
        return EXIT_FAILURE;
    }

    // Run Scalaroptimizations optimizer and store results in `scapi`
    char *scafile = calloc(1, MAX_FILENAME_LEN + 1);
    strcpy(scafile, filename);
    sscanf(scafile + MAX_FILENAME_LEN, "optimized.%d", &scapi->solver);

    // Free resources and exit (return code is not used)
    scaper_delete(scapi);
    sca_delete(scapi);

    return EXIT_SUCCESS;
}