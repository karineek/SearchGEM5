
#include <stdio.h> // required for printf()
#include <stdlib.h> // required for exit()

// BASH function with sign types and analysis
int main(int argc, char *argv[]) {
    int a = atoi(argv[1]); // take input from user as an integer using strtol()
    
    // if the input is positive:
    if (a > 0) {
        printf("The number %d is greater than zero.\n", a);
    } else {
        printf("The number %d is less than or equal to zero.\n", a);
    }
    
    // if the input is negative:
    if (a < 0) {
        printf("The number %d is less than zero.\n", a);
    } else {
        printf("The number %d is greater than or equal to zero.\n", a);
    }
    
    // exit the program with success
    return 0;
}