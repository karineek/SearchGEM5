
#include <stdio.h>
#include <stdlib.h>
#include "llvm/IR/IRBuilder.h"

int main() {
    char *str;
    int i, num_args = 0;
    const char **argv;
    char **argp;
    
    argv = (const char **) malloc(sizeof(char *) * 2);
    argp = (const char **) malloc(sizeof(char *) * 2);
    
    argv[0] = "hello.bc";
    argp[0] = "-O3";
    str = argv[1];
    num_args++; // Add a single argument with default value of -O3
    if (argc == 2) {
        argp[num_args++] = "--target-cpu=native"; // Set target CPU
        argp[num_args++] = "-g";
        argv += num_args;
        i = num_args - 1; // Remove the last argument (default value)
    } else {
        argp[0] = "hello.bc";
        argp[1] = argc < 2 ? "" : "-O3" + str + "--target-cpu=native";
    }
    
    int exit_code = llvm::sys::ExecuteCommand(argv, argv[0], argp, num_args);
    
    free(argv);
    free(argp);
    
    printf("%s\n", exit_code == 0 ? "Success" : "Failure")); // Print success/failure message
    
    return 0;
}