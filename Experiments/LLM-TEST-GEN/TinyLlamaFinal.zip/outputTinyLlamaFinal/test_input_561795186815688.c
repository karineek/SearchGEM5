
#include <stdio.h>
#include <stdlib.h>

int main() {
    char c = getchar();
    
    while (c != '\n') {
        printf("%c", c);
        c = getchar();
    }
    
    return 0;
}