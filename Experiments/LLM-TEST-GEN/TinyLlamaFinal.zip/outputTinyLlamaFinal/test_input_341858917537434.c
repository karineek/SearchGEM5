
#include <stdio.h> /* printf() function */
#include <string.h> /* memset() function */
#include "specialize.h" /* Function Specialization API */

/* Example usage */
void usage(const char *progname) {
    printf("%s: Usage: %s input_file\n", progname, argv[0]);
}

int main(int argc, const char *argv[]) {
    if (argc != 2) {
        usage(argv[0]); /* Print error message */
        return EXIT_FAILURE;
    }
    
    /* Call specialized function */
    int status = specialize(&strcpy, argv[1], "%D", "test.txt");
    if (status) {
        printf("%s: Error: %d - Invalid input format.\n", argv[0], status);
        return EXIT_FAILURE;
    }
    
    /* Call non-specialized function */
    int status2 = strcpy(argv[1], "test.txt");
    if (status2) {
        printf("%s: Error: %d - Failed to copy input.\n", argv[0], status2);
        return EXIT_FAILURE;
    } else {
        printf("%s: Successfully copied input to '%s'.\n", argv[0], argv[1]);
    }
    
    /* Exit with success code */
    return 0;
}