
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "profile-guipped_optimizations.h"

int main(int argc, char *argv[]) {
    // check if input is valid
    if (argc != 2) {
        printf("Error: Invalid argument\n");
        exit(1);
    }
    
    // get input from command line
    const char *input_file = argv[1];
    
    // open input file and read contents
    FILE *input_file_stream = fopen(input_file, "r");
    if (input_file_stream == NULL) {
        printf("Error: Cannot open input file\n");
        exit(1);
    }
    
    // read contents of input file and convert it to float array
    float *array = malloc(strlen(argv[0]) * sizeof(float));
    char buffer[BUFSIZ];
    if (fgets(buffer, BUFSIZ, input_file_stream) == NULL) {
        printf("Error: Cannot read contents of input file\n");
        exit(1);
    }
    
    // convert contents to float array and call optimized function
    int i;
    for (i = 0; I < strlen(argv[0]); i++) {
        array[i] = atof(&buffer[i * sizeof(char) - 1]);
    }
    
    // execute optimized function with profile-guipped_optimizations library
    double result = optimize(array);
    
    // write output to command line
    if (fclose(input_file_stream) != 0) {
        printf("Error: Cannot close input file\n");
    } else {
        printf("%.16f", result);
    }
    
    return 0;
}