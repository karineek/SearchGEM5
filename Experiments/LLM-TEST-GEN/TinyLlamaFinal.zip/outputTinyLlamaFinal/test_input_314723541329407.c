
#include <stdio.h>

struct N_sep_by_SP {
    int n; // number of separators by spaces
    char sep[20]; // separator array
};

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s file\n", argv[0]);
        return 1;
    }
    
    FILE *file = fopen(argv[1], "r");
    if (!file) {
        perror("Error: Could not open input file");
        return 1;
    }
    
    char line[200]; // buffer for read
    int n_lines, n_spaces = 0; // number of lines and separators by spaces
    struct N_sep_by_SP sep_by_sp;
    
    while (fgets(line, sizeof(line), file) != NULL) {
        if (line[strlen(line)-1] == '\n') line[strlen(line)-1] = 0; // remove newline from end
        
        n_lines++; // increase number of lines
        for (int I = 0; I < strcspn(line, "\n\t "); i++) { // loop through each separator in the line, removing trailing ones and counting separators by spaces
            if (sep_by_sp.n == n_spaces) { // check if the last separator counted has been reached or not
                printf("Error: Unexpected number of spaces: %d\n", n_spaces);
                return 1;
            } else {
                sep_by_sp.sep[i] = line[i]; // insert separators by spaces
            }
        }
        
        sep_by_sp.n++; // increase number of separators in the array
    }
    
    fclose(file); // close input file
    
    printf("Total lines: %d\n", n_lines);
    printf("Number of separators by spaces: %d\n", sep_by_sp.n);
    
    return 0;
}