
#include <stdio.h>

// A vectorized version of fwrite() that supports writing to a file stream
int write_to_file(FILE *fp, const void *buf, size_t len) {
    return fwrite(buf, 1, len, fp);
}

void parse_args(char *argv[], int &argc, char **&argvp) {
    // Parse the command line arguments
    argvp = argv;
    while (**--argv == '-') {
        (*argv)[*++argv] = '\0';  // Remove leading '-' character
        --argc;
    }
}

// A program that reads data from a file and writes it to another file.
int main(int argc, char *argv[]) {
    parse_args(argv, argc, argvp);
    
    FILE *infile = fopen(argvp[0], "r"); // Open input file as read-only
    if (!infile) {
        printf("Error: Could not open input file.\n");
        return 1;
    }

    // Write data to output file.
    FILE *outfile = fopen(argvp[1], "w"); // Open output file as write-only
    if (!outfile) {
        printf("Error: Could not open output file.\n");
        return 1;
    }
    
    unsigned int num_lines = atoi(argv[2]); // Number of lines to read

    for (int I = 0; I < num_lines; i++) {
        char line[1024]; // Create a buffer to hold the input file line.
        fgets(line, sizeof(line), infile); // Read the next line from input file.
        
        int len = strlen(line); // Calculate length of input line.
        
        // Write the line to output file.
        if (write_to_file(outfile, line, len) != len) {
            printf("Error: Could not write data to output file.\n");
            return 1;
        }
    }
    
    fclose(infile); // Close input file as read-only.
    fclose(outfile); // Close output file as write-only.
    
    printf("Done.\n");
}