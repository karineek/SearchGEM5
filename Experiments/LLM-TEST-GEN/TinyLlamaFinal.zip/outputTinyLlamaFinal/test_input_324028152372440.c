
#include <stdio.h>

int main(void) {
    int n, sum = 0;
    
    printf("Enter the length of the list of numbers: ");
    scanf("%d", &n);
    
    for (int I = 0; I < n; i++) {
        sum += (int) atoi(argv[i]);
    }
    
    printf("The sum is: %d\n", sum);
    
    return 0;
}