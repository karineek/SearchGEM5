
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    int n, sum = 0;
    
    if (argc != 2) {
        printf("Usage: %s [number]\n", argv[0]);
        return 1;
    }
    
    while ((n = atoi(argv[1])) > 0) {
        int c = n % 10, rem = n / 10;
        
        sum += (c * (rem - 2));
    }
    
    printf("%d\n", sum);
    
    return 0;
}