
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>

int main(int argc, char *argv[]) {
    int pid;
    if (argc != 2) {
        fprintf(stderr, "Usage: %s [<input file>]\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    char *filename = argv[1];
    FILE *infile = fopen(filename, "r");
    if (!infile) {
        fprintf(stderr, "Failed to open file: %s\n", filename);
        exit(EXIT_FAILURE);
    }
    
    pid = fork();
    if (pid == 0) {
        while (1) {
            int c;
            do {
                c = fgetc(infile);
                printf("%c", c);
            } while (c != EOF);
            exit(EXIT_SUCCESS);
        }
    } else if (pid > 0) {
        wait(&pid);
    } else {
        return EXIT_FAILURE;
    }
    
    fclose(infile);
    
    return 0;
}