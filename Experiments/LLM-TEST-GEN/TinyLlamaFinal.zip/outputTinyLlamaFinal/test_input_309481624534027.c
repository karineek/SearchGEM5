
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "getopt.h"

int main(int argc, char *argv[]) {
    int opt;
    
    if (argc != 2) {
        fprintf(stderr, "Usage: %s [<options>]\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    /* Get command-line arguments */
    char *command = argv[1];
    
    if (!getopt(argc, argv, "h")) {
        fprintf(stderr, "Error: invalid command\n");
        return EXIT_FAILURE;
    }
    
    switch (opt) {
        case 'h': /* Help */
            fputs("Usage: "argv[0]":\n", stderr);
            break;
        
        default: /* Default behaviour */
            printf("%s\n", command);
            
            return EXIT_SUCCESS;
    }
    
    return EXIT_SUCCESS;
}