
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>

typedef uint16_t uintN;

uintN convert(char *from, char *to) {
    return atoi(from);
}

void error(const char *format, ...) {
    va_list args;
    va_start(args, format);
    fprintf(stderr, "error: ");
    vfprintf(stderr, format, args);
    va_end(args);
    exit(1);
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        error("Expecting one argument\n");
        return EXIT_FAILURE;
    }
    const uintN from = convert(argv[1], "");
    int to;
    if ((to = convert(argv[1], "")) == -1) {
        error("Invalid argument\n");
        return EXIT_FAILURE;
    }
    printf("%u is converted to %d\n", from, to);
    return 0;
}