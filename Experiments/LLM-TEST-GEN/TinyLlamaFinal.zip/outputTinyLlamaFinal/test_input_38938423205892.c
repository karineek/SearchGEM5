
#include <stdio.h>
#include "opt.h"

int main(int argc, char *argv[]) {
  int i;

  /* Initialize ScalarOptimizations */
  ScalarOptimizations = opt_init();
  
  /* Run ScalaR on the input */
  for (i = 0; i < MAX_ITERATIONS; i++) {
    printf("Input: ");
    if (!gets(argv[0])) {
      fprintf(stderr, "Failed to read input.\n");
      exit(1);
    }
    
    /* Run ScalaR on the input */
    ccoshl(argc > 1 ? argv[1] : "input.txt");
    
    /* Check if optimized version was generated */
    printf("Output: ");
    if (opt_check()) {
      printf("Optimized.\n");
    } else {
      printf("Unoptimized.\n");
    }
  }
  
  return EXIT_SUCCESS;
}