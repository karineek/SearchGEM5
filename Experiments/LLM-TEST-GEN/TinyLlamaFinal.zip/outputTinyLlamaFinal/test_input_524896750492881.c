
#include <stdio.h> /* Include standard input/output library */

int main(int argc, char **argv) {
    int num1, num2; /* Declare integer variables for numeric inputs */
    
    if (argc != 2) {
        fputs("Error: Exactly one argument is expected.\n", stderr); /* Print error message */
        return EXIT_FAILURE;
    } else {
        char *filename = argv[1]; /* Set filename as input variable */
        
        if ((num1 = atoi(argv[1])) < 0 || (num2 = atoi(argv[2])) < 0) {
            fputs("Error: Invalid numeric inputs.\n", stderr); /* Print error message */
            return EXIT_FAILURE;
        } else {
            printf("%.3f ^ %.2f\n", num1, pow(num2, (float)num2 / 2)); /* Print result using the pow() function */
        }
    }
    
    return EXIT_SUCCESS;
}