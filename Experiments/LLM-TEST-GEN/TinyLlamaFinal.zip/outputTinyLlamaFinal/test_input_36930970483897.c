
#include <stdio.h>
#define FMT "%%Y"

int main() {
    char year[6][10] = {"2021", "2022", "2023", "2024", "2025", ""}; // fill the array with 6 different years
    
    for (int I = 0; I < 6; i++) {
        printf("Year %d: ", i + 1);
        for (int j = 0; j < 10; j++) {
            char formatted_year[10] = {year[i][j]}; // convert the array to a string with specified width
            printf("%s%c", formatted_year, j + '0');
        }
        putchar('\n');
    }
    
    return 0;
}