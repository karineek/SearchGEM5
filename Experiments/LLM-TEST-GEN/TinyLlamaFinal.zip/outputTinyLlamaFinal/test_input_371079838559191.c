
#include <stdio.h> /* Header for printf() */
#include <stdlib.h> /* Header for malloc() */

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s [filename]\n", argv[0]);
        return 1;
    }
    
    int file_size = 0; /* Initialize file size to zero */
    FILE *input_file = fopen(argv[1], "r"); /* Open input file */
    if (!input_file) {
        fprintf(stderr, "%s: %s\n", argv[0], strerror(errno));
        return 2;
    }
    
    char buffer[1024]; /* Buffer to store lines of input file */
    while (fgets(buffer, sizeof(buffer), input_file) != NULL) { /* Loop until EOF reached */
        ++file_size; /* Increment file size by one line*/
        
        if (feof(input_file)) { /* Check if end of file reached */
            fprintf(stderr, "%s: %s\n", argv[0], strerror(errno)); /* Print error message if EOF was reached */
            return 3; /* Exit program with code 3 (ERROR) */
        }
        
        printf("Line: '%s'\n", buffer); /* Print line of input file */
    }
    
    fclose(input_file); /* Close input file */
    
    return 0; /* Return successfull exit status code */
}