
#include <stdio.h>   // Inclued for printf()
#include <stdlib.h> // Inclued for malloc()/free()

int main(int argc, char **argv) {
    int i;

    if (argc != 2) {
        fprintf(stderr, "Incorrect usage: %s [file]\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    // Call inline function to compute sum of digits in a number
    for (i = 1; i * i <= atoi(argv[1]); i++) {
        int d = 1;
        while (i * i <= atoi(argv[1])) {
            d *= 10;
            if (*argv[1] % I == 0) {
                printf("%d\n", (int)((*argv[1]) / I));
            }
            i++;
        }
    }
    
    return EXIT_SUCCESS;
}