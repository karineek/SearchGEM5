
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int size = 1024;
    char buffer[size];
    
    // Input argv only
    int I = 1;
    for (; I <= argc-1; i++) {
        const char *input = argv[i];
        if (input[0] == '-') {
            switch (*input) {
                case 'a': // Arithmetic optimizations
                    if (strcmp(input + 1, "-w") == 0 || strcmp(input + 1, "--whole-program") == 0) {
                        printf("Writing whole program...\n");
                        i++;
                        write(STDOUT_FILENO, buffer, size); // Write memory to register promotions
                    } else if (strcmp(input + 1, "-b") == 0) {
                        printf("Bashing whole program...\n");
                        i++;
                        while ((size = read(STDIN_FILENO, buffer, size)) > 0) {
                            write(STDOUT_FILENO, buffer, size); // Write memory to register promotions
                        }
                    } else {
                        printf("Invalid input.\n");
                        exit(EXIT_FAILURE);
                    }
                    break;
                case 'c': // C code
                    printf("%s\n", buffer);
                    break;
                default:
                    printf("Invalid input.\n");
                    exit(EXIT_FAILURE);
            }
        } else {
            printf("%s ", input);
        }
    }
    
    return 0;
}