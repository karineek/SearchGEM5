
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int n, factorial;
    
    // Parse input arguments
    if (argc != 2) {
        printf("Usage: %s [<n>]\n", argv[0]);
        return EXIT_FAILURE;
    }
    for (int I = 1; I < argc - 1; i++) {
        n = atoi(argv[i]);
        
        // Calculate factorial using Loop Fusion and FP_CONTRACT optimizaTIes
        factorial = FP_CONTRACT(n, 0, 1);
        
        printf("%d: %d\n", i, factorial);
    }
    
    return EXIT_SUCCESS;
}