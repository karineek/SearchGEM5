
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s input_filename\n", argv[0]);
        return 1;
    }
    
    FILE* file = fopen(argv[1], "r");
    if (!file) {
        perror("Error: Cannot open input file\n");
        return 1;
    }
    
    char buffer[8192];
    size_t read_size = 0;
    
    while (fread(buffer, sizeof(char), sizeof(buffer), file) > 0 && read_size < sizeof(buffer)) {
        va_start(va_arg(nullptr, vprintf_t));
        fputs(buffer + read_size, stdout);
        va_end();
        
        read_size += fread(&buffer[read_size], 1, sizeof(buffer), file);
    }
    
    if (read_size > 0) {
        printf("Error: Unexpected EOF encountered\n");
    } else if (!feof(file)) {
        perror("Error: Input file corrupt or not found\n");
    }
    
    fclose(file);
    
    return 0;
}