
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Function Prototypes
void print_help(void);
int main(int argc, char **argv) {
    if (argc != 2) { // Check that number of arguments is two
        printf("Usage: %s <input file>\n", argv[0]);
        return 1;
    }
    
    // Read input file and print output to standard output
    FILE *file = fopen(argv[1], "r");
    if (!file) {
        perror("Error: Failed to open input file\n");
        exit(1);
    }
    printf("Reading input...\n");
    
    // Create an AST representation of the input file
    int line_no = 0;
    while (fscanf(file, "%d %s", &line_no, argv[2 + line_no]) == 2) {
        printf("Line number: %d\n", line_no);
        
        // Print the line using ANSI C
        if (fgets(argv[3 + line_no], 1024, file) != NULL) {
            printf("%s\n", argv[3 + line_no]);
        } else {
            perror("Error: Failed to read input\n");
            return 1;
        }
    }
    
    // Close the input file and print a message indicating success
    fclose(file);
    printf("\nFile successfully read and printed.\n");
    
    return 0;
}

// Function Prototypes (Functions used in main)
void print_help(void) {
    printf("Usage: %s [OPTIONS] INPUTFILE\n", argv[0]);
    printf("\nOptions:\n");
    
    printf("-h          Print this help message\n");
}