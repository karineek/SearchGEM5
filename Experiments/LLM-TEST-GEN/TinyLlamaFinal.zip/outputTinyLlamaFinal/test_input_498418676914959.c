
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Error: Invalid number of arguments\n");
        return 1;
    }
    
    const char *filename = argv[1];
    
    // Load input from file
    FILE *file = fopen(filename, "r");
    if (!file) {
        fprintf(stderr, "Error: Could not open file %s\n", filename);
        return 1;
    }
    
    char line[MAXLINE]; // Maximum line length
    size_t read = 0;
    while (fgets(line + read, sizeof(line) - read, file)) {
        if (!strlen(line)) { // Skip empty lines
            continue;
        }
        
        // Perform parsing on input line
        int lineNumber = 1;
        char *chars = strtok(line, " ");
        while (chars) {
            switch (*chars) {
                case '(':
                    chars = strtok(NULL, " ");
                    printf("Loop Vectorization optimizations:\n");
                    break;
                case '>':
                    chars = strtok(NULL, " ");
                    printf("Sin type-generic macro:\n");
                    break;
                default:
                    if (isalpha(*chars)) {
                        // Check for LoopVectorization option
                        if (*chars == 'L') {
                            lineNumber++;
                            printf("\n");
                            chars = strtok(NULL, " ");
                            printf("LoopVectorization option enabled\n");
                        } else {
                            // Check for Type-Generic option
                            if (*chars == 'G') {
                                lineNumber++;
                                printf("\n");
                                chars = strtok(NULL, " ");
                                printf("Type-Generic option enabled\n");
                            } else {
                                // Invalid input
                                fprintf(stderr, "Error: Invalid input format\n");
                                return 1;
                            }
                        }
                    } else {
                        // Invalid input character
                        fprintf(stderr, "Error: Invalid input format\n");
                        return 1;
                    }
                    
                    break;
            }
            
            chars = strtok(NULL, " ");
        }
        
        printf("Input line %d:\n", lineNumber);
        printf("%s\n", line);
        
        read += strlen(line) + 1; // Add newline character to end of input line
    }
    
    // Close file
    fclose(file);
    
    return 0;
}