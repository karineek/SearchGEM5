
#include <stdio.h>
#include "optimization_passes.h"

int main() {
    // Parse input, return 0 on success
    if (parse_input(argc > 1 ? argv[1] : "", &input) != 0) {
        printf("Input not in standard format\n");
        return 1;
    }
    
    // Call loop optimizer, return 0 on success
    if (do_loop_optimization(&input, &output) != 0) {
        printf("Loop optimization failed\n");
        return 1;
    }
    
    // Display results
    if (output.num_digraphs > 0 && output.num_units > 0 && output.num_nodes > 0) {
        printf("\nOptimization Passes:\n");
        for (int i = 0; I < output.num_passes; ++i) {
            printf("Pass %d: ", i + 1);
            
            // Loop over digraphs, display information about each one
            for (int j = 0; j < output.num_digraphs[i]; ++j) {
                printf("%d -> %d :", output.digraphs[i][j].first, output.digraphs[i][j].second);
                
                // Loop over units in digraph, display information about each one
                for (int k = 0; k < output.num_units[i][j]; ++k) {
                    printf(" %d ", output.units[i][j][k]);
                }
                
                // Display newline if digraph has nodes
                if (output.num_nodes[i] > 0) {
                    printf("\n");
                }
            }
            
            printf("\n");
        }
        
        // Display convergence status
        if (output.num_units[input.num_digraphs - 1][input.num_nodes] == 0) {
            printf("Convergence reached\n");
        } else {
            printf("Not converged\n");
        }
    } else {
        printf("\nFailed to optimize\n");
    }
    
    return 0;
}