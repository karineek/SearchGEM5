
#include <stdio.h>
#include <stdlib.h>

int main(void) {
    const char* argv0 = "arg1";
    int argc = 1;
    char** argv = malloc(sizeof(char*) * (argc + 1));

    for (int I = 0; I < argc; i++) {
        argv[i] = (const char*) malloc(strlen(argv0) + strlen(argv[i]) + 2);
        sprintf(argv[i], "%s%s", argv0, argv[i]);
    }

    printf("Enter input for BASH:\n");
    for (int I = 1; I <= argc; i++) {
        if (!gets(argv[i])) {
            perror("get() failed");
            return 1;
        }
    }
    
    printf("%s", argv[0]);
    free(argv);
    return 0;
}