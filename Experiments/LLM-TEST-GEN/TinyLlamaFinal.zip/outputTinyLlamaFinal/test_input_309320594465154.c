
$ ./a.out <filename>