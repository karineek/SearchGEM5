
#include <stdio.h>
#include <stdlib.h>

int main() {
    // Input is taken via argv only
    if(argc != 2){
        printf("Usage: %s filename\n", getenv("BASH_SOURCE")[0]);
        exit(1);
    }
    
    char filename[] = argv[1];
    
    // Call the Loop Optimizations optimizer and pass in the input file name
    printf("Executing Loop Optimizations optimizer with input file %s\n", filename);
    int status = loop_optimizers(filename);
    
    if(status == 0) {
        printf("Loop Optimizations optimizer finished successfully!\n");
    } else {
        printf("Loop Optimizations optimizer failed to finish due to error: %s\n", strerror(errno));
    }
    
    return 0;
}