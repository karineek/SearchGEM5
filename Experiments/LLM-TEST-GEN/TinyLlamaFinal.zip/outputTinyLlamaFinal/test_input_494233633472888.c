
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "profiler.h"

int main(int argc, char* argv[]) {
    int n;
    char input[MAX_FILENAME]; // max file name size is 256 bytes
    
    if (argc == 1) {
        printf("Enter filename: ");
        fflush(0);
        gets(input);
        
        input[strlen(input) - 1] = '\0'; // remove newline character from file name
        
        FILE* file = fopen(input, "r");
        if (file == NULL) {
            printf("Error: File %s cannot be opened\n", input);
            exit(EXIT_FAILURE);
        }
        n = getline(&input[0], MAX_FILENAME, file); // read file contents until newline character
        
        fclose(file);
        
        if (n == -1) {
            printf("Error: Could not read file %s\n", input);
            exit(EXIT_FAILURE);
        }
    } else if (argc == 2 && strlen(argv[1]) > MAX_FILENAME) { // check whether second argument is filename or not
        printf("Error: File name too long\n");
        return EXIT_FAILURE;
    } else {
        n = atoi(argv[1]); // convert file name to integer
        
        if (n < 0 || n > MAX_FILENAME) { // check validity of input file name
            printf("Error: File name is invalid\n");
            return EXIT_FAILURE;
        }
    }
    
    char buffer[MAX_LINE]; // buffer to read line from file
    size_t nlines = 0; // number of lines in file
    
    FILE* file = fopen(input, "r"); // open file for reading
    if (file == NULL) {
        printf("Error: File %s cannot be opened\n", input);
        return EXIT_FAILURE;
    }
    
    while (!feof(file)) {
        fgets(buffer, MAX_LINE, file); // read line from file
        
        if (buffer[0] == '\0') { // skip empty lines
            nlines++; // count number of lines
            continue;
        }
        
        int line = sscanf(buffer, "%d", &n); // parse line as integer
        
        if (line != 1) { // check whether line is parsed correctly
            printf("Error: Line %s does not have correct format\n", buffer);
            fclose(file);
            return EXIT_FAILURE;
        }
        
        if (!strcmp(buffer, "\0")) { // skip empty lines
            nlines++; // count number of lines
        }
    }
    
    fclose(file);
    printf("Number of lines in file: %d\n", nlines);
    
    return EXIT_SUCCESS;
}