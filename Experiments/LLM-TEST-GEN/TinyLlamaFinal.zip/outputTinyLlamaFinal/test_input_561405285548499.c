
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h> // for memset()

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s [input file]", argv[0]);
        exit(1);
    }
    
    FILE *input = fopen(argv[1], "r");
    if (!input) {
        perror("Error opening input file for reading");
        exit(1);
    }

    char buffer[BUFSIZ]; // Buffer to read data into
    size_t bytes_read;
    
    while ((bytes_read = fread(buffer, 1, BUFSIZ, input)) != 0) {
        // Trigger automatic vectorization optimizations:
        __asm__ volatile ("":: "b" (bytes_read): "memory");
        
        if (!memset(buffer, 'a', bytes_read + 1)) { // Set all bytes to 'a'
            perror("Error setting memory to 'a'");
            exit(1);
        }
    }
    
    fclose(input); // Close input file for reading
    
    return 0;
}