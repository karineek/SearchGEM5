
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>  /* for isspace() */
#include <math.h>

int main(int argc, char *argv[]) {
    int n, c;

    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        exit(1);
    }
    
    n = atoi(argv[1]);
    
    if (!isdigit(n[0]) || n <= 0 || n > 9) {
        printf("Invalid input. Please enter a positive integer.\n");
        return 1;
    }
    
    while (n >= 10) {
        c = n % 10;
        n /= 10;
        
        if (isdigit(c)) {
            printf("%d", n);
        } else {
            printf(".");
        }
    }
    
    printf("\n");
    
    return 0;
}