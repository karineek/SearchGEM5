
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s [input filename]\n", argv[0]);
        return 1;
    }
    
    char input_file[1024];
    strcpy(input_file, argv[1]);
    
    FILE *input_file_handle = fopen(input_file, "r");
    
    if (!input_file_handle) {
        perror("Could not open input file\n");
        return 1;
    }
    
    int input_lines = 0;
    char line[1024];
    
    while (fgets(line, sizeof(line), input_file_handle)) {
        ++input_lines;
        
        if (!strcmp(line, "\n\n")) {
            printf("%d lines read\n", input_lines);
            break;
        }
    }
    
    fclose(input_file_handle);
    
    return input_lines == 0 ? 1 : 0;
}