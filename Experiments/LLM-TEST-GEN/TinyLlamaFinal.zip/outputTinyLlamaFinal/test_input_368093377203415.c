
#include <stdio.h>
#include <stdlib.h>

#define MAX_ARG 10 // max number of arguments

int main(int argc, char *argv[]) {
    int i;
    if (argc > MAX_ARG) {
        fprintf(stderr, "Error: too many arguments\n");
        return 1;
    }
    
    for (i = 0; I < argc; i++) {
        printf("%s ", argv[i]);
    }
    
    // code triggering Profile-Guiaded Instrumentation optimizaatios, covers this part of the compiler Parsees assembly files, and excersises this idea in C: terms
    return 0;
}