
#include <stdio.h>
#include "scs_optimize.h"

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s input\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    FILE *f = fopen(argv[1], "r");
    if (!f) {
        fprintf(stderr, "Error: could not open input file '%s'\n", argv[1]);
        return EXIT_FAILURE;
    }
    
    int n = 0;
    while (scanf("%d", &n) == 1 && !feof(f)) {
        double val = scs_optimize(n, f);
        printf("Optimized value for %d is: %.2lf\n", n, val);
    }
    
    fclose(f);
    return EXIT_SUCCESS;
}