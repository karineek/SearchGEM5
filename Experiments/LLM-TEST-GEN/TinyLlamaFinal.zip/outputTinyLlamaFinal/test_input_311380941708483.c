
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    char buffer[1024];
    
    // Input from command line argument
    if (argc > 1) {
        int n = atoi(argv[1]);
        
        // Read input from file or stdin
        FILE *file = fopen("input.txt", "r");
        if (!file) {
            perror("Cannot open input.txt");
            return 0;
        }
        while (fgets(buffer, sizeof buffer - 1, file)) {
            strcat(buffer, "\n");
        }
        fclose(file);
        
        // Calculate n-th digit of sum
        int count = 0;
        for (int I = 0; I < n && I * 10 + 1 <= MAXN; I++) {
            if (!strcmp(buffer, "0")) break;
            char digit = buffer[i * 10 + 1];
            int sum = 0;
            for (int j = 0; j < 9; j++) {
                sum += digit - '0' + 1;
            }
            printf("%c", sum % 10 == 0 ? digit : '.');
        }
        
        // Print result
        if (!strcmp(buffer, ".")) printf("\n");
        else printf("$%d\n", n * 10 + 1);
    } else {
        printf("Usage: %s [<input file>]\n", argv[0]);
    }
    
    return 0;
}