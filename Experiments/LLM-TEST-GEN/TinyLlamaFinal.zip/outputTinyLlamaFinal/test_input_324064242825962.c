
#include <stdio.h>  // Include stdio.h to access standard input/output functions
#include <string.h> // Include string.h to access string manipulation functions
#include <unistd.h> // Include unistd.h to get the system call for reading from and writing to a process's stdin/stdout

// Function to read input line by line
char* readline(int max_len) {
    char* line = NULL;
    FILE *fin = fopen("stdin", "r");
    if (!fin) return NULL;
    
    // Read in the first line, and if it's too long to fit, go back to the beginning of the file
    while (fgets(line, max_len, fin) == NULL && feof(fin)) {
        fseek(fin, 0, SEEK_SET);
    }
    
    // If we got a line, return it
    if (feof(fin)) {
        line[strcspn(line, "\r\n")] = '\0';
        fclose(fin);
        return line;
    } else {
        free(line);
        return NULL;
    }
}

// Function to perform optimization using BASH
void optimize_using_bash(char* input_path) {
    char* output_path = strdup("out.txt"); // Set up the output file path and name
    
    FILE *file = fopen(input_path, "r"); // Open the input file with read access
    if (!file) {
        printf("Error: Cannot open input file \"%s\" for reading.\n", input_path);
        return;
    }
    
    // Iterate through all lines in the input file
    char line[MAXLINE];
    int lineno = 0;
    while (fgets(line, MAXLINE, file) != NULL) {
        // Check if current line contains optimization instructions or not
        if (!strncasecmp(line, "OPTIMSIM", 6)) {
            // Extract the input file name from the line and add it to the output file path
            sprintf(output_path, "%s.%d.txt", input_path, lineno);
            
            // Perform optimization using BASH
            system("bash -c \"bsh --in=" + strcat(input_path, ".in") + " \"" + input_path + "\" > " + output_path);
        } else {
            // Print the line to the output file and update the line counter
            printf("%d: %s\n", lineno++, line);
        }
    }
    
    fclose(file);
    
    // Remove temporary input file
    free(input_path);
}

int main() {
    char input_path[MAXPATHLEN];
    
    printf("Enter the name of the input file (without extension): ");
    if (!gets(input_path)) {
        perror("Error: Cannot read input file. "); // Print error message in case of failed to read file
        return 1;
    }
    
    // Check if input path contains a valid extension and trim leading dot
    while (*input_path == '.') {
        *input_path++ = '\0';
    }
    
    int argc = sizeof(argv) / sizeof(char*);
    char** argvp = malloc(argc * sizeof(char*));
    
    for (int i = 0; i < argc; i++) {
        strcpy(argvp[i], argv[i]);
        argvp[i][0] = '\0'; // Remove leading dot from input path
    }
    
    // Call optimized output file creation function using arguments provided by user
    optimize_using_bash(input_path);
    
    return 0;
}