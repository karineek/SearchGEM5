
#include <stdio.h>

int main() {
    int argc;
    char *argv[2];
    
    argv[0] = "hello";
    argv[1] = NULL;
    
    if (argc != 2) {
        printf("Please provide at least one argument\n");
        return 1;
    } else {
        printf("%s", argv[1]);
        return 0;
    }
}