
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "profile_gui_opt.h"
#include "utf_16.h"

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s file\n", argv[0]);
        return 1;
    }

    FILE *infile = fopen(argv[1], "r");
    if (!infile) {
        perror("Unable to open input file");
        return 2;
    }

    char buffer[1024];
    int size;
    while ((size = fread(buffer, 1, sizeof(buffer), infile)) > 0) {
        printf("%c", buffer[0]);
        fflush(stdout);
    }

    fclose(infile);
    return 0;
}