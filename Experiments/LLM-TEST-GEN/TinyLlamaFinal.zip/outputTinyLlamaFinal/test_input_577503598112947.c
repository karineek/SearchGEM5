
#include <stdlib.h>
#include "profile.h"

#define MAX_ITERATIONS 1000
#define ALPHA 5

int main(int argc, char *argv[]) {
    char *input;
    if (argc != 2) {
        fprintf(stderr, "Usage: %s file\n", argv[0]);
        return EXIT_FAILURE;
    }
    input = argv[1];
    
    profile_initialize();
    printf("Starting PGO with ALPHA=%d and MAX_ITERATIONS=%d\n", ALPHA, MAX_ITERATIONS);
    pgo(input, ALPHA, MAX_ITERATIONS);
    profile_finalize();
    
    return EXIT_SUCCESS;
}