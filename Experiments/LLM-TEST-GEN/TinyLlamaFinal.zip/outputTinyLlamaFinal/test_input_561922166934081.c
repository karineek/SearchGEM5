
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> // for getopt()
#include "optimizer.h"

int main(int argc, char* argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s file\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    // initialize the optimizer
    opt_t* opt = init_optimizer();
    
    // read input from file and process
    FILE* fin = fopen(argv[1], "r");
    if (!fin) {
        perror("Cannot open file");
        exit(EXIT_FAILURE);
    }
    char buffer[512];
    while (fgets(buffer, sizeof(buffer), fin)) {
        char* line = strtok(buffer, "\n\r");
        if (!line) { continue; }
        process_line(opt, line);
    }
    
    // write output to file and close
    fprintf(stderr, "Optimized source code:\n");
    print_source(opt, stdout);
    fflush(stdout);
    
    // cleanup the optimizer
    clean_optimizer(opt);
    
    return 0;
}