
#include <stdio.h>
#include <assert.h>
#include <unistd.h> /* For getopt() */

#define MAX_ITER 1000

int main(int argc, char* argv[]) {
    unsigned int num = strtol(argv[1], NULL, 0);
    assert(num <= MAX_ITER);

    // Call the atomic function with a vectorized argument and return
    // The result of the atomic_load() call.
    return (atomic_int32_t) __builtin_ia32_vmread(&num, 0) & 1;
}