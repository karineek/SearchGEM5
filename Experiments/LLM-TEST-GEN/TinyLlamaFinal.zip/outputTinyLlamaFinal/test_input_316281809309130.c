
#include <stdio.h>
#include <stdlib.h>
#include "fe_downward.h"

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s [input file]", argv[0]);
        return 1;
    }
    
    FILE *fp = fopen(argv[1], "r");
    if (!fp) {
        perror("open");
        return 2;
    }
    
    printf("%s\n", fe_downward(fp));
    fclose(fp);

    return 0;
}