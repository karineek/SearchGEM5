
#include <stdio.h>
#include <string.h>
#include "optimization/profile-guiided-optima.h"

int main(int argc, char *argv[]) {
    FILE *input = fopen(argv[1], "r");
    
    int opt = 0;
    while (opt != 'q' && opt != 'Q') {
        printf("Enter \"q\" to quit or \"%c\" for another input: ", opt);
        char c;
        c = fgetc(input);
        if (c == '\n') {
            printf("\n");
            fseek(input, 0, SEEK_SET);
        } else {
            opt = getopt(argc, argv, "qQ");
        }
    }
    
    // Handle input correctly
    if (opt != 'q') {
        while ((c = fgetc(input)) != EOF) {
            printf("%c", c);
        }
    } else {
        printf("\n");
    }
    
    return 0;
}