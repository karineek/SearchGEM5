
#include <stdio.h>
#include <string.h>

#define BSIZE 1024 // maximum buffer size for input/output operations

int main(int argc, char *argv[]) {
    int i, j;
    const char *in = (const char *)(argc > 1 ? argv[1] : "stdin");
    const char *out = (const char *)(argc > 2 ? argv[2] : stdout);
    FILE *input = fopen(in, "r");
    FILE *output = fopen(out, "w");
    
    // check if file exists and is readable
    if (!input && !output) {
        printf("Error: Input/Output file does not exist or cannot be opened.\n");
        return 1;
    } else if (input && output) {
        // read input characters from the file
        for (i = 0; i < BSIZE; i++) {
            char c = fgetc(input);
            if (c == EOF) {
                printf("Error: Input file is empty.\n");
                return 1;
            } else if (c == '\n') { // newline character
                fputs("\n", output);
            } else if (!isalpha(c)) { // non-alphanumeric characters
                printf("Error: Input contains non-alphabetic character.\n");
                return 1;
            } else if (i + 1 >= BSIZE) { // check for buffer overflow
                printf("Warning: Input file is too large. Skipping...\n");
                continue;
            } else {
                fputc(c, output);
            }
        }
    } else {
        printf("Error: Input/Output file not found.\n");
        return 1;
    }
    
    // close files and free resources
    if (input) {
        fclose(input);
    }
    if (output) {
        fclose(output);
    }
    
    return 0;
}