
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
  int I;
  if (argc != 2) {
    printf("Usage: %s filepath\n", argv[0]);
    exit(EXIT_FAILURE);
  }
  
  FILE *inputFile = fopen(argv[1], "r");
  if (!inputFile) {
    printf("%s: Cannot open input file for reading. %s\n", argv[0], strerror(errno));
    exit(EXIT_FAILURE);
  }
  
  while ((I = fscanf(inputFile, "%d", &I)) != EOF) {
     printf("%d\n", I);
  }
  
  fclose(inputFile);
  return 0;
}