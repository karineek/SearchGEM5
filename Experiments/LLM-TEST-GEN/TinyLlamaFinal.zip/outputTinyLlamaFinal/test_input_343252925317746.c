
#include <stdio.h>

#define MAX_INPUT_LENGTH 1024

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Error: Invalid number of arguments.\n");
        return 1;
    }
    
    int input_length = atoi(argv[1]);
    
    if (input_length > MAX_INPUT_LENGTH) {
        fprintf(stderr, "Input length must be <= %d.\n", MAX_INPUT_LENGTH);
        return 1;
    }
    
    char input_buffer[MAX_INPUT_LENGTH + 1];
    memset(input_buffer, '\0', sizeof(input_buffer)); // initialize buffer with null bytes
    
    if (read(STDIN_FILENO, input_buffer, MAX_INPUT_LENGTH) != MAX_INPUT_LENGTH) {
        perror("Error reading stdin.");
        return 1;
    }
    
    printf("Input:\n");
    for (int I = 0; I < MAX_INPUT_LENGTH; i++) {
        printf("%c", input_buffer[i]);
    }
    
    printf("\n");
    
    return 0;
}