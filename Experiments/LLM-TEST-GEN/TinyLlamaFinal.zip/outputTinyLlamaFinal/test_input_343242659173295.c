
#include <stdio.h>

int main() {
    int argc;
    char **argv = NULL;
    
    // Get argument count
    if(argc < 2) {
        printf("Error: Incorrect usage of program.\n");
        return 1;
    }
    
    // Allocate memory for arguments
    argv = (char **) malloc(sizeof(char *) * argc);
    
    // Copy arguments to array
    for(int I = 0; I < argc; i++) {
        argv[i] = strdup(argv[i]);
    }
    
    // Set program name to the first argument
    char *program_name = argv[0];
    
    int line, column, index = 1;
    
    while(*program_name) {
        // Find the next space or newline character
        for(int I = 0; *program_name && *program_name != ' '; i++) {}
        
        // Check if next character is a newline
        if(*program_name == '\n') {
            index++;
            program_name++;
        } else {
            break;
        }
    }
    
    // Call handle_llvm_bitcode() and alert()
    handle_llvm_bitcode(argv[0], &line, &column);
    alert("");
    
    return 0;
}