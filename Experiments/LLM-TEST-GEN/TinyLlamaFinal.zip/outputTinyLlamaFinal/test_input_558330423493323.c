
#include <stdio.h>
#include <stdlib.h>

int main() {
    int nargs;
    char **argv = NULL; // declare a pointer to the array
    
    if (getopt(argc, argv, "hi:") != -1) {
        printf("Invalid arguments.\n");
        return 0;
    }
    
    nargs = optind + 1; // get remaining args after the option string
    
    for (int I = 0; I < nargs; i++) {
        char arg[MAX_ARG];
        int len = read(STDIN_FILENO, &arg, sizeof(arg)) > -1 ? strlen(arg) + 1 : -1; // read a single argument and add a trailing \0
        
        if (arg && len == argc[i] && memcmp(argv[i], "--", 2) == 0) { // check if an option string is present
            printf("Invalid options.\n");
            return 1;
        }
        
        if (len > MAX_ARG) {
            fprintf(stderr, "Input exceeds maximum length (%d).\n", MAX_ARG);
            return 2; // exit with error code 2 (input exceeded max length)
        }
        
        printf("%s ", arg);
    }
    
    return 0;
}