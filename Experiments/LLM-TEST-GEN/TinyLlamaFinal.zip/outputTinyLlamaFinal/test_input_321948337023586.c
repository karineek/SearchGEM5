
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv) {
    int num = 0;
    
    if (argc == 1 && !strcmp(argv[1], "--help")) {
        printf("Usage: %s [-h]\n", argv[0]);
        return 0;
    } else if (argc > 1) {
        num = atoi(argv[1]);
        
        if (num <= 0 || num > 99) {
            printf("Invalid number: %s\n", argv[1]);
            return 1;
        } else {
            printf("%d\n", num);
            return 0;
        }
    } else {
        printf("Usage: %s [--help]\n", argv[0]);
        return 1;
    }
}