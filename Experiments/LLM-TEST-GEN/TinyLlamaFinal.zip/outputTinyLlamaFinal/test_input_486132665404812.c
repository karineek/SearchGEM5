
#include <stdio.h>
#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/Module.h"

// Function to return LLVM IR representation of a program
LLVMValueRef get_ir(const char *filename) {
  LLVMContext* ctx = llvm::getGlobalDefault();
  LLVMType* types[] = {
      llvm::Type::IntTy(32), // function pointer arg
      llvm::Type::DoubleTy() // double arg
    };
  LLVMPassManager* manager = new LLVMPassManagerBuilder(llvm::PassManagerBase::SIGNS_AND_WARNINGS)
      .Add<LLVMCleanupPass>().Build();
  LLVMOption opt;
  std::vector<char*> args(2);
  args[0] = filename;
  args[1] = nullptr; // no other arguments needed here
  manager->run(*ctx, args.data(), 2, &opt);
  if (!opt.getError()) {
    LLVMValueRef module = llvm::parseStandardInput(filename);
    std::vector<LLVMValueRef> args({module}, {});
    return llvm::InvokePasses(*ctx, manager, opt.getValue(), args).getResult()[0];
  } else {
    printf("Error: Failed to parse %s\n", filename);
    exit(1);
  }
}