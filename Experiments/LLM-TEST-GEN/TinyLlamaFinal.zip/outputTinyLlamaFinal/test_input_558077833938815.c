
#include <stdio.h>
#include <stdlib.h>

#define BASH 1

int main() {
    int argc;
    char **argv;
    
    argv = getarg(&argc, &argv);
    
    if (argc != 2) {
        printf("Usage: %s <input>\n", argv[0]);
        return 1;
    }
    
    FILE *f = fopen(argv[1], "r");
    if (!f) {
        perror("Error: Unable to open input file\n");
        exit(EXIT_FAILURE);
    }
    
    int n = 0;
    char line[128];
    
    while (fgets(line, sizeof(line), f) != NULL) {
        n++;
        
        if (n % BASH == 0) {
            printf("Line %d:", n);
            
            if (fread(&line[n], 1, sizeof(line)-n-1, f) != sizeof(line)-n-1) {
                perror("Error reading input file\n");
                exit(EXIT_FAILURE);
            }
            
            printf("%s\n", line);
        }
    }
    
    if (fclose(f) != 0) {
        perror("Error: Unable to close input file\n");
        exit(EXIT_FAILURE);
    }
    
    return 0;
}