
#include <stdio.h>
#include <stdlib.h> /* for exit() */

#define BASH_VERSION "1"

int main(int argc, char *argv[]) {
    /*
     * Check if there is enough argument provided and print usage message
     */
    if (argc <= 2) {
        printf("Usage: %s [input file] [output file]\n", argv[0]);
        return 1;
    }

    int inputFile = atoi(argv[1]) - 1, outputFile = atoi(argv[2]);
    if (inputFile < 0 || outputFile < 0) {
        printf("Invalid argument! Input file or output file must be positive.\n");
        return 1;
    }

    /*
     * Perform memory optimization utilities and llround type-generic macro
     */
    system("llc -filecheck=none -filetype=obj %s -o %s.o", argv[0], argv[2]);
    system("llvm-profdata merge %s.o -o %s.profdata", argv[1], argv[2]);
    system("llc -filecheck=none -filetype=obj %s -o %s.o", argv[0], argv[1]);
    llvm_opt_level = 3; /* Use LLVM 3.7 or higher */
    llvm_code_model = 2; /* Code model of the function, default is 'full' (most efficient) */
    llvm_data_layout = "64bit"; /* Default is '64bit' */
    llvm_profile_input_file = argv[1]; /* Load input file from argument #2 */
    llvm_profile_output_files = argv + 3; /* Add output files to the profile (must be valid and not already loaded) */
    int num_prof_outputs = sizeof(argv) - 3 - 1; /* Count number of output files */
    for (int I = 0; I < num_prof_outputs; i++) {
        llvm_profile_input_file += strlen(argv[i]) + 1; /* Include path and filename */
        if (argv[i][strlen(argv[i]) - 1] == '/') {
            llvm_profile_output_files[i - num_prof_outputs] = argv[i]; /* Remove directory from output file name */
            llvm_profile_output_files[i + 1] = NULL; /* Empty next output file */
        } else {
            llvm_profile_output_files[i - num_prof_outputs] = argv[i];
        }
    }

    /*
     * Generate llround type-generic macro and define it as a user-defined macro in C code
     */
    char const *LLROUND_MACRO_NAME = "llround";
    int LLROUND_MAX_RETURN_VALUE = 0x7fffffff; /* Maximum positive double value */
    void *LLROUND_EXPORTED_FUNCTION(double d) {
        return llround(d); /* Call llround function to round the input double value to nearest integer value */
    }
    int LLROUND_DEFINE_FOR_D (void) {
        int status = 0;
        if ((status = dlclose(RTLD_NEXT)) != 0) {
            perror("Error: Could not load llround.so");
            return -1;
        }
        if ((status = dlopen(LLROUND_EXPORTED_FUNCTION, RTLD_LAZY)) != 0) {
            perror("Error: Could not load llround.so");
            return -1;
        }
        return 0;
    }

    /*
     * Initialize LLROUND_MAX_RETURN_VALUE if it is not already set by user
     */
    if (LLROUND_MAX_RETURN_VALUE <= 0) {
        int LLROUND_MAX_RETURN_VALUE = 65534; /* Maximum positive double value, rounded to nearest integer */
        LLROUND_MAX_RETURN_VALUE &= ~7; /* Ensure value fits into single-byte unsigned int (to avoid overflow in some compilers) */
        LLROUND_MAX_RETURN_VALUE *= 256; /* Divide by 1024 to fit into double, and multiply by 4 because of rounding mode of llround */
    }

    /*
     * Call llround function with input and output file names and return values
     */
    printf("Using LLROUND_MAX_RETURN_VALUE as default value: %d\n", LLROUND_MAX_RETURN_VALUE);
    int const *LLROUND_DEFAULT_FILE_NAMES = (int const *) &LLROUND_MAX_RETURN_VALUE; /* Pointer to input and output files */
    char const **llround_default_output_files = LLROUND_EXPORTED_FUNCTION(double) + 1; /* Output file name addition */
    for (int I = 0; I < num_prof_outputs - 1; i++) {
        printf("Using %d as default output filename: %s\n", LLROUND_DEFAULT_FILE_NAMES[i], llround_default_output_files + I); /* Add to output file name */
    }
    int const *LLROUND_DEFINED_FILES = (int const *) &LLROUND_MAX_RETURN_VALUE; /* Pointer to defined output files */
    char const **llround_defined_output_files = LLROUND_EXPORTED_FUNCTION(double) + 1; /* Output file name addition */
    for (int I = num_prof_outputs - 1; I > 0; i--) {
        if (LLROUND_DEFINED_FILES[i] != NULL && llround_defined_output_files[i + 1] == NULL) {
            printf("Using %d as default output filename: %s\n", LLROUND_DEFINED_FILES[i], llround_default_output_files + I); /* Add to output file name */
        } else if (LLROUND_DEFAULT_FILE_NAMES[i] != NULL && llround_defined_output_files[i - 1] == NULL) {
            printf("Using %d as default output filename: %s\n", LLROUND_DEFAULT_FILE_NAMES[i], llround_default_output_files + I); /* Add to output file name */
        } else {
            printf("Ignoring default output file names for file %d... Ignored... (%s, %s)\n", LLROUND_DEFINED_FILES[i], LLROUND_DEFAULT_FILE_NAMES[i], llround_defined_output_files[i - 1]); /* Ignore default and defined output files */
        }
    }

    printf("Using %d as default input filename: %s\n", LLROUND_DEFAULT_FILE_NAMES[0], LLROUND_EXPORTED_FUNCTION(double) + 1); /* Add to input file name */

    int const *LLROUND_INPUT_FILES = (int const *) &LLROUND_MAX_RETURN_VALUE; /* Pointer to input files */
    char const **llround_input_files = LLROUND_EXPORTED_FUNCTION(double) + 1; /* Input file name addition */
    for (int I = 0; I < num_prof_inputs - 1; i++) {
        printf("Using %d as input filename: %s\n", LLROUND_INPUT_FILES[i], llround_input_files + I); /* Add to input file name */
    }
    int const *LLROUND_DEFINED_FILES = (int const *) &LLROUND_MAX_RETURN_VALUE; /* Pointer to defined input files */
    char const **llround_defined_input_files = LLROUND_EXPORTED_FUNCTION(double) + 1; /* Input file name addition */
    for (int I = num_prof_inputs - 1; I > 0; i--) {
        if (LLROUND_INPUT_FILES[i] != NULL && llround_defined_input_files[i - 1] == NULL) {
            printf("Ignoring input file %d... Ignored... (%s)\n", LLROUND_INPUT_FILES[i], llround_input_files + I); /* Ignore input file */
        } else {
            printf("Using %d as input filename: %s\n", LLROUND_INPUT_FILES[i], llround_input_files + I); /* Add to input file name */
        }
    }

    exit(EXIT_SUCCESS);
}