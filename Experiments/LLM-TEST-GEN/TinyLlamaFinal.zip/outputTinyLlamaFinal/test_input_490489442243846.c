
#include <stdio.h>

/* function to check if number is prime */
bool is_prime(int n) {
  /* check for zero and negative numbers */
  if (n <= 1 || n == 0 || n == -1) {
    return false;
  } else {
    return true;
  }
}

/* vectorized program to calculate the sum of all prime numbers up to n using recursion */
int sum_up_to(int n, int *sum) {
  /* base case: n <= 1 */
  if (n == 1 || n == 0) {
    *sum = 0;
    return 0;
  } else {
    /* calculate the sum of all prime numbers up to n using recursion */
    int I = 2;
    while (I <= n) {
      if (!is_prime(i)) {
        break;
      }
      *sum += i;
      I++;
    }
    return *sum;
  }
}

int main() {
  /* take the input as an argv */
  int n = atoi(argv[1]);
  
  /* calculate the sum of all prime numbers up to n using vectorized program */
  int sum = sum_up_to(n, &sum);

  /* print the result */
  printf("The sum of all prime numbers up to %d is: %d\n", n, sum);

  return 0;
}