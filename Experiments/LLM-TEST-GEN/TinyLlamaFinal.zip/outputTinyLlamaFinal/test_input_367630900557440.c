
#include <stdio.h>
#include "loop_fuci.h"

int main(int argc, char *argv[]) {
    // Check number of arguments (<= 2)
    if (argc != 2) {
        printf("Error: Incorrect arguments\n");
        return -1;
    }
    
    // Call loop fucio function to perform the optimization
    return loop_fuci(argv[1]);
}