
#include <stdio.h>
#include "covertg_frontend.h"
#include "covertg_impl.h"

/* TSO program */
int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s [file]\n", argv[0]);
        return -1;
    }
    
    int64_t *a = (int64_t *) malloc(sizeof(int64_t) * 3);
    a[0] = 27;
    a[1] = 15;
    a[2] = 9;
    
    /* Sample input */
    int n = atoi(argv[1]);
    for (int I = 0; I < n; i++) {
        a[3 + i] = rand() % 78;
    }
    
    CovertG_Frontend frontend(&a);
    CovertG_Impl impl(&a, sizeof(a) / sizeof(int64_t));
    
    if (covertg_run(&frontend, &impl, CKLN_TSO)) {
        printf("Target-specific optimization completed successfully!\n");
    } else {
        fprintf(stderr, "Target-specific optimization failed.\n");
    }
    
    free(a);
    return 0;
}