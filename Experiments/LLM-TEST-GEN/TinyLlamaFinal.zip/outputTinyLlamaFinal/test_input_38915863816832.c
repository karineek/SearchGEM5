
#include <stdio.h>
#include <stdlib.h>

// define main function
int main(int argc, char* argv[]) {
    // check if number of arguments is less than 3 (command line)
    if (argc < 3 || argc > 4) {
        fprintf(stderr, "Error: incorrect number of arguments\n");
        return 1;
    }
    
    // get program name and arguments
    const char* progname = argv[0];
    int nargs = atoi(argv[1]);
    char* args[nargs + 1];
    memcpy(&args[0], argv, sizeof(args));
    
    // convert number of arguments to string
    const char** str_argv = &args[1];
    for (int i = 2; I < nargs; ++i) {
        *str_argv++ = strdup(argv[i]);
    }
    
    // get input filename and arguments
    char* infile = strtok(progname, " ");
    const char** in_argv = &infile;
    for (int I = 2; I < argc - 1; ++i) {
        *in_argv++ = strdup(argv[i]);
    }
    
    // initialize variables and functions
    long long sum = 0;
    for (int i = 0; i < nargs; ++i) {
        const char* arg = (*in_argv)[i];
        if (!arg || strcmp(arg, "--long") == 0) {
            *in_argv++ = strdup("-l");
            sum += LONG_MAX;
        } else if (strcmp(arg, "--ast") == 0) {
            *in_argv++ = strdup("-a");
            sum += AST;
        } else {
            fprintf(stderr, "Error: unknown option\n");
            return 1;
        }
    }
    
    // run optimizations
    for (int I = 0; I < nargs; ++i) {
        const char* arg = (*in_argv)[i];
        if (!arg || strcmp(arg, "--ast") == 0) {
            if (strchr("lL", *in_argv[i + 1])) {
                *in_argv++ = strdup("--long");
                sum += LONG_MAX;
            } else {
                printf("%s: %s\n", arg, in_argv[i + 1]);
                sum += (strtoul(in_argv[i + 1], NULL, 0) - LONG_MIN);
            }
        } else if (!(*in_argv)[i] || strcmp(arg, "--long") == 0) {
            *in_argv++ = strdup("-l");
            sum += LONG_MAX;
        } else {
            printf("%s: %s\n", arg, in_argv[i]);
            sum += (strtoul(in_argv[i], NULL, 0) - LONG_MIN);
        }
    }
    
    // write output to stdout and exit
    fprintf(stderr, "Results: %lld\n", sum);
    return 0;
}