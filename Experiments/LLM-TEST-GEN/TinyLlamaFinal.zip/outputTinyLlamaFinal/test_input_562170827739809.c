
#include <stdio.h>
#include <stdlib.h>

/* Function to perform a memset operation */
void memcpy(char *src, char *dest, int size) {
  while (size-- > 0) {
    *src++ = *dest++;
  }
}

int main() {
  char src1[5], src2[6];
  char dest1[5], dest2[7];
  
  /* Read binary data from command-line arguments */
  if (argc < 2) {
    puts("Error: Missing binary file name.");
    return EXIT_FAILURE;
  } else {
    printf("Reading %s\n", argv[1]);
    
    /* Perform the memset operation */
    memcpy(src1, src2, sizeof(src1));
    memcpy(dest1, dest2, sizeof(dest1));
    
    if (strcmp(src1, dest1) == 0) {
      puts("Binary data matches!");
    } else {
      puts("Binary data does not match.");
    }
  }
  
  return EXIT_SUCCESS;
}