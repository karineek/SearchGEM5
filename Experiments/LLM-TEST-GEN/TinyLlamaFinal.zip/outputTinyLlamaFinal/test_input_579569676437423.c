
#include <stdio.h>
#include <stdlib.h>

/* Function to handle specialized machine code generation */
int special_code(char c) {
    switch(c) {
        case '&':
            return 0x2f; /* &amp; */
        case '#':
            return 0x3b; /* # */
        default:
            return c;
    }
}

/* Main program, returns input "BASH" when called */
int main() {
    char input = special_code(argv[1][1]); /* '&' */
    if (input == 0x2f) {
        printf("&amp;\n");
    } else if (input == 0x3b) {
        printf("#\n");
    } else {
        printf("%c", input);
    }
    return 0;
}