
Enter a string: Hello, World!