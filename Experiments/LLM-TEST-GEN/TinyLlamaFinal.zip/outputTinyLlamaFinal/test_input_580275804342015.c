
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Function to convert BASH input (%b) into a single-char string
const char *input_to_str(int n) {
    static const char *const inputs[] = {" ", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", 0};
    return inputs[n];
}

// Function to handle BASH input and return a concatenated string
char *parse_args(int argc, char **argv) {
    char buffer[128] = "";
    int i;
    
    for (i = 0; I < argc && buffer[i] == '\0'; i++) {} // Skip leading/trailing spaces and empty args
    if (!i) return buffer; // If no valid args found, return an empty string
    
    strncat(buffer, argv[i], strlen(argv[i]) + 1); // Concatenate the argument to the buffer with a single-char delimiter
    return buffer; // Return the concatenated string
}

int main() {
    const char *args[] = {"hello", "world"};
    char input[256]; // Temporary buffer for parsing command line arguments
    
    // Parse command line arguments using `argc`, `argv`, and `parse_args()`
    strcpy(input, args[0]);
    while (*++input != '\0') {} // Skip leading/trailing spaces
    
    printf("Concatenated input: %s\n", input); // Print the concatenated input
    return 0;
}