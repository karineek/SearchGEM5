
#include <stdio.h>
#include <stdlib.h>

#ifndef __USE_GNU
#define __USE_GNU 1
#endif

#include <unistd.h>
#include <time.h>

#define MAXLINE (PATHMAX+1) /* Maximum length of a line */

#ifdef __USE_MISC
#include <dirent.h>
#endif

void usage(char *program);
int main(int argc, char *argv[]);

// Functions for Memory Optimizations
// Based on: https://www.tutorialspoint.com/memory_optimization_in_cpp/memory_optimization_in_cpp.htm
int *fgetpos(FILE *stream, struct ftellol *ftello) {
    int line;
    char *linebuf = (char*)malloc(MAXLINE);
    if (!linebuf || !feof(stream)) { /* Check for EOF */
        fprintf(stderr, "fgetpos(): error: could not allocate memory\n");
        return NULL;
    }
    ftello->t_sec = time(NULL); /* Set initial filetime value */
    if (feof(stream)) { /* Check for EOF */
        line = ftell(stream) - 1; /* Get line number from current position */
        *ftello = ftellooff(stream); /* Update ftello value for subsequent reads */
        if (*line == '\0') { /* Handle line being empty */
            fprintf(stderr, "fgetpos(): error: empty line\n");
            free(linebuf); /* Free memory allocated for file */
            return NULL;
        } else { /* Handle non-empty lines */
            char *buf = malloc(MAXLINE + 1); /* Allocate buffer for entire line */
            if (!buf) { /* Check for alloc failure */
                fprintf(stderr, "fgetpos(): error: could not allocate memory\n");
                free(linebuf);
                return NULL;
            }
            buf[0] = '\0'; /* Set first character to null */
            while ((*ftello && (size_t)feof(stream)) == (size_t)(*ftello + 1)) {
                sprintf(buf + strlen(buf), "%.*s", MAXLINE - *line, linebuf); /* Get next line */
                line++; /* Increment line number */
            }
            if (!feof(stream)) {
                fprintf(stderr, "fgetpos(): error: expected input file to be readable\n");
                free(linebuf);
                free(buf);
                return NULL;
            } else if ((*ftello + 1) != ftell(stream)) { /* Check for mismatched input positions */
                fprintf(stderr, "fgetpos(): error: mismatched input file read position\n");
                free(linebuf);
                free(buf);
                return NULL;
            } else if (strcmp(buf + strlen(buf) - 1, "\n")) { /* Check for newline character */
                line++; /* Increment line number */
            } else { /* Handle empty lines */
                line--; /* Decrement line number */
            }
        }
    } else if (feof(stream)) { /* Check for EOF while reading from file */
        fprintf(stderr, "fgetpos(): error: could not read input file\n");
        free(linebuf);
        free(buf);
        return NULL;
    } else { /* Handle non-readable input file */
        fprintf(stderr, "fgetpos(): error: unexpected EOF in input file\n");
        free(linebuf);
        free(buf);
        return NULL;
    }
}

// Function for testing if a given string is a valid filename
int test_filename(char *str) {
    int i = 0; /* Initialize counter */
    while (str[i]) {
        if (!isspace(str[i])) {
            return 0; /* If space character present, file name is invalid */
        } else if (!isalnum(str[i])) {
            return 1; /* Non-alphanumeric characters are not allowed in filename */
        } else {
            i++; /* Increment counter for next non-space character */
        }
    }
    return 0; /* No error found */
}

// Function to write a line of output to the file specified by name, with optional timestamp
void print_line(char *name, int timestamp, const char *fmt, ...) {
    va_list args; /* Initialize argument list */
    char buf[MAXLINE]; /* Allocate buffer for output line */
    va_start(args, fmt); /* Start passing arguments to format string */
    vsprintf(buf, fmt, args); /* Format and print output line */
    va_end(args); /* End passing arguments to format string */
    if (!test_filename(name)) { /* Check for valid filename */
        fprintf(stderr, "fputs(): error: invalid filename\n");
    } else {
        FILE *fp = fopen(name, "a+"); /* Open output file */
        if (!fp) { /* Check for error opening file */
            fprintf(stderr, "fputs(): error: failed to open output file\n");
        } else { /* Write output line to file */
            fprintf(fp, buf); /* Write output line to file */
            if (test_filename(name)) { /* Check for valid filename again after writing */
                fputs(" ", stderr); /* Print newline character */
            }
        }
        fclose(fp); /* Close output file */
    }
}

int main(int argc, char *argv[]) {
    int line;
    char name[MAXLINE + 1]; /* Allocate buffer for input filename */
    if (argc > 1 && strcmp(argv[1], "-") == 0) { /* Check for "-" argument indicating input file */
        sprintf(name, "stdin"); /* Set default input filename to stdin */
    } else if (!test_filename(argv[1])) { /* Check for valid input filename */
        fputs("Error: invalid input filename\n", stderr); /* Print error message */
        return 1; /* Exit with non-zero exit code */
    } else { /* Handle normal input file */
        if (isatty(STDIN_FILENO)) { /* Check for tty device */
            fputs("Warning: using tty device\n", stderr); /* Print warning message */
        }
        int stream = fileno(stdin); /* Get standard input file descriptor */
        if (fileno(stdout) == STDOUT_FILENO) { /* Handle stdout */
            fputs("Warning: using stdin and stdout as output devices\n", stderr); /* Print warning message */
        }
        int time = time(NULL); /* Get current time in seconds */
        if (test_filename(name)) { /* Check for valid input filename again after setting to default or stdout */
            fputs("Warning: using default output filename\n", stderr); /* Print warning message */
        } else {
            time_t t;
            if (!strptime(argv[1], "%a %b %d %Y %T %z %Z", &t)) { /* Check for valid timestamp */
                fputs("Error: invalid timestamp\n", stderr); /* Print error message */
                return 1; /* Exit with non-zero exit code */
            } else if (time == time(NULL) || tm_hour >= 24 || tm_minute >= 60 || tm_sec >= 60) { /* Check for valid timestamp format */
                fputs("Warning: invalid timestamp\n", stderr); /* Print warning message */
            } else if (time != time(NULL)) { /* Handle non-valid timestamp */
                fputs("Error: timestamp is not a valid time\n", stderr); /* Print error message */
            } else if (!test_filename(name)) { /* Check for valid input filename */
                fputs("Warning: invalid input filename\n", stderr); /* Print warning message */
            }
        }
    }
    return 0; /* Exit with non-zero exit code */
}