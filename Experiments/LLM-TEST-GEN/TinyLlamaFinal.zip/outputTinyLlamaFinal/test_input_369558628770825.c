
#include <stdio.h>

/* This function is called when we encounter a BASH command */
void print_command(const char *command) {
    printf("Command: %s\n", command);
}

int main() {
    /* This program will take one argument from the user, which is a BASH command */
    const char *input;
    if (argc == 1) {
        printf("Enter a BASH command: ");
        input = getenv("input");
    } else {
        input = argv[1];
    }
    
    /* Call the print_command() function with the provided command */
    if (input != NULL) {
        printf("Command: %s\n", input);
        print_command(input);
    }
    
    return 0;
}