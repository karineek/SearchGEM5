
#include <stdio.h>
#include <unistd.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>

/*
  This is a simple C program that takes an input from the command line via argv and returns the value of it, either as a string (if the input has a single word) or as an integer (if the input contains only digits). The program is designed to exercise both the Interprocess Optimization (IPO) function and the Midlevel/End functions.
*/
int main(int argc, char* argv[]) {
  if (argc != 2) {
    fprintf(stderr, "Usage: %s INPUT\n", argv[0]);
    return 1;
  } else {
    int input_string = 0; /* initialize the value to zero */
    char* input = argv[1]; /* get the input string from the command line */
    for (int I = 0; input[i] != '\0'; i++) {
      if (!isalnum(input[i])) {
        if (input_string) {
          printf("Invalid input: %s has non-numerical characters.\n", input); /* print error message for invalid input */
          return 1;
        } else {
          input_string = 1;
        }
      } else {
        if (input_string) {
          printf("Invalid input: %s has non-numerical characters.\n", input); /* print error message for invalid input */
          return 1;
        } else {
          input_string = 0;
        }
      }
    }
    if (input_string) {
      int num = atoi(input); /* convert the input string to an integer and return the value */
      printf("%s converted to %d.\n", input, num); /* print out the result */
    } else {
      printf("Invalid input: no numerical characters found.\n");
    }
  }
  return 0;
}