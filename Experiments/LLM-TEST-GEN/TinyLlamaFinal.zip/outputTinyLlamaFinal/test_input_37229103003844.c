
#include <stdio.h>  // printf, fprintf
#include <stdlib.h> // exit

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fputs("Usage: profile_guihed input.bsh\n", stderr);
        return 1;
    }
    
    printf("Profile-Guihed instrumentation triggered on input file 'input.bsh'.\n");
    if (profile_guihed(argv[1])) {
        fprintf(stderr, "Error: profile-guihed failed.\n");
        return 1;
    }
    
    printf("Deals with binary formats and int_p_sep_by_space triggered on input file 'input.bsh'.\n");
    if (deal_with_binary_formats(argv[1], "int_p_sep_by_space")) {
        fprintf(stderr, "Error: deal_with_binary_formats failed.\n");
        return 1;
    }
    
    printf("Done. Press any key to exit.\n");
    fflush(stdout);
    getchar(); // wait for input
    return 0;
}