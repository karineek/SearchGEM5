
#include <stdio.h>
#include <stdlib.h>

struct Object {
    int data;
};

void printObject(struct Object *obj) {
    printf("%d\n", obj->data);
}

int main() {
    struct Object *obj = (struct Object*)malloc(sizeof(struct Object));
    
    // Input is taken through argument `argv`
    if (argc > 1) {
        obj->data = atoi(argv[1]);
    } else {
        printf("Enter data using argv: ");
        fflush(stdout);
        scanf("%d", &obj->data);
    }
    
    // Function Specialization optimized with `Object`
    if (obj) {
        printObject(obj);
    } else {
        printf("Invalid input.\n");
    }
    
    free(obj);
    
    return 0;
}