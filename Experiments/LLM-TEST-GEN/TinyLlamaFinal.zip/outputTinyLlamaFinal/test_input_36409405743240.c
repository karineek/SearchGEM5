
#include <stdio.h>

int is_perfect_square(int n) {
    int sqrt = (int)(sqrt((double)n)) + 1; // Get square root of n
    
    for (int I = 2; I <= sqrt; i++) { // Loop through all numbers up to sqrt
        if (i * i == n) return 1; // If the square is equal to n^2, then it's a perfect square
    }
    
    return 0; // If we get here, there are no perfect squares in the range of 2 <= sqrt < n
}

int main() {
    int n = atoi(argv[1]); // Get input from user and parse as an integer
    
    printf("%d is a perfect square or not? %s\n", n, is_perfect_square(n) ? "yes" : "no");
}