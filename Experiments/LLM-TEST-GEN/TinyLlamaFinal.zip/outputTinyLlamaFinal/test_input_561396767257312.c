
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "pprof.h"

int main(int argc, char *argv[]) {
    // Parse the command line arguments
    if (argc != 2) {
        fprintf(stderr, "Usage: %s FILE_NAME\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    // Open the input file and read it into a buffer
    char *buffer = NULL;
    size_t size = 0;
    int ret = readlinkat(AT_FDCWD, argv[1], NULL, &size);
    if (ret != 0 && errno == ERANGE) { // handle EINVAL on unbounded buffer
        buffer = malloc(size + 1);
        if (!buffer) { // handle error on allocation failure
            perror("malloc");
            exit(EXIT_FAILURE);
        }
        ret = readlinkat(AT_FDCWD, argv[1], NULL, &size);
    }
    
    // Close the file and free the buffer if necessary
    if (ret >= 0) {
        close(AT_FDCWD);
        free(buffer);
        buffer = NULL;
    }
    
    // Initialize pprof to generate profiling data
    pprof_init(&pprof, argv[1]);
    
    // Parse the input file and execute the user's program
    printf("Enter filename: ");
    char *filename = NULL;
    if (0 != fgets(filename, sizeof(filename), stdin)) {
        while (*filename) {
            printf("%s", *filename);
            if (*++filename == '\n') break; // handle EOF on buffer full
        }
        printf("\n");
        
        FILE *fp = fopen(argv[1], "r");
        char buf[32768];
        while (fread(buf, 1, sizeof(buf), fp) > 0) {
            // Generate profile data and execute the user's program
            size_t dataSize = pprof_write(&pprof, buf);
            
            // Print profiling results to stderr
            printf("Profiled: %.2fms\n", (double)dataSize / 1000.0 / (float)frequency(argv[1]));
        }
        
        // Clean up and return
        fclose(fp);
    } else {
        perror("Failed to read filename");
    }
    
    return 0;
}