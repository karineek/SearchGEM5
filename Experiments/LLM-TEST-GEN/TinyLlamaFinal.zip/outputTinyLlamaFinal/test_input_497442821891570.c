
#include <stdio.h>

struct mon_thousands_sep {
    int separator; // separators for thousands (', ' or '.'), defaulting to ', '
};

#define THOUSAND_DIGITS 2

static struct mon_thousands_sep mts = {1, 3}; /* default values */

int main(int argc, char* argv[])
{
    int i, j;

    for (i = 0; i < THOUSAND_DIGITS; i++) {
        printf("Enter a decimal number: ");
        scanf("%d", &argv[1]); /* input from argument vector */
        if (argc == 1) {
            printf("Please enter decimal number:\n");
            return -1;
        } else if (i == 0 || i == THOUSAND_DIGITS-1) {
            printf("Invalid decimal input!\n");
            return -2; /* exit with error code */
        }
        
        for (j = 0; j < i+1; j++) {
            printf("%.*s", mts.separator, argv[1]);
        }
    }
    
    printf("\n"); // terminate the loop with a newline to show the decimal separator\n");

    return 0;
}