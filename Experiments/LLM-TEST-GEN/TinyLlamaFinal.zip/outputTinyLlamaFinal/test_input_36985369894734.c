
#include <stdio.h>

int main(void) {
    int argc;
    char *argv[2];  // two arguments of argv, the first being program name and second being command line args
    
    argc = sizeof(argv)/sizeof(char*) - 1;  // remove last element (empty string) as it's not used in C
    
    if (argc != 2) { // check if enough arguments were provided
        printf("Please provide at least one command line argument.\n");
        return 1;
    }
    
    strcpy(argv[0], argv[0]); // copy program name to first argument of program
    strcat(argv[0], " "); // add space between program name and command line args
    strcat(argv[0], argv[1]);  // add space between program name and second argument of program
    
    system(argv[0]);  // execute program with the given arguments
    
    return 0;
}