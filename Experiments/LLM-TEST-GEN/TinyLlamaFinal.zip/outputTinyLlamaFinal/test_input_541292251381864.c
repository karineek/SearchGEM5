
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> // for getpid()

int main(int argc, char **argv) {
    const char *input = argv[1];
    
    // Get the process ID using getpid()
    pid_t pid = getpid();
    
    // Call the input program with command line arguments
    int status = system(input);
    
    // Exit the program if the call to system failed
    if (status) {
        fprintf(stderr, "Error: Failed to execute %s\n", input);
        return 1;
    } else {
        // Print out the process status using perror()
        printf("Process status: %d\n", status);
        
        // Wait for the process to exit and print its exit code using waitpid()
        pid_t pid2 = waitpid(pid, &status, 0);
        if (pid2 == -1) {
            perror("Error while waiting for process");
            return 1;
        } else if (WIFEXITED(status)) {
            int exitCode = WEXITSTATUS(status);
            
            // Print out the final status using perror()
            printf("Final status: %d\n", exitCode);
            
            // Exit the program with success if all calls to system succeeded
            return 0;
        } else {
            fprintf(stderr, "Error: Process did not exit cleanly\n");
            perror("Error while waiting for process");
            return 1;
        }
    }
}