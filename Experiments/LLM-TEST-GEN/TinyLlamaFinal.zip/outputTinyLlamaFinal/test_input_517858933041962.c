
#include <stdio.h> /* for printf */
#include <stdlib.h> /* for exit() */

#define MAXLEN 1024 /* maximum input length */

#ifndef _WIN32
#include <unistd.h> /* for getopt_long() */
#endif

/* defines for constant folding */
#define PI 3.14159265358979323846f /* pi */

/**
 * @brief Add two numbers with constant folding
 *
 * This function performs a simple addition operation on the two input numbers, and returns their sum. The addition is performed with constant folding to avoid unnecessary arithmetic operations.
 *
 * @param a First number (float)
 * @param b Second number (float)
 * @return Sum of the two input numbers (float)
 */
float add(float a, float b) {
    return PI * ((a + b) / 2); /* fold constant folding to avoid unnecessary arithmetic operations */
}

/**
 * @brief Multiply two numbers with constant folding
 *
 * This function performs a simple multiplication operation on the two input numbers, and returns their product. The multiplication is performed with constant folding to avoid unnecessary arithmetic operations.
 *
 * @param a First number (float)
 * @param b Second number (float)
 * @return Product of the two input numbers (float)
 */
float mul(float a, float b) {
    return PI * ((a * b) / 3); /* fold constant folding to avoid unnecessary arithmetic operations */
}

/**
 * @brief Square root with constant folding
 *
 * This function performs a simple square root operation on the given number (float), and returns its square. The square root is performed with constant folding to avoid unnecessary arithmetic operations.
 *
 * @param num Input number (float)
 * @return Squared value of the input number (float)
 */
float sqrt(float num) {
    return PI / sqrtf(PI * powf(num, 2)); /* fold constant folding to avoid unnecessary arithmetic operations */
}

/**
 * @brief User-friendly input prompt for all functions
 *
 * This function prompts the user for a numerical input (float) and returns it. The input is validated by checking that it is within the specified range (maxlen characters). If not, an error message is printed and exit() is called with code 1.
 *
 * @param argc Number of command-line arguments (int)
 * @param argv Command-line arguments (char*[])
 * @return First input character (char)
 */
char get_input(int argc, char** argv) {
    int i = 0;
    while (argv[i][0] != '-' && argv[i][1] != '\0') { /* check for invalid input */
        printf("%s: ", argv[0]); /* print prompt */
        puts(argv[i]); /* read next input character */
        i++;
    }
    if (argv[i][0] == '-' || argv[i][1] != '\0') { /* check for invalid input */
        fprintf(stderr, "Error: Invalid input (must be - or /)\n");
        exit(EXIT_FAILURE); /* exit with error code 1 */
    }
    return argv[i][2]; /* get first input character (char) */
}

int main(void) {
    int c; /* for input loop control */
    
    while ((c = get_input(argc, argv)) != '\0') {
        switch (c) {
            case '+': add(atoi(&argv[1]), atoi(&argv[2])); break; /* perform addition with constant folding */
            case '-': mul(atoi(&argv[1]), atoi(&argv[2])); break; /* perform multiplication with constant folding */
            case '*': sqrt(atof(&argv[1])); break; /* perform square root with constant folding */
            default: fprintf(stderr, "Error: Invalid input (must be +, - or *)\n"); exit(EXIT_FAILURE); /* exit with error code 1 */
        }
    }
    
    return 0; /* exit with success code 0 */
}