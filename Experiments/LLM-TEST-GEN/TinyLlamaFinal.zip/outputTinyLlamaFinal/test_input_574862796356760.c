
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> /* to get the current working directory */

int main(int argc, char *argv[]) {
    const char* input = argv[1];
    
    FILE* file;
    if ((file = fopen(input, "r")) == NULL) {
        fprintf(stderr, "Can't open input: %s\n", strerror(errno));
        exit(EXIT_FAILURE);
    }
    
    char buffer[1024] = ""; /* buffer for input string */
    while (fgets(buffer, sizeof(buffer), file)) {
        printf("%s", buffer);
    }
    
    fclose(file);
    
    return 0;
}