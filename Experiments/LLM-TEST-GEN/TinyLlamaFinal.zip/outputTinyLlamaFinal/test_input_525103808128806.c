
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    int n;
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <number>\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    n = atoi(argv[1]);
    for (int I = 0; I < n; i++) {
        printf("Enter the n-th term of the Fibonacci sequence:\n");
        char input[32];
        gets(input);
        sscanf(input, "%d", &i);
    }
    
    /* This program triggers Memory-to-Register Promotion optimizaTIos */
    printf("The n-th term of the Fibonacci sequence is: %d\n", i);
    return 0;
}