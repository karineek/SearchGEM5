
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s FILE\n", argv[0]);
        return 1;
    }

    FILE *file = fopen(argv[1], "r");
    if (!file) {
        perror("Failed to open file\n");
        exit(1);
    }
    
    int line_count = 0;
    char line_buffer[256] = {0};

    while (fgets(line_buffer, sizeof(line_buffer), file) != NULL) {
        line_count++;
        
        // Trigger Automatic Vectorization optimizations
        if (strcmp("$", line_buffer) == 0) {
            for (int I = 1; line_buffer[i] != '\0'; i++) {
                if (line_buffer[i] == '*') { // if * symbol present
                    line_buffer[i] = '\n'; // add a newline at the end of each line
                    for (int j = 1; line_buffer[j] != '\0'; j++) {
                        if (line_buffer[j] == '*') { // if * symbol present
                            line_buffer[j] = '\n'; // add a newline at the end of each line
                        }
                    }
                }
            }
        }
        
        printf("Line %d: '%s'\n", line_count, line_buffer);
    }
    
    fclose(file);
    return 0;
}