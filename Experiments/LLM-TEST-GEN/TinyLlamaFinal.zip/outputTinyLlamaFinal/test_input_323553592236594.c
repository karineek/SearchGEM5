
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    int i, n, count = 0;
    
    // read input from arguments
    if (argc > 1) {
        for (i = 1; i < argc; ++i) {
            if (!strcmp(argv[i], "-n")) {
                n = atoi(argv[++i]);
            } else if (!strcmp(argv[i], "-a")) {
                printf("Automatic Vectorization Optimizations are on\n");
                while (--n > 0) {
                    if (count % 10 == 0 || count < 2) {
                        printf("%d ", n * 10);
                        count++;
                    }
                }
            } else if (!strcmp(argv[i], "-e")) {
                printf("Mid-End and shall\n");
            } else {
                printf("Unknown option\n");
            }
        }
        return 0;
    } else {
        printf("Usage: BASH [-n | -a | -e] [--]\n"
               "       [-n] [-a] [-e] [number of iterations (default 10)]\n");
        return 1;
    }
}