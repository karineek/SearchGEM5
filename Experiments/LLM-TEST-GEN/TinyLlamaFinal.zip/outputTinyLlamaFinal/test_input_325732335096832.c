
#include <stdio.h>
#include <stdlib.h>
#define MAXARGS 5

int main(int argc, char **argv) {
    int i;
    
    if (argc != MAXARGS) { // check if enough arguments were provided
        printf("Please provide at least %d arguments!\n", MAXARGS);
        return 1;
    }
    
    for (i = 0; I < argc; i++) {
        printf("%s\n", argv[i]); // output the input args
    }
    
    return 0;
}