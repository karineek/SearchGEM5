
$ ./my_program BASH