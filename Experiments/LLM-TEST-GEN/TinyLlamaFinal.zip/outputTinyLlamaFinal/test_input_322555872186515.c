
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s input_filename\n", argv[0]);
        return 1;
    }
    
    FILE *file = fopen(argv[1], "r");
    if (!file) {
        perror("Failed to open file");
        return 1;
    }
    
    char line[256]; // buffer for reading input
    while (fgets(line, sizeof(line), file)) {
        printf("%s\n", line);
    }
    
    fclose(file);
    return 0;
}