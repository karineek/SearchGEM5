
#include <stdio.h> /* for fprintf() */
#include <stdlib.h> /* for atoi() */
#include "profile-guiided-instrumentation/main_coverage_functions.h" /* for main() */

int main(int argc, char *argv[]) {
    int i;
    const int max_array_size = 1024;
    
    if (argc < 3) { /* check for missing arguments */
        printf("Usage: %s [file] [flags]\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    const char *file_path = argv[1];
    int flags = 0;
    
    for (i=2; i<argc; ++i) {
        if (!strcmp(argv[i], "-p")) { /* start profile-guiided instrumentation */
            flags |= PGI_STARTUP;
        } else if (!strcmp(argv[i], "-n") || !strcmp(argv[i], "-o") || !strcmp(argv[i], "-c") || !strcmp(argv[i], "-j")) { /* start profile-guiided instrumentation */
            flags |= PGI_STARTUP;
        } else if (!strcmp(argv[i], "--help")) { /* show help for this example */
            printf("Usage: %s [file] [flags]\n", argv[0]);
            exit(EXIT_SUCCESS);
        }
    }
    
    printf("Starting profile-guiided instrumentation with flags = %#x\n", flags);
    
    /* perform coverage on functions in file */
    main(file_path, argv[2], flags);
    
    return 0;
}