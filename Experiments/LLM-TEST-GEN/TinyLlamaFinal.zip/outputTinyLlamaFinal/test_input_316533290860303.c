
#include <stdio.h> // for printf()
#include <stdlib.h> // for malloc(), free()
#include "llvm/IR/IRBuilder.h" // for llvm::BasicBlock, llvm::Function

// Function that takes a string as argument and prints it using putwchar() function
void print_string(const char *str) {
    printf("Printing '%s'...\n", str);
    while (*str != '\0') {
        putwchar(*str++);
    }
    puts("Done!");
}

int main(int argc, char *argv[]) {
    // Read input from command line arguments and call the print_string() function with it
    if (argc == 2) {
        const char *input = argv[1];
        print_string(input);
    } else {
        printf("Usage: %s <input>\n", argv[0]);
        return 1; // Exit with error code 1 (non-zero) on non-empty argument or invalid input
    }
    
    return 0;
}