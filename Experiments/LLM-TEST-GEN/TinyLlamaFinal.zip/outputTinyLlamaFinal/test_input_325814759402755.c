
#include <stdio.h>
#include <stdlib.h>
#include "scala/scala.h"

int main(int argc, char *argv[]) {
    char buffer[1024] = "";
    if (argc > 1) {
        printf("Enter input file name: ");
        fgets(buffer, sizeof(buffer), stdin);
        if (!strcmp(buffer, "-")) {
            FILE *input_file;
            input_file = fopen("/dev/stdin", "r");
            if (input_file == NULL) {
                perror("Error: failed to open standard input stream for reading");
                exit(1);
            }
        } else {
            input_file = fopen(argv[1], "r");
            if (input_file == NULL) {
                perror("Error: failed to open input file for reading");
                exit(1);
            }
        }
    } else {
        printf("Enter input file name\n");
        fgets(buffer, sizeof(buffer), stdin);
    }
    
    // Call ScalaR optimizations and output optimized code to the standard output stream
    double start_time = time(NULL);
    double stop_time;
    printf("Enter input file name: ");
    fgets(buffer, sizeof(buffer), stdin);
    int script_file = open(argv[1], O_RDONLY);
    if (script_file < 0) {
        perror("Error: failed to open input script file for reading");
        exit(1);
    }
    
    // Call ScalaR optimizations and output optimized code to the standard output stream
    double end_time = time(NULL);
    stop_time = (double)end_time - (double)start_time;
    printf("Optimized script file size: %.2f bytes\n", end_time * 1024.0);
    
    int optimized_size = (int)(stop_time * 1024.0 / 3600.0); // Time in hours, minutes, and seconds
    printf("Optimized script file size: %.2f kb\n", stop_time * 1024.0 / 1024.0);
    
    // Write optimized code to output file
    if (write(script_file, buffer, strlen(buffer)) < 0) {
        perror("Error: failed to write optimized script code to output file");
        exit(1);
    } else {
        printf("Optimized script written to output file\n");
    }
    
    close(script_file);
    return 0;
}