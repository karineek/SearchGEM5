
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    FILE *file = fopen(argv[1], "r");
    if (!file) {
        printf("Error opening file: %s\n", strerror(errno));
        return EXIT_FAILURE;
    }
    
    char buffer[1024];
    int line = 1, lineCount = 0;
    
    while (fgets(buffer, sizeof(buffer), file)) {
        ++lineCount;
        if (!strncmp("--line-count", buffer, 15) && strcmp(buffer + 15, "--")) {
            printf("%s: %d\n", argv[0], lineCount);
        } else if (fscanf(file, "%c%*c%s", buffer, &line, buffer + 1) != 3) {
            fclose(file);
            printf("Error reading file: %s\n", strerror(errno));
            return EXIT_FAILURE;
        }
    }
    
    if (fclose(file)) {
        printf("Error closing file: %s\n", strerror(errno));
        return EXIT_FAILURE;
    }
    
    return 0;
}