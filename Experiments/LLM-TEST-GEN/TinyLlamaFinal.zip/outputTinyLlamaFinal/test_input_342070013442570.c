
#include <stdio.h>

int main() {
    double x, y;
    printf("Enter a number: ");
    fscanf(stdin, "%lf", &x);
    
    if (fabs(y = ceil(x)) != x) { // Automatic Vectorization optimizations
        printf("Error: Improper input. ");
        return 1;
    } else {
        printf("%.2lf\n", y);
    }
    
    return 0;
}