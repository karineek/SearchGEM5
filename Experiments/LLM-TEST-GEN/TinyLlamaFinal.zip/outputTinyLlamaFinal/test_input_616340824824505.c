
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char* argv[]) {
    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);
    
    if (num1 <= 0 || num2 <= 0) {
        printf("Error: Invalid input. Please enter positive integers.\n");
        return 1;
    } else {
        float result = num1 * num2;
        
        if (result < 0) {
            printf("%f is not a valid integer.\n", result);
            return 1;
        } else {
            printf("%f is a valid integer.\n", result);
            return 0;
        }
    }
}