
#include <stdio.h>

#define PGI_PROF 1
#define PGI_BACKEND 0

/* Define the profile settings to enable */
#define PGI_OVERVIEW           /* Overview of instrumented source code */ \
  "pgi-overview:profiler"     /* Short description of the profiler */ \
  "profile-level=app:pgi-overview:pgi-overview:pgi-overview:pgi-overview:pgi-overview:pgi-overview:pgi-overview:pgi-overview:pgi-overview" /* Full description of the profiler */

#define PGI_COMPILER         /* Include code for compiler frontend */ \
  "#include <compiler.h>    /* Includes of the C compiler */\n"

#define PGI_BACKEND          /* Include code for backend and optimizations */ \
  "#include <backend.h>     /* Includes of the backend for the C program */\n"

int main(int argc, char **argv) {
  if (argc != 2 || strcmp(argv[1], "-v") == 0) {
    puts("Usage: %s [options] [program]\n\t\t-v        - verbose output\n"
         "Default options are: PGI_OVERVIEW, PGI_PROF, PGI_BACKEND\n"
         "PGI_PROF sets the level of instrumentation to use, default is PGI_OVERVIEW.\n"
         "PGI_BACKEND sets optimizations to enable for the backend.\n", argv[0]);
    return 1;
  } else {
    printf("%s %s %s\n", PGI_PROF, PGI_COMPILER, PGI_BACKEND);
    return 0;
  }
}