
#include <stdio.h> /* stdio library */

int main() {
    int x = 5;
    
    printf("x: %d\n", x); // call of pre-declared variable x
    
    if (1) {
        x *= 2;
    } else {
        printf("%d is not defined for the type 'int'!\n", x); // if statement with no value
    }
    
    printf("x: %d\n", x); // post-declared variable x will be initialized to 10 (CSE optimization)
    
    return 0;
}