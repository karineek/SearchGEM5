
#include <stdio.h>
#include <stdlib.h>

int main() {
    int argc;
    char** argv;

    // get the number of arguments
    if ((argc = getargcount()) == -1) {
        fprintf(stderr, "Usage: %s [options]\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    // parse input arguments and insert them into an array of strings
    if ((argv = getargs(&argc, &argv)) == NULL) {
        fprintf(stderr, "Failed to get arguments.\n");
        return EXIT_FAILURE;
    }

    // execute the program with the specified arguments
    printf("%s\n", argv[0]);
    system(argv[0]);

    return EXIT_SUCCESS;
}

// getargcount() function
int getargcount() {
    int argc, i = 1;

    while (i < argc) {
        // skip spaces and white space characters
        if (isspace(*(argv[i] + 0))) {
            argv[i++];
        } else {
            break;
        }
    }

    // subtract one from the argument count since we skipped spaces and white space characters
    return i - 1;
}

// getargs() function
char** getargs(int* argc, char** argv) {
    int I = 0;
    char** ret = NULL;

    // initialize the output array
    if (!ret) {
        ret = calloc(MAX_ARGS, sizeof(char*));
        if (ret == NULL) {
            fprintf(stderr, "Failed to allocate memory.\n");
            return NULL;
        }
    }

    // find the length of the input arguments array and set argc
    while (*argv[i]) {
        I++;
    }
    *argc = i;

    // copy the arguments into the output array
    for (int j = 0; j < *argc; ++j) {
        ret[j] = strdup(*(argv + i));
    }

    return ret;
}