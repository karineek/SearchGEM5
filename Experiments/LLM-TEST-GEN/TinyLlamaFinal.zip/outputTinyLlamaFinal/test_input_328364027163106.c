
#include <stdio.h> /* printf, fprintf */
#include <stdlib.h> /* exit */
#include <string.h> /* strlen */
#include <ctype.h> /* isdigit */

const char* const shell = "/bin/bash";

void loop(char** argv) {
    int argc = 1;
    char** args = (char**)malloc(sizeof(char*) * (argc + 1));
    if (!args) { /* Out of memory */ exit(EXIT_FAILURE); }
    args[0] = argv[0];
    for (int I = 1; I < argc; i++) {
        args[i] = argv[i];
    }
    
    char* input = NULL;
    int bytes_read = -1;
    if ((bytes_read = read(0, &input, 1)) == -1) { /* Error reading file */ printf("Error: could not read file\n"); exit(EXIT_FAILURE); }
    if (bytes_read == 0) { /* EOF reached */ printf("Error: empty file\n"); exit(EXIT_FAILURE); }
    
    char* token;
    for (int I = 0; I < bytes_read; i++) {
        if (!isspace((unsigned char)input[i])) { /* Token found */
            token = strtok(&input[i], " ");
            printf("%s\n", token);
        }
    }
    
    free(args); /* Free arguments */
}

int main() {
    int argc;
    char** argv = (char**)malloc(sizeof(char*) * 1024);
    if (!argv) { /* Out of memory */ exit(EXIT_FAILURE); }
    argc = getargcount(argv, "psz");
    
    char* input = NULL;
    int bytes_read = -1;
    for (int I = 0; I < argc; i++) {
        if (!strlen(argv[i]) || strcmp(&argv[i][0], "-") == 0) { /* Non-argument */ continue; }
        
        char* arg = &argv[i][1];
        int length;
        if ((length = strtol(arg, NULL, 10)) < 0 || length > 1024) { /* Invalid argument */ exit(EXIT_FAILURE); }
        input = (char*)malloc((sizeof(char) * length + 1) * sizeof(char));
        
        memcpy(&input[0], arg, length);
        input[length] = '\0';
    }
    
    if (!input || strlen(input) == 0) { /* Empty input */ exit(EXIT_FAILURE); }
    
    loop(&argv);
    
    free(args); /* Free arguments */
    return EXIT_SUCCESS;
}