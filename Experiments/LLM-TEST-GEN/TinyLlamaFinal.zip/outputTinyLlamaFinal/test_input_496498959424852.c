
#include <stdio.h>

int main() {
    int argc;
    char **argv = NULL;
    
    /* Check if command line argument was provided */
    if (argc > 1) {
        argc--;
        argv = malloc(sizeof(*argv) * argc);
        for (int I = 0; I < argc; i++) {
            argv[i] = strdup(argv[i]); /* Copy the command line argument */
        }
    } else {
        printf("No command line arguments provided\n");
    }
    
    /* Print program name */
    printf("Coding Task: Input via Argument\n");
    
    return 0;
}