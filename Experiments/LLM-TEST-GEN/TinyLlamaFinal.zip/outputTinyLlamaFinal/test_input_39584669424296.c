
#include <stdio.h>
#include <stdlib.h>
#include "inlining_optimizations.h"

// This function is called by the main() function
int main(int argc, char* argv[]) {
    int input;
    
    // Read in an integer from command line argument (1-4)
    if (argc >= 2 && strlen(argv[1]) == 1) {
        sscanf(argv[1], "%d", &input);
        
        // Check for input of 0 or less, trigger inlining optimizations
        if (input <= 0) {
            printf("Error: Input must be >= 1\n");
            return EXIT_FAILURE;
        }
    } else if (argc == 2 && strcmp(argv[1], "EOF") == 0) { // EOF is treated as an input of 0
        printf("Exiting with 0\n");
        exit(EXIT_SUCCESS);
    } else { // If none of the above cases fit, print error and exit with code FAILURE
        printf("Error: Unrecognized input\n");
        return EXIT_FAILURE;
    }
    
    // Perform input processing (e.g. Inlining optimizations)
    if (input == 0) {
        puts("Inline and optimize code...");
    } else {
        printf("Read in integer %d\n", input);
    }
    
    return EXIT_SUCCESS; // Exit with success status
}