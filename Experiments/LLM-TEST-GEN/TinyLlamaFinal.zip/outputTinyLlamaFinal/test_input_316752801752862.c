
#include <stdio.h>
#include "compiler_info.h"

// Define a function that returns an input from the command line arguments
int getInput(char* argv[], char* inp) {
    int i = 0;
    for (i = 1; i < sizeof(argv)/sizeof(*argv); i++) {
        strcpy(inp, argv[i]);
        return i;
    }
    fprintf(stderr, "Input not found.\n");
    exit(1);
}

// Define a function to execute the code of the program
int main(void) {
    char* inp = NULL;
    int ret = getInput(&argv[0], &inp);
    if (ret == 0) {
        printf("%s\n", inp);
    } else {
        fprintf(stderr, "Input not found.\n");
    }
    return 0;
}