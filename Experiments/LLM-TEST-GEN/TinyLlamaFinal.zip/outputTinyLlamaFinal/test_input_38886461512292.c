
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main(int argc, char **argv) {
    // check if the number of arguments is greater than 1 or less than 2
    if (argc > 1 && argc < 3) {
        printf("Error: Invalid number of arguments\n");
        return EXIT_FAILURE;
    } else {
        // extract the program name from the first positional argument
        char program[MAX_SIZE] = argv[0];
        int pos = 1;
        for (; pos < argc && pos <= MAX_POSITIONAL_ARGUMENTS; ++pos) {
            if (!isalpha(argv[pos][0]) || strcmp(program + pos, "--") == 0) {
                printf("Error: Invalid number of arguments\n");
                return EXIT_FAILURE;
            }
        }
    }
    
    // check if the program name is empty or contains only spaces
    if (strlen(program) == 1 && program[0] != ' ') {
        printf("Error: Invalid program name\n");
        return EXIT_FAILURE;
    }
    
    // validate the positional arguments
    for (int I = 1; I < argc - 1; ++i) {
        char arg[MAX_SIZE] = argv[i];
        int pos = strlen(arg) + 1;
        
        // extract the input name from the last positional argument
        for (int j = 0; j < MAX_POSITIONAL_ARGUMENTS - I; ++j) {
            if (!isalpha(argv[i][j]) || strcmp(program + pos, "--") == 0) {
                printf("Error: Invalid input name\n");
                return EXIT_FAILURE;
            }
        }
        
        // validate the argument value
        char *argPtr = argv[i];
        for (int k = 1; k < MAX_SIZE; ++k) {
            if (!isalpha(*argPtr) || strcmp(program + pos, "--") == 0) {
                printf("Error: Invalid input name\n");
                return EXIT_FAILURE;
            }
        }
        
        // set the argument value to the program
        for (int k = 1; k < MAX_POSITIONAL_ARGUMENTS - I; ++k) {
            if (!isalpha(argv[i][j]) || strcmp(program + pos, "--") == 0) {
                printf("Error: Invalid input name\n");
                return EXIT_FAILURE;
            }
        }
    }
    
    // set the program exit code to 1 if any input validation errors are detected
    return EXIT_SUCCESS;
}