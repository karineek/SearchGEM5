
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    const char *argv[1] = {"/dev/stdin"}; // Input is taken via argv only
    
    char line[1024];  // buffer to hold input
    FILE *file = fopen(argv[0], "r"); // open the file for reading
    while (fgets(line, sizeof(line), file) != NULL) { // read the input until EOF or newline character
        printf("%s\n", line); // output the input line
    }
    
    return 0;
}