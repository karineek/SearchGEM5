
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int main(int argc, char *argv[]) {
    FILE *fp;
    int line = 0, cnt = 0;
    
    if (argc <= 1) { // check for no input file
        printf("Error: No file specified.\n");
        return 1;
    } else {
        fp = fopen(argv[1], "r");
        if (!fp) { // check for error opening file
            perror("Error: Could not open file.\n");
            return 2;
        }
        
        while ((line < 10) && (cnt < 10)) {
            char linebuf[32];
            
            if (fgets(linebuf, sizeof(linebuf), fp) == NULL) { // check for error reading file
                perror("Error: Could not read file.\n");
                return 3;
            } else {
                cnt++;
                line = atoi(linebuf);
                if (line <= 0) { // check for negative line number
                    printf("Error: Invalid line number.\n");
                    return 4;
                }
            }
        }
        
        fclose(fp);
        
        printf("Line numbers:\n");
        for (int I = 1; I <= 10; i++) {
            printf("%d ", i);
        }
        printf("\n");
    }
    
    return 0;
}