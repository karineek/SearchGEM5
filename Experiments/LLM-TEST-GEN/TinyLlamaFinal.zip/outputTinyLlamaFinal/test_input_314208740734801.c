
#include <stdio.h>

int main(void) {
    int argc;
    char **argv = NULL;
    
    while (1) {
        if (argc == 0 || (argc > 1 && !getopt(argc, argv, "a:b:d:")) != 3) {
            break;
        }
        
        printf("arg %s is %d\n", optarg, atoi(argv[2]));
    }
    
    return 0;
}