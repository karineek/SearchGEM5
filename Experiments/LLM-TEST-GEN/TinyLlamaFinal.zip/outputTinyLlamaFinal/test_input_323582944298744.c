
#include <stdio.h> /* For printf() */
#include <stdlib.h> /* For atoi() */

int main(int argc, char **argv) {
  int n = atoi(argv[1]); /* Read input from CLI args */
  int sum = 0; /* Initialize sum variable */
  
  for (int I = 0; I < n; i++) {
    sum += i * i; /* Calculate product of all elements */
  }
  
  printf("The sum is: %d\n", sum);
  
  return 0;
}