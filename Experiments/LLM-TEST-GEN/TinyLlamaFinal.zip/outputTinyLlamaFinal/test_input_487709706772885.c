
#include <stdio.h>
#include <stdlib.h>
#include "bash_opt.h"

int main() {
    int argc = 1; /* dummy argument */
    char *argv[1] = {"hello"}; /* dummy program name and arguments */
    bash_opt_t opt = BASH_OPT_INIT(argc, argv);
    
    /* do some stuff */
    
    return EXIT_SUCCESS;
}