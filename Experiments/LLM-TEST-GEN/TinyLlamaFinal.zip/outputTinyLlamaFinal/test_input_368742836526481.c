
#include <stdio.h>
#include <stdlib.h>
#define MAXLINE 1024

int getline(char **s, int *n);
void usage(void);
int main(int argc, char **argv) {
    if (argc != 2 || strcmp(argv[1], "-h") == 0) {
        puts("Usage: " ARGV[0] " [-h] FILE_NAME");
        return 1;
    }
    int n = 0, line_len = MAXLINE, line_buf[MAXLINE]; // initilizing variables for getline() function
    FILE *fptr;
    if ((fptr = fopen(argv[1], "r")) == NULL) {
        puts("Error: Unable to open file \"" ARGV[1] "\".\n");
        return 1;
    }
    for ( ; n < line_len && !feof(fptr); ++n) {
        if ((line_buf[n] = getc(fptr)) == EOF) { // getting newline characters
            fputs("\n", stderr);
        } else {
            printf("Line %d: \"%.*s\"\n", n, line_len - n + 1, line_buf + n); // outputing the line to console
        }
    }
    fclose(fptr);
    return 0;
}