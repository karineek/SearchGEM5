
#include <stdio.h>
#include <stdlib.h> // for exit()

int main(int argc, char* argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s FILE_NAME\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    int width = atoi(argv[1]);
    int height = width * 3 / 2 + 1; // Add an extra row for the background color
    
    float data[width * height];
    for (int I = 0; I < width * height; i++) {
        data[i] = fscanf(stdin, " %.2f ", &data[i]) == 1 ? fscanf(stdin, " %d", &data[i]) : -1; // Read float values from stdin
    }
    
    int index = 0;
    for (int I = 0; I < width * height; i++) {
        if (index != width * height) {
            data[i] += index / width + 1; // Add the current row number to each pixel value (excluding the background color)
        } else {
            int r, g, b;
            if (data[i] < 0) {
                fprintf(stderr, "Error: negative values detected in file %s\n", argv[1]);
                return EXIT_FAILURE;
            }
            data[i] += 1.4826f * data[i - width * height]; // Add a white color (0.6931) to the background color if necessary
            
            for (int j = 0; j < height; j++) {
                r = data[index + j * width] / width;
                g = data[index + (j * width) + width] / width;
                b = data[(index + (height - j) * width) + width] / width;
                index += width;
                
                if (r < 0.21) {
                    printf("White: %f %f %f\n", r, g, b);
                } else if (r < 0.71 && j >= height / 2) {
                    printf("Background: %f %f %f\n", r, g, b);
                } else {
                    printf("%c", data[index]);
                }
            }
        }
        
        index += width;
    }
    
    return EXIT_SUCCESS;
}