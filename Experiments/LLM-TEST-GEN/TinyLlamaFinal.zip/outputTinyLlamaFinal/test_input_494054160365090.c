
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int i;
    float num = 0.0f;
    
    // Check if file exists
    if (argc <= 1) {
        printf("Error: No input file specified.\n");
        return EXIT_FAILURE;
    }
    
    // Open input file
    FILE *input = fopen(argv[1], "r");
    
    // Check if file is opened successfully
    if (!input) {
        printf("Error: Unable to open input file.\n");
        return EXIT_FAILURE;
    }
    
    // Read each line of the input file and store it in the buffer
    char line[50];
    for (i = 0; fgets(line, sizeof(line), input) != NULL; i++) {
        num += strtof(line, nullptr);
    }
    
    // Close input file
    fclose(input);
    
    // Return program's output and exit with success status
    printf("Program completed successfully with an average of %.2f.\n", num / argc);
    return EXIT_SUCCESS;
}