
#include <stdio.h>
#include <string.h>

struct currency_symbol {
    const char symbol[3]; // symbol and symbol_size must be declared externally so they can be included
};

static struct currency_symbol symbols[] = {
        {"$", "USD"}, {"€", "EUR"}, {"£", "GBP"}
};

int get_currency(char* c) {
    const char* symbol_str = strchr(c, '$');
    if (symbol_str != NULL) { // check for valid input
        size_t symbol_size = 0;
        while (*symbol_str++ != ' ') symbol_size++;
        return symbol_str - symbols[0].symbol - symbol_size; // get the currency symbol and its length
    } else {
        return -1; // no valid input, error message should be printed
    }
}

int main(void) {
    struct currency_symbol* currencies = NULL; // allocate memory for currency symbols
    int i, j, k;
    char c[256]; // buffer to read input from console
    
    printf("Enter a string with currency symbol\n");
    while (getchar() != '\n') { // read until end of line or newline
        if (!gets(c)) { // get input failed, error message should be printed
            perror("error: getline() failed");
            return 1;
        }
        
        // convert string to lowercase
        for (i = 0; i < strlen(c); i++) {
            c[i] = tolower(c[i]);
        }
        
        // remove leading whitespace and split by comma, if present
        k = 0;
        while (*c && isspace(*c)) {
            *c = '\0';
            ++k;
        }
        if (k) {
            strncpy(c+1, c, k); // copy leading whitespace and the comma
            currencies = realloc(currencies, sizeof(struct currency_symbol*) * (j += 2));
            currencies[j].symbol = realloc(currencies[j].symbol, currencies[j].symbol_size + strlen(c) + 1); // allocate memory for new symbol and add trailing newline
            
            if (!currencies[j].symbol) {
                perror("error: realloc() failed");
                return 1;
            }
            
            currencies[j].symbol_size = strlen(c) + 1; // calculate symbol size and add leading newline
            currencies[j+1].symbol = strdup(currencies[j].symbol); // duplicate symbol for new currency symbol
        } else {
            perror("error: not enough space in currency symbols array");
            return 1;
        }
        
        // get next input line, if any
        while ((c[0] == ' ') || (c[0] == '\n')) {
            fscanf(stdin, "%s", c); // read another input line
        }
    }
    
    free(currencies); // free memory for currency symbols array
    return 0;
}