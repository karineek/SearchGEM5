
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>

#define MAX_LINE_LEN 1024

int main(int argc, char *argv[]) {
    FILE *fp;
    int num_lines = 0;
    
    if (argc != 2) {
        printf("Usage: %s [input file]", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    fp = fopen(argv[1], "r");
    
    if (!fp) {
        perror("Failed to open input file");
        return EXIT_FAILURE;
    }
    
    for (;;) {
        char line[MAX_LINE_LEN];
        
        if (fgets(line, MAX_LINE_LEN, fp) == NULL) {
            break;
        } else if (strlen(line) < MAX_LINE_LEN) {
            num_lines++;
        } else {
            printf("Invalid input file: %s\n", argv[1]);
            exit(EXIT_FAILURE);
        }
    }
    
    fclose(fp);
    
    return 0;
}