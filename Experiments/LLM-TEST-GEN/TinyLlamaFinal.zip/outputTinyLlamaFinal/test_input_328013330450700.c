
#include <stdio.h>
#include <stdlib.h>
#define MAX_CHAR_LEN 20

int main(int argc, char* argv[]) {
    if (argc != 1) {
        printf("Usage: %s [input file]\n", argv[0]);
        return EXIT_FAILURE;
    }
    FILE* input = fopen(argv[1], "r");
    if (!input) {
        perror("Error opening input file\n");
        exit(EXIT_FAILURE);
    }
    
    printf("Input: ");
    char buffer[MAX_CHAR_LEN];
    int length = fread(buffer, 1, MAX_CHAR_LEN, input);
    if (length != MAX_CHAR_LEN) {
        perror("Error reading input file\n");
        exit(EXIT_FAILURE);
    }
    
    fclose(input);
    
    return 0;
}