
#include <stdio.h>
#include <stdlib.h>

enum { MAX_ARG = 10 };

int main(int argc, char* argv[]) {
    int i;
    for (i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "-h")) {
            printf("Usage: %s [options] filename\n", argv[0]);
            return 0;
        }
        else if (!strcmp(argv[i], "--help") || !strcmp(argv[i], "-h")) {
            printf("%s (C program)\n\nUsage: %s [options] filename\n", argv[0], argv[0]);
            return 0;
        }
    }

    // Parsing the command line arguments and exiting if invalid
    for (i = 1; i < argc; i++) {
        char* arg = argv[i];

        // Check if filename argument is present
        if (!strcmp(arg, "-")) {
            printf("%s: Error: Missing filename\n", argv[0]);
            return 1;
        }
        
        // Parse the filename and check for validity
        char* filename = strchr(arg + 1, '/');
        if (filename == NULL) {
            printf("%s: Error: Invalid filename\n", argv[0]);
            return 1;
        }
        
        // Check for validity of file extension
        if (!strcmp(filename + 1, ".BASH")) {
            // Open the BASH file for reading and parsing
            FILE* f = fopen(filename + 2, "r");
            if (f == NULL) {
                printf("%s: Error: Cannot open BASH file\n", argv[0]);
                return 1;
            }
            
            // Read the BASH file and exit when finished
            while (!feof(f)) {
                char line[MAX_LINE];
                if (fgets(line, sizeof(line), f) == NULL) {
                    printf("%s: Error: Cannot read BASH file\n", argv[0]);
                    fclose(f);
                    return 1;
                }
                else {
                    // Remove spaces and commas from line
                    int len = strlen(line);
                    for (int I = 0; I < len / 2; i++) {
                        if (line[i] == ' ' || line[i] == '\t') {
                            line[i] = '\0';
                        }
                    }
                }

                // Call the parse function to handle the BASH file
                int result = parse(line);
                if (result != 0) {
                    printf("%s: Error: Unexpected character %c in BASH\n", argv[0], line[0]);
                    fclose(f);
                    return 1;
                }
            }
        }
        else {
            // Non-BASH file, exit with error message and call parse function
            printf("%s: Error: Invalid filename\n", argv[0]);
            return 1;
        }
        
        // Close the BASH file and proceed to next argument
        fclose(f);
    }
    
    // Check for required input arguments and exit with error message if none found
    printf("%s: Error: Missing required input arguments\n", argv[0]);
    return 1;
}