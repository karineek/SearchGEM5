
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> /* for getopt */

#define DEFAULT_GLOBAL_ARRAY_SIZE 1024 * 1024 /* 1 MiB */

int main(int argc, char **argv) {
    int n;
    double x[DEFAULT_GLOBAL_ARRAY_SIZE];
    double y[DEFAULT_GLOBAL_ARRAY_SIZE];
    double result = 0.0;
    float alpha = 1.0f;
    char opt;
    
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <input> [-o <output>] [-d]\n", argv[0]);
        return 1;
    }

    opt = getopt(argc, argv, "o:d"); /* Get options and arguments */
    
    if (opt == -1) {
        fprintf(stderr, "Error: Invalid option\n");
        return 1;
    } else if (opt == 'd') {
        alpha = 0.5f;
    }
    
    for (n = 0; n < DEFAULT_GLOBAL_ARRAY_SIZE; ++n) {
        x[n] = powf(alpha, n);
    }
    
    if (argc == 3 && optarg != NULL) {
        FILE *fp;
        char buf[1024]; /* buffer for input file */
        
        fp = popen(optarg, "r");
        if (!fp) {
            fprintf(stderr, "Error: Could not open %s\n", optarg);
            return 1;
        }
    
        while (fgets(buf, sizeof(buf), fp)) {
            result += x[atoi(buf)];
        }
        
        if (!ferror(fp)) {
            fclose(fp);
        }
    } else {
        for (n = 0; n < DEFAULT_GLOBAL_ARRAY_SIZE; ++n) {
            y[n] = x[n];
        }
    }
    
    printf("Original input:\n");
    for (n = 0; n < DEFAULT_GLOBAL_ARRAY_SIZE; ++n) {
        printf("%f ", x[n]);
    }
    puts("\n");
    
    printf("Vectorized result (%g):\n", result);
    for (n = 0; n < DEFAULT_GLOBAL_ARRAY_SIZE; ++n) {
        printf("%f ", y[n]);
    }
    puts("\n");

    return 0;
}