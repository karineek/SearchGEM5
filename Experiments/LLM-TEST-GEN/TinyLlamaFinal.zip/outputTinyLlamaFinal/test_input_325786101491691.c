
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// function to check whether a given string is empty or not
int is_empty(const char *str) {
    for (; (*str == '\0'); str++) {}
    return 1; // if the string is empty, we return 1
}

// main() function that takes two arguments: filename and mode (either "r" or "w")
int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s [<filename>] [<mode>]\n", argv[0]);
        return 1;
    }
    const char *filename = argv[1]; // filename of the input file
    const char *mode = (argc > 2) ? argv[2] : "r"; // mode of operation (r for read, w for write)
    
    // open file for reading or writing depending on argument
    FILE *fptr = fopen(filename, mode);
    if (!fptr) {
        perror("Error: unable to open file");
        return 1;
    }
    
    // check whether input is empty
    int is_empty_flag = is_empty(argv[2]);
    if (is_empty_flag != 1) {
        fprintf(stderr, "Input string cannot be empty.\n");
        return 1;
    }
    
    // read contents of file into a buffer
    char buffer[1024];
    int read_size = fread(buffer, sizeof(char), 1024, fptr);
    if (read_size < 1 || read_size > 1023) { // sanity check - ensure we can read at most 1023 characters into the buffer
        perror("Error: failed to read file contents");
        return 1;
    }
    
    // handle any exceptions during program execution by returning an error code
    int exit_code = 0;
    if (is_empty(argv[2]) != 1) { // handle non-empty strings in case of error
        fprintf(stderr, "Error: file contents are empty\n");
        exit_code = 1;
    }
    
    printf("File contents: %s\n", buffer);
    
    return exit_code;
}