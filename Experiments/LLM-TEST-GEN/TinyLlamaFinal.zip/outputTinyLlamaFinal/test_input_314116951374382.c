
#include <stdio.h>
#include <stdlib.h>
#include "opt_defs.h"
#include "symtab.h"
#include "util.h"
#include "llvm_utils.h"

/*
 * ScalaR Optimizations with BASH
 *
 * This program implements ScalaR optimizations in LLVM IR
 * The function 'opt' performs the optimization, and 'symtab' is used to maintain symbol table
 * It also defines two helper functions:
 *     - get_function_name(): returns name of specified function as a C string
 *     - get_entry_point(): returns address of entry point as a C string
 *
 * The program is divided into several modules, each module handles a specific aspect
 *   (e.g. Scalarization, PHI elimination, etc.). Each module contains the required function 'opt'
 *
 */

int main(int argc, char **argv) {
    LLVMContext *context = llvm_create_llvm_context();
    LLVMTargetTriple triple;
    char target[32];
    LLVMAddTargetData *data = nullptr;
    LLVMTarget *target_ptr;
    LLVMCodeGenFileType *CFGFileType = llvm_create_cfg_file_type(context, "Bash", "C");
    
    // Get function name and entry point
    if (argc < 2) {
        fprintf(stderr, "Usage: %s [options] file.ll\n", argv[0]);
        exit(1);
    } else {
        // Read in LLVM IR module
        printf("Reading LLVM IR file... ");
        char *filename = argv[1];
        printf("%s", filename);
        fflush(stdout);
        FILE *file = fopen(filename, "r");
        if (!file) {
            perror("Failed to open LLVM IR file for reading\n");
            exit(1);
        }
        
        // Allocate space for symbol table and functions
        symtab_initialize(&context->symtab);
        symtab_add_function_symbols(&context->symtab, LLVMTargetData(context), CFGFileType, "main", target);
        
        // Parse LLVM IR module
        printf("Parsing LLVM IR... ");
        char *filename = argv[1];
        printf("%s", filename);
        fflush(stdout);
        LLVMParsingResult result;
        if (!llvm_parse_module(result, context, filename, 0)) {
            fprintf(stderr, "LLVM parsing failed\n");
            exit(1);
        }
        
        // Print symbol table
        printf("Symbol Table:\n");
        symtab_print(&context->symtab);
        
        // Optimize LLVM IR module and output optimized module
        printf("Optimizing LLVM IR... ");
        char *filename = argv[1];
        printf("%s", filename);
        fflush(stdout);
        if (!opt(context, context->symtab.functions, filename)) {
            fprintf(stderr, "LLVM Optimization failed\n");
            exit(1);
        }
        
        // Print optimized LLVM IR module
        printf("Optimized LLVM IR:\n");
        symtab_print(&context->symtab);
    }
    
    // Clean up
    free(target_ptr);
    LLVMAddTargetDataRelease(data);
    LLVMDisposeContext(context);
    exit(0);
}