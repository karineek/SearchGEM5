
#include <stdio.h>
#include <stdlib.h>

#define TRUE 1
#define FALSE 0

int main() {
    char argv[2] = {"myfile.txt"};
    
    int lineNum = 0;
    FILE *fp = fopen(argv[1], "r");
    while (!feof(fp)) {
        if (fscanf(fp, "%d", &lineNum) == 1) {
            printf("%s:%d: %d\n", argv[0], lineNum, fgets(buffer, BAHSH_BUFSIZE, fp));
        } else {
            puts("error: unexpected EOF");
            return 1;
        }
    }
    
    fclose(fp);
    return 0;
}