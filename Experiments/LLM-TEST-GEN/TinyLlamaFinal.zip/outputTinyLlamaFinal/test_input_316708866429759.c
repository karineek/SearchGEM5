
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> // Needed to get process id (PID) and command line arguments using fork()/execvp().

int main(int argc, char* argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <command line arguments>\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    pid_t pid = fork(); // Create a new process.
    if (pid == 0) { // If the first child, execute command line args.
        execvp(argv[1], argv + 1); // Execute given command line arguments using execvp() function from system libc.
        exit(EXIT_FAILURE);
    } else if (pid > 0) { // If the parent, wait for child process.
        waitpid(pid, NULL, 0); // Wait for child process.
    } else {
        printf("Error: Cannot fork or execvp.\n");
        exit(EXIT_FAILURE);
    }
    
    return 0;
}