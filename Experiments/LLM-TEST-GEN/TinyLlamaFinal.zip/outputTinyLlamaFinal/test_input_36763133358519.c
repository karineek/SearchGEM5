
#include <stdio.h> /* printf function */

int main() {
    int argc;
    char *argv[10]; /* max number of args is 9, but we'll use 10 for better performance */
    
    argv[0] = "hello world";
    argc = 1;
    
    while (argc < 10) {
        argv[argc++] = argv[0]; /* add the filename to the argument vector */
        printf("Please enter a filename, max. 9 arguments: ");
        scanf("%s", argv[argc-1]);
    }
    
    int n = atoi(argv[argc - 1]) + 1; /* add 1 for the argument "filename" */
    
    printf("The filename is: %s\n", argv[0]);
    printf("Please enter an integer argument (0-9): ");
    scanf("%d", &n);
    
    printf("File name: %s\n", argv[0]); /* display the result */
    
    return 0;
}