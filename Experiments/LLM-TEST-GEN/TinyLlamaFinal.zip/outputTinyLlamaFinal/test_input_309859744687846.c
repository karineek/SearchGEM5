
#include <stdio.h> /* for printf() */
#include "interproc.h" // handles machine code generation and variable-length arrays

int main(int argc, char* argv[]) {
    int input[argc]; // create an array of input integers
    
    if (argc < 1) { // check if the program has enough arguments
        printf("Error: No input provided\n");
        return 1; // exit the program
    } else { // parse and process the input integers
        for (int I = 0; I < argc; i++) { // loop over all inputs
            int input_value; // initialize the input value to zero
            char* input_string = argv[i] + strlen(argv[i]) + 1; // add 1 to make it a string and then split into separate words
            
            for (int I = 0; I < 32 && !isspace(*input_string); i++) { // loop over all whitespace characters, up until we find the first non-whitespace character (including newline)
                input_value += *(input_string + i) - ' '; // add each character's ASCII code value to the input value
            }
            
            input[i] = input_value; // set the input value to the corresponding integer
        }
        
        printf("%d\n", input[0]); // print the first input value
    }
    
    return 0; // exit with success
}