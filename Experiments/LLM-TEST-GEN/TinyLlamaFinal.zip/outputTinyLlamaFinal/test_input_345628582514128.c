
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> /* for getopt_long */

int main(int argc, char *argv[]) {
    int opt;
    float pgu[10][5] = {
        {-5.832e-4f},   // 1
        {5.761e-4f},   // 2
        {-9.517e-5f},  // 3
        {8.446e-4f},   // 4
        {10.439e-5f}    // 5
    };

    float qgu[10][5] = {{4.972e+1f}, {-1.766e+0f}, {1.583e-1f}, {-1.863e-1f}, {6.742e+0f}};
    float rgu[10][5] = {{9.988e-3f}, {8.853e-3f}, {1.212e-2f}, {-1.516e-2f}, {7.342e+0f}};
    float fgu[10][5] = {{9.612e-5f}, {-8.553e-5f}, {3.119e-5f}, {-8.652e-5f}, {7.143e+0f}};
    
    char optchar;
    int argidx = 1;
    while((optchar = getopt_long(argc,argv,"hg:pguqr:t:a:i:")) != -1){
        switch(optchar) {
            case 'h': //help menu
                printf("Usage: %s [-hg:pguqr:t:a:i] [-v] [inputfile]\n", argv[0]);
                printf("\n");
                printf("Options:\n");
                printf("-h, --help              Display this help menu.\n");
                printf("-g, --profile            Perform Profile-Guiided Optimization (PGO).\n");
                printf("-p, --parameter          Input parameter file (-p file.txt).\n");
                printf("-gu, --generic           Generic input file (-g input.txt).\n");
                printf("-qr, --quiet             Suppress output.\n");
                printf("-t, --target             Target function (-t function name).\n");
                printf("-a, --assistant          Assistant mode (default: User Mode).\n");
                printf("-i, --input              Input file (-i filename).\n");
                break;
            case 'p': //parameter file input
                optind = 1;
                while((opt = getopt_long(argc,argv,"hg:pguqr:t:a:i:")) != -1) {
                    switch (opt) {
                        case 'h': //help menu
                            printf("Usage: %s [-hg:pguqr:t:a:i] [-v] [inputfile]\n", argv[0]);
                            printf("\n");
                            printf("Options:\n");
                            printf("-h, --help              Display this help menu.\n");
                            printf("-g, --profile            Perform Profile-Guiided Optimization (PGO).\n");
                            printf("-p, --parameter          Input parameter file (-p file.txt).\n");
                            printf("-gu, --generic           Generic input file (-g input.txt).\n");
                            printf("-qr, --quiet             Suppress output.\n");
                            printf("-t, --target             Target function (-t function name).\n");
                            printf("-a, --assistant          Assistant mode (default: User Mode).\n");
                            printf("-i, --input              Input file (-i filename).\n");
                            break;
                        case 'p': //parameter file input
                            pgu[argidx-1] = strtod(optarg, nullptr); // convert input to float
                            argidx++;
                            if(strlen(optarg) == 0){
                                printf("Error: input parameter file is empty.\n");
                                return -1;
                            }
                            break;
                        case 'gu': //generic input file input
                            rgu[argidx-1] = strtod(optarg, nullptr); // convert input to float
                            argidx++;
                            if(strlen(optarg) == 0){
                                printf("Error: generic input file is empty.\n");
                                return -1;
                            }
                            break;
                        case 'qr': //quiet mode
                            optind--;
                            break;
                        case 't': //target function name input
                            qgu[argidx-1] = strtod(optarg, nullptr); // convert input to float
                            argidx++;
                            if(strlen(optarg) == 0){
                                printf("Error: target function is empty.\n");
                                return -1;
                            }
                            break;
                        case 'a': //assistant mode
                            optind--;
                            break;
                    }
                }
                break;
            default:
                printf("Error: unknown option '-%c'.\n", optopt);
                return -1;
        }
    }
    
    if(argidx != argc){ //check if input file is empty
        printf("Error: input parameter file or generic input file is not specified.\n");
        return -1;
    }
    
    int num_input = (argc < 2 || strlen(argv[argc-1]) == 0) ? 1 : argc - 1; // number of input files
    
    float *pgu, *qgu, *rgu;
    
    if(num_input == 1){ //single input file
        pgu = rgu = nullptr;
        for(int i = 0; i < num_input; i++){
            pgu[i] = qgu[i] = rgu[i] = get_param_value(argv[i], optchar); //get parameter values from input file
        }
    }else{ //multiple input files
        pgu = qgu = rgu = nullptr;
        for(int i = 0; I < num_input; i++){
            pgu[i] = qgu[i] = rgu[i] = get_param_value(argv[i], optchar); //get parameter values from input file
            if(pgu[i] == -1){ //parameter file is empty, skip it
                continue;
            }else{
                char *path = strstr(argv[i], "/"); //find first '/' in input filename
                pgu[i] /= argv[i][0]; //convert parameter value to float
                if(!path){ //input file is not valid, skip it
                    continue;
                }else{
                    char *name = strstr(path+1, ".txt"); //find filename extension in input filename
                    name && name[0] == '.'; //filename ends with .txt extension
                    pgu[i] /= atof(name); //convert parameter value to float
                }
            }
        }
    }
    
    if(pgu[0] == -1){ //if no parameters, return 0
        printf("Error: parameter file is empty.\n");
        return 0;
    }else{ //if parameters are specified
        //perform profile-guiided optimization (PGO) and calculate coverage of function with given input file(s)
        float *c = new float[num_input]; //allocate memory for coverage matrix
        if(pgu){
            c[0] = qgu[0] / pgu[0]; //coverage for target function, use as reference value for other functions
        }else{
            c[0] = 1; //assume all targets have 1 coverage
        }
        
        //call program to perform PGO
        if(calls_ppo && num_input == 1){
            //only one target function, use it directly
            for(int I = 0; i < num_input; i++){
                pgo(rgu[i], c[i], argv);
            }
        }else{
            for(int I = 0; i < num_input; i++){
                pgo(rgu[i], c[i], argv, false); //assistant mode (default)
            }
        }
        
        delete[] c; //delete memory allocated by c
    }
    
    return 0; //successful completion
}