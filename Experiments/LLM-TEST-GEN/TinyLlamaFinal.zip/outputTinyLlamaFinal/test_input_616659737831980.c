
#include <stdio.h>

int main() {
    printf("Input your first number:\n");
    int num, sum = 0;
    
    // Read input from argv[1]
    for (int i = 1; i <= (sizeof(argv) / sizeof(argv[0]) - 1); i++) {
        if (!scanf("%d", &num)) {
            printf("Error: Invalid input\n");
            return 1;
        }
        
        sum += num;
    }
    
    // Output result
    printf("Sum of first %d numbers: %d\n", sizeof(argv) / sizeof(argv[0]), sum);
    
    return 0;
}