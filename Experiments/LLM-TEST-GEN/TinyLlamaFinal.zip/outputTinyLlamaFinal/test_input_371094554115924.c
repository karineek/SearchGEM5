
#include <stdio.h>

int main() {
    int x, y;

    // Read input from command line arguments
    if(getchar() != '\n') {
        printf("Error: Invalid input\n");
        return 1;
    }

    // Promote memory to register for all inputs
    scanf("%d %d", &x, &y);

    // Perform calculation using x and y
    int sum = x + y;

    // Display the result
    printf("The sum of %.2f and %.2f is %.2f\n", x, y, sum);

    return 0;
}