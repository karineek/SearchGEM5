
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    FILE *file = fopen(argv[1], "r");
    char buffer[4096];
    int size = 0;
    
    if (file == NULL) {
        printf("Error: unable to open file\n");
        return EXIT_FAILURE;
    }
    
    while (fread(buffer, sizeof(char), sizeof(buffer), file) != 0) {
        size += fwrite(buffer, 1, sizeof(buffer), stdout);
    }
    
    fclose(file);
    
    printf("File: %s\nSize: %d bytes\n", argv[1], size);
    
    return EXIT_SUCCESS;
}