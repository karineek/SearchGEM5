
#include <stdio.h>
#define MAX_LINE 1024 /* Maximum line size */

int main(int argc, char *argv[]) {
    FILE *fp;
    int lineno = 0;
    char line[MAX_LINE];

    if (argc < 2) {
        fprintf(stderr, "Usage: %s BASH\n", argv[0]);
        return 1;
    }

    fp = popen(argv[1], "r");
    if (!fp) {
        fprintf(stderr, "%s: error: can't open file\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    while (fgets(line, MAX_LINE, fp)) {
        lineno++;
        /* Memory-to-Register Promotion optimizations here */
        // ...

        if (ferror(fp) || feof(fp)) {
            perror("Error while reading file");
            fclose(fp);
            return 1;
        }
    }
    
    fclose(fp); /* Close the input file handle */
    
    printf("%s: finished\n", argv[0]); /* Print a success message */

    return 0; /* Exit successfully */
}