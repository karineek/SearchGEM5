
/* This is a simple Bash Shell script. It uses the LICM (Loop-Invative Code Motion) tool to optimize its execution. */

#include <stdio.h>

int main(int argc, char *argv[]) {
    int i;
    
    /* Loop through all arguments and execute them in order. */
    for (i = 1; i < argc; i++) {
        printf("%s", argv[i]);
        puts(" ");
    }
    
    return 0;
}