
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    const char *input_type = "arg"; // Optional input type, can be set to 'arg' or 'bash'.
    int input_size;

    if (argc != 2 || !strcmp(argv[1], "bash")) {
        printf("Enter the input: \n");
        if (!gets(input)) {
            fprintf(stderr, "Failed to read input.\n");
            exit(EXIT_FAILURE);
        }
        // Split input into lines and count words.
        char **words = strtok(input, "\n\r");
        int n_words = 0;
        while (words != NULL) {
            if (*words == '#' || *words == '!') {
                puts("WARNING: Ignoring non-word character at line " PRIdPTR ". Skipping line.");
                continue;
            }
            words = strtok(NULL, "\n\r");
            n_words++;
        }
        if (n_words == 0) {
            fprintf(stderr, "Empty input.\n");
            exit(EXIT_FAILURE);
        } else if (n_words > 1 && strcmp(input+strlen(input)-1, ".bash_history") != 0) {
            printf("Using Bash history for %d words.\n", n_words);
        }
    } else {
        fprintf(stderr, "Invalid input format.\n");
        exit(EXIT_FAILURE);
    }
    // Inline expansion of exp2 macro to handle complex numbers.
    const char *input = argv[1];
    if (input_type == 'arg') {
        const char *pattern[] = {"^(\\d+)(?:(?:x\\d+)|(?:h(?:ex|i))?(?:[0-9a-fA-F]+)?)$"}; // Match 1 to 3 number + hex or octal + any number.
        char *output[2];
        int pattern_size = 0, num_matches = 0;
        int i;
        for (i=1; strcmp(input, argv[2]) == 0; i++) { // Match one input at a time.
            if (!strmatch(input+strlen(input)-1-i, pattern, &pattern_size)) { // If not match, check again with last pattern and set flag.
                printf("Invalid input format.\n");
                exit(EXIT_FAILURE);
            } else if (num_matches > 0 && strcmp(input+strlen(input)-1-i+pattern_size-1, ".bash_history") != 0) { // If more than one match, check last pattern and set flag.
                printf("Using Bash history for %d words.\n", num_matches);
            } else if (num_matches == 0 || strcmp(input+strlen(input)-1-i, ".bash_history") != 0) { // If no match, check last pattern and set flag.
                printf("Using Bash history for %d words.\n", num_matches);
            } else if (num_matches > 0 && strmatch(input+strlen(input)-1-i, "\\d+")) { // If number matches, expand to integer.
                output[0][0] = '\0';
                strncpy(output[0], input+strlen(input)-1-i, 3); // Expand up to two digits and add 'x'.
            } else if (num_matches == 1 && strmatch(input+strlen(input)-1-i, "\\d*") && strmatch(input+strlen(input)-1-i, "\\h[0-9a-fA-F]+")) { // If only one number match and hex or octal matches.
                output[0][0] = '\0';
                strncpy(output[0], input+strlen(input)-1-i, 3); // Expand up to two digits and add 'x'
            } else {
                printf("Invalid input format.\n");
                exit(EXIT_FAILURE);
            }
            if (num_matches == 0 || strcmp(output[0], ".bash_history") != 0) { // If no match, check last pattern and set flag.
                printf("Using Bash history for %d words.\n", num_matches);
            } else if (num_matches > 0 && strmatch(input+strlen(input)-1-i, "\\d+") && strmatch(input+strlen(input)-1-i, "x\\d+")) { // If more than one match, check last pattern and set flag.
                printf("Using Bash history for %d words.\n", num_matches);
            } else if (num_matches == 0 && strcmp(output[0], ".bash_history") != 0) { // If no match, check last pattern and set flag.
                printf("Using Bash history for %d words.\n", num_matches);
            }
        }
    } else if (input_type == 'bash') {
        const char *pattern[] = {"\$([0-9]*)$"}; // Match 1 to 3 numbers.
        char *output[2];
        int pattern_size = 0, num_matches = 0;
        for (i=0; strcmp(input+strlen(input)-1-i, ".bash_history") != 0; i++) { // Match one input at a time.
            if (!strmatch(input+strlen(input)-1-i, pattern, &pattern_size)) { // If not match, check again with last pattern and set flag.
                printf("Invalid input format.\n");
                exit(EXIT_FAILURE);
            } else if (num_matches > 0 && strcmp(input+strlen(input)-1-i+pattern_size, ".bash_history") != 0) { // If more than one match, check last pattern and set flag.
                printf("Using Bash history for %d words.\n", num_matches);
            } else if (num_matches == 0 || strcmp(input+strlen(input)-1-i, ".bash_history") != 0) { // If no match, check last pattern and set flag.
                printf("Using Bash history for %d words.\n", num_matches);
            } else if (num_matches > 0 && strmatch(input+strlen(input)-1-i, "\\d+")) { // If number matches, expand to integer.
                output[0][0] = '\0';
                strncpy(output[0], input+strlen(input)-1-i, 3); // Expand up to two digits and add 'x'.
            } else if (num_matches == 1 && strmatch(input+strlen(input)-1-i, "\\d*") && strmatch(input+strlen(input)-1-i, "\\h[0-9a-fA-F]+")) { // If only one number match and hex or octal matches.
                output[0][0] = '\0';
                strncpy(output[0], input+strlen(input)-1-i, 3); // Expand up to two digits and add 'x'
            } else {
                printf("Invalid input format.\n");
                exit(EXIT_FAILURE);
            }
        }
    } else if (input_type == 'bash') {
        const char *pattern[] = {"\$([0-9]*)$"}; // Match 1 to 3 numbers.
        char *output[2];
        int pattern_size = 0, num_matches = 0;
        for (i=0; strcmp(input+strlen(input), ".bash_history") != 0 && !strmatch(input+strlen(input), "\n\r", &pattern_size); i++) { // Match one input at a time.
            if (!strmatch(input+strlen(input), pattern, &pattern_size)) { // If not match, check again with last pattern and set flag.
                printf("Invalid input format.\n");
                exit(EXIT_FAILURE);
            } else if (num_matches > 0 && strcmp(input+strlen(input), ".bash_history") != 0) { // If no match, check last pattern and set flag.
                printf("Using Bash history for %d words.\n", num_matches);
            } else if (num_matches == 0 || strmatch(input+strlen(input), "\\d*") && strmatch(input+strlen(input), "\\h[0-9a-fA-F]+")) { // If only one number match and hex or octal matches.
                output[0][0] = '\0';
            } else {
                printf("Invalid input format.\n");
                exit(EXIT_FAILURE);
            }
        }
    }

    return 0;
}