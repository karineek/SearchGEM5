
#include <stdio.h>
#include <stdlib.h>
#include "bash.h"

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s [input]\n", argv[0]);
        return 1;
    } else {
        char buffer[BUFSIZ];
        if (read(STDIN_FILENO, buffer, sizeof(buffer)) < 0) {
            perror("Read error");
            return 2;
        }
        if (!bash_init()) {
            perror("BASH initialization failed");
            return 3;
        }
        int status = bash_interact(&argv[1][1], buffer, sizeof(buffer), 0);
        printf("DCE: %s\n", status == -1 ? "ERROR" : "OK");
        if (status != 0) {
            bash_exit();
        } else {
            bash_restart();
            return 0;
        }
    }
}