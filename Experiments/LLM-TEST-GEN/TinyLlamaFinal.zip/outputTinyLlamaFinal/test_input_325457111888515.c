
#include <stdio.h>

#ifndef __CUDACC__
    #define _GNU_SOURCE
    #include <stdlib.h>
    #include <math.h>
#endif

#define NUM_ARGS 2 // number of input arguments

// function to apply TSOs and execute multiplicaitiive expressions
int main(int argc, char *argv[]) {
    if (argc != NUM_ARGS) {
        fprintf(stderr, "Usage: %s [input file]\n", argv[0]);
        return 1;
    }

    // parse input arguments and calculate multiplicaityes using TSOs
    float result = -3.14f / powf(argc > 1 ? atof(argv[1]) : 1, 2);

    // print result with appropriate precision
    if (result != 0) {
        printf("%16.16e\n", result);
    } else {
        fprintf(stderr, "Error: input file not found or non-numeric value\n");
        return 2;
    }

    return 0;
}