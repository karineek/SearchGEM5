
#include <stdio.h>
#include <stdlib.h> // for exit() function

int main(int argc, char **argv) {
    if (argc != 2 || argv[1][0] == '-') {
        printf("Usage: %s FILE\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    FILE *file = fopen(argv[1], "r");
    if (file == NULL) {
        perror("Error opening file.");
        exit(EXIT_FAILURE);
    }

    int numLines = 0;
    char line[256]; // buffer for input
    while (fgets(line, sizeof(line), file)) {
        ++numLines;
    }
    
    fclose(file);
    
    printf("Read %d lines.\n", numLines);
    
    return EXIT_SUCCESS;
}