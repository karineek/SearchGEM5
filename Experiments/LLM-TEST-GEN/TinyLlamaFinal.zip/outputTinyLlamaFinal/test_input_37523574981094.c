
#include <stdio.h>
#include <stdlib.h>
#include "sclair/opt.h"

void print_usage(const char* name) {
    printf("%s: Input filename, or '-' for stdin\n", name);
}

int main(int argc, char** argv) {
    if (argc < 2) { // Check if input file is not specified
        print_usage("-");
        return EXIT_FAILURE;
    }
    
    const char* filename = argv[1];
    int fd = -1;
    FILE* fin = NULL;
    
    while (-1 != (fd = open(filename, O_RDONLY))) { // Open file for reading
        fin = fopen(filename, "r"); // Create a new file object in the given filename
        if (!fin) {
            perror("Failed to open input file");
            return EXIT_FAILURE;
        } else { // Check if file is valid
            struct stat st;
            if (stat(filename, &st) < 0) {
                printf("%s: Invalid input file\n", filename);
                return EXIT_FAILURE;
            } else if (!S_ISREG(st.st_mode)) { // If not a regular file
                printf("%s: Invalid input file (non-regular file)\n", filename);
                return EXIT_FAILURE;
            }
        }
        
        fin = fdopen(fd, "r"); // Open file for reading with specified flags
        if (!fin) {
            perror("Failed to open input file for reading\n");
            return EXIT_FAILURE;
        } else {
            printf("%s: Read from '%s' (%d bytes)\n", filename, fin->name, fin->size);
        }
        
        fclose(fin); // Close file for reading
    }
    
    return EXIT_SUCCESS;
}