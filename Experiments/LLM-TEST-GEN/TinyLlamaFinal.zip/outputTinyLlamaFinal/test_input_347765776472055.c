
#include <stdio.h>
#include <stdlib.h>

#define BASH 6

char argv[] = {"arg1", "arg2"};

int main(void) {
    char output[BASH + 1] = "";
    puts("Enter first string: ");
    if (readline(&argv[0]) < BASH) {
        return EXIT_FAILURE;
    }
    for (int I = 1; I < BASH; i++) {
        printf("%s%c ", argv[i], '\n');
        output[i] = arg[i];
    }
    strcat(output, "\n");
    puts(output);
}