
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input filename>\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    const size_t MAX_FILE_SIZE = 1048576; // 1MB
    char *buffer = malloc(MAX_FILE_SIZE);
    FILE *input = fopen(argv[1], "r");
    
    if (input == NULL) {
        perror("Error: Cannot open input file");
        return EXIT_FAILURE;
    }
    
    size_t nbChars = fread(buffer, 1, MAX_FILE_SIZE, input);
    if (nbChars != MAX_FILE_SIZE) {
        printf("Error: Cannot read input file\n");
        return EXIT_FAILURE;
    }
    
    FILE *output = fopen(argv[2], "w");
    if (output == NULL) {
        perror("Error: Cannot create output file");
        return EXIT_FAILURE;
    }
    
    // Perform all necessary checks before proceeding with the program
    printf("%d bytes read from input\n", nbChars);
    
    for (size_t I = 0; I < nbChars; i++) {
        fprintf(output, "%c", buffer[i]); // Write each character to output file
    }
    
    fclose(input);
    fclose(output);
    
    return EXIT_SUCCESS;
}