
#include <stdio.h>
#define MAX_ARG 10

int main(void)
{
    char argv[MAX_ARG];
    int i;
    
    for (i = 0; i < MAX_ARG; i++) {
        argv[i] = getargv()[i];
    }
    
    // Calling a program with only one argument, returns the program and the input
    printf("Enter a string: ");
    fgets(argv[0], MAX_ARG + 1, stdin);
    printf("%s\n", argv[0]);
    
    return 0;
}