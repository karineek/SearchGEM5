
#include <iostream>
#include <string>
using namespace std;
namespace BASEH {
    template<typename T> struct specialized_functor {
        using functor = T(T::*)(int);
        void operator()(int n, int p) const {
            cout << "Specialization: " << get_name<T>() << "(" << n << ", " << p << ")" << endl;
        }
    };
} // namespace BASEH

template<typename T> using specialized_functor = typename BASEH::specialized_functor<>;

int main() {
    int n, p;
    string argv[2];
    
    cout << "BASH: Specialization Optimizations" << endl;
    cin >> n >> argv[0] >> argv[1]; // Get input from command line arguments

    BASEH::specialized_functor<T> specializer([] (int n, int p) { return n*p; });
    
    specializer(n, p); // Call Specialization and print result

    cout << endl;

    return 0;
}