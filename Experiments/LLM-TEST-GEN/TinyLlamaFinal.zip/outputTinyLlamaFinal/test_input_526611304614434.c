
#include <stdio.h> // for printf()
#include <stdlib.h> // for exit()
#include "parser.h"

int main(int argc, char *argv[]) {
    parser_t *parser; // create a parser instance
    int line = 1; // set the first line to 1
    int offset = 0; // set the offset for parsing
    
    if (argc < 2 || argv[1][0] == '-') { // check if there is an argument or not
        printf("Usage: %s [options] script_file\n", argv[0]);
        return EXIT_SUCCESS;
    }
    
    parser = parser_create(argv[1], argc - 1); // create the parser from a BASH script file
    
    while (parser->parse(&line, &offset)) {
        printf("Line %d: %s\n", line, parser->get_script());
        if (parser->error()) {
            printf("Error parsing line %d:\n%s\n", line, parser->get_message());
        }
    }
    
    // cleanup memory and exit the program gracefully
    parser_delete(parser); // delete the parser instance
    return EXIT_SUCCESS;
}