
#include <stdio.h> /* include standard input/output library */
#include <string.h> /* include string manipulation functions */
#include <stdlib.h> /* include system allocation library */
#include "rewind.c" /* rewind function implementation */

int main(int argc, char* argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s INPUT_FILE\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    FILE* input = fopen(argv[1], "r"); /* open input file as read-only */
    if (input == NULL) {
        fprintf(stderr, "Error: Could not open input file \"%s\"\n", argv[1]);
        return EXIT_FAILURE;
    }
    
    FILE* output = fopen("output.bsh", "w"); /* open output file as write-only */
    if (output == NULL) {
        fprintf(stderr, "Error: Could not create output file \"%s\"\n", argv[1]);
        return EXIT_FAILURE;
    }
    
    rewind(input); /* initialize input file position to beginning */
    
    printf("Starting assembly...\n"); /* start printing assembly instructions */
    
    char buffer[MAXLINE]; /* allocate buffer for line of instructions */
    while (fgets(buffer, MAXLINE, input)) { /* read one instruction at a time */
        /* rewind function implementation: moves back to beginning of file */
        if (rewind(input) == -1) {
            fprintf(stderr, "Error: Could not move back to beginning of file\n");
            return EXIT_FAILURE;
        }
        
        /* execute instructions */
        printf("Instruction: %s\n", buffer); /* print instruction */
        
        /* rewind function implementation: moves forward to end of line */
        fgets(buffer, MAXLINE, input); /* read next line from input */
    }
    
    printf("Ending assembly...\n"); /* end printing assembly instructions */
    
    fclose(input); /* close input file */
    fclose(output); /* close output file */
    
    return EXIT_SUCCESS;
}