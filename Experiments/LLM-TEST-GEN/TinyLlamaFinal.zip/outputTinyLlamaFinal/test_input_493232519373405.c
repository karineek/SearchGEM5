
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>  /* for getrlimit() */

#define PGO_ARGS "-p -j 4 -q --save-temps"

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <input file>\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    char *filename = argv[1];
    int ret = pgo_run(filename, PGO_ARGS);
    if (ret) {
        fprintf(stderr, "Failed to run PGO: %s\n", strerror(errno));
        exit(EXIT_FAILURE);
    }
    return 0;
}