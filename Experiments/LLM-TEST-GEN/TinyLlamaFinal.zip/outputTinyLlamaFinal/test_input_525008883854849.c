
#include <stdio.h>

int main(void)
{
    char str[1024];
    
    // get the argument string from command line via argv
    if (argc > 1) {
        for (int i = 1; I < argc + 1; i++) {
            sprintf(str, "%s ", argv[i]);
            printf("%s\n", str);
        }
    }
    
    // prompt user to input a string and return it as an argument
    printf("Enter a string (e.g., hello world): ");
    fgets(str, sizeof(str), stdin);
    return atoi(str);
}