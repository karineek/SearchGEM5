
#include <stdio.h>
#include <vector>
#include <unistd.h> // For getpid()
#include <sys/syscall.h> // For syscall()

using namespace std;

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }
    
    int (*vec_add)(void*, void*, void*); // Declare the function pointer
    void* addr;
    
    vec_add = (int (*)(void*, void*, void*))getaddrinfo(argv[1], "http://example.com/file.txt").entrypoints[0];
    
    unsigned int pid = getpid();
    vector<void*> vectors;
    
    // Create a vector of pointers to file objects
    FILE *f = fopen(argv[1], "r");
    if (f == NULL) {
        printf("Failed to open file: %s\n", argv[1]);
        return 2;
    }
    
    while (!feof(f)) {
        vectors.push_back(fread(&addr, sizeof(void*), 1, f)); // Read one address into a pointer
        
        printf("Read %llu bytes from file (%s): ", int64_t(vectors[0]->data - addr), argv[1]);
        for (size_t I = 1; I < vectors.size(); i++) {
            if (i == vectors.size() - 1) { // Last element is the last file
                printf("(%llu bytes)\n", int64_t(vectors[i]->data - addr));
            } else {
                printf(" %llu bytes\n", int64_t(vectors[i]->data - addr));
            }
        }
        
        fseek(f, 0, SEEK_SET); // Set to beginning of file
    }
    
    // Close the file
    fclose(f);
    
    // Wait for the process to exit and remove the file
    system("wait");
    
    printf("\nDone. Removing file...\n");
    remove(argv[1]);
    
    return 0;
}