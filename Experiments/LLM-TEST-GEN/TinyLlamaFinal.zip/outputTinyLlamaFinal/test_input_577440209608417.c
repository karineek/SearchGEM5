
#include <stdio.h>
#include <string.h>

int main() {
    const char* input = argv[1];
    
    /* Trigger Loop Optimizations */
    while (*input != '\0') {
        int count = 0;
        for (int I = 0; *input == ' '; i++) {
            if (!strcmp(input + I, " ")) {
                break;
            } else {
                ++count;
            }
        }
        
        /* PlaceMarker */
        printf("PlaceMarker: %d\n", count);
        input += count;
    }
    
    return 0;
}