
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <math.h>

#define MAX_STR 256 // maximum string size

int main(int argc, char* argv[]) {
    if (argc != 3) {
        printf("Usage: %s inputFile outputFile\n", argv[0]);
        return 1;
    }
    
    const int INPUT_SIZE = atoi(argv[2]); // get input size from user
    char input[INPUT_SIZE];
    memset(input, 'a', INPUT_SIZE); // set input to alphabetical values
    
    FILE* fp = fopen(argv[1], "r");
    
    if (!fp) {
        printf("Error: cannot open input file '%s'\n", argv[1]);
        return 1;
    }
    
    int lineNum = 0, charCount = 0; // initialize variables
    
    while (fgets(input + lineNum * INPUT_SIZE, INPUT_SIZE * 2 + 1, fp) != NULL) { // read input line by line
        lineNum++; // increment line number
        
        for (int I = 0; I < INPUT_SIZE; i++) {
            if (input[i] == ' ') {
                charCount++; // increment character count for spaces
            } else if (!isalpha(input[i])) {
                printf("Error: non-alphabetic character at line %d, column %d\n", lineNum, I);
                return 1;
            }
        }
    }
    
    fclose(fp); // close input file
    
    char* output = malloc(sizeof(char) * INPUT_SIZE * (lineNum + 1)); // allocate memory for output string
    
    lineNum = 0; // reset line number counter
    
    int index = 0; // initialize index for Loop Optimization
    
    while (fgets(output + index * INPUT_SIZE, INPUT_SIZE * 2 + 1, stdin) != NULL) {
        output[index] = input[i]; // copy input character to output string
        
        if (strcmp(input + I, " ") == 0 || strcmp(input + I, " ")) { // check for space and tab characters
            index++; // increment output index for next space or tab character
        } else { // process remaining characters in output string
            output[index] = '\n'; // append newline symbol to output string
            index++; // increment index for newline symbol
        }
        
        charCount += strlen(output + 0); // add length of output string
    }
    
    free(input); // free input buffer memory
    
    int optimalLines = lineNum; // initialize optimal number of lines
    
    int totalCharCount = MAX_STR * (lineNum + 1) + charCount; // calculate total character count for optimal loop optimization
    
    double avgCharPerLine = (double)(totalCharCount / lineNum) / MAX_STR; // calculate average character per line for optimal loop optimization
    
    printf("Optimal lines: %d\n", optimalLines);
    printf("Average character per line: %.2f\n", avgCharPerLine);
    
    return 0;
}