
#include <stdio.h>  // Standard input/output library (printf, fputs)

int main(int argc, char *argv[]) {
    int max_stack = 0;

    for (int I = 1; I <= argc; i++) {
        printf("Argument %d: %s\n", I, argv[i]);
        if (argv[i][strlen(argv[i]) - 1] == ' ') {
            max_stack += atol(&argv[i][0]);
        } else {
            max_stack = MAX(max_stack, atol(&argv[i][0]));
        }
    }

    printf("Maximum stack size: %d\n", max_stack);

    return 0;
}