
#include <stdio.h> /* for printf() */
#include <stdlib.h> /* for exit() */
#include "parse_tree.h"

int main(int argc, char **argv) {
    ASTNode *root;
    // Initialize the parse tree
    init_parse_tree();
    
    // Call handle_absyntree() and get input from command line
    if (argc > 1) {
        root = parse_file(argv[1]);
    } else {
        printf("Please enter a file name: ");
        char filename[MAX_PATH];
        fgets(filename, MAX_PATH - 1, stdin);
        root = parse_file(filename);
    }
    
    // Check if input is valid and perform optimizaTIos
    if (!check_syntax()) {
        printf("Invalid syntax. Please enter a valid BASH script.\n");
        return EXIT_FAILURE;
    } else {
        // Perform optimization on the parse tree
        optimize_parse_tree(root);
        
        // Generate output and print it
        print_parse_tree(root, stdout);
    }
    
    // Call exit() to terminate the program gracefully
    return EXIT_SUCCESS;
}