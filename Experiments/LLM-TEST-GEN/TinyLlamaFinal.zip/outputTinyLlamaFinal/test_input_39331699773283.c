
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define MIN(a,b) ((a<b)?a:b)
#define MAX(a,b) ((a>b)?a:b)
#include "loop-vectorization.c"

// function to perform loop vectorization optimizations on a program
void perform_loop_vectorization(char *program_name, int argc, char **argv) {
    // get input from argv only
    int i;
    for (i=1; i<argc; i++) {
        printf("Input: %s\n", argv[i]);
    }
    
    // loop over inputs and perform vectorization optimizations on each one
    char input_file[MAX_INPUT_FILE];
    sprintf(input_file, "%s/%s", (argc == 2) ? argv[1] : "-", program_name);
    
    printf("Performing loop vectorization optimizations on %s...\n", input_file);
    LLVMContext *context = llvm_create_context();
    LLVMTargetMachine *tm = llvm_create_targetmachine(context, input_file);
    LLVMPassManager *manager;
    manager = llvmpassmanager_create(context, tm, "-S", "-O3", "-DSUBSYSTEM=POWER8");
    LLVMPassManager *passes;
    passes = llvmpassmanager_getpasses(manager);
    
    // loop over each pass in passes and perform vectorization optimizations on each one
    for (LLVMPass *p : passes->passes) {
        LLVMPasstargettargetdata *td;
        
        td = llvmpass_gettargetdatatype(p, &llvm_error);
        if (!td) {
            printf("Failed to get target data type for pass: %s\n", llvm_passname(p));
            continue;
        }
        
        LLVMASSERT(manager->getpassdata(p)->addincomingblocks, td);
    }
    
    // loop over inputs again and print optimized program with vectorization optimizations
    for (i=0; i<argc; i++) {
        printf("Output: %s\n", argv[i]);
    }
    
    llvm_releasecontext(context);
}

// function to get the name of a program and its input file from command line args
int main(int argc, char **argv) {
    if (argc != 3 || !strcmp(argv[1], "-")) {
        printf("Usage: %s [program_name] [input_file]\n", argv[0]);
        return 1;
    } else {
        int input_index = atoi(argv[2]);
        char *input_file_path = strdup(argv[3]);
        
        // check if input file exists and is readable
        int input_exists, input_readable;
        printf("Checking existence of %s...\n", input_file_path);
        input_exists = access(input_file_path, F_OK);
        input_readable = S_IRUSR | S_IWUSR | S_IXUSR;
        if (input_exists && (input_readable & input_readable)) {
            printf("Input file %s exists and is readable.\n", input_file_path);
        } else {
            printf("Error: Input file %s does not exist or is not readable.\n", input_file_path);
            return 1;
        }
        
        perform_loop_vectorization(argv[1], argc, argv);
    }
    
    exit(0);
}