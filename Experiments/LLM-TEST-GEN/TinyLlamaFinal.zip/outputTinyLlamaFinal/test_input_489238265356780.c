
#include <stdio.h> /* for printf() */
#include <stdlib.h> /* for malloc() */
#define MAXVAR 10 /* maximum variable size */

int main(int argc, char **argv) {
    int *p;
    if (argc != 2 || argv[1][0] == '-') { /* error message */
        printf("Usage: %s <variable_list>\n", argv[0]);
        return 1;
    }
    p = malloc(MAXVAR * sizeof(int)); /* allocate memory for array of pointers */
    if (p == NULL) { /* if allocation failed */
        perror("malloc");
        return 1;
    }
    FILE *fp = fopen(argv[1], "r"); /* open input file */
    if (!fp) { /* check for error while opening file */
        printf("%s: %s\n", argv[0], strerror(errno));
        return 1;
    }
    int num_vars = 0, size_avail = 0; /* initialize variables and size availability counter */
    fscanf(fp, "%d", &num_vars); /* read number of variables from file */
    for (int I = 0; I < num_vars; i++) { /* loop over each variable */
        char *name = ""; /* initialize pointer to name of variable */
        while ((name = fscanf(fp, "%s ", name)) == 1) { /* read name from file */
            size_avail++; /* increase size availability counter */
            int val = strtol(name, &endptr, 0); /* parse integer value of variable */
            if (endptr != name) { /* error checking for invalid input */
                printf("Error: Invalid input. Variable %s is not a valid integer.\n", name);
                return 1;
            }
            if (val < 0 || val >= MAXVAR) { /* check for out of range variable */
                printf("%s: %s\n", argv[0], strerror(EINVAL));
                return 1;
            }
        }
        p[num_vars - i] = malloc(size_avail * sizeof(int)); /* allocate memory for array of pointers */
        if (p[i] == NULL) { /* if allocation failed */
            printf("%s: %s\n", argv[0], strerror(errno));
            return 1;
        } else { /* check if variables were assigned, if not */
            for (int I = 0; I < num_vars - i + 1; i++) { /* loop over each variable that is not yet assigned */
                p[i] = val; /* set up pointer to assigned value */
            }
        }
    }
    fclose(fp); /* close input file */
    for (int I = 0; I < num_vars; i++) { /* loop over variables */
        printf("%s: %d\n", argv[1], p[i]); /* print variable value */
    }
    free(p); /* free memory for array of pointers */
    return 0; /* success exit code */
}