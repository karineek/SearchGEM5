
/*
 * This code triggers target-specific optimizations using LLVM bitcode. It uses the
 * "search" function from the LLVM tooling library to execute a specific optimization.
 * The optimization can be specified through command line arguments (e.g., -O for Optimization).
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <llvm/Bitcode/ReaderWriter.h>

/*
 * Search function used to execute optimization
 */
static void optimize(const char* filename) {
    // Load the LLVM bitcode
    const char* filepath = strdup(filename);
    llvm::Module* module = llvm::readBitcodeForFile(filepath, nullptr);
    if (!module) {
        fprintf(stderr, "Failed to read %s: %s\n", filename, llvm::sys::last_error_message());
        free(filepath);
        exit(EXIT_FAILURE);
    }

    // Execute optimization
    std::unique_ptr<llvm::BitcodeReader> reader(llvm::make_unique<llvm::BitcodeReader>(module));
    llvm::bitcode::bitcode_writer writer;
    const char* code = nullptr;
    if (llvm::bitcode::read_bitcode_to_string(reader.get(), &code)) {
        // Remove the optimization that was done on this file
        std::string optimized_filepath = filename + "_optimized";
        if (!std::rename(filepath, optimized_filepath.c_str())) {
            fprintf(stderr, "Failed to rename %s to %s: %s\n", filepath, optimized_filepath.c_str(), strerror(errno));
            exit(EXIT_FAILURE);
        }
        printf("Renamed %s to %s\n", filepath, optimized_filepath.c_str());
    } else {
        fprintf(stderr, "Failed to read %s: %s\n", filename, llvm::sys::error_info<char*>().c_str());
        exit(EXIT_FAILURE);
    }
}

int main(int argc, char** argv) {
    if (argc > 1 && strcmp(argv[1], "-O") == 0) {
        printf("Optimization requested\n");
        optimize(argv[2]);
        return EXIT_SUCCESS;
    } else {
        printf("Invalid argument: -O\n");
        return EXIT_FAILURE;
    }
}