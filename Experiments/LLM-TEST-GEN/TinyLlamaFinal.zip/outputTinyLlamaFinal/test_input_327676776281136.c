
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int i = 0;
    
    while (i < argc) {
        printf("arg %d: %s\n", i++, argv[i]);
    }
    
    return 0;
}