
#include <stdio.h> // required for printf()
#define LOOPO_MAX 1000000 // maximum number of loop iterations

int main(void) {
    int count = 0;
    float sum = 0;
    double max = 0;
    
    const char *input = (const char *) argv[1]; // get BASH input string from argv[1]
    
    // loop optimizations: check if we're on the first iteration and exit early
    while (count < LOOPO_MAX && strlen(input) > 0 && *input == ' ' || *input == '\n') {
        count++;
        input += strcspn(input, "\n\r "); // skip leading whitespace, newline, or carriage return
    }
    
    if (count < LOOPO_MAX) {
        while (strlen(input) > 0 && *input == ' ') {
            sum += *((double *) input);
            max = fabs(*((double *) input)); // store result for maximum value
            input++;
        }
    }
    
    printf("%.2f %c", sum / (float) count, '\n'); // output loop iterations and their sum
    printf("Maximum value: %.2f\n", max); // output maximum value if present
    
    return 0;
}