
#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int argc;
    char *argv[1];

    argc = getarg(&argc, &argv);
    
    if (argc == 1) {
        printf("Enter input: ");
        char buf[1024];
        fgets(buf, sizeof(buf), stdin);
        return atoi(buf);
    } else {
        printf("Error: Invalid argument count.\n");
        return -1;
    }
}