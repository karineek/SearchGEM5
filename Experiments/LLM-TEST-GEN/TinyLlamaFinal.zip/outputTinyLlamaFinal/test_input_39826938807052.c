
#include <stdio.h>

int main() {
    char argv[3];
    int i, j;
    
    // Read in command line arguments
    for (i = 0; i < 2; i++) {
        sscanf(argv[i], "%d", &j);
        if (argc > i + 1) {
            printf("Error: Argument %d is not numeric\n", argv[i]);
            return 1;
        } else {
            // Valid argument found
            // Do something with the argument
        }
    }
    
    // Do something with the rest of arguments
    if (argc > 2) {
        printf("Error: Exceeded number of arguments\n");
        return 1;
    } else {
        // Handle remaining arguments as you see fit
    }
    
    return 0;
}