
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Invalid Input\n");
        return 0;
    }
    
    // Checking if argv[1] is a valid input for the program
    char str_input[MAX_LENGTH];
    FILE* fp = fopen(argv[1], "r");
    if (fp == NULL) {
        printf("Invalid Input\n");
        return 0;
    }
    
    // Reading the file to an array of characters
    int len = fread(str_input, 1, MAX_LENGTH, fp);
    if (len != MAX_LENGTH) {
        perror("Error reading input file\n");
        return 0;
    }
    
    // Truncating the string to the length of argv[1]
    strncpy(str_input, argv[1], MAX_LENGTH);
    str_input[MAX_LENGTH - 1] = '\0';
    
    printf("%s\n", str_input);
    
    return 0;
}