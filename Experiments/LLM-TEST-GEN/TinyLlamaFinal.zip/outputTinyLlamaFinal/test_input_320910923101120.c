
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int i = 0;
    
    while(argc > i && (*argv[i] == '-' || *argv[i] == '+' || *argv[i] == '/')) {
        switch(*argv[++i]) {
            case '+':
                printf("Value of arg %d: %.2f\n", ++i, DBL_MANTHO(DBL_DIV(atof(argv[i]), 10))); break;
            case '-':
                printf("Value of arg %d: %.2f\n", --i, DBL_MANTHO(-DBL_DIV(atof(argv[i]), 10))); break;
            default:
                printf("Invalid argument (or option): %c\n", *argv[i]);
        }
    }
    
    return 0;
}