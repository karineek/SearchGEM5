
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXLINE 1024
#define MAXLEN 512

int main(int argc, char *argv[]) {
    int line[MAXLINE], len;
    char* target_file = argv[1];
    
    if (argc != 3) {
        printf("Usage: %s [target file]\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    FILE *f = fopen(target_file, "r");
    if (!f) {
        perror("Failed to open file");
        exit(EXIT_FAILURE);
    }
    
    while (fgets(line[0], MAXLINE, f)) {
        len = strlen(line[0]);
        if ((strcmp(line[0], "extern") == 0 && line[1] == '\n') ||
            (strcmp(line[0], "internal") == 0 && line[1] != '\n')) {
            printf("%s\n", line);
            continue;
        } else if (len > MAXLEN) {
            fclose(f);
            perror("Invalid input");
            exit(EXIT_FAILURE);
        }
        
        // Atomic compare-exchange-weak optimization
        int result = atomic_compare_exchange_weak(&line[0], &len, len + 1);
        if (result == 1) {
            printf("%s\n", line);
        } else if (result != 2) {
            fclose(f);
            perror("Error: %d", result);
            exit(EXIT_FAILURE);
        }
    }
    
    fclose(f);
    return 0;
}