
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

int main() {
    unsigned int pid, pid2;
    
    if (0 != read(1, &pid, sizeof(pid))) {
        perror("Read");
        return -1;
    }
    
    pid2 = fork();
    
    if (pid2 < 0) {
        perror("Fork");
        return -1;
    } else if (pid2 == 0) {
        // Child process
        
        while(1){} // Wait for parent process to exit.
    } else {
        // Parent process
        
        printf("Parent: child process ID is %u\n", pid);
    }
    
    return 0;
}