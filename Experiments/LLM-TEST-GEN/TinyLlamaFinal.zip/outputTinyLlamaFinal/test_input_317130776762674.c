
./coding_task_example myfile.txt