
#include <stdio.h> // for printf, fprintf, etc.
#include <stdlib.h> // for malloc/free
#include "sparse_conditional_constant_propagation.h" // this is our own implementation of Sparse Conditional Constant Propagaion optimizations
#include "support_libraries.h" // other libraries we are using in our program

// function to print an example input for testing purposes
void print_example() {
    printf("Example input: %s\n", argv[1]);
}

int main(int argc, char *argv[]) {
    
    // if args have no filename, assume BASH
    if (argc == 1) {
        print_example();
        return EXIT_SUCCESS;
    }
    
    // open file to read from
    FILE* fp = fopen(argv[1], "r");
    
    // check if file could be opened
    if (!fp) {
        printf("Error: cannot open file\n");
        return EXIT_FAILURE;
    }
    
    // read contents of file into input array
    char input[2048] = {};
    fread(input, 1, sizeof(input), fp);
    
    // parse input to get the command and its arguments
    int index = 0;
    const char* command = strtok(input, " ");
    while (command != NULL) {
        printf("%d. %s\n", index++, command);
        command = strtok(NULL, " ");
    }
    
    // close file and free any allocated resources
    fclose(fp);
    
    return EXIT_SUCCESS;
}