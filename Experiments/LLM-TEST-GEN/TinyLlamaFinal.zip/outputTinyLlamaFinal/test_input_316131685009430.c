
#include <stdio.h> /* for fopen, fprintf, ... */
#include <stdlib.h> /* for malloc, free, ... */
#include <time.h>  /* for srand, time, ... */
#include <sys/types.h> /* for stat() syscall, ... */
#include <sys/stat.h> /* for S_ISUID and S_IXOTH, ... */
#include <sys/wait.h> /* for waitpid(), ... */

/* macros for type-generic exp2 calculation */
#define __exp2(x) ((double) pow((double)(10.), (double)(x)))

int main() {
    int pid;  // process id of main program
    pid = getppid(); /* find parent process id */

    char command[256];
    char* argv[2] = { "bash", "-c", "/home/user/bin/command.sh" };

    if (fork() == 0) {                             // spawn child process and execute bash
        execve("/bin/bash", argv, (argc > 1 ? (char**) &argv[1] : NULL));
        exit(EX_SUCCESS);
    } else {                                       // wait for child to finish
        sleep(5);
        pid = waitpid(-1, NULL, WNOHANG);          // wait for parent to finish
        if (pid == -1) {
            perror("waitpid");
            exit(EX_FAILURE);
        } else if (pid != 0) {                     // re-raise error on child
            kill(pid, SIGKILL);
            exit(EX_SUCCESS);
        }
    }

    /* print help message */
    if (!strcmp(command, "/bin/bash -c ")) {
        puts("Usage: bash [OPTIONS] COMMAND...");
        return 0;
    } else {
        printf("Error: command not found.\n");
        return 1;
    }
}