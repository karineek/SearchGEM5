
#include <stdio.h>
#include <stdlib.h>

int main() {
    float a = 1;
    printf("%f\n", csqrt(a)); // returns the square root of a
    return 0;
}