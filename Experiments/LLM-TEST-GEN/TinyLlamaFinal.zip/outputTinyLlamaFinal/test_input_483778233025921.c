
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_ARGS 1024

int main(int argc, char *argv[]) {
    int i, j, nargs;
    char buf[MAX_ARGS][MAX_ARGS+1]; // buffer with argv strings
    
    for (i = 0; i < argc; i++) {
        nargs = strlen(argv[i]); // get length of current arg
        j = 0; // initialize counter to start
        
        while (j < nargs && strchr("0123456789", argv[i][j])) { // loop from first non-digit character to last
            buf[i][j] = argv[i][j]; // copy arg into buffer
            j++; // increment counter
        }
        
        if (j == nargs) { // check for last character of arg, convert to null and add it to buf
            buf[i][j] = '\0';
            buf[i][nargs+1] = '\0'; // terminate buffer at first null char + space char (to align with argv[])
        } else if (j == 0) { // check for empty arg (excluding first), convert to null and add it to buf
            buf[i][0] = '\0';
            buf[i][1] = '\0';
        } else { // non-empty arg, concatenate with buffer
            j--; // decrease length of current arg by 1 (to remove trailing space char)
            strcat(buf[i], argv[i]+j+1); // add argument to end of buffer with last null char added
        }
        
        printf("arg %s = %s\n", argv[i]+j, buf[i]);
    }
    
    return 0;
}