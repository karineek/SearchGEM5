
#include <stdio.h>  /* for fprintf */
#include <stdlib.h> /* for exit() */

/* This function is called by the main() function to handle errors */
int error_handler(int error, const char *file, int line) {
    perror(file);
    printf("Error: %d @%d (%s)\n", error, line, file);
    exit(1);
}

int main() {
    int argc;
    char **argv;
    argc = 2; // assume we have one argument (input)
    argv = calloc(argc + 1, sizeof(char *));
    argv[0] = "Enter a program (BASH)";
    argv[1] = "Your input is: ";
    if (readlink(".", argv[2], MAXPATHLEN) == -1 || strlen(argv[2]) > 1000) {
        fprintf(stderr, "Error: Cannot read the link name\n");
        exit(1);
    }
    strcpy(argv[argc + 1], argv[2]); // copy input to output
    printf("%s", argv[argc + 1]); // print the input
    
    /* Check if the input is valid */
    struct stat st;
    if (stat(argv[0], &st) == -1 || S_ISREG(st.st_mode)) {
        fprintf(stderr, "Error: Input is not a file\n");
        exit(1);
    }
    
    /* Handle errors */
    setbuf(stdout, NULL); // set stdout to non-blocking (avoids buffer overflow)
    setbuf(stderr, NULL);
    setlocale(LC_ALL, ""); // set the language to English for better output
    printf("Enter a program (BASH) (Ctrl+D): ");
    fgets(argv[argc + 2], MAXPATHLEN - 1, stdin);
    
    /* Return the input */
    return atoi(argv[argc + 2]); // convert input to int
}