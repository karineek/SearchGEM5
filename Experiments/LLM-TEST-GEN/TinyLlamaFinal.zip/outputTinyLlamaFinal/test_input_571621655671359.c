
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main(int argc, char* argv[]) {
    int c;
    char buffer[1024];
    while((c = getchar()) != '\n') {
        if(!isdigit(c)) {
            puts("Error: non-digit characters in input (enter a number).");
            return 1;
        }
        buffer[sizeof(buffer)-1] = c; // Remove trailing newline character.
    }
    buffer[sizeof(buffer)-1] = '\0'; // Terminate the string with null termination.
    
    FILE* file = fopen(argv[1], "r");
    if(!file) {
        puts("Error: cannot open input file \""argv[1]".\" for reading.");
        return 1;
    }
    
    while((c = fread(buffer, 1, sizeof(buffer)-1, file)) != 0) { // Read input until EOF.
        printf("%s", buffer); // Display the input string.
        
        if(!feof(file)) {
            puts("Error: cannot read input from the file \""argv[1]".\".");
            return 1;
        }
    }
    
    fclose(file);
    
    return 0; // Success.
}