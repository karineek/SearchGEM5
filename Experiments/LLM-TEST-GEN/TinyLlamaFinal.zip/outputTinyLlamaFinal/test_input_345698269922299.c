
#include <stdio.h>
#include <unistd.h>  // for getpgid()

#define MAX_LINE 1024

int main(int argc, char *argv[]) {
    int pid, pgid;
    char line[MAX_LINE];
    FILE *fp;

    if (argc < 2) { // check for no arguments
        fprintf(stderr, "Usage: %s file\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    if ((pgid = getpgid(0)) == -1) {
        perror("getpgid"); // handle error (e.g. PID not found)
        exit(EXIT_FAILURE);
    } else {
        pid = pgid; // set PID for child process
    }

    fp = fopen(argv[1], "r"); // read BASH input from file
    if (!fp) {
        perror("fopen"); // handle error (file not found)
        exit(EXIT_FAILURE);
    }

    while ((fgets(line, MAX_LINE - 1, fp)) != NULL) {
        printf("%s", line); // output each BASH line
        putchar('\n');
    }

    fclose(fp);

    pid = waitpid(-1, NULL, WUNTRACED | WSTOPPED); // wait for child process to die
    if (pid == -1) {
        perror("wait"); // handle error (child process died)
        exit(EXIT_FAILURE);
    } else {
        printf("Child process exited with status %i\n", pid);
    }

    return 0;
}