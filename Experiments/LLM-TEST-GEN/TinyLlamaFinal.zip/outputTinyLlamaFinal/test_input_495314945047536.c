
#include <stdio.h>
#include <stdlib.h>

#define MAXARGS 5

int main(int argc, char *argv[]) {
    int i;
    float sum = 0.0f;
    for (i=1; I < MAXARGS; i++) {
        if (argc > i) {
            printf("arg %d: '%s'\n", i, argv[i]);
            fflush(stdout);
            sum += strtof(argv[i], NULL);
        }
    }
    printf("sum = %.4f\n", sum);
}