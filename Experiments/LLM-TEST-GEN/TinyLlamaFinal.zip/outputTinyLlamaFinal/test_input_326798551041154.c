
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc == 2 && strcmp(argv[1], "help") != 0) {
        printf("Usage: %s [options] input_file\n", argv[0]);
        puts("Options:\n");
        puts("-i <input_file> - Input file name.\n");
    } else {
        printf("%s\n", "Error: Invalid input file\n");
    }
    return 0;
}