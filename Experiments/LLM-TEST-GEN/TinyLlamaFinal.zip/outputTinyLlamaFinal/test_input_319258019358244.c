
#include <stdio.h>
#include <llvm/IR/Module.h>
#include <llvm/IR/DerivedTypes.h>
#include <llvm/Support/FileSystem.h>
#include <llvm/Support/ManagedStatic.h>
#include <llvm/Transforms/Scalar/ScalarOptimizer.h>

using namespace llvm;

void run_loop_opt(Module &M) {
    // Create a pass manager with the scalar optimizer
    PassManager PM = getGlobalPassRegistry().getPass<ScalarEvolutionPass>("");
    
    // Apply ScalarEvolution pass to module
    M.apply(*PM);
}

int main(int argc, char **argv) {
    if (argc != 2 || argv[1][0] == '-') {
        fprintf(stderr, "Usage: %s file.inch-feet\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    const char *input = argv[1]; // Example input: "C:/Users/Administrator/Desktop/testinput.txt"
    // Open input file for reading using stdin
    FILE *file = fopen(input, "r");
    if (!file) {
        perror("Error opening input file");
        return EXIT_FAILURE;
    }
    
    // Read LLVM IR from file
    Module *M = nullptr;
    if (file != stdin) {
        M = readIRFromFile(input);
        if (!M) {
            perror("Error reading LLVM IR");
            return EXIT_FAILURE;
        }
    }
    
    // Find N distances in LLVM IR and system
    std::vector<int64_t> nDistances;
    std::string llvmIR = "";
    if (M) {
        for (const auto &entry : M->getGlobalEntries()) {
            const Function *F = dyn_cast<Function>(entry.get());
            
            // Check for LLVM IR function with given name and call it
            std::string fnName(llvmIR.begin(), llvmIR.end() - 1);
            auto llvf = F->getLLVMOptionallyImportedFunction();
            if (llvf) {
                // Found function: call with LLVM IR
                const FunctionType *FTy = llvf->get()->getFunctionType();
                int64_t n = 1;
                for (const auto &arg : F->getArgList()) {
                    const auto argTy = arg->getType()->castTo<LLVMIRFunctionType>();
                    if (!argTy) {
                        printf("Error: Invalid type\n");
                        return EXIT_FAILURE;
                    }
                    
                    n *= argTy->getNumParams();
                }
                
                // Call LLVM IR function
                if (llvm::sys::fs::exists(input)) {
                    llvf = llvmIRFileToFunction(input);
                    if (!llvf) {
                        printf("Error: Invalid file\n");
                        return EXIT_FAILURE;
                    }
                }
                else {
                    llvf = M->getLLVMAttribute(*F, "llvm.function.name", fnName.c_str());
                    if (!llvf) {
                        printf("Error: Invalid function name\n");
                        return EXIT_FAILURE;
                    }
                }
                llvf = M->getLLVMIRFunction(*F, "llvm.function.argtypes", nDistances.data(), (int64_t)n);
                if (!llvf) {
                    printf("Error: Invalid LLVM IR function\n");
                    return EXIT_FAILURE;
                }
            }
            else {
                printf("Warning: Function not found in LLVM IR\n");
            }
        }
        
        // Build LLVM IR with all functions and call LLVM IR function
        auto llvf = M->getLLVMAttribute(*F, "llvm.function.name", fnName.c_str());
        if (!llvf) {
            printf("Error: Invalid function name\n");
            return EXIT_FAILURE;
        }
        
        llvf = M->getLLVMIRFunction(*F, "llvm.function.argtypes", nDistances.data(), (int64_t)n);
        if (!llvf) {
            printf("Error: Invalid LLVM IR function\n");
            return EXIT_FAILURE;
        }
    }
    
    // Convert LLVM IR to BASH code for loop optimization
    std::string output = runOptimization(*M, nDistances);
    if (!output.empty()) {
        printf("BASH:\n%s\n", output.c_str());
    }
    
    // Cleanup: close input file if opened, remove LLVM IR file (if exists) and unlink LLVM IR (if exists)
    fclose(file);
    if (llvmIRFileToFunction != nullptr && llvmIRFileToFunction->get() != nullptr) {
        std::remove(*llvmIRFileToFunction);
        printf("LLVM IR file removed\n");
    }
    
    return EXIT_SUCCESS;
}