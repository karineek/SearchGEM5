
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define INPUT_BUF_SIZE 1024

int main(int argc, char **argv) {
    if (argc != 2 || strcmp(argv[1], "--help") == 0) {
        printf("Usage: %s [options] file\n", argv[0]);
        return 0;
    }

    char input_buffer[INPUT_BUF_SIZE]; // pre-allocated buffer for input
    size_t read_size = 0;
    FILE *file = fopen(argv[1], "r"); // open file for reading with binary mode
    if (!file) {
        printf("Error: unable to open %s\n", argv[1]);
        return 1;
    }

    while (read(0, input_buffer + read_size, INPUT_BUF_SIZE - read_size) != 0 && read_size < INPUT_BUF_SIZE) { // read input until EOF or buffer is full
        read_size += fread(input_buffer + read_size, 1, INPUT_BUF_SIZE - read_size, file); // read and append to buffer
    }

    if (file != stdin || !file) { // check if input was from standard input or not
        printf("Error: invalid input type\n");
        return 1;
    }

    printf("%.*s", INPUT_BUF_SIZE - read_size, input_buffer);

    fclose(file); // close file after reading

    char output_buffer[INPUT_BUF_SIZE]; // pre-allocated buffer for output

    if (!strcmp(argv[2], "-")) { // ignore output option
        return 0;
    }

    FILE *output_file = fopen(argv[2], "w"); // open output file for writing with text mode
    if (!output_file) {
        printf("Error: unable to create %s\n", argv[2]);
        return 1;
    }

    write(0, output_buffer, INPUT_BUF_SIZE); // write output buffer to file

    fclose(output_file); // close output file after writing

    return 0;
}