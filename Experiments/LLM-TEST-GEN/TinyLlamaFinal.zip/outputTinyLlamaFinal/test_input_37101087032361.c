
#include <stdio.h>
#include <unistd.h>

int main() {
  char argv[1024]; // maximum args allowed by BASH
  
  // prompt user to input a command
  while (getchar() != '\n') {}
  printf("Enter a command: ");
  
  // read input from stdin
  fgets(argv, sizeof(argv), stdin);
  
  // split arguments based on space and comma delimiter
  char *args[256];
  int i = 0;
  while (isspace(*argv)) {
    args[i++] = argv++;
  }
  
  // call exec() with command as argument and input arguments as default
  if (!execve(argv[0], args, NULL, NULL) < 0) {
    printf("Error: %s\n", strerror(errno));
    return -1;
  }
  
  // prompt user to enter another command (if there is one)
  while (getchar() != '\n') {}
  printf("Enter a command: ");
  
  // read input from stdin
  fgets(argv, sizeof(argv), stdin);
  
  return 0;
}