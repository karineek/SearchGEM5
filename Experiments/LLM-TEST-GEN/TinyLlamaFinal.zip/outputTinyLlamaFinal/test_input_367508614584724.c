
#include <stdio.h>
#include <stdlib.h>
#include <string.h> // for memcpy()

// Define a function that takes an array of strings as input and returns its sorted version using the quick sort algorithm
int* quickSort(int* arr, int size) {
    if (size == 0 || size == 1) return arr; // Empty/singleton array or single element not acceptable for sorting
    
    int* pivot = arr + (size / 2); // Pick the middle element as the pivot
    quickSort(arr, size-1);           // Sort remaining elements in ascending order
    quickSort(arr+1, size-1);         // Sort remaining elements in descending order
    
    int* sorted = arr + (size/2) - 1; // Pointer to end of sorted array
    while (sorted < pivot) {          // Loop until end of the sorted array is reached
        *sorted = arr[++sorted];       // Swap elements in sorted array
    }
    
    return sorted + 1;                 // Return pointer to next element in unsorted array
}

// Main program that prompts user for input and calls quickSort() function
int main(void) {
    int size;
    char* argv[3]; // Define three arguments: the array of strings, the string indicating the optimization/format type (e.g., "-h" for human-readable output or "--daily" for daily format), and the flag indicating whether to optimize for specific architectures/formats (e.g., "yes" for all architectures and formats)
    if ((size = getarg(2, argv)) < 1 || size > 3 || strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "--daily") == 0) {
        fprintf(stderr, "Error: Invalid input.\n");
        return 1; // Exit program with error message if invalid input is detected
    }
    
    int* arr = NULL; // Prevent memory leak when the program crashes
    char format[256]; // Prevent memory leak when the program crashes
    switch (strcmp(argv[1], "-h")) {
        case 0: // Humans can read this output format (e.g., "--daily", "--hourly")
            strcpy(format, "-h");
            break;
        
        case 'y': // This flag indicates that the program should optimize for specific architectures/formats
            strcpy(format, "-daily");
            break;
        
        default: // Invalid option/flag combination (e.g., "-h" and "--daily", "--hourly" and "-y")
            fprintf(stderr, "Error: Invalid input.\n");
            return 1; // Exit program with error message if invalid input is detected
    }
    
    arr = quickSort(strtol(argv[2], NULL, 0), atoi(argv[3]));
    printf("%s\n", format); // Print sorted array in specified format (e.g., "-h" for human-readable output, "--daily" for daily format)
    
    return 0; // Exit program with success status
}