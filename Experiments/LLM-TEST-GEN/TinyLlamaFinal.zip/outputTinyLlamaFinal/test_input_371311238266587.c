
#include <stdio.h>
#include <stdlib.h> /* for rand() */
#include "utils.h"  /* for fgetpos() */

int main(int argc, char *argv[]) {
    FILE *f = fopen(argv[1], "r");
    if (!f) {
        perror("Failed to open input file\n");
        exit(EXIT_FAILURE);
    }
    
    int r; /* for read() */
    r = fgetpos(fileno(f), &pfh);
    if (r < 0) {
        perror("Failed to get file position\n");
        exit(EXIT_FAILURE);
    }
    
    char buf[128]; /* for read() */
    while ((r = read(fileno(f), buf, sizeof(buf))) > 0) {
        printf("%s", buf);
    }
    
    fclose(f);
    return 0;
}