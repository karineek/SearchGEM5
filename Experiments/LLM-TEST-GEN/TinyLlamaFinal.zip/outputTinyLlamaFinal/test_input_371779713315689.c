
   #include <stdio.h>
   #include <stdlib.h>
   
   int main(int argc, char *argv[]) {
       if (argc != 2) {
           fprintf(stderr, "Usage: %s FILE\n", argv[0]);
           return EXIT_FAILURE;
       }
       return runFile(argv[1]);
   }
   
   int runFile(char *filename) {
       FILE *file = fopen(filename, "r");
       if (!file) {
           perror("Error: Failed to open file");
           exit(EXIT_FAILURE);
       }
       char buffer[1024];
       while (fgets(buffer, sizeof(buffer), file)) {
           puts(buffer);
       }
       fclose(file);
       return 0;
   }