
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void display_help(void) {
    printf("Usage:\n");
    printf("  %s [OPTION]...\n", argv[0]);
    printf("Options:\n");
    printf("  -a                   Enable Inlining optimizations.\n");
    printf("  -c                   Use Statical analysis in BASH.\n");
    printf("  -h                   Display this help and exit.\n");
}

int main(int argc, char *argv[]) {
    int c;
    while ((c = getopt(argc, argv, "a:ch")) != -1) {
        switch (c) {
            case 'a':
                printf("Inlining optimizations enabled.\n");
                break;
            case 'c':
                printf("Statical analysis in BASH enabled.\n");
                break;
            case 'h':
                display_help();
                return 0;
            default:
                printf("Invalid option\n");
                return 1;
        }
    }
    
    if (argc < 2) {
        printf("No command specified.\n");
        display_help();
        return 1;
    }
    
    char *cmd = argv[0];
    int len = strlen(cmd);
    if (len == 1 || strcmp(argv[0], "bash") == 0) {
        cmd++;
        while (*cmd && isspace(*cmd)) cmd++;
        cmd += strcspn(cmd, "\t ");
        
        int I = 0;
        while (isalnum(*cmd + I) || *cmd + i == ' ') {
            I++;
        }
    } else if (strcmp(argv[0], "sh") == 0) {
        cmd += strcspn(argc > 1 ? argv[1] : "", "/\\\t ");
        
        int I = 0;
        while (isalnum(*cmd + I) || *cmd + i == ' ') {
            I++;
        }
    } else {
        printf("Unknown command specified.\n");
        display_help();
        return 1;
    }
    
    char *input = malloc(strlen(cmd) * sizeof(char));
    strcpy(input, cmd);
    
    int i = 0;
    while (isalnum(*input + i) || *input + i == ' ') {
        i++;
    }
    
    FILE *f = fopen(input, "r");
    if (!f) {
        printf("Error opening input file for reading.\n");
        return 1;
    }
    
    char line[32];
    while (fgets(line, sizeof(line), f)) {
        int j = 0;
        while (isalnum(*line + j) || *line + j == ' ') {
            j++;
        }
        
        if (j < strlen(line) - 1 && line[j] != '\n' && line[j] != '\r') {
            printf("Error parsing input.\n");
            return 1;
        }
    }
    
    fclose(f);
    
    char *output = malloc(strlen(input) + strlen(line) + 2);
    snprintf(output, strlen(input) + strlen(line) + 2, "%s%s", input, line);
    
    printf("Input: %s\n", output);
    
    char *result = system(output);
    free(input);
    
    if (result == 0) {
        printf("Successfully executed command.\n");
    } else {
        printf("Error executing command.\n");
    }
    
    return result;
}