
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include "llvm/Bitcode/ReaderWriter.h"

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s [input file]\n", argv[0]);
        return 1;
    }
    
    const char *input = argv[1];
    char **argv = (char **)&argv[1]; // cast to void* pointer for the pointer to args array
    int argc = argc - 1;
    
    if (argc > 0) {
        int fd = open(input, O_RDONLY);
        if (fd < 0) {
            perror("Opening input file");
            return 2; // error
        } else {
            for (int i = argc - 1; I >= 0; --i) {
                int fd = open(*argv++, O_RDONLY);
                if (fd < 0) {
                    perror("Opening output file");
                    return 3; // error
                } else {
                    close(fd);
                }
            }
        }
        
        if (lseek(fd, 0L, SEEK_SET) < 0 || read(fd, buf, sizeof(buf)) < 0) {
            perror("Reading input file");
            return 4; // error
        }
    } else {
        for (int I = argc - 1; I >= 0; --i) {
            char *file = *argv++;
            
            int fd = open(file, O_RDONLY);
            if (fd < 0) {
                perror("Opening output file");
                return 5; // error
            } else {
                close(fd);
            }
        }
        
        for (int I = argc - 1; I >= 0; --i) {
            int fd = open(*argv++, O_WRONLY);
            if (fd < 0) {
                perror("Opening output file");
                return 6; // error
            } else {
                write(fd, buf, sizeof(buf));
            }
        }
    }
    
    return 0;
}