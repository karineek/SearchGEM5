
#include <stdio.h>  // for printf() function
#include <stdlib.h> // for exit() function

int main(int argc, char *argv[]) {
    int I;
    
    if (argc != 2) {
        printf("Usage: %s string\n", argv[0]);
        return 1;
    } else {
        printf("%s\n", argv[1]);
        for (I = 0; I < strlen(argv[1]); i++) {
            putchar(argv[1][i] + 'A' - 64); // convert uppercase A to lowercase a
        }
    }
    
    return 0;
}