
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(int argc, char* argv[]) {
    int fd;
    char buf[4096];

    if (argc != 2) {
        printf("Usage: %s INPUT_FILE\n", argv[0]);
        return 1;
    }

    // Open input file and read its content to buffer
    fd = open(argv[1], O_RDONLY);
    if (fd == -1) {
        perror("Open input file failed");
        return 2;
    }
    
    int bytesRead = 0;
    while (bytesRead < 4096 && read(fd, buf, sizeof(buf)) >= 0) {
        bytesRead += sizeof(buf);
    }

    // Close input file and file descriptor
    close(fd);
    
    if (bytesRead == -1) {
        perror("Read input file failed");
        return 3;
    }

    buf[bytesRead] = '\0';

    // Perform the profile-guiaded optimization and output to stdout
    int rv = profileguidedoptimizations(buf, strlen(buf), &mdl_info);
    
    if (rv == -1) {
        printf("Profile-GUI: Optimization failed\n");
        return 4;
    }

    // Output optimization results to stdout
    printf("Profile-GUI: Optimized code:\n%s\n", buf);
    
    // Close the optimized file and close all file descriptors
    close(fd);

    return 0;
}