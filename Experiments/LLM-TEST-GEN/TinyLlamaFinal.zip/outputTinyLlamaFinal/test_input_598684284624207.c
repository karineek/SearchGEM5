
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    FILE *file = fopen(argv[1], "r");
    if (!file) {
        perror("fopen");
        return EXIT_FAILURE;
    }
    
    char buffer[2048];
    size_t read = 0;
    while (read != 0 && fread(buffer, 1, sizeof(buffer), file) > 0) {
        printf("%s", buffer);
        read += fread(buffer, 1, sizeof(buffer), file);
    }
    
    fclose(file);
    return EXIT_SUCCESS;
}