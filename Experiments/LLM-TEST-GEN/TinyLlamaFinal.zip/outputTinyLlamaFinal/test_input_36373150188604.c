
#include <stdio.h>

int main() {
    int argc;
    char **argv;
    
    argc = getarg(2, &argv);
    
    if (argc == 1) {
        printf("%s\n", argv[0]); // example input: echo
        return 0;
    } else {
        printf("Usage: %s <input file>\n", argv[0]);
        return -1;
    }
}

int getarg(int n, char **argv) {
    int i = 0;
    
    if (n > 2 || argv == NULL) {
        printf("Invalid arguments.\n");
        return -1;
    } else if (n == 1) {
        *argv++ = "echo";
        *(argv + 1) = argv[0]; // use the first argument as input file name
        ++argc;
        printf("Using input file %s.\n", argv[0]);
    } else {
        for (i = 1; i < n; i++) {
            *argv++ = argv[i];
        }
        --argc;
    }
    
    return argc;
}