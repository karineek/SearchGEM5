
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <vector>
using namespace std;

const double EPSILON = 1e-16; // Smallest acceptable difference for comparisons
const int MAX_ITERATIONS = 5000;

double dbl_exp(double x) { return exp(x); }

// Function to calculate ln(b/a) for a given ratio between the base and exponent terms.
double ldblexp(double b, double a, double e) {
    int i = 0;
    while (i < MAX_ITERATIONS && fabs(b * pow(10, a + i * 2)) > EPSILON)
        i++;
    if (!i || i == MAX_ITERATIONS) { // If we couldn't find a solution
        printf("Could not find an ln(b/a) value for %g and %g.\n", b, a);
        return 0;
    }
    return (b / (double)i * pow(10.0, e + i * 2)); // Calculate ln(b/a) using the solution
}

int main() {
    double x = atof(argv[1]); // Prompt user for input, set argv to first argument
    
    if (x == 0.0 || x <= 0.0) {
        printf("Invalid input: must be greater than or equal to 0.\n");
        return -1; // Exit program with error code
    }
    
    double lnba = ldblexp(x, 1, 6); // Calculate log(b/a) using formula
    
    if (fabs(lnba - log(x)) > EPSILON || fabs(lnba - sqrt(ln(2 * x))) > EPSILON) { // Check for error in calculation
        printf("Error: invalid values provided. Please enter a valid number.\n");
        return 0; // Exit program with error code
    } else {
        printf("%lf\n", lnba); // Display the log of the given number
    }
    
    return 0; // Exit program
}