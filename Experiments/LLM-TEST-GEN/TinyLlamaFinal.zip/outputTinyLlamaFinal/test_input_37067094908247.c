
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv) {
    float num1 = 0.0f;
    float num2 = 0.0f;
    long double output = 0.0LDBL_MAX;
    
    if (argc < 3 || !isdigit(argv[1][0])) { // check for input data type
        printf("Usage: %s [input file]\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    int inputFile = atoi(argv[1]);
    
    FILE* fp = fopen(argv[2], "r");
    
    if (!fp) { // check for file opening error
        printf("Error: Could not open input file \"%s\"\n", argv[2]);
        return EXIT_FAILURE;
    }
    
    while (fgets(buffer, sizeof(buffer), fp)) { // read lines from the file
        int num1Int = atoi(buffer);
        
        if (num1Int < 0) { // check for negative input
            printf("Error: Input number must be positive\n");
            return EXIT_FAILURE;
        }
        
        float num1Float = (float)num1Int;
        
        if (output < num1Float) { // check for overflowing the output buffer
            printf("Overflow: %lf >= %f\n", num1Float, output);
            return EXIT_FAILURE;
        }
        
        num2 = num1Float;
    }
    
    fclose(fp); // close file
    
    output += powl(num1, num2) / logl(output);
    
    printf("Output: %.3Lf\n", output);

    return EXIT_SUCCESS;
}