
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s [command]\n", argv[0]);
        return EXIT_FAILURE;
    } else {
        int ret = system(argv[1]);
        if (ret == -1) {
            perror("Error during execution");
            return EXIT_FAILURE;
        }
        return 0;
    }
}