
#include <stdio.h>
#include <unistd.h>  // To get the current process id (PID)

// Inline functions:
void inline_function() {
    printf("I'm a function inlined\n");
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s [FILE]\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    // Open the file as read-only and threaded with 1 worker:
    int fd = open(argv[1], O_RDONLY | O_THREAD_ID, 0);
    if (fd < 0) {
        perror("open");
        return EXIT_FAILURE;
    }
    
    // Inline functions in the thread:
    pid_t pid = getpid();  // Get current process id (PID)
    pthread_t tid;           // Create a new thread with PID as argument
    if (!pthread_create(&tid, NULL, inline_function, &pid)) {
        perror("pthread_create");
        return EXIT_FAILURE;
    }
    
    // Wait for the thread to exit:
    pthread_join(tid, NULL);
    
    printf("Inlined function executed on pid %d\n", pid);
    
    return 0;
}