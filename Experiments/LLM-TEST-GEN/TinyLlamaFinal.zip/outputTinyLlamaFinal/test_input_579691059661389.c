
#include <stdio.h>
#include <stdlib.h>

#define MAX 1024 // maximum length of input string

int main(int argc, char *argv[]) {
    const char *input = (argc > 1) ? argv[1] : "input.txt";
    unsigned long int result = atol(input);
    
    printf("Result: %lu\n", result);
    
    return 0;
}