
#include <stdio.h>

int main(int argc, char* argv[]) {
    if (argc != 1) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }
    
    FILE *input = fopen(argv[1], "r");
    if (!input) {
        perror("Failed to open input file for reading");
        return 2;
    }
    
    char line[1024]; // maximum size of one line
    int counter = 0;
    while (fgets(line, sizeof(line), input)) {
        printf("%d: %s\n", counter++, line);
    }
    
    fclose(input);
    
    return 0;
}