
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int I = 0;
    char buffer[1024];
    
    if (argc != 2) {
        printf("Usage: %s [command]\n", argv[0]);
        return 1;
    }
    
    FILE *inputFile = fopen(argv[1], "r");
    
    for (I = 0; I < strlen(buffer); i++) {
        if ((fscanf(inputFile, "%c", &buffer[i]) != 1) || (buffer[i] == '\n') ) {
            printf("Error reading input file %s. Exiting...\n", argv[1]);
            return 1;
        }
    }
    
    fclose(inputFile);
    
    char outputBuffer[1024];
    
    printf("%s", buffer); // Output to stdout
    
    while ((fgets(outputBuffer, sizeof(outputBuffer), stdin)) != NULL) {
        printf("%s", outputBuffer); // Output to screen
    }
    
    return 0;
}