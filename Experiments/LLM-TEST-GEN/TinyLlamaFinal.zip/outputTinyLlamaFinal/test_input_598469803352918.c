
#include <stdlib.h> /* for malloc/free */
#include <stdio.h>  /* for fprintf, printf */
#include "atlas-api.h"

/* Define a function to be called by the profiler when profiling is enabled */
static double func(double x) {
    printf("Call to profilable function: %f\n", x);
    return x * 2;
}

/* Main program starts here */
int main(void) {
    int argc = 1; /* Assume an argument */
    char **argv = malloc(argc * sizeof(char *)); /* Allocate memory for the arguments */
    
    argv[0] = "myprog"; /* Set the first argument to our program name */
    argv[1] = (char *)&argc; /* Add the program name as the second argument */
    argv += 2; /* Increment pointer after second argument */
    
    atlas_initialize(argc, argv); /* Initialize the profiler by passing the arguments */
    
    return atlas_start(0 /* Optional argument to tell the profiler to start immediately */); /* Start the profiling process */
}