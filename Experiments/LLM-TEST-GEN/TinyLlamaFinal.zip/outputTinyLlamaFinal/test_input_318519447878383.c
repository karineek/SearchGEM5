
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#define BIT_SIZE 32 /* number of bits */

int main(int argc, char *argv[]) {
    int a = atoi(argv[1]), b = atoi(argv[2]);
    int res = (a & b);

    printf("Bitwise AND of %d and %d: %d\n", a, b, res);

    return 0;
}