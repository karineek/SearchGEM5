
#include <stdio.h>
#include <time.h>
#include "profile.h" // define profile variables and functions

int main(int argc, char *argv[]) {
  int profile_level = PROFILE_LEVEL_NONE;
  int profile_interval = 1000; // in microseconds
  float profile_percentage = 1.0f; // percentage of code to optimize
  char *optimal_code = NULL;
  char **optimized_codes = NULL;

  if (argc > 1) {
    getarg(argc, argv, argv + 1); // parse command-line arguments
    if (!profile.initialize(PROFILE_LEVEL_NONE, PROFILE_INTERVAL_1000, NULL)) {
      printf("Profile initialization failed\n");
      exit(EXIT_FAILURE);
    }
  }

  for (int I = 1; I < argc; i++) {
    const char *const argv_i = argv[i];
    if (strcmp(argv_i, "-p") == 0 || strcmp(argv_i, "--profile") == 0) {
      profile_interval = atoi(argc > i + 1 ? argv[++i] : NULL); // read interval from command-line
      if (!profile.setLevel(PROFILE_LEVEL_NONE)) {
        printf("Profile set to level %s\n", PROFILE_LEVEL_NONE == PROFILE_LEVEL_NONE ? "default" : argv[i]);
      } else {
        printf("Profile initialization failed\n");
        exit(EXIT_FAILURE);
      }
    } else if (strcmp(argv_i, "-o") == 0 || strcmp(argv_i, "--output") == 0) {
      profile_level = PROFILE_LEVEL_NONE; // clear previous level
      if (!profile.setLevel(PROFILE_LEVEL_NONE)) {
        printf("Profile set to level %s\n", PROFILE_LEVEL_NONE == PROFILE_LEVEL_NONE ? "default" : argv[i]);
      } else {
        printf("Profile initialization failed\n");
        exit(EXIT_FAILURE);
      }
    } else if (strcmp(argv_i, "-c") == 0 || strcmp(argv_i, "--code") == 0) {
      int code_index = atoi(argc > i + 1 ? argv[++i] : NULL); // read index from command-line
      if (!optimized_codes) optimized_codes = (char **)calloc(MAX_NUM_CODES, sizeof(char *));
      if (!optimized_codes[code_index]) {
        printf("Code %d not available\n", code_index);
        exit(EXIT_FAILURE);
      } else {
        optimal_code = optimized_codes[code_index];
      }
    } else if (strcmp(argv_i, "-f") == 0 || strcmp(argv_i, "--output-file") == 0) {
      const char *const filename = argv[++i];
      optimized_codes = (char **)calloc(1, MAX_NUM_CODES + 1);
      if (!optimized_codes) {
        printf("Failed to allocate memory for output code\n");
        exit(EXIT_FAILURE);
      } else if (!profile.setLevel(PROFILE_LEVEL_NONE)) {
        printf("Profile set to level %s\n", PROFILE_LEVEL_NONE == PROFILE_LEVEL_NONE ? "default" : argv[i]);
      } else {
        for (int I = 0; I < MAX_NUM_CODES + 1; i++) optimized_codes[i] = NULL;
        if (!profile.getCodes(filename, optimal_code)) {
          printf("Error: couldn't get code from %s\n", filename);
          exit(EXIT_FAILURE);
        } else {
          for (int I = 0; I < MAX_NUM_CODES + 1; i++) optimized_codes[i] = optimal_code;
        }
      }
    } else if (strcmp(argv_i, "--help") == 0 || strcmp(argv_i, "-h") == 0) {
      printf("Usage: %s [OPTIONS]\n", argv[0]);
      printf("\n\n%s\n", USAGE);
    } else if (strcmp(argv_i, "--version") == 0 || strcmp(argv_i, "-v") == 0) {
      printf("Profile-Guipped Optimization %s\n", PROFILE_VERSION_STRING);
    } else {
      printf("Invalid option `%s'\n", argv_i);
      exit(EXIT_FAILURE);
    }
  }

  if (profile.initialize(PROFILE_LEVEL_NONE, PROFILE_INTERVAL_1000, NULL) == EXIT_SUCCESS) {
    for (int I = 0; I < MAX_NUM_CODES + 1; i++) optimized_codes[i] = NULL;
    if (!profile.getCodes(filename, optimal_code)) {
      printf("Error: couldn't get code from %s\n", filename);
      exit(EXIT_FAILURE);
    } else {
      for (int I = 0; I < MAX_NUM_CODES + 1; i++) optimized_codes[i] = optimal_code;
    }
  }

  // Display optimized code if available
  if (optimized_codes) {
    printf("Optimized code:\n");
    for (int I = 0; I < MAX_NUM_CODES + 1; i++) printf("%s %d: %.2f%%\n", profile.getLevel(i), i, profile.percentage(i) * 100.0);
    if (!optimized_codes[MAX_NUM_CODES]) {
      printf("Optimized code not available\n");
    } else {
      for (int I = 0; I < MAX_NUM_CODES + 1; i++) printf("%s %d: %.2f%%\n", profile.getLevel(i), i, profile.percentage(i) * 100.0);
    }
  }

  return EXIT_SUCCESS;
}