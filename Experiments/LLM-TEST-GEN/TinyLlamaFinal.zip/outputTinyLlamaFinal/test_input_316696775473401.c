
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* This function defines a recursive `cbrt` function */
static double cbrt(double x, int base) {
    if (base == 0) return 1. / x;
    
    int i = floor(log(x, pow(2, -base)) + 1);
    return x * cbrt(pow(2, -i), base - 1) / base;
}

/* The `main` function is the entry point for this program */
int main(void) {
    /* Function pointer to call when a Bash script is being executed */
    const char *cmd_pattern[] = { "BASH", "\0" };
    
    int argc, i;
    char **argv;
    
    for (i = 0; i < sizeof(cmd_pattern) / sizeof(cmd_pattern[0]); ++i) {
        argv = getopt(argc, argv, cmd_pattern[i]);
        if (!argv) exit(-1);
        
        const char *program = argv[0];
        
        /* Test whether the current command is a Bash script */
        if (strcmp(program, program + strlen(program)) != 0) {
            fprintf(stderr, "Error: \"%s\" is not a valid Bash script\n", program);
            return -1;
        }
        
        /* Test whether this command matches the specified pattern */
        if (strcmp(argv[1], cmd_pattern[i]) != 0) {
            fprintf(stderr, "Error: %s is not a valid Bash script for \"%s\"\n", argv[1], program);
            return -1;
        }
        
        printf("ScalaR Optimizations optimizer and serialization system:\n");
        printf("===========================================\n");
    }
    
    /* Call the ScalaR Optimizations and Serialization system */
    return scalaroptimizations(argc, argv);
}