
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    int n; // number of elements
    float *arr; // array of floats
    
    if (argc != 2) { // check the input count
        printf("Usage: %s <array_name>\n", argv[0]);
        return 1;
    }
    
    n = atoi(argv[1]);
    
    arr = (float*)malloc(sizeof(float) * n); // allocate memory for array
    if (!arr) { // handle memory allocation error
        printf("Error: unable to allocate memory for array\n");
        return 2;
    }
    
    // read in the input file and convert it into floats
    FILE* f = fopen(argv[1], "r");
    if (!f) { // handle file open error
        printf("Error: unable to open input file %s\n", argv[1]);
        return 3;
    }
    
    for (int I = 0; I < n; i++) {
        float x; // read in next number
        
        if (!fscanf(f, "%f", &x)) { // handle read failure
            printf("Error: unable to read input file\n");
            fclose(f);
            return 4;
        }
        
        arr[i] = x; // store in array
    }
    
    fclose(f);
    
    return 0;
}