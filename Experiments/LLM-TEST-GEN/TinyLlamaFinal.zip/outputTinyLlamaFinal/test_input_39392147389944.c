
cat input.txt | ./my_program