
#include <stdio.h> /* for printf() */

#define BASH_SHELL  "bash"

int main(int argc, char *argv[]) {
    const char *program = BASH_SHELL;
    
    if (argc != 1 || strcmp(argv[0], program) == 0) { /* only one argument */
        printf("%s: Invalid command. Usage: %s <command>\n", BASH_SHELL, argv[0]);
        return 1;
    }
    
    int status = system(argv[0] + strlen(argv[0])); /* run the executable */
    if (status != 0) {
        perror("Error running BASH");
        return 2;
    } else { /* success */
        printf("%s: %s\n", BASH_SHELL, argv[1]);
        return 0;
    }
}