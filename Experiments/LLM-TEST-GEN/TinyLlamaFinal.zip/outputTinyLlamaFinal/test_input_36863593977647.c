
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    FILE *file = fopen(argv[1], "r");
    
    // Check if the input file is valid
    if (file == NULL) {
        perror("Could not open file");
        return 1;
    }
    
    // Open an output file
    FILE *output = fopen("output.txt", "w+");
    
    // Read the input file content and write it to the output file
    char buffer[1024];
    fread(buffer, 1, sizeof(buffer), file);
    fwrite(&buffer[0], 1, sizeof(buffer), output);
    
    // Close files
    fclose(file);
    fclose(output);
    
    return 0;
}