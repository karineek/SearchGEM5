
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    char *argv[1];
    argv[0] = strdup("");  // empty command line argument

    for (int I = 1; I < sizeof(argv) / 2; i++) {
        int len = strlen(argv[i]);
        char *cmd = malloc(strlen(argv[i]) + 5);
        sprintf(cmd, "%s %s", argv[0], argv[i]);
        printf("%s\n", cmd);
    }

    return 0;
}