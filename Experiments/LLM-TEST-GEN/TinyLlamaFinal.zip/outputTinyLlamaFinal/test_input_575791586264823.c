
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    int argc;
    char *argv[5] = {"input.txt", NULL}; // Add the filename as an argument
    
    if (argc < 2) { // Check if input file is given
        fprintf(stderr, "Error: Invalid input file\n");
        return 1;
    }
    
    char buf[5];
    if (read(fileno(stdin), buf, sizeof(buf)) < 0) { // Read the file and exit with error code if needed
        perror("Error: Could not read input\n");
        return 1;
    }
    
    puts(buf); // Display the content of the input file as a message
    
    return 0;
}