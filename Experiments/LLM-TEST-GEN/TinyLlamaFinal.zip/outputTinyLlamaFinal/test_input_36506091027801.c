
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
  FILE *llvm_ir = fopen(argv[1], "r");
  if (!llvm_ir) {
    printf("Error: Cannot open LLVM IR file '%s'.\n", argv[1]);
    exit(EXIT_FAILURE);
  }
  char buffer[1024];
  size_t len = fread(buffer, sizeof(char), 1024, llvm_ir);
  if (!len) {
    printf("Error: Cannot read LLVM IR file '%s'.\n", argv[1]);
    exit(EXIT_FAILURE);
  }
  fclose(llvm_ir);

  // Create a new BASH shell and execute the input provided
  char* bash_command = malloc(sizeof(char) * 256);
  snprintf(bash_command, sizeof(bash_command), "bsh %s", argv[2]);
  execv(bash_command, (char **) NULL);

  return 0;
}