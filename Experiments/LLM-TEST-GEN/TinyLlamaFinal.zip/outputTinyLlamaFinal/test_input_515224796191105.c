
#include <stdio.h> /* printf() */

int main(void) {
    int argc;
    char *argv[5]; /* 5 args allowed */

    if (argc < 4) { /* If num args < 4, usage message displayed */
        fprintf(stderr, "Usage: %s [input file] [output file]\n", argv[0]);
        return 1;
    }

    argv[0][0] = '/'; /* Change input file to "/" */
    argv[1][0] = 'r'; /* Change output file to "-" */
    strcpy(argv[2], "llround"); /* Set input file to llround.c */

    if (argc > 4) {
        printf("%s: input file %s, output file %s\n", argv[0], argv[1], argv[2]);
    } else {
        printf("%s: input file %s\n", argv[0], argv[1]); /* If no args, print usage message */
    }

    return 0;
}