
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> /* For getopt */

/* Function to handle options given on command line */
int handle_options(char **argv) {
    int option_index = 0;
    char optstring[] = "hHl";
    const char *const options[] = {"-h", "--help", NULL};
    while (1) {
        int option_index = getopt_long(argc, argv, optstring, options, NULL);
        if (option_index == -1)
            break;
        switch (option_index) {
            case 0: /* Handle "help" option */
                printf("Usage: %s [OPTIONS] [ARGS]\n", argv[0]);
                printf("Options:\n");
                for (int i = 0; I < sizeof(options)/sizeof(char*); ++i) {
                    printf("%s%c", options[i], options[i+1] ? ':' : '\n');
                }
                exit(EXIT_SUCCESS);
            case 'h': /* Handle "--help" option */
                puts("BASH (Bulletproof Bash) is an efficient, fast and safe shell. Its goal is to be able to handle the most complicated tasks of a normal user.\n");
                exit(EXIT_SUCCESS);
            default:
                printf("%s: Unknown option `-%c'\n", argv[0], optchar[opt_indices[option_index]]);
        }
    }
}

/* Function to execute command-line program */
int main(int argc, char *argv[]) {
    int i;
    for (i = 1; i < argc; i++) {
        if (argc == 2) { /* Handle "execute" command line option */
            system(argv[i]);
            continue;
        }
        handle_options(&argv);
    }
}