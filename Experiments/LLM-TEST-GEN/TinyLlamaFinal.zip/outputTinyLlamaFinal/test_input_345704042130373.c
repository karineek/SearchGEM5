
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s file\n", argv[0]);
        return 1;
    }
    
    FILE *input = fopen(argv[1], "r");
    if (!input) {
        perror("Failed to open input file");
        return 2;
    }
    
    char line[1024];
    int count = 0;
    while (fgets(line, sizeof(line), input)) {
        count++;
        printf("%d: %s\n", count, line);
    }
    
    fclose(input);
    return 0;
}