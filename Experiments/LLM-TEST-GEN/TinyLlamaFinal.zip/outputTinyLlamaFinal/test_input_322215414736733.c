
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    int argc;
    char *argv[10];

    argv[0] = "/usr/bin/bsh";
    argv[1] = "arg1";
    argv[2] = NULL; // skip arg2
    argc = 3;

    // input handling
    while(argc > 0) {
        if (argv[0][0] == 'a' && argv[0][1] == 'g' && argv[0][2] == '-') {
            printf("Generic selection: %s\n", argv[0]);
            // trigger instrumentation and coverage for this part of the compiler
            char *comp = getenv("BASH_COMMAND");
            if (strcmp(argv[0], comp) != 0) {
                printf("Profile-Guided Instrumentation support: %s\n", argv[0]);
                // trigger instrumentation and coverage for this part of the compiler
                printf("Support for profile-guieded instrumentation optimizations:\n");
            }
        } else if (argv[0][0] == 'p' && argv[0][1] == 'g') {
            printf("Profile-Guided Instrumentation: %s\n", argv[0]);
        } else if (argv[0][0] == '-' && argv[0][1] == 't') {
            printf("Generic selection: %s\n", argv[0]);
        } else {
            printf("Unrecognized argument: %s\n", argv[0]);
        }
        argc--;
    }

    return 0;
}