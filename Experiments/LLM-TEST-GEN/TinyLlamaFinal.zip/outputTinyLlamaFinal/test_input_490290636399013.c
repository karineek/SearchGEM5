
#include <stdio.h>

int main(int argc, char *argv[]) {
    int num;
    
    if (argc != 2) {
        printf("Usage: %s [number]\n", argv[0]);
        return 1;
    }
    
    num = atoi(argv[1]);
    
    if (num < 0 || num > 9) {
        printf("Invalid input: must be a positive integer\n");
        return 1;
    }
    
    return 0;
}