
#include <stdio.h>
#include <stdlib.h> // for exit() function

// Function to check input arguments
int validate_argc(int argc, char *argv[], int min, int max) {
    if (argc < min || argc > max) {
        printf("Error: Invalid number of arguments.\n");
        return 1;
    } else {
        return 0;
    }
}

int main(int argc, char *argv[]) {
    // Check input parameters
    if (!validate_argc(argc, argv, 2, 5)) {
        printf("Error: Invalid number of arguments.\n");
        exit(1);
    }
    
    // Perform WPA and COP
    int ret = perform_wpa_and_cop(argv[1], argv[2]);
    
    if (ret != 0) {
        printf("Error: Program failed to run.\n");
        exit(1);
    }
    
    return 0;
}