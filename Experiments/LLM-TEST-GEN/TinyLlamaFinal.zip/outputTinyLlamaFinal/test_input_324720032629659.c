
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s [input.txt]\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    char input[1024];
    if (!read(STDIN_FILENO, input, sizeof(input)) || strcmp(argv[1], input) == 0) {
        printf("Input is a match!\n");
        return EXIT_SUCCESS;
    } else {
        printf("Input does not match!\n");
        return EXIT_FAILURE;
    }
}