
#include <stdio.h> /* standard input/output library */
#include <stdlib.h> /* standard library */

int main(int argc, char *argv[]) {
    if (argc != 2) { /* check number of arguments */
        fprintf(stderr, "Usage: %s [input file]\n", argv[0]);
        exit(1);
    }
    FILE *f = fopen(argv[1], "r"); /* open input file for reading */
    if (!f) {
        fprintf(stderr, "Cannot open file: %s\n", strerror(errno));
        exit(2);
    }
    int line_num = 0;
    while (fscanf(f, "%d %s", &line_num, buf) == 2) { /* read a line and its name */
        if (!strcmp(buf, "#")) { /* comment line */
            fprintf(stderr, "Comment line found: %d\n", line_num);
        } else if (strncmp(buf, "$#", 3) == 0 && strlen(buf) == 4) { /* arithmetic constant expression */
            const char *exp = buf + 3; /* get exponent */
            int a, b; /* coefficients */
            while (*exp != ' ') { /* skip spaces */
                exp++;
            }
            if (!strcmp(buf, "+") || !strcmp(buf, "-")) { /* add/subtract sign */
                a = atoi(&exp[1]);
                b = atoi(&exp[2]);
                if (a < 0 && b > 0) { /* add for positive numbers */
                    line_num += 2; /* skip plus sign and add sign, as we're adding */
                } else if (a > 0 && b < 0) { /* substract for negative numbers */
                    a = -a;
                    b = -b;
                } else { /* error or no-op */
                    fprintf(stderr, "Error: arithmetic expression must be either add (+), subtract (-), or constant (%c)\n", exp[0]);
                    exit(3);
                }
            } else if (!strcmp(buf, "*") || !strcmp(buf, "/")) { /* multiply/divide sign */
                a = atoi(&exp[1]);
                b = atoi(&exp[2]);
                if (a < 0 && b > 0) { /* add for positive numbers */
                    line_num += 3; /* skip plus sign and mul sign, as we're multiplying */
                } else if (a > 0 && b < 0) { /* substract for negative numbers */
                    a = -a;
                    b = -b;
                } else { /* error or no-op */
                    fprintf(stderr, "Error: arithmetic expression must be either add (+), subtract (-), or constant (%c)\n", exp[0]);
                    exit(3);
                }
            } else { /* error or no-op */
                fprintf(stderr, "Unknown arithmetic expression: %s\n", buf);
                exit(4);
            }
        } else if (!strcmp(buf, "$")) { /* comment line */
            fprintf(stderr, "Comment line found: %d\n", line_num);
        } else { /* error or no-op */
            fprintf(stderr, "Unknown character: %c\n", buf[0]);
            exit(5);
        }
    }
    fclose(f);
    return 0;
}