
  $ cat input_bash
  echo "Hello, World!"