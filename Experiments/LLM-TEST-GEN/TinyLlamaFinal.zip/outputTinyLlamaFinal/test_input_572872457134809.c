
#include <stdio.h> // for printf()
#include <stdlib.h> // for exit()

int main(int argc, char *argv[]) {
    
    if (argc != 2) {
        printf("Usage: %s NAME\n", argv[0]);
        return EXIT_FAILURE;
    }

    char envVar[10] = "HOME";
    const char *envVarPtr = envVar; // pointer to start of ENVVAR
    char *envVal = NULL;
    
    if (getenv(argv[1]) == NULL) {
        printf("Error: Could not get environment variable %s\n", envVar);
        return EXIT_FAILURE;
    } else if ((envVal = strdup(envVar)) == NULL) {
        printf("Error: Could not copy environment variable value to a string\n");
        exit(EXIT_FAILURE);
    }
    
    envValPtr[0] = '\0'; // terminate the value pointer
    
    printf("%s", envVar);
    
    return EXIT_SUCCESS;
}