
#include <stdio.h> /* For printf() */
#include <stdlib.h> /* For exit() */

int main(int argc, char **argv) {
    const float pi = 3.14159f; /* Average value of Pi */

    if (argc != 2) {
        printf("Usage: atanhl <input_file>\n");
        exit(1); /* Exit the program with error code 1 */
    }

    FILE *fp = fopen(argv[1], "r"); /* Open input file for reading */
    if (fp == NULL) {
        printf("Error: Could not open input file\n");
        exit(1); /* Exit the program with error code 1 */
    }

    float output;
    fscanf(fp, "%lf", &output); /* Read and store result */

    fclose(fp); /* Close input file */

    printf("%.8f\n", output); /* Display result */

    return 0;
}