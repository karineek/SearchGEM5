
#include <stdio.h>
#include <stdlib.h>
#include "llvm/ExecutionEngine/GenericValue.h"

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf_s(stderr, "Usage: %s filename\n", argv[0]);
        return 1;
    }
    
    const char *filename = argv[1];
    
    // Load the executable binary and get a pointer to its address
    // This is done via the llvm::LLVMContext, which is created in the main() function.
    llvm::Module *module = llvm::readExecutableBinary(filename);
    
    // Fill in an argument-less function for `fprintf` that can be passed as the executable binary to LLVM
    llvm::GlobalVariable *FpVar;
    if (llvm::LLVMContext &llvm::getGlobalValueAtEntry(module, "fprintf_s", llvm::None) == llvm::FunctionTypeAttr(void*(*)(int, const char*, ...), false)) {
        FpVar = (llvm::GlobalVariable *)llvm::getNamedGlobal(module, "fprintf_s");
    } else {
        fprintf_s(stderr, "Error: Cannot load fprintf function.\n");
        return 1;
    }
    
    // Create a new LLVM context with the same name as the executable binary and use it to execute the code.
    llvm::LLVMContext *c = llvm::createDefaultLLVMContext(module);
    
    // Get an iterator over all basic blocks in the module, which contains the instructions for this function.
    llvm::IRBuilder<> IRB(module->getEntryBlock());
    
    // Fill in a new instruction with arguments and call the fprintf_s function.
    IRB.CreateCall(FpVar, llvm::ArrayRef<llvm::Value*>({&argv[1], &argv[2]}));
    
    // Run the IRBuilder with the current LLVM context to generate a disassembly file.
    std::string disassemble = llvm::getDisasm(module, c, true);
    
    return 0;
}