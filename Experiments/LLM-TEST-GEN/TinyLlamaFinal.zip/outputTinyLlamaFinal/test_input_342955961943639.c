
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    int i;
    char buf[1024];
    FILE *input = fopen(argv[1], "r"); // input file name (e.g., "input.txt")
    
    if (!input) {
        perror("Error: cannot open input file\n");
        exit(EXIT_FAILURE);
    }
    
    for (i = 0; i < 1024 && fread(buf, sizeof(char), 1, input) >= 1; i++) {} // read at most 1024 bytes from file into buffer
    
    fclose(input);
    
    printf("Enter a string: "); // prompt the user for a string to be read in
    if (!fgets(buf, sizeof(char), stdin)) {
        perror("Error: cannot read input\n");
        exit(EXIT_FAILURE);
    }
    
    buf[sizeof(char) - 1] = '\0'; // terminate string with null character
    
    for (i = 0; i < strlen(buf); i++) {
        if (!isalnum((int)buf[i]) && (buf[i] != '.')) {
            printf("Invalid character at index %d\n", i);
            return EXIT_FAILURE; // exit with error code if invalid character is found
        }
    }
    
    printf("%s\n", buf); // print the string read from file

    return EXIT_SUCCESS; // exit with success code
}