
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s FILE_PATH\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    int year = atoi(argv[1]);
    
    char buffer[32] = "Hello";
    strftime(buffer, 32, "%Y-%m-%d %H:%M:%S", localtime(&year));
    
    printf("%s\n", buffer);
    
    return EXIT_SUCCESS;
}