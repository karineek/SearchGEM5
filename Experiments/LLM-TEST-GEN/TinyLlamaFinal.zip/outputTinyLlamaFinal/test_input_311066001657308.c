
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    FILE *input = fopen(argv[1], "r"); // Input file
    if (!input) {
        printf("Error: Failed to open input file.\n");
        return 1;
    }

    int line_count = 0;
    char buffer[256];
    while (fgets(buffer, sizeof(buffer), input)) { // Read input lines
        if (feof(input) && !ferror(input)) { // If we have read a complete line
            printf("%d: %s\n", ++line_count, buffer);
        } else { // If the end of file was reached or an error occurred
            printf("Error: Failed to read input line.\n");
            return 1;
        }
    }

    fclose(input);

    return 0;
}