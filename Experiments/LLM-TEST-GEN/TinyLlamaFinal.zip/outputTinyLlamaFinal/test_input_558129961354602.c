
#include <stdio.h>
#include <stdlib.h>

int main() {
    int argc, i;
    char *argv[2] = {"ls", NULL};
    
    // include whole program analysis and semantic analysis functionality for this part of the compiler
    #include "wholeprogramanalysis.h"
    #include "sema.h"
    
    // parse command line arguments using getopt_long() and check if all required options are set
    if (getopt_long(argc, argv, "h", opts, NULL) == -1) {
        fprintf(stderr, "Invalid usage: %s\n", argv[0]);
        return 1;
    }
    
    // check if user input is valid for this command
    switch (opts[0]) {
        case 'h':
            printf("%s\n", BASH_HELP);
            break;
        
        default:
            printf("Usage: %s [OPTIONS] COMMAND\n", argv[0]);
            for (i = 1; i < argc - 1; ++i) {
                printf("\t%s", argv[i+1]);
            }
            putchar('\n');
            break;
    }
    
    return 0;
}