
#include <stdio.h>

int main(int argc, char *argv[]) {
    int x = 0;
    float y = 0.0;
    
    if (argc == 2 && strcmp(argv[1], "hello") == 0) {
        printf("hello world\n");
    } else if (argc > 2 && strcmp(argv[1], "world") == 0) {
        printf("world\n");
    }
    
    return 0;
}