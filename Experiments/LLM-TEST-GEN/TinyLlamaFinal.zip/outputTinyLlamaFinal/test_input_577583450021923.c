
#include <stdio.h>

/*
 * This program tests the profile-guided instrumentation optimizations of C. It triggers PGI by invoking a
 * type-generic macro `frexp` with 600 arguments, and then checks the resulting frexp value with a
 * type-generic macro `frexpf` (with 600 arguments). It also uses a `frexp` function with 100 argument as a
 * benchmark to test the instrumentation optimizations.
 */

#define PGI_ARGS    (argc >= 2 ? argv[1] : NULL)   /* Command line argument */

int main(int argc, char* argv[]) {
    int ret = 0;
    float frexpval = 0.5f * frexp(0.5f);       /* Frexp value with SA-triggered PGI */
    float frexpval_benchmark = 0.5f;          /* Frexp value with benchamrk frexp function */
    
    if (argc >= 1) {                           /* If command line argument is provided */
        printf("Profiling: %s\n", PGI_ARGS);   /* Output profile information */
        
        // Invoking PGI with SA-triggered optimizations and frexp function with 600 arguments
        ret = frexp(frexpval, NULL);
        if (ret == -1) {                       /* Check for error (if not, the optimizations have been disabled) */
            fprintf(stderr, "Error: Frexp failed with error %d\n", errno);
            return 1;
        } else {                               /* If successful, frexp value was captured and printed */
            printf("Frexp: %.3f\n", frexpval);
            
            // Invoking SA-triggered optimizations with frexp function with 600 arguments (benchmark)
            ret = frexp(frexpval_benchmark, NULL);
            if (ret == -1) {                    /* Check for error (if not, the optimizations have been disabled) */
                fprintf(stderr, "Error: Frexp failed with error %d\n", errno);
                return 1;
            } else {                           /* If successful, frexp value was captured and printed */
                printf("Frexp Benchmark: %.3f\n", frexpval_benchmark);
            }
        }
    } else {                                   /* No command line arguments provided, so profiling will be disabled */
        printf("Profiling: %s (disabled)\n", PGI_ARGS);
    }
    
    return 0;
}