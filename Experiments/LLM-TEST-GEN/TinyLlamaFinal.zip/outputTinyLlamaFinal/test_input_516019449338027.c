
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void check_result(int result, const char* filename) {
    if (result != 0) {
        fprintf(stderr, "Error: %s returned non-zero exit code\n", filename);
        exit(1);
    }
}

int main(int argc, char *argv[]) {
    check_result(0, "input.bsh");
    
    int value = atoi(argv[1]);
    check_result(value == 3, "expected value");
    
    return 0;
}