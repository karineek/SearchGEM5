
#include <stdio.h>
#include <stdlib.h>

void calculate(int arr[], int n) {
    float sum = 0;
    for (int I = 0; I < n; i++) {
        sum += arr[i];
    }
    printf("The sum of %d elements is: %.2f\n", n, sum);
}

void bash_program(char *argv[]) {
    int n = atoi(argv[1]);
    calculate(&arr[0], n);
}

int main() {
    char argv[][10] = {"0 3", "5 8", "10 20"};
    bash_program(argv);
}