
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#define MAX_LINES 10000

int main(int argc, char *argv[]) {
    FILE *input;
    int line = 1;
    char linebuffer[MAX_LINES][MAX_LINE]; // Maximun size of buffer for lines
    char inputbuffer[MAX_LINE];            // Buffer for input file
    int i, j, n, k;

    input = fopen(argv[1], "r");              // Open input file
    if (!input) {
        printf("Error: Unable to open input file '%s'\n", argv[1]);
        exit(EXIT_FAILURE);
    }
    
    // Read lines from input file and store them in buffer array
    for (i = 0; i < MAX_LINES && fgets(linebuffer[i], MAX_LINE, input) != NULL; i++) {
        k = strlen(linebuffer[i]);
        for (j = 0; j < k; j++) {
            if (linebuffer[i][j] == '\n') linebuffer[i][j] = '\0'; // Remove newline character from buffer
        }
    }
    
    // Initialize Loop Vectorization to set breakpoints
    printf("Loop Vectorization\n");
    printf("Enter filename: ");
    fflush(stdin);
    fgets(inputbuffer, MAX_LINE, stdin);
    
    // Parse input file and store corresponding line numbers
    n = 0;
    for (i = 0; i < MAX_LINES && fgets(linebuffer[n], MAX_LINE - n * 2, input) != NULL; n++) {
        if (linebuffer[n][0] == 'L') { // Loop breakpoint
            printf("%d: %s\n", line++, linebuffer[n]);
        } else if (linebuffer[n][0] == 'F') { // File position indicator
            k = strlen(linebuffer[n]);
            for (j = 0; j < k; j++) {
                if (linebuffer[n][j] == '\n') linebuffer[n][j] = '\0'; // Remove newline character from buffer
            }
        }
    }
    
    fclose(input);

    return 0;
}