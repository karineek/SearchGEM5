
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/Module.h"
#include "llvm/ExecutionEngine/ExecutionEngine.h"
#include "llvm/ExecutionEngine/JITCompilerTool.h"
#include "llvm/ExecutionEngine/Orc/JIT.h"

using namespace llvm;

static LLVMContext *context = nullptr;

int main(int argc, char **argv) {
    if (argc != 2 || strcmp(argv[1], "--help") == 0) {
        printf("Usage: %s <input>\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    const char *input = argv[1];
    if (!strcmp(input, "-")) {
        // Read input from stdin instead of command line args.
        printf("Reading from stdin...\n");
        FILE *stdin_file = stdin;
        
        char buf[1024]; // buffer to read the file into
        fread(buf, 1, sizeof(buf), stdin_file);
        stdin_file->close();
        
        printf("Finished reading from stdin.\n");
    } else {
        // Read input from specified file.
        FILE *input_file = fopen(input, "r");
        if (!input_file) {
            perror(input);
            return EXIT_FAILURE;
        }
        
        int num_lines = 0;
        char buffer[1024]; // buffer to read the file into
        while (fread(buffer, 1, sizeof(buffer), input_file) == sizeof(buffer)) {
            num_lines++;
            
            printf("Line %d: %s\n", num_lines, buffer);
        }
        
        fclose(input_file);
    }
    
    // Get LLVMContext and pass it to the program.
    context = get_llvm_context();
    
    // Create an ExecutionEngine with this LLVMContext.
    const char *opt_suffix = nullptr;
    if (!strcmp(argv[1], "--help")) {
        opt_suffix = "-help";
    } else if (argc != 2 && strcmp(argv[1], "-") == 0) {
        printf("Error: Invalid input. Please specify a valid command.\n");
        return EXIT_FAILURE;
    }
    
    ExecutionEngine *execution_engine = ExecutionEngine::create(context, opt_suffix);
    
    // Compile the program.
    Program *program = Program::create(execution_engine, input);
    
    // Run the JIT compilation.
    const char *opt_suffix2 = nullptr;
    if (!strcmp(argv[1], "--help") || strcmp(argv[1], "-") == 0) {
        opt_suffix2 = "";
    } else if (argc != 3 && strcmp(argv[1], "-") == 0) {
        printf("Error: Invalid input. Please specify a valid command.\n");
        return EXIT_FAILURE;
    }
    
    OptimizationFlags *optimization_flags = nullptr;
    if (strcmp(argv[1], "-") == 0) {
        optimization_flags = new OptimizationFlags();
        optimization_flags->add(opt_suffix2);
    } else {
        const char *input_file = argv[2];
        
        std::ifstream input_file_stream(input_file, std::ios::binary);
        if (!input_file_stream.is_open()) {
            perror(input_file);
            return EXIT_FAILURE;
        }
        
        const size_t buffer_size = 1024;
        char *buffer = static_cast<char*>(malloc(buffer_size));
        if (!buffer) {
            perror("Failed to allocate memory for buffer.");
            return EXIT_FAILURE;
        }
        
        input_file_stream.read(buffer, buffer_size);
        input_file_stream.close();
        
        optimization_flags = new OptimizationFlags(buffer, buffer_size);
    }
    
    // Run the JIT compilation with optimized flags.
    int jit_success = ProgramJIT::run(program, optimization_flags, execution_engine);
    
    if (jit_success) {
        printf("Compiled and optimized program successfully.\n");
    } else {
        printf("Failed to compile and optimize program.\n");
    }
    
    return jit_success ? EXIT_SUCCESS : EXIT_FAILURE;
}