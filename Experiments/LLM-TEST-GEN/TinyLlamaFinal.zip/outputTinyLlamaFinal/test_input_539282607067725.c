
#include <stdio.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fputs("Usage: vector-program inputfile outputfile\n", stderr);
        return EXIT_FAILURE;
    }
    
    // Read input file
    FILE *f = fopen(argv[1], "r");
    if (!f) {
        fputs("Failed to open input file: \"" argv[1] "\"\n", stderr);
        return EXIT_FAILURE;
    }
    
    // Read output file
    FILE *of = fopen(argv[2], "w");
    if (!of) {
        fputs("Failed to open output file: \"" argv[2] "\"\n", stderr);
        return EXIT_FAILURE;
    }
    
    // Vectorize code
    unsigned char *code = (unsigned char*)calloc(1, 4096);
    if (!code) {
        fputs("Failed to allocate memory for vectorized code\n", stderr);
        return EXIT_FAILURE;
    }
    
    // Compile and vectorize
    int err = compile(f, code);
    if (err != 0) {
        fprintf(stderr, "Error: %s\n", strerror(err));
        return EXIT_FAILURE;
    }
    
    // Run assembly
    unsigned char *assembly = vectorize(code, of);
    if (!assembly) {
        fputs("Failed to vectorize assembly code\n", stderr);
        return EXIT_FAILURE;
    }
    
    // Write assembly output
    if (fwrite(assembly, sizeof(unsigned char), 4096, of) != 4096) {
        fputs("Failed to write assembly output\n", stderr);
        return EXIT_FAILURE;
    }
    
    // Close files
    fclose(f);
    fclose(of);
    
    // Return success code
    return 0;
}