
#include <stdio.h>
#define PAGESIZE 4096     // size of page used by malloc()

// Callback function that triggers loop fuziion optimizaatios and handles machine code generation for C program.
int loop(void *arg) {
    printf("Enter the maximum number to generate: ");
    int max = (int)arg;  // copy argument to integer variable

    for (int i = 1; i <= max; ++i) {
        printf("%d ", i);
    }
    puts("");
    return 0;
}

// Callback function that handles machine code generation for C program.
void handle(void *arg) {
    // Generate machine code for the specified maximum number
    int max = (int)arg;

    char buffer[max * PAGESIZE];
    size_t bytes = malloc(sizeof(buffer[0]) + max * PAGESIZE);
    if (!bytes) {
        fprintf(stderr, "Error: Failed to allocate memory.\n");
        return;
    }
    memset(buffer, 0xcc, sizeof(buffer)); // fill the buffer with random data

    printf("Generating machine code for %d... ", max);
    size_t i = 0;
    while (i < max) {
        int64_t offset = i * PAGESIZE;
        memcpy(&buffer[offset], &bytes, PAGESIZE); // copy buffer to machine code
        printf("%" PRId64 " ", i);
        i += PAGESIZE;
    }
    puts("");

    FILE *out = fopen("/dev/stdout", "w");
    if (!out) {
        perror("Failed to open /dev/stdout for writing.");
        return;
    }
    int error = execvp("/bin/sh", (char **) argv);
    if (error != 0) {
        fprintf(stderr, "Error: %s.\n", strerror(errno));
        perror("Failed to execute /bin/sh.");
        return;
    }
    puts("\nMachine code generation successful! Generated at:\t");
    printf("%.2f seconds\n", (double) (time(NULL)) / 1000.); // display execution time in seconds
}

int main() {
    int argc;
    char *argv[] = {"/bin/sh"};
    argv[0] = "/usr/bin/env";
    argc = sizeof(argv) / sizeof(char *);

    void (*handler)(void *) = handle;
    handler = &loop;

    if (argc == 1) {
        printf("Enter a maximum number for generating machine code: ");
        char max_str[1024];
        int max = atoi(max_str);
        argv[1] = &max_str[0];
        handler = loop;
    }

    if (handler) {
        handler();
        fflush(stdout);
    } else {
        printf("Error: No callback function given. Exit.\n");
        return 1;
    }
}