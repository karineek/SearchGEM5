
#include <stdio.h> // Includes printf() function, which is used for output printing
#include <stdlib.h> // Includes exit() function to handle errors

// Function to get a user-provided input using argv
int get_input(char **input) {
    char *buffer;
    FILE *input_file = fopen(argv[1], "r");

    if (input_file == NULL) {
        perror("Error: Cannot open file for reading\n");
        return -1; // Return non-zero value to indicate error
    }

    buffer = malloc(1024);

    if (fgets(buffer, 1023, input_file) == NULL) {
        perror("Error: Cannot read file\n");
        fclose(input_file);
        return -1; // Return non-zero value to indicate error
    }

    *input = buffer;
    fclose(input_file);

    return 0; // Exit program successfully
}

// Main function
int main() {
    char input[5];

    if (get_input(&input) == -1) {
        printf("Error: Cannot get user input\n");
        return 1; // Exit program with error code
    }

    printf("User input: %s", input);

    return 0;
}