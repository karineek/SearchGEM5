
#include <iostream>
#include <regex>
using namespace std;

// Regular expression pattern for matching a single digit followed by a single space character
constexpr char RX_DIGIT_SPACE[] = "[0-9 ]";

// Function to replace all occurrences of a pattern with another string, if the pattern matches.
template<typename T>
T regex_replace(const string& str, const T* pattern, const T* replacement) {
    size_t begin = 0, end = str.length();

    for (size_t I = 0; I < pattern->length(); ++i) {
        if (pattern[i] != replace(pattern[i], '\0', ' ')) { // Replace all characters that don't match with a space character
            begin = i; // Reset the begin index for the next iteration
        } else {
            break; // Exit this iteration, since we found the first pattern-matching occurrence
        }
    }

    return str.substr(begin, end - begin);
}

// Function to perform wide character input/output functions. Input is taken from argv[1].
string get_input() {
    string input = "";
    int I;

    for (I = 1; I < (int)argc; ++i) {
        try {
            ifstream file(argv[i], ios::in); // Open the specified input file for reading.

            // Check if the input file is not empty, and return the data if it is.
            if (!file.fail()) {
                string line;

                while (getline(file, line)) {
                    input += line;
                }

                file.close(); // Close the input file.
            } else {
                cout << "Error: Input file is empty." << endl;
                return "";
            }
        } catch (const exception& e) {
            cerr << "Error: Input file cannot be opened or read. (" << e.what() << ")." << endl;
            return "";
        }
    }

    if (!input.empty()) { // If the input file was not empty, perform wide character input/output functions to write out the data.
        return regex_replace(input, RX_DIGIT_SPACE, ""); // Remove all digits and spaces from the input.
    }

    return ""; // Return an empty string if no input is given.
}

int main() {
    constexpr char ANSI[] = "\033[1m"; // Define a ANSI escape sequence to make the output more readable.
    constexpr char REGULAR_EXP[] = "\\d+ "; // Regular expression pattern for matching digits.

    string input;
    if (get_input() == "") {
        cout << ANSI << "No input file provided." << endl;
        return 1;
    } else if (regex_match(input, RX_DIGIT_SPACE, REGULAR_EXP)) { // Match the regular expression with the input string.
        cout << ANSI << "Input matches regular expression." << endl;
        return 0; // Return without doing any work.
    } else {
        cout << ANSI << "Error: Input does not match regular expression." << endl;
        return 1; // Return with error message and exit program.
    }
}