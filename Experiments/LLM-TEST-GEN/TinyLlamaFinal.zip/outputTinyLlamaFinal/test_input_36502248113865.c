
#include <stdio.h>

#ifndef FIB_H
#define FIB_H

struct fib {
    int a;
    int b;
};

#endif // FIB_H

struct fib * fibs[30];
int fibs_count = 0;

static inline void add(int a, int b) {
    fibs[fibs_count] = (struct fib *) malloc(sizeof(struct fib));
    fibs[fibs_count]->a = a;
    fibs[fibs_count]->b = b;
    fibs_count++;
}

int main() {
    int fib_input, n;

    printf("Enter the number of Fibonacci numbers to calculate: ");
    if (scanf("%d", &n) != 1) {
        return 1;
    }

    for (int I = 0; I < n; i++) {
        add(i, 0);
        add(i, 1);
    }
    
    printf("Fibonacci numbers up to %d:\n", n+1);
    for (int I = 0; I <= n; i++) {
        printf("%d ", fibs[i].a);
        if (i < n) printf(" ");
    }
    
    return 0;
}