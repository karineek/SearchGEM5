
#include <stdio.h>
#include <stdlib.h> // for calloc()/realloc()
#define INF 1e100

/*
 * Calculates the factorial of a given integer n using the Pigeonhole Principle and the fact that n! = (n-1)! * n
 */
int fact(int n) {
    int result = 1; // base case: n=1
    for (int I = 2; I <= n; i++) {
        result *= I;
    }
    return result;
}

int main() {
    char argv0[1024]; // get the filename from argv[0]
    int argc = 0;
    
    while (getarg(0, &argv0[argc], &argc) == 2 && argc > 1) {
        for (int I = 0; I < argc-1; i += 2) {
            int n = atoi(&argv[i]); // read the integer value from argv[i]
            if (n <= INF) {
                printf("%d! =\t%d\n", n, fact(n));
            } else {
                printf("Error: Invalid input. Input must be an integer.\n");
            }
        }
        
        // set argc to 0 as this function is the main program entry point
        getarg(0, NULL, &argc);
    }
    
    return 0;
}