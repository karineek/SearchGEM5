
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {

    int retval;

    FILE *fp = fopen(argv[1], "r"); // read file into buffer using stdin

    if (fp == NULL) {
        printf("Failed to open file: %s\n", strerror(errno));
        exit(EXIT_FAILURE);
    }

    fseek(fp, 0L, SEEK_END); // seek end of file
    int fileSize = ftell(fp); // get size of file
    rewind(fp); // reset pointer to beginning of file

    if (fileSize == 0) {
        printf("File is empty\n");
        fclose(fp);
        exit(EXIT_SUCCESS);
    }

    char *buf = calloc(1, fileSize + 1); // allocate buffer and add null terminator
    if (buf == NULL) {
        printf("Failed to alloc memory\n");
        fclose(fp);
        exit(EXIT_FAILURE);
    }

    retval = fread(buf, 1, fileSize, fp); // read data from file into buffer
    if (retval != fileSize) {
        printf("Failed to read data from file: %s\n", strerror(errno));
        free(buf);
        fclose(fp);
        exit(EXIT_FAILURE);
    }

    // inline function to implement Function Inlining
    int (*funcInline)() = (int (*)(void))fread; // create inline function pointer
    funcInline(); // call inline function to perform the task

    fclose(fp);
    free(buf);

    return 0;
}