
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> /* For getopt() */
#include "profile_gui.h"

int main(int argc, char *argv[]) {
    // Check for required arguments (e.g., if no binary file is specified, error message will be displayed)
    if (argc != 2 || strcmp(argv[1], "-") == 0) {
        printf("Usage: %s <binary_file>\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    // Parse command line options (if any) and set up profile data
    char *bin_name = argv[1];
    if (parse_args(argc, argv, &profile_data) != 0) {
        return EXIT_FAILURE;
    }
    
    // Open binary file for reading and processing
    FILE *bin_file = fopen(bin_name, "r");
    if (!bin_file) {
        perror("Error: unable to open binary file\n");
        return EXIT_FAILURE;
    }
    
    // Calculate profile data for this binary file and process it
    printf("Profile-gui optimized code analysis in progress...\n");
    profile(bin_file, &profile_data);
    printf("\nCode optimization complete.\n");
    
    // Clean up memory usage
    fclose(bin_file);
    free(profile_data.code_info.global_symbols);
    
    return EXIT_SUCCESS;
}