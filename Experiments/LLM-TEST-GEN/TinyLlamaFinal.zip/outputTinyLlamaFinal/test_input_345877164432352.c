
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void mem_optimize(char *str) {
    char temp[1024];
    int I, j, k;
    
    // Allocating memory to store the input string
    for (i = 0; str[i] != '\0'; i++)
        temp[i] = str[i];
    
    // Copying the string from memory to output buffer
    for (k = 0, I = 0, j = 0; I < strlen(str); i++, k++, j++) {
        if (j % 2 == 1)
            temp[i] = ' ';
        
        // Check if the current character is alphabetic or numeric
        if (isalpha(str[i]) || isdigit(str[i]))
            temp[k] = str[i];
    }
    
    printf("Mem_optimized string: %s", temp);
}

int main() {
    char *input;
    
    // Getting input from the user via argv
    if (argc < 2) {
        puts("Please provide an argument.");
        return 1;
    }
    
    // Opening the file using fopen()
    input = (char*)fopen(argv[1], "r");
    
    // Checking for invalid input
    if (input == NULL) {
        puts("Invalid input.");
        return 2;
    }
    
    // Calling mem_optimize function to optimize the string
    mem_optimize(input);
    
    // Reading the output from file into memory
    input = fgets(temp, sizeof temp, input);
    
    // Printing the optimized string to console
    puts("Mem_optimized string: " + strntrim(temp));
    
    return 0;
}