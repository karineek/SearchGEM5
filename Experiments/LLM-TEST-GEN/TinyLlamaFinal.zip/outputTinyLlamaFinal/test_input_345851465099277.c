
   #include <stdio.h>
   #include <stdlib.h>
   #include <ctype.h>
   #include <string.h>
   #include "specialization_optimizations.h" // This file contains the code triggering Function Specialization optimizaTIos, and is included in this example program