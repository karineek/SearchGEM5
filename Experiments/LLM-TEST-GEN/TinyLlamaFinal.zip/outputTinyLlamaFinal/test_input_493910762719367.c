
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s [file]\n", argv[0]);
        return 1;
    }
    FILE *input = fopen(argv[1], "r");
    if (!input) {
        perror("Failed to open input file");
        return 2;
    }
    
    // Read the first line as a test case:
    char buffer[1024];
    int line_num = 1;
    while (fgets(buffer, sizeof(buffer), input) != NULL) {
        assert(line_num < 10);
        if (!strcmp(buffer, "#include")) {
            fseek(input, -4, SEEK_CUR);
            fgets(buffer, sizeof(buffer), input);
            line_num++;
        } else if (!strcmp(buffer, ".c") || !strcmp(buffer, "/*")) {
            // Skip comment lines and the opening .c for now.
            fseek(input, -4, SEEK_CUR);
        } else {
            fputs(buffer, stdout);
            fflush(stdout);
            line_num++;
        }
    }
    
    // Close input file and exit:
    fclose(input);
    return 0;
}