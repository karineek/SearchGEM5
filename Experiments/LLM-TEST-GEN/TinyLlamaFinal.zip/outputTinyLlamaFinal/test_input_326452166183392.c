
#include <stdio.h>
#include <stdlib.h>
#include <string.h> // for memset() function

int main(void) {
    char input[100];
    
    if(argc < 2) { // check the number of arguments provided
        printf("Usage: program filename\n");
        return EXIT_FAILURE;
    }
    
    // read input from file or command line argument and validate it using memset() function
    FILE *fp = fopen(argv[1], "r");
    if(!fp) {
        printf("Error: Failed to open file %s\n", argv[1]);
        return EXIT_FAILURE;
    }
    
    fseek(fp, 0L, SEEK_END); // seek to end of file
    long size = ftell(fp) + 1; // add one to avoid buffer overflow in memset() function
    
    if(!memset((void*)input, 'a', size)) { // use memset() function to validate input string and fill it with 'a'
        printf("Error: Invalid input\n");
        return EXIT_FAILURE;
    }
    
    fseek(fp, 0L, SEEK_SET); // move back to beginning of file
    fwrite(input, sizeof(char), size, fp); // write input string to file
    
    printf("Input successfully validated and written to file\n");
    
    return EXIT_SUCCESS;
}