
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s FILENAME\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    /* CSE optimizations */
    int ret = llvm_lower_cse(argv[1], stdout);
    if (ret != 0) {
        fprintf(stderr, "Failed to lower CSE optimizations for file: %s\n", argv[1]);
        return EXIT_FAILURE;
    }
    
    /* Common Subexpression Elimincation optimizations */
    ret = llvm_lower_cfg(stdout);
    if (ret != 0) {
        fprintf(stderr, "Failed to lower Common Subexpression Eliminiation for file: %s\n", argv[1]);
        return EXIT_FAILURE;
    }
    
    /* Generate output */
    FILE *output = fopen("out.ll", "w");
    if (!output) {
        perror("Failed to create output file.");
        exit(EXIT_FAILURE);
    }
    
    /* Run LLVM IRGen pass to generate LLVM IR */
    int ret = llvm_run_passes(output, argv[1], "llc", "", LLVM_CUSTOM_OPTIONS);
    if (ret != 0) {
        fprintf(stderr, "Failed to run LLVM IRGen pass for file: %s\n", argv[1]);
        return EXIT_FAILURE;
    }
    
    /* Generate optimized code */
    int ret = llvm_optimize_code(output);
    if (ret != 0) {
        fprintf(stderr, "Failed to optimize code for file: %s\n", argv[1]);
        return EXIT_FAILURE;
    }
    
    /* Generate debug info */
    ret = llvm_generate_debug_info(output);
    if (ret != 0) {
        fprintf(stderr, "Failed to generate debug info for file: %s\n", argv[1]);
        return EXIT_FAILURE;
    }
    
    /* Generate assembly */
    ret = llvm_generate_assembly(output);
    if (ret != 0) {
        fprintf(stderr, "Failed to generate assembly for file: %s\n", argv[1]);
        return EXIT_FAILURE;
    }
    
    /* Print output */
    fprintf(stdout, "Output:");
    print_llvm_ir(output);
    
    fclose(output);
    
    return 0;
}