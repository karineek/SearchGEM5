
#include <stdio.h>
#include <stdlib.h>

int main()
{
    int choice, optind;
    char command[20], argv[10];

    printf("Enter your choice: ");
    fgets(command, sizeof(command), stdin);
    command[strcspn(command, "\n")] = '\0';

    optind = 0;
    while (fscanf(stdin, "%s %s", argv[optind], &argv[optind + 1]) != EOF) {
        switch (atoi(argv[optind])) {
            case 1:
                printf("Enter command: ");
                fgets(command, sizeof(command), stdin);
                command[strcspn(command, "\n")] = '\0';
                break;
            default:
                printf("%s: invalid choice\n", argv[optind]);
        }
    }

    return 0;
}