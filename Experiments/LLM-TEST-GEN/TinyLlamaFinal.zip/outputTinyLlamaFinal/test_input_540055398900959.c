
#include <stdio.h>

int main() {
    int num = atoi(argv[1]);
    
    if (num <= 0) {
        printf("Error: Input must be positive\n");
        return 1;
    } else {
        printf("%d", num);
        return 0;
    }
}