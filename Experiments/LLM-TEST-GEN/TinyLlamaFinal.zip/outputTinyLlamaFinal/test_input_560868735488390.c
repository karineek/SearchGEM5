
#include <stdio.h> /* For printf */
#include <unistd.h> /* For getopt() */
#include "sigill.h" /* For SIGILL macro */

/*
  Function to call SIGILL macro
*/
void sigill(int sig) {
  puts("SIGILL invoked");
}

int main(int argc, char *argv[]) {
  int opt;
  sigill_t sigill = SIGILL; /* Set the SIGILL macro to handle SIGILL */
  
  if (argc > 1 && strcmp(argv[1], "--help") == 0 || strcmp(argv[1], "-h") == 0) {
    puts("Usage: BASH [OPTIONS]"); /* Print usage message */
    puts("Example: BASH -c \"SIGILL\""); /* Example of input with SIGILL macro */
    exit(EX_USAGE); /* Exit the program with EX_USAGE */
  }
  
  if (getopt(argc, argv, "h") == -1) { /* Call getopt() to get options */
    puts("No option detected"); /* Print error message */
    exit(EX_USAGE); /* Exit the program with EX_USAGE */
  }
  
  switch (getopt(argc, argv, "h")) {
  case '?': /* Handle unknown options */
    puts("Unknown option: -?"); /* Print help message for --help*/
    exit(EX_USAGE); /* Exit the program with EX_USAGE */
  default:
    sigill(&sigill); /* Call SIGILL macro for handling SIGILL */
  }
  
  return 0;
}