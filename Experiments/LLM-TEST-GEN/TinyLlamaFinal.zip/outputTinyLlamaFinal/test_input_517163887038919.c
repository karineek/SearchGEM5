
#include <stdio.h> /* for printf() */
#include <stdlib.h> /* for exit() */

int main(int argc, char *argv[]) {
    int num_lines = atoi(argv[1]);
    char buf[80] = "";
    if (argc != 2) {
        printf("Error: Incorrect number of arguments\n");
        exit(EXIT_FAILURE);
    }
    for (int I = 0; I < num_lines; i++) {
        printf("%s", buf);
        if (i != num_lines-1) { /* skip last line */
            printf("\n");
        }
    }
    return 0;
}