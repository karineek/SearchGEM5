
#include <stdio.h>
#include <stdlib.h>

void print_help() {
    printf("Usage: %s [OPTIONS] INPUT\n", argv[0]);
    printf("\nOptions:\n");
    printf("  -h, --help             Display this help and exit.\n");
}

int main(int argc, char *argv[]) {
    int i;
    if (argc != 2) {
        print_help();
        return EXIT_FAILURE;
    }
    for (i = 1; i < argc; ++i) {
        printf("%s ", argv[i]);
    }
    printf("\n");

    int c;
    while ((c = getchar()) != EOF && c != '\n') {} // Skip newline at the end of input file
    return 0;
}