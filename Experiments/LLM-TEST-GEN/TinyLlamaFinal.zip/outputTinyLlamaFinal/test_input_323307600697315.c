
#include <stdio.h>  // for FILE *open, fputs, puts
#include <string.h>  // for strlen()

void execute(char input[], int n) {
    char buf[1024];
    ssize_t r = read(STDIN_FILENO, buf, sizeof(buf));
    if (r < 0) {
        perror("read");
        exit(1);
    } else if (r == 0) {
        puts("End of file!");
    } else if (r > n) {
        fprintf(stderr, "Invalid input length: %zu\n", r);
        return;
    }
    
    int i = 0;
    while (i < n && buf[i] != '\n') {
        printf("%.*s ", sizeof(buf) / sizeof(char), buf + i);
        i += strlen(buf + i); // trim newline
    }
    printf("\n");
}

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s FILE\n", argv[0]);
        return 1;
    }
    
    char input[MAX_LINE + 1];
    FILE *f = fopen(argv[1], "r");
    if (f == NULL) {
        perror("fopen");
        return 1;
    }
    while (!feof(f)) {
        fgets(input, sizeof(input), f);
        input[strcspn(input, "\n")] = '\0';
        
        // Check for end of file
        if (feof(f) && !fgets(input + strlen(input), sizeof(input) - strlen(input), f)) {
            perror("fgets");
            return 1;
        }
        
        execute(input, strlen(input)); // pass input to execuable program
    }
    
    fclose(f);
    return 0;
}