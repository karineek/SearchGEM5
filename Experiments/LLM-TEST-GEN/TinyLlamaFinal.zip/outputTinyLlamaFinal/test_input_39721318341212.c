
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#define MAX_ITERS 1000000

/* Function prototypes */
double loop_optim(int iterations, int* time_dependence);
void display_result(double result, int iterations, int time_dependence);

int main() {
    double start_time = 0.0;
    double end_time = 0.0;
    int time_dependence = 1;
    int iterations = 0;
    
    /* Read input from args */
    if (argc < 2) {
        printf("Error: No arguments provided.\n");
        exit(EXIT_FAILURE);
    }
    char argv[3][argv[0]] = {{"-", "--", ""}, {"-t", "--time_dependence", ""}, argv[1]};
    
    for (int I = 2; I < argc; i++) {
        if (!strcmp(argv[i], "-") || !strcmp(argv[i], "--")) {
            switch (i) {
                case 2:
                    time_dependence = atoi(argv[++i]);
                    break;
                default:
                    printf("Error: Invalid argument %s.\n", argv[i]);
                    exit(EXIT_FAILURE);
            }
        } else {
            if (strlen(argv[i]) > 1) {
                iterations = atoi(argv[i]);
            } else {
                printf("Error: Invalid argument %s.\n", argv[i]);
                exit(EXIT_FAILURE);
            }
        }
    }
    
    /* Perform Loop Optimizations */
    start_time = gettimeofday();
    double result = loop_optim(iterations, &time_dependence);
    end_time = gettimeofday();
    printf("Time: %.4f\n", (end_time - start_time) / 1000.0);
    display_result(result, iterations, time_dependence);
    
    return 0;
}

/* Function to perform Loop Optimizations */
double loop_optim(int iterations, int* time_dependence) {
    double start = gettimeofday();
    for (int I = 0; I < iterations; i++) {
        *time_dependence++;
    }
    double end = gettimeofday();
    return end - start;
}

/* Function to display results */
void display_result(double result, int iterations, int time_dependence) {
    printf("Time: %.4f\n", (end - start) / 1000.0);
    printf("Result: %.3e\n", result);
    printf("Iterations: %d\n", iterations);
}