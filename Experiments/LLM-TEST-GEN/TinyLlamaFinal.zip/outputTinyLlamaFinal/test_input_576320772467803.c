
#include <stdio.h>
#include <stdlib.h>
#include "so.h"

int main(int argc, char *argv[]) {
    // Input data
    double a = atof(argv[1]);
    double b = atof(argv[2]);
    int n = atoi(argv[3]);
    
    // Call SO function and get optimized result
    double c = so_optimize(a, b, n);
    printf("SO: %g\n", c);
    
    return 0;
}