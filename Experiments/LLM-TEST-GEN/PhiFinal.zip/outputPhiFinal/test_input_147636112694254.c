
#include <stdio.h>

int main(int argc, char *argv[]) {
    int num = atoi(argv[1]);
    printf("The number is: %d\n", num);
    return 0;
}