
int main(int argc, char** argv) {
    //use argv[i] for each argument starting from index i+1
}