
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <sys/time.h>
#include <unistd.h>

int factorial(int n);
void thrd_sleep(int delay) {
    int i;
    struct timeval tv;
    getpid();
    clock_t start, end;
    start = clock();
    for (i = 1; i <= n; i++) {
        factorial(i);
    }
    end = clock();
    tv.tv_sec = end - start;
    tv.tv_usec = time() * 1000 + tv.tv_usec;
    for (i = 0; i < delay; i++) {
        sleep(1);
    }
}

int main(int argc, char* argv[]) {
    int n = atoi(argv[1]);
    thrd_sleep(0); // This is the default value of delay. You can modify it as per your needs.
    printf("Factorial of %d: ", n);
    for (int i = 1; i <= n; i++) {
        if (i == n) {
            printf("%d\n", factorial(i));
        } else {
            printf("*");
        }
    }
    return 0;
}