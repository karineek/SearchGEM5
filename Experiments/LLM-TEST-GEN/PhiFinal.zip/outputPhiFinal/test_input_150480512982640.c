
#include <stdio.h>
int main(int argc, char **argv) {
    int n1 = atoi(argv[1]); // convert first argument to integer
    int n2 = atoi(argv[2]); // convert second argument to integer
    printf("The sum of %d and %d is %d\n", n1, n2, n1 + n2);
    return 0;
}