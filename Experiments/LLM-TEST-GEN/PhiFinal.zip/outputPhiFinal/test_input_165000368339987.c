
#include <stdio.h>
#include <math.h>

int main(int argc, char **argv) {
    int i;

    for (i = 1; i < argc; ++i) {
        // print the input argument value
        printf("%s\n", argv[i]);
    }

    // calculate the square of each integer in an array using pow
    int arr[5] = { 1, 2, 3, 4, 5 };
    for (int j = 0; j < 5; ++j) {
        printf("%d squared is %f\n", arr[j], pow(arr[j], 2));
    }

    return 0;
}