
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int n;
    if (argc < 3) {
        printf("Usage: ./program <n>\n");
        return 1;
    }

    n = atoi(argv[1]); // read the first argument as an integer
    if (n <= 0) {
        printf("Invalid input: %s\n", argv[1]);
        return 1;
    }

    for (int i = 2; i < argc && atoi(argv[i]) > 0; i++) { // read the remaining arguments as integers
        n += atoi(argv[i]);
    }

    printf("Sum of %d and all positive integer inputs: %d\n", n, n);

    return 0;
}