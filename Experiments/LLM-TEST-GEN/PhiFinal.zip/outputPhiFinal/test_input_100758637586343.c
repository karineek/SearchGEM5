
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }

    // check if file exists
    FILE *file = fopen(argv[1], "r");
    if (file == NULL) {
        printf("Error: File not found.\n");
        return 1;
    }

    // read file line by line and store each line in an array of strings
    char *line = NULL;
    size_t len = 0;
    int num_lines = 0;
    while ((line = getline(&len, &len, file)) != NULL) {
        strcpy(argv[num_lines], line);
        ++num_lines;
    }

    // close the file
    fclose(file);

    int num_args = num_lines - 1;
    printf("Number of arguments: %d\n", num_args);

    for (int i = 0; i < num_args; ++i) {
        int value = atoi(argv[i+1]);
        if (value > 10) {
            printf("Value %d is greater than 10\n", value);
        } else {
            printf("Value %d is less than or equal to 10\n", value);
        }
    }

    return 0;
}