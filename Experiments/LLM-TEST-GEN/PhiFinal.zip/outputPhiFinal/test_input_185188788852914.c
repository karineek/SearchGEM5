
// Define a typedef for the output variable
typedef char *argv_str;

// Function to initialize the argv array
int init_argv(char **argv) {
    printf("Initializing arguments...\n");
    argv[0] = "Hello, world!"; // Set the first argument as 'Hello, world!'
    return 1;
}

// Function to print the values of argv
void print_argv(char **argv) {
    int i = 0;
    while (i < sizeof(argv) / sizeof(argv[0]) && strcmp(argv[i], "--help") != 0) { // Skip the help option
        printf("%s\n", argv[i]); // Print each argument
        i++;
    }
}