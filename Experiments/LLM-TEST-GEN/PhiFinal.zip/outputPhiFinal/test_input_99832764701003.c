
#include <stdio.h>

int main(int argc, char **argv) {
  int x = atoi(argv[1]);
  int y = atoi(argv[2]);
  
  if (x % 2 == 0 && y % 2 == 1) {
    printf("%d is an even number and %d is an odd number.\n", x, y);
  } else {
    printf("Both inputs must be even or both inputs must be odd.\n");
  }
  
  return 0;
}