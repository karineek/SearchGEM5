
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {

    // initialize a string variable for user input
    char input_str[100];

    // read the first argument from the command line (input)
    fgets(input_str, sizeof(input_str), stdin);

    // check if there was enough input
    if (strlen(input_str) == 0 || strcmp(input_str, argv[1]) != 0) {
        printf("Invalid input. Please enter a valid string as the first argument\n");
    }

    // print the user input
    printf("Input: %s\n", input_str);

    return 0;
}