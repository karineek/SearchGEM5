
#include <stdio.h>
#include <string.h>
#include <sys/time.h>

int main(int argc, char *argv[]) {
    int n = atoi(argv[1]);
    double start_time;
    double end_time;
    struct timeval start, stop;

    // Profile-Guided Instrumentation
    if (n > 1) {
        for (int i = 2; i <= n; i++) {
            printf("Running %d iterations with fsetpos...\n", i);
            start_time = gettimeofday(&start, 0); // Get current time
            for (int j = 1; j <= i; j++) {
                fsetpos(argv[2], -1 * n + j); // Set file pointer to the last position
            }
            for (int j = i; j > 1; j--) {
                fsetpos(argv[2], -1 * n + j); // Set file pointer to the last position again
            }
            for (int j = 1; j <= i; j++) {
                fsetpos(argv[2], -1 * n + j); // Set file pointer to the last position again
            }
            stop_time = gettimeofday(&stop, 0); // Get current time
            printf("Finished %d iterations with fsetpos. Elapsed time: %lf\n", i, (double)(stop_time.tv_sec - start_time.tv_sec) + (double)(stop_time.tv_usec - start_time.tv_usec) / 1000000);
        }
    } else {
        for (int i = 1; i <= argc; i++) {
            printf("Running %d iterations with fsetpos...\n", i);
            start_time = gettimeofday(&start, 0); // Get current time
            for (int j = 1; j <= i; j++) {
                fsetpos(argv[1], -1 * argc + j); // Set file pointer to the last position
            }
            for (int j = i; j > 1; j--) {
                fsetpos(argv[1], -1 * argc + j); // Set file pointer to the last position again
            }
            for (int j = 1; j <= i; j++) {
                fsetpos(argv[1], -1 * argc + j); // Set file pointer to the last position again
            }
            stop_time = gettimeofday(&stop, 0); // Get current time
            printf("Finished %d iterations with fsetpos. Elapsed time: %lf\n", i, (double)(stop_time.tv_sec - start_time.tv_sec) + (double)(stop_time.tv_usec - start_time.tv_usec) / 1000000);
        }
    }

    return 0;
}