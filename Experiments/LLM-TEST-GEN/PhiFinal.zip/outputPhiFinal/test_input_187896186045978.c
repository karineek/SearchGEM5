
#include <stdio.h>

int main(int argc, char* argv[]) {
  printf("Including headers...\n"); // Inlining optimization
  int i;
  for (i = 1; i <= 10; i++) { // Middle-End optimization
    if (argc != i+1) {
      break;
    }
    printf("%s\n", argv[i]);
  }
  printf("Middle end completed.\n");
  return 0;
}