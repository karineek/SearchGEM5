
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {
    // check if enough arguments have been provided
    if (argc < 2) {
        printf("Usage: %s input\n", argv[0]);
        return 1;
    }

    char *input = argv[1];
    printf("Input: %s\n", input);

    // exit program if user presses "q" on keyboard
    for (;;) {
        char c = getchar();
        if (c == 'q') {
            printf("\nExiting program...");
            return 0;
        }

        // check for end of input
        if (c == '\n') {
            break;
        }

        printf("Character: %c\n", c);
    }

    return 0;
}