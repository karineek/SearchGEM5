
#include <stdio.h>
#include <string.h>

int main() {
    int i;
    char str[100];

    for(i=1;i<argc;++i) {
        if (strcmp(argv[i], "ispunct") == 0) {
            // process input with ispunct function
        } else {
            strcpy(str, argv[i]);
            printf("Input: %s\n", str); // print input
        }
    }

    return 0;
}