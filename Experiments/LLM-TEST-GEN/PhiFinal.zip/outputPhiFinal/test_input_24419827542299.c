
#include <iostream>
using namespace std;
int main(int argc, char* argv[]) {
    int i;
    float num1, num2;
    for (i=1; i<argc; i++) {
        if (argc > i) { // Check input size first.
            cout << "Invalid input. Please enter a number within 20 characters." << endl;
        } else {
            string num_str = argv[i]; // Convert argument to string for easy length check.
            if (num_str.size() > 20) cout << "Invalid input. Please enter a number within 20 characters.";
            else { // Check if the numbers are positive.
                if (stoi(num_str) > 0 && stoi(argv[i-1]) > 0) {
                    // Check if the numbers are equal.
                    if (stoi(num_str) == stoi(argv[i-1])) {
                        cout << "Equal" << endl;
                    } else {
                        // If the numbers are not equal, print their sum.
                        cout << num1 << " + " << num2 << " = " << (num1+num2) << endl;
                    }
                } else {
                    cout << "Invalid input. Please enter a positive number.";
                }
            } else {
                cout << "Invalid input. Please enter a positive number.";
            }
        }
    }
}