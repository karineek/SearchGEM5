
#include <stdio.h>
#include <math.h>
#define MAX 1000000
int main(int argc, char *argv[]) {
    int i;
    int sum = 0;
    for (i = 1; i <= MAX; i++) {
        if (strcmp(argv[1], "even") == 0) { // special case for even numbers
            if (i % 2 == 0) {
                sum += i;
            }
        } else if (strcmp(argv[1], "odd") == 0) { // special case for odd numbers
            if (i % 2 != 0) {
                sum += i;
            }
        } else if (strcmp(argv[1], "prime") == 0) { // special case for prime numbers
            if (is_prime(i)) {
                sum += i;
            }
        } else { // general case for all numbers
            sum += i;
        }
    }
    printf("The sum of %d to %d is %d\n", argv[1], MAX, sum);
    return 0;
}