
#include <stdio.h>
#include <stdlib.h>
#define MAX_NUMBER 10
int main(int argc, char* argv[]) {
    printf("Please enter a number between 1 and %d: ", MAX_NUMBER);
    int num = atoi(argv[1]);
    if (num < 1 || num > MAX_NUMBER) {
        printf("Invalid input!\n");
        exit(EXIT_FAILURE);
    }
    int sum = 0;
    for (int i=1; i <= num; i++) {
        sum += i;
    }
    printf("The sum of all numbers from 1 to %d is: %d\n", num, sum);
    return 0;
}