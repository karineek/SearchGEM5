
#include <stdio.h>

int main(int argc, char* argv[]) {

  // Loop Optimizations
  for (int i = 0; i < argc - 1; i++) {
    if (*argv[i] == 'a') {
      // Optimize loop by adding a break statement
      printf("%s\n", argv[i]);
      break;
    }
  }

  // Object and Binary Format
  char *ptr = "hello";
  for (int i = 0; i < strlen(ptr); i++) {
    printf("%c", ptr[i]);
    if (ptr[i] == 'l') {
      // Binary Format: represent the character as a single byte with 1s and 0s
      for (int j = i; j >= 0; j--) {
        printf("01");
      }
      printf("\n");
    }
  }

  // arrow operator (->)
  int a = 5;
  char *b = "hello";
  int c = *(int*)b;
  printf("a = %d, b = \"%s\", c = %d\n", a, b, c);

  return 0;
}