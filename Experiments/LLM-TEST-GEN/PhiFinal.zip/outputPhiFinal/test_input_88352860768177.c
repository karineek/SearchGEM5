
#include <stdio.h>
int main(int argc, char *argv[]) {
    // Initialize a pointer to the first element of argv, which contains the program name
    char *p;
    p = argv[1];
    
    // Loop through the rest of the arguments and print them out one by one
    for (int i = 2; i < argc; i++) {
        printf("arg%d: %s\n", i, argv[i]);
    }
    
    return 0;
}