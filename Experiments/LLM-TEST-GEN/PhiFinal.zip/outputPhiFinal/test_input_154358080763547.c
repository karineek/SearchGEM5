
#include <stdio.h>

int main(int argc, char *argv[]) {

    // get the index of the second argument (the filename) and use it as a pointer to read the file
    FILE* fp = fopen(argv[2], "r");
    if (!fp) {
        printf("Error opening file\n");
        return 1;
    }

    // read the input from the file and store it in an array of integers
    int nums[argc-2];
    for (int i = argc-3; i < argc-1; i++) {
        fscanf(fp, "%d", &nums[i-1]);
    }

    // close the file
    fclose(fp);

    // print the array of integers
    for (int i = 0; i < argc-2; i++) {
        printf("%d ", nums[i]);
    }
    printf("\n");

    // exit the program
    return 0;
}