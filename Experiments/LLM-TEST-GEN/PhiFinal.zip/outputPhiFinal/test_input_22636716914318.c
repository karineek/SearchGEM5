
#include <stdio.h>

int main(int argc, char **argv) {
    int i;
    int n = atoi(argv[1]); //converts first argument to integer and stores it in variable n

    //initialize sum to 0
    int sum = 0;

    for (i = 2; i <= argc; i++) { //iterates through the remaining arguments, which are treated as integers and added to the sum
        sum += atoi(argv[i]);
    }

    printf("Sum: %d\n", sum); 
    return 0;
}