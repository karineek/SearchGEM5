
#include <stdio.h>

int main(int argc, char *argv[]) {
  int num = atoi(argv[1]);
  int dec_num = 0;

  // Convert the hex number to decimal using bitwise operations and multiplication by powers of 16.
  for (int i = 1; i <= 6; i++) {
    dec_num += ((num >> 4 * i) & 0xf) << (4 * i - 1);
  }

  // Print the result.
  printf("%d\n", dec_num);

  return 0;
}