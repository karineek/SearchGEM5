
#include <stdio.h>
#include <stdbool.h>

int main(int argc, char *argv[]) {
  int n;
  if (argc != 2) {
    printf("Usage: %s INT\n", argv[0]);
    return 1;
  }

  n = atoi(argv[1]);
  if (n <= 0) {
    printf("Input must be a positive integer.\n");
    return 2;
  }

  for (int i = 1; i <= 5; ++i) {
    printf("%d + %d = %d\n", n, i, n + i);
  }

  for (int i = 1; i <= 10; ++i) {
    if (n % i == 0) {
      printf("%d is divisible by %d.\n", n, i);
    }
  }

  return 0;
}