
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {
    if (argc != 3) {
        printf("Usage: %s [filename]\n", argv[0]);
        return 1;
    }

    FILE *file = fopen(argv[1], "r");
    if (!file) {
        printf("Error: file not found\n");
        return 2;
    }

    char line[100];
    while (fgets(line, sizeof(line), file)) {
        if (!strncmp(line, "//", 2) && !strncmp(line, "\0\n", 3)) {
            line[2] = '\0'; // Remove comment symbol and newline character
        } else if (!strncmp(line, "const char *" && strlen(argv) > 2)) {
            printf("%s: invalid argument\n", argv[0]);
            return 3;
        } else {
            printf("%s:\n", argv[1]);
            fclose(file);
            return 4;
        }
    }

    fclose(file);
    return 0;
}