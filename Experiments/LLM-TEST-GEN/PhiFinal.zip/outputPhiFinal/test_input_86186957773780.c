
#include <stdio.h>
int main() {
    int i;
    char *argc = NULL;
    char **argv = NULL;
    if ((argc > 1) && (strcmp(argv[1], "--help") == 0)) {
        // print usage message
        printf("Usage: %s <command>\n", argv[0]);
        return 0;
    } else if ((argc > 1) && (strcmp(argv[1], "--version") == 0)) {
        // print version information
        printf("$0 is version %s\n", argv[0]);
        return 0;
    } else if ((argc > 1) && (strcmp(argv[1], "--name") == 0)) {
        // print name inputted by user
        printf("Your name is %s\n", argv[2]);
        return 0;
    } else if ((argc > 1) && (strcmp(argv[1], "--age") == 0)) {
        // print age inputted by user
        printf("Your age is %d\n", atoi(argv[2]));
        return 0;
    } else {
        // no command was specified, print help message
        printf("Usage: %s <command>\n", argv[0]);
        return 0;
    }
}