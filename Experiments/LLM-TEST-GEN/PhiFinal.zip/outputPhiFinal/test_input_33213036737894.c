
#include <stdio.h>

int main(int argc, char *argv[]) {
	// Check if input argument is provided
	if (argc != 2) {
		printf("Please provide an input as the first argument\n");
		return 1;
	}

	// Read in input from argv and output it followed by "Hello World!"
	printf("%s Hello World!\n", argv[1]);

	return 0;
}