
#include <stdio.h>

int main(int argc, char *argv[]) {

  // Prints "Hello, World!" to the terminal
  printf("Hello, World!\n");

  // Using argv[1], which is the second element of argv, we can access any input
  int num = atoi(argv[1]);

  return 0;
}