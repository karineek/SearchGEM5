
#include <stdio.h>

int main(int argc, char *argv[]) {
    int num = atoi(argv[1]); // Convert the first argument to an integer
    printf("You entered %d\n", num);
    return 0;
}