
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    int num;
    if (strcmp(argv[1], "") == 0) {
        fprintf(stderr, "Error: no input provided.\n");
        return 1;
    }

    if (sscanf(argv[1], "%d", &num) == 1) {
        printf("Input is a valid integer:\n");
        for (int i = num; i > 0; i--) {
            printf("%d ", i);
        }
        printf("\n");
    } else {
        fprintf(stderr, "Input is not a valid integer.\n");
        return 1;
    }

    return 0;
}