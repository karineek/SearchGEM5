
#include <stdio.h>
#include <stdlib.h>
#define TIMER_LENGTH 3 // number of seconds to wait for the input

 
int main(int argc, char *argv[]) {
    printf("Enter your name: ");
    char* user_input = malloc(strlen(argv[1]) + 1);
    strncpy(user_input, argv[1], strlen(argv[1]));
    printf("Hello %s\n", user_input);

    // wait for the input using a timer
    struct timespec startTime, endTime;
    gettimeofday(&startTime, NULL);
    scanf("%*c", &user_input[0]); // skip leading space
    gettimeofday(&endTime, NULL);
    double elapsedTime = difftime(endTime.tv_sec, startTime.tv_sec) + endTime.tv_usec * 0.000001;

    printf("Input took %f seconds\n", elapsedTime);

    return EXIT_SUCCESS;
}