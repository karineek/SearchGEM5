
#include <stdio.h>
int main(int argc, char *argv[]) {
    // Initialize variables with argv values
    int x = atoi(argv[1]);
    int y = atoi(argv[2]);

    // Perform some arithmetic operations and print the results
    printf("x + y = %d\n", x+y);
    printf("x - y = %d\n", x-y);
    printf("x * y = %d\n", x*y);
    printf("x / y = %d\n", x/y);

    return 0;
}