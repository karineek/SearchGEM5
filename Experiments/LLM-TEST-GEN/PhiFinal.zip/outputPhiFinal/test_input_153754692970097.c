
#include <stdio.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    // Check if input is valid
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <input file path>\n", argv[0]);
        return 1;
    }

    // Open input file for reading
    FILE *infile = fopen(argv[1], "rb");
    if (infile == NULL) {
        perror("Error opening file");
        return 2;
    }

    // Read input file and print output
    char buffer[1024];
    while (fgets(buffer, sizeof(buffer), infile) != NULL) {
        printf("%s\n", buffer);
    }

    fclose(infile);

    return 0;
}