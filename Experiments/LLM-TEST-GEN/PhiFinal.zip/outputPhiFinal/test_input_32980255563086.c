
#!/bin/bash
echo "This is an example of a string in a bash script. This will be used for testing..."
sleep 1