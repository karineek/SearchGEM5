
#include <stdio.h>

int main(int argc, char **argv) {
    if (argc == 1) { // input is taken via argv only
        printf("No command line arguments provided. Please try again.");
        return -1;
    }

    char *input = argv[1]; // take the first argument as input

    printf("Input: %s\n", input); // output the input

    if (strcmp(input, "Hello") == 0) { // compare the input with a known value
        printf("Output: Hello, world!\n");
    } else {
        printf("Output: Not Hello.\n");
    }

    return 0;
}