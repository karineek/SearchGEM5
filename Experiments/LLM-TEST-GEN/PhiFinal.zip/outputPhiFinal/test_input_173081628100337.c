
Enter a number: 3.14159
The floating-point representation of 3.14159 is 3.141590