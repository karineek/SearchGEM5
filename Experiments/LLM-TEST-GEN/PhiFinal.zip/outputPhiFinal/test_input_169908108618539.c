
#include <stdio.h>
#include <string.h>

int main(int argc, char** argv) {
    int n;
    if (argc == 2) {
        n = atoi(argv[1]);
        printf("%d\n", n);
    } else {
        printf("Usage: ./program <integer>\n");
        return 1;
    }

    return 0;
}