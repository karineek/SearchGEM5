
#include <stdio.h>
#include <string.h>

int main(int argc, char** argv) {
    // Check if enough arguments were given
    if (argc < 2) {
        printf("Error: you need to provide at least one argument\n");
        return 1;
    }

    // Get the first argument and output it back to the user
    char* input = argv[1];
    printf("Input: %s\n", input);

    return 0;
}