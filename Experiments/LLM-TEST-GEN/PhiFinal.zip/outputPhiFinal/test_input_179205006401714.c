
#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    FILE* fp = fopen(argv[1], "r");
    if (fp == NULL) {
        printf("Error: could not open input file.\n");
        return 1;
    }

    char line[1024];
    while ((fgets(line, sizeof(line), fp))) {
        // TODO: Apply Target-Specific Optimization here
        printf("%s\n", line);
    }

    fclose(fp);
    return 0;
}