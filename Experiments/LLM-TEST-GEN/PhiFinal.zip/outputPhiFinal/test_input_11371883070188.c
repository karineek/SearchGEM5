
#include <stdio.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s input_file\n", argv[0]);
        return 1;
    }

    // Read the contents of the input file and process it using Function Specialization
    FILE *f = fopen(argv[1], "r");
    if (f == NULL) {
        printf("Error: Unable to open file.\n");
        return 1;
    }

    // Read the input and process it using Function Specialization
    char input[100];
    fgets(input, 100, f);
    if (sscanf(input, "%d", &num) != 1 || num < 0 || num > 255) {
        printf("Invalid input: must be a number between 0 and 255.\n");
        return 2;
    }

    // Process the input using Function Specialization
    if (num % 2 == 0) {
        printf("The number is even.\n");
    } else {
        printf("The number is odd.\n");
    }

    // Write the output to standard output
    fclose(f);
    return 0;
}