
#include <stdio.h>
int main(int argc, char *argv[]) {
    int n;
    if (argc != 2) {
        printf("Usage: %s N\n", argv[0]);
        return 1;
    }
    n = atoi(argv[1]);
    for (int i = 0; i < n; i++) {
        if (i % 2 == 0) {
            printf("Even\n");
        } else {
            printf("Odd\n");
        }
    }
    return 0;
}