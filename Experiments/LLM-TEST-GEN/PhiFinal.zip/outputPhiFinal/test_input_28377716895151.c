
#include <stdio.h>
#define N 1000000

int main(int argc, char *argv[]) {
    int nums[N];
    if (argc != 2) {
        printf("Usage: %s input_file\n", argv[0]);
        return 1;
    }
    char* file = argv[1];
    if (!fopen(file, "r")) {
        printf("Error: cannot open %s for reading\n", file);
        return 1;
    }
    int n = 0;
    while (fscanf(file, "%d", &nums[n++]) == EOF) {
        if (n > N) {
            printf("Error: input file too large\n");
            return 1;
        }
    }
    fclose(file);
    for (int i = 0; i < n; ++i) {
        printf("%d ", nums[i]);
    }
    return 0;
}