
#include <stdio.h>

int main(int argc, char**argv) {
    // input taken via argv only
    if (argc != 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    // reading input from the file using fread function
    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        printf("Error: file not found or unable to open\n");
        return 1;
    }

    // creating a variable of type unsigned long int
    uintmax_t num = 0;

    // reading input from the file line by line and adding it to the variable
    while (fread(&num, sizeof(uintmax_t), 1, fp) == 1) {
        printf("%d\n", num);
    }

    // closing the file pointer
    fclose(fp);

    return 0;
}