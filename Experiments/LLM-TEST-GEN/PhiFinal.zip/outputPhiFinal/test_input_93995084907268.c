
#include <stdio.h>
void main() {
    printf("%s\n", argv[1]);
}