
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {
    int i;
    for (i = 1; i <= argc - 2; i++) {
        if (!strcmp(argv[i], "--version")) {
            printf("This version: %s\n", argv[i+1]);
        } else {
            if (strcmp(argv[i], "--help")) {
                printf("Usage: %s <input>\n", argv[0]);
            } else {
                char input_str[BUF_SIZE];
                fgets(input_str, BUF_SIZE, stdin);
                printf("Your input is: %s\n", input_str);
            }
        }
    }
    return 0;
}