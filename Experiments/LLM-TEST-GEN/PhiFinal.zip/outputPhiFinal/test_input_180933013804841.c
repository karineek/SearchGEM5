
#include <stdio.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input>\n", argv[0]);
        return 1;
    }

    char input[strlen(argv[1]) + 1];
    strcpy(input, argv[1]);

    for (int i = 0; i < strlen(input); i++) {
        if (input[i] >= 'A' && input[i] <= 'Z') {
            printf("Error: Input must only contain lowercase letters.\n");
            return 1;
        }
    }

    printf("Input: %s\n", input);

    return 0;
}