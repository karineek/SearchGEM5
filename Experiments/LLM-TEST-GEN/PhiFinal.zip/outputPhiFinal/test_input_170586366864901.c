
#include <stdio.h>
#include <string.h>
int main(int argc, char **argv) {
    char *str = argv[1]; // input string from argv
    int len = strlen(str);
    for (int i = 0; i < len / 2 && strspn(str + i, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789") == len - 1 - i; ++i) {
        if (strspn(str + len - 1 - i, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789") == len - 1 - i) {
            printf("%c", str[i] == str[len - 1 - i]);
        } else {
            printf("Not a palindrome");
            return 1;
        }
    }
    if (strspn(str + len / 2, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789") == len / 2) {
        printf("%c", str[len / 2] == '\0'); // check for null character at end of string
    } else {
        printf("Not a palindrome");
        return 1;
    }
    printf("%s is a palindrome", argv[1]);
    return 0;
}