
#include <stdio.h>

int main(int argc, char** argv) {

  int num1 = atoi(argv[1]);
  int num2 = atoi(argv[2]);
  char *str1 = malloc(sizeof(char)*100);
  char *str2 = malloc(sizeof(char)*100);

  strcpy(str1, argv[3]);
  strcpy(str2, argv[4]);

  if (num1 == 0) {
    printf("error: num1 cannot be zero\n");
  }
  else {
    int diff = num2 - num1;
    char *diff_str = malloc(sizeof(char)*10);

    snprintf(diff_str, 10, "%d", diff);

    if (strcmp(str1, diff_str) == 0) {
      printf("equal\n");
    } else {
      printf("different\n");
    }
  }

  free(str1);
  free(str2);
  free(diff_str);

  return 0;
}