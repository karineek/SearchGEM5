
#include <iostream>
#include <vector>

int main() {
  std::vector<int> inputs;

  // Read input from command line arguments
  for (int i = 1; i <= argc; i++) {
    inputs.push_back(atoi(argv[i]));
  }

  // Perform Inliner Heuristics optimization
  int output = 0;
  for (auto x : inputs) {
    output += x;
    std::cout << "Sum: " << output << std::endl;
  }

  return 0;
}