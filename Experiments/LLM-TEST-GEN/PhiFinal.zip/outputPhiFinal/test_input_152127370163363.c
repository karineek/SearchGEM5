
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {

    // check if the number of arguments provided is correct
    if (argc != 3) {
        printf("Error: incorrect number of arguments\n");
        return 1;
    }

    // parse the first argument as an integer value
    int val = atoi(argv[1]);

    // use Loop Fusion optimization to reduce computation time and memory usage
    while (val > 0) {
        printf("%d\n", val--);
    }

    return 0;
}