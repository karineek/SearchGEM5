
#include <stdio.h>
#include <string.h>

char *concatenate(int argc, char **argv) {
  char output[100];
  int i;

  for (i = 1; i <= argc; i++) {
    strcat(output, argv[i]);
  }

  return output;
}