
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    // Get length of string
    int len = strlen(argv[1]);

    // Reverse the input string and print it out
    printf("Reversed: %s\n", strrev(argv[1]));

    return 0;
}