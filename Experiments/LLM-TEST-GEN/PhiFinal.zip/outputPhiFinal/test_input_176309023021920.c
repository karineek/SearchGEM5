
#include <stdio.h>
#include <math.h>

int main() {
    for (int i = 1; i <= strlen(argv[1]); i++) {
        printf("sinh(%c) = %f\n", argv[i], csinh((double)argv[i]));
    }

    return 0;
}