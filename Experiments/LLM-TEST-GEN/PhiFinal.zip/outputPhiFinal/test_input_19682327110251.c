
#include <stdio.h>

int main(int argc, char **argv) {
    int x = 0;
    if (argc != 2) {
        printf("Usage: %s integer\n", *argv[0]);
        return 1;
    } else {
        x = atoi(argv[1]);
        if (x < 0) {
            printf("Invalid input. Please enter a non-negative integer.\n");
            return 1;
        }
        int result = x * x + 10; // inline the function call to save time and space
        printf("The square of %d is %d.\n", x, result);
        return 0;
    }
}