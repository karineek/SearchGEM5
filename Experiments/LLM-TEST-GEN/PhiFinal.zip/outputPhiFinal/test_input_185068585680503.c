
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    int i;
    char *str = argv[1];

    // Loop over all characters in the input string and print them out
    for (i = 0; str[i] != '\0'; i++) {
        printf("%c", str[i]);
    }

    return 0;
}