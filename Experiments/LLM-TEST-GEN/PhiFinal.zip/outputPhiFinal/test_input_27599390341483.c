
#include <stdio.h>
#include <stdbool.h>
#include <ctype.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s input\n", argv[0]);
        return 1;
    }

    int input = strtoul(argv[1], NULL, 10);
    if (input <= 0) {
        printf("Invalid input. Please enter a positive integer\n");
        return 1;
    }

    for (int i = 0; i < 5; i++) {
        int product = 1;
        for (int j = 0; j < input; j++) {
            product *= i + j;
        }
        printf("Product of %d: %d\n", i, product);
    }

    return 0;
}