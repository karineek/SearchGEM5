
#include <stdio.h>

int main(int argc, char* argv[]) {
    printf("Enter a number: ");
    scanf("%d", &argv[1]);
    return 0;
}