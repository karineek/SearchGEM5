
#include <stdio.h>
int main(int argc, char **argv) {
    int i;
    for (i = 1; i <= argc; i++) {
        if (!isfinite(strtol(argv[i], NULL, 0))) {
            fprintf(stderr, "Error: input must be a number.\n");
            return 1;
        }
        printf("Input %s is a valid integer.\n", argv[i]);
    }
    return 0;
}