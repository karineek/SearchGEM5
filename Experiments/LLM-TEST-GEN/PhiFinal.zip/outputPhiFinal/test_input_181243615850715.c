
#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]) {
    char *input_str = NULL;

    if (argc > 1) {
        input_str = malloc(strlen(argv[1]) + 1);
        strcpy(input_str, argv[1]);
    } else {
        printf("Please provide input.\n");
    }

    printf("Input: %s\n", input_str);

    return 0;
}