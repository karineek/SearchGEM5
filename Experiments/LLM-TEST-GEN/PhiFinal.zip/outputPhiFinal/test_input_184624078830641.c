
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    int sum = 0;
    for (int i = 1; i <= argc; i++) {
        int number = atoi(argv[i]);
        sum += number;
    }
    printf("The average is: %d", sum / (int)argc);
    return 0;
}