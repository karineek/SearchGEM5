
#include <stdio.h>

int main(int argc, char *argv[]) {
    // Check if there are enough command line arguments
    if (argc != 2) {
        printf("Usage: %s integer\n", argv[0]);
        return 1;
    }

    // Parse the input as an integer using sscanf function
    int number = 0;
    if (sscanf(argv[1], "%d", &number) == 1) {
        printf("The input is %d\n", number);
    } else {
        printf("Invalid input. Please enter an integer.\n");
        return 2;
    }

    // Return the program exit code (0 for success, 1 or 2 for error)
    return 0;
}