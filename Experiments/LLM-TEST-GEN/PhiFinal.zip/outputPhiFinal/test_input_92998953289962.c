
#include <stdio.h>
#include <string.h>

int main() {
    char* argv[2]; // input is taken via argv only

    argv[0] = "input.txt"; // name of the file to read from
    argv[1] = "-l"; // -l flag for loop vectorization optimization

    int i;
    char* line = NULL;
    size_t len = 0;
    FILE* fp = fopen(argv[0], "r");

    if (fp == NULL) { // check if file is open for reading
        printf("Error: could not open file\n");
        return 1;
    }

    while ((line = readline(fp)) != NULL) {
        // process each line of the input file here
        printf("Processed: %s\n", line);
    }

    fclose(fp); // close the file when done

    return 0;
}