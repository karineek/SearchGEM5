
#include <stdio.h>

int main(int argc, char **argv) {

   // example usage with Sparse Conditional Constant Propagation and Static analysis in Clang
   if (strcmp(argv[1], "hello") == 0) {
      printf("Hello world!");
   } else {
      printf("Goodbye world!");
   }

   return 0;
}