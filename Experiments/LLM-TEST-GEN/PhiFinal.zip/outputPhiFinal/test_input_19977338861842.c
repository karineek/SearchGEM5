
#include <stdio.h>
#include <string.h>

/* function to get the arguments from command line */
int main(int argc, char *argv[]) {
    // initialize the output string
    char output[100];

    // loop through the arguments to parse and concatenate them into a message
    for (int i = 1; i < argc; i++) {
        sscanf(argv[i], "%s", &output);
    }

    printf("Message: %s\n", output);

    // return the program code
    return 0;
}