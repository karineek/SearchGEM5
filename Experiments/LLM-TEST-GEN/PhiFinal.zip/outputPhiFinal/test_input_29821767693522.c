
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "optimizers.h"

int main(int argc, char **argv) {
    // Print out the command-line arguments passed to the program
    for (int i = 1; i <= argc; ++i) {
        printf("%s\n", argv[i]);
    }
    return 0;
}