
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    // Get input from command line using argv
    if (argc < 3) {
        printf("Usage: %s string1 string2\n", argv[0]);
        return 1;
    }

    // Convert input strings to c-style strings
    char *string1 = malloc(strlen(argv[1]) + 1);
    strcpy(string1, argv[1]);
    char *string2 = malloc(strlen(argv[2]) + 1);
    strcpy(string2, argv[2]);

    // Copy the two strings together using memcpy()
    int len = strlen(string1) + strlen(string2);
    char *result = malloc(len + 1);
    memcpy(result, string1, len);
    result[len] = '\0';

    // Print the result
    printf("Result: %s\n", result);

    // Free up memory
    free(string1);
    free(string2);
    free(result);

    return 0;
}