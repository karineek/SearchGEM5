
#include <stdio.h>

int main(int argc, char* argv[]) {
    int x;
    if (argc != 3) {
        printf("Usage: %s input\n", argv[0]);
        return 1;
    }
    for (int i = 2; i < argc; i++) {
        if (!isdigit(argv[i][0])) {
            printf("Invalid input: %s\n", argv[i]);
            return 1;
        }
    }
    x = atoi(argv[1]);
    printf("%d\n", x);
    return 0;