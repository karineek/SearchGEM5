
#include <stdio.h>

int main(int argc, char** argv) {
    if (argc != 2) {
        printf("Usage: %s <integer>\n", *argv);
        return 1;
    }

    int num = atoi(argv[1]);
    printf("Binary: ");
    for (int i = 0; i < 32; i++) {
        if ((num >> i) & 1) {
            printf("1");
        } else {
            printf("0");
        }
    }

    printf("\nDecimal: %d\nHexadecimal: %X", num, num);
    return 0;
}