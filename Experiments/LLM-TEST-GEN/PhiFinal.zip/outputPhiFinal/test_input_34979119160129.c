
#include <stdio.h>
#include <sys/types.h>

int main(int argc, char*argv[]) {

    double num1 = atof(argv[1]);
    double num2 = atof(argv[2]);
    int i;

    for (i = 0; i < sizeof(num1); i++) {
        printf("%lf\n", num1 + num2);
    }

    return EXIT_SUCCESS;
}