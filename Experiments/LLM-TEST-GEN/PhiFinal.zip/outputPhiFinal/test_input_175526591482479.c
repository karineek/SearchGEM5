
#include <stdio.h>
#include <stdlib.h>

void wcscpy_s(char *dst, const char *src) {
    int cnt = 0;
    while ((dst[cnt++] = (char) getc(src)) != EOF);
}

int main() {
    // Declare argv array to store input arguments
    char *argv[] = {NULL};

    // Number of command line arguments
    int argc = 0;

    // Parse command line arguments using argv
    for (int i=1; i<argc; i++) {
        argv[i] = strdup(argv[i]); // Copy each argument into a new memory location
    }

    // Print the number of command line arguments
    printf("%d\n", argc);

    return 0;
}