
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#define NUM_ARG 3

int main(int argc, char **argv) {
    int i, n;
    double sum = 0;

    // Check if the number of arguments is correct
    if (argc != NUM_ARG + 1) {
        printf("Error: incorrect number of arguments\n");
        return 1;
    }

    // Extract the value of n from the first argument
    n = atoi(argv[1]);

    // Check if n is a positive integer
    if (n <= 0) {
        printf("Error: input must be a positive integer\n");
        return 1;
    }

    // Loop from 1 to n and calculate the sum of the first n integers
    for (i = 1; i <= n; i++) {
        sum += i;
    }

    // Calculate the factorial of n using recursion
    int fact = n;
    while (n > 1) {
        n--;
        fact *= n;
    }

    // Print the result to stdout
    printf("Sum: %f\n", sum);
    printf("Factorial: %d\n", fact);

    return 0;
}