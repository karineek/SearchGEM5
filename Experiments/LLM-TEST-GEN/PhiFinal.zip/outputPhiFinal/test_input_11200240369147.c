
#include <stdio.h>
int main(int argc, char *argv[]) {
  int n = atoi(argv[1]); // convert first argument to integer
  for (int i = 0; i < n; i++) {
    printf("Hello, World!\n");
  }
  return 0;
}