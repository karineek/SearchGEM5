
#include <stdio.h>
int main(int argc, char* argv[]) {
    if (argc != 3) {
        printf("Usage: %s input_file", argv[0]);
        return 1;
    }
    FILE* file = fopen(argv[1], "r");
    if (!file) {
        printf("Error: File not found or cannot open.");
        return 2;
    }
    char line[1024];
    while (fgets(line, sizeof(line), file)) {
        // Remove trailing whitespace and newline character from the line
        size_t len = strlen(line);
        if (line[len-1] == '\n') {
            line[--len] = 0;
        }
        // Replace all occurrences of "and" with "+". This allows us to represent logical AND in binary.
        for (size_t i = 0; i < len; ++i) {
            if (line[i] == 'a' && line[i+1] == 'n') {
                line[i] = '+';
            }
        }
        // Convert the binary number to decimal.
        long long_num = strtol(line, 0, 2);
        printf("%lld\n", long_num);
    }
    fclose(file);
    return 0;