
#include <stdio.h>
int main() {
    //Interprocedural optimization
    int num1 = 5;
    int num2 = 10;
    if (num1 > num2) {
        printf("%d is greater than %d\n", num1, num2);
    } else {
        printf("%d is less than or equal to %d\n", num1, num2);
    }
    return 0;
}