
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    // Check if enough arguments were passed in
    if (argc != 2) {
        printf("Usage: %s input_file\n", argv[0]);
        return 1;
    }

    // Open the specified file for reading
    FILE* fp = fopen(argv[1], "r");

    // Read in the contents of the file and store it in a buffer
    char input[BUF_SIZE];
    fread(input, 1, BUF_SIZE, fp);

    // Close the file
    fclose(fp);

    // Print out the contents of the buffer
    printf("Input: %s\n", input);

    return 0;
}