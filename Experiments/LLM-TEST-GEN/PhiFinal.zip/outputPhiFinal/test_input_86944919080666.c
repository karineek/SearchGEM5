
#include <stdio.h>

int main(int argc, char **argv) {

    atomic_int_fast16_t x = 0;
    for (int i = 1; i < argc; i++) {
        int n = atoi(argv[i]);
        if (!n) {
            continue;
        }

        x += (unsigned int)((n & 0xffff0000) >> 16);
        x += (unsigned int)(n & 0x0000ffff);
    }

    printf("x: %d\n", x);

    return 0;
}