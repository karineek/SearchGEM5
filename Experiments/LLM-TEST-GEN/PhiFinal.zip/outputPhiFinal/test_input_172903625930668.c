
#include <stdio.h>
#define MAX_ARG 10
int main(int argc, char *argv[]) {
    for (int i=1; i<argc && strlen(argv[i]) <= 1000 && i <= MAX_ARG; i++) {
        printf("%s\n", argv[i]); // Output the argument, max 10
    }
    return 0;
}