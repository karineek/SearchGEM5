
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char* argv[]) {
    // Check for valid command line arguments
    if (argc != 2) {
        fprintf(stderr, "Usage: %s input\n", argv[0]);
        return 1;
    }

    // Read the input file name from the first argument (argv[1])
    char* filename = argv[1];

    // Open the file for reading
    FILE* fp = fopen(filename, "r");
    if (!fp) {
        perror("Failed to open file:");
        return 1;
    }

    // Read the contents of the file into a buffer
    char* buf = malloc(1024 * 1024);
    if (!buf) {
        perror("Failed to allocate memory");
        return 1;
    }
    fread(buf, sizeof(char), 1024*1024, fp);

    // Close the file
    fclose(fp);

    // Output the contents of the buffer to stdout
    printf("Input:\n");
    puts(buf);

    return 0;
}