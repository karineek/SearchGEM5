
#include <stdio.h>

int main(int argc, char** argv) {
    int num = atoi(argv[1]); //converts input from argument to integer
    printf("The entered number is %d", num);

    if (num % 2 == 0) {
        printf("It's an even number!");
    } else {
        printf("It's an odd number!");
    }

    return 0;
}