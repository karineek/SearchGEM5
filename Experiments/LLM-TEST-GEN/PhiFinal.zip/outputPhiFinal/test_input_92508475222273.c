
#include <stdio.h>
#include <stdlib.h>
#include "spcc_support.h"
#include "catanf.h"

int main(int argc, char *argv[]) {
    for (int i = 1; i <= argc; i++) {
        if (isdigit(*(argv[i]))) {
            // Process the number argument as required.
            char *num = argv[i];
            int num_value = atoi(num);
            printf("%d\n", num_value);
        } else {
            // Process the argument as required.
            int arg_int = atoi(argv[i]);
            printf("%d\n", arg_int);
        }
    }

    return 0;
}