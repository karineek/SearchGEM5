
#include <stdio.h>
#include <math.h>
#include <string.h>

int main(int argc, char *argv[]) {

    // Check if the correct number of arguments is given
    if (argc != 3) {
        printf("Usage: %s INPUT_FILE", argv[0]);
        return 1;
    }

    // Get the input file name from command line arguments
    char *input_file = argv[1];

    // Open the input file for reading
    FILE *input_f = fopen(input_file, "r");
    if (input_f == NULL) {
        printf("Error: could not open input file\n");
        return 1;
    }

    // Read the first line of the input file
    char *line = fgets(input_f, sizeof(char) * 100, input_f);

    // Check if the input file is empty
    while (strcmp(line, "") == 0) {
        line = fgets(input_f, sizeof(char) * 100, input_f);
    }

    // Print the first line of the input file
    printf("First line: %s\n", line);

    // Close the input file
    fclose(input_f);

    return 0;
}