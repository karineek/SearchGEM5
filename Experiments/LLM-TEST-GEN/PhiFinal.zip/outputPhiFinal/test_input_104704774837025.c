
#include <stdio.h>
int main(int argc, char **argv) {
    int n = atoi(argv[1]); //Assuming the first argument is an integer

    for (int i = 2; i <= n; i++) {
        printf("%d\n", 1.0 + (float)i / ((float)n - i));
    }
    return 0;
}