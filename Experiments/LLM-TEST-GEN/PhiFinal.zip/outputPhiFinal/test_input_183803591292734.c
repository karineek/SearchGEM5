
#include <iostream>
#include <string>
using namespace std;

int main() {
    // Read input from command line arguments using argv[]
    int n = atoi(argv[1]);
    string arr[n];

    for (int i=2; i<=n; i++) {
        cin >> arr[i-1];
    }

    // Dead Code Elimination and Deals with binary formats

    // Maximum length

    // Return a C++ program

    return 0;
}