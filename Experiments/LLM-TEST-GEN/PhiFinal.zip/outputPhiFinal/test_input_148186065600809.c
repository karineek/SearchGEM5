
#include <stdio.h>

int main(int argc, char** argv) {

    if (argc != 3) {
        printf("Usage: %s operator operand\n", argv[0]);
        return 1;
    }

    int op1 = atoi(argv[2]);
    char op = argv[1][0];

    switch (op) {
        case '+':
            printf("%d + %d = %d\n", op1, atoi(argv[3]), op1 + atoi(argv[3]));
            break;
        case '-':
            printf("%d - %d = %d\n", op1, atoi(argv[3]), op1 - atoi(argv[3]));
            break;
        case '*':
            printf("%d * %d = %d\n", op1, atoi(argv[3]), op1 * atoi(argv[3]));
            break;
        case '/':
            if (atoi(argv[3]) == 0) {
                printf("Error: division by zero\n");
                return 1;
            }
            printf("%d / %d = %d\n", op1, atoi(argv[3]), op1 / atoi(argv[3]));
            break;
        default:
            printf("Invalid operator\n");
            return 1;
    }

    return 0;
}