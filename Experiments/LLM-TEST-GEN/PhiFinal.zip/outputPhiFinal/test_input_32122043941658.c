
#include <stdio.h>

int main(int argc, char *argv[]) {
    printf("Number of arguments: %d\n", argc);

    // Printing the input from command line
    for (int i = 1; i < argc; i++) {
        printf("Argument #%d: %s\n", i, argv[i]);
    }
}