
#include <stdio.h>
#include <stdbool.h>

int main(int argc, char *argv[]) {
    int limit = atoi(argv[1]);
    if (limit <= 0) {
        printf("Limit must be a positive integer.\n");
        return 1;
    }

    long sum = 0;
    for (int i = 1; i <= limit; ++i) {
        sum += i;
    }

    printf("Sum of numbers between 1 and %d: %ld\n", limit, sum);

    return 0;
}