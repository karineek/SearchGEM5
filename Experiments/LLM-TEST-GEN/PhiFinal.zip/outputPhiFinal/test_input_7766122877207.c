
#include <stdio.h>

int main(int argc, char *argv[]) {
    int n = atoi(argv[1]);
    int m = atoi(argv[2]);

    printf("Input: ");
    for (int i = 1; i <= argc - 1; i++) {
        char c = argv[i][0];
        if (!isdigit(c)) break;
    }

    printf("%d, %d\n", n, m);
    ilogbf(&n, &m);
    return 0;
}