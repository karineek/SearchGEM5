
#include <stdio.h>
#include <string.h>

int main() {
    // input taken via argv
    char* filename = argv[1];

    FILE* fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("Cannot open file %s\n", filename);
        return 1;
    }

    // read input from file and process it with snprintf function
    int n = 0, i = 0, j = 0;
    char* buffer = (char*) malloc(sizeof(char) * 1024);
    while (fgets(buffer + i, sizeof(buffer), fp)) {
        snprintf(buffer + n, size_t(1024), "%s", buffer + n);
        j++;
    }

    printf("Processed %d lines\n", j);

    // close file
    fclose(fp);

    return 0;