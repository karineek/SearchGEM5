
#include <stdio.h>

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s INPUT\n", argv[0]);
        return 1;
    }

    int input = atoi(argv[1]);
    int square = input * input;
    printf("The square of %d is %d.\n", input, square);

    return 0;
}