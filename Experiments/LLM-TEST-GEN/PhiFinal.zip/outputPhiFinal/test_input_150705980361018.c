
#include <stdio.h>  // printf, scanf
#include <stdbool.h>

int main(int argc, char *argv[]) {
    int num1;
    int num2;

    if (argc != 3) {
        printf("Usage: %s <num1> <num2>\n", argv[0]);
        return -1; // error message
    }

    num1 = strtol(argv[1], NULL, 10);
    num2 = strtol(argv[2], NULL, 10);

    if (num1 == 0 || num2 == 0) {
        printf("Error: zero argument\n");
        return -1; // error message
    }

    int sum = num1 + num2;
    int difference = num1 - num2;
    int product = num1 * num2;
    int quotient = num1 / num2;

    printf("Sum: %d\n", sum);
    printf("Difference: %d\n", difference);
    printf("Product: %d\n", product);
    printf("Quotient: %d\n", quotient);

    return 0; // success message
}