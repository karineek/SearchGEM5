
#include <stdio.h>

int main(int argc, char *argv[]) {
  int num1, num2;

  // Read the input from args
  if (argc != 3) {
    printf("Usage: %s num1 num2\n", argv[0]);
    return 1;
  }

  // Check for invalid inputs
  if ((int) strtol(argv[1], NULL, 10) <= 0 || (int) strtol(argv[2], NULL, 10) <= 0) {
    printf("Invalid input\n");
    return 1;
  }

  // Add the two numbers and print the sum
  num1 = atoi(argv[1]);
  num2 = atoi(argv[2]);
  printf("%d + %d = %d\n", num1, num2, num1 + num2);

  return 0;
}