
#include <stdio.h>
#define MAX 1000
#define SIZE 10

int main(int argc, char *argv[]) {

	// Initialize the inputs with default values:
	char a[MAX];
	long b = 0;
	long c = 0;
	long d = 0;

	// Get input from command line arguments:
    if (argc > 1) {
        a = argv[1];
    }

    // Check if the first character is 's':
    char s_flag;
    s_flag = a[0];
    a++;
    
    // If the flag is 's', parse the inputs as integers:
    if (s_flag == 's') {
        b = atoi(a);
        c = atoi(++a);
        d = atoi(++a);
    } else {
        // If the flag is 'c', parse the inputs as a list of integers:
        for (int i=1; i<argc; ++i) {
            b = atoi(++a);
        }

        // Check if there are more than SIZE inputs:
        for (int i=1; i<argc-SIZE+1; ++i) {
            c = atoi(++a);
            d = atoi(++a);

            if (argc-SIZE > i+2) {
                break; // too many inputs
            } else {
                b += c + d;
            }
        }
    }

	// Perform some operations on the inputs:
    if (s_flag == 'c') {
        long sum = b + c;
        printf("The sum is %ld.\n", sum);
    } else if (argc == 3) {
        long product = b * c * d;
        printf("The product is %ld.\n", product);
    } else {
        long result = b - c + d;
        printf("The difference is %ld.\n", result);
    }

	// Check if the LC_TIME macro has been enabled:
    if (argc > 2 && argv[2][0] == 'i') {
        long time = atoi(++a);
        printf("The elapsed time is %ld milliseconds.\n", time * 1000);
    }

	// Print out a message indicating the end of the program:
    printf("\nThank you for using my program. Goodbye!\n");
}