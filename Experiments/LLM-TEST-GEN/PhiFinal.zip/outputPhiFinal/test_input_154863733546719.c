
#include <stdio.h>

int main(int argc, char *argv[]) {
    int n;
    if (argc != 2) {
        printf("Usage: %s <filename>\n", argv[0]);
        return 1;
    }
    FILE *f = fopen(argv[1], "r");
    if (f == NULL) {
        printf("Could not open file: %s\n", argv[1]);
        return 1;
    }
    int sum = 0;
    char c;
    while ((c = fgetc(f)) != EOF) {
        if (isdigit(c)) {
            n = 10 * sum + (int)(c - '0');
        } else {
            fputs("Invalid input: " + argv[1], stderr);
            return 1;
        }
        sum = n;
    }
    printf("Sum of integers in %s: %d\n", argv[1], sum);
    fclose(f);
    return 0;
}