
#include <stdio.h>

int main(int argc, char* argv[]) {
    // Check if enough arguments are provided
    if (argc != 2) {
        printf("Usage: %s input\n", argv[0]);
        return 1;
    }

    // Read the input from command line argument
    char input_str[256];
    strcpy(input_str, argv[1]);

    printf("Input: %s\n", input_str);

    return 0;
}