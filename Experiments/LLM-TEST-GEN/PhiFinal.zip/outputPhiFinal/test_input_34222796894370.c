
#include <stdio.h>

int main(int argc, char *argv[]) {
    int i;
    for (i = 1; i <= argc - 2; i++) {
        printf("%s ", argv[i]);
    }
    return 0;
}