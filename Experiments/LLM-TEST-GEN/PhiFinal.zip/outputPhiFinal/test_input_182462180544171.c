
#include <stdio.h>

int main(int argc, char *argv[]) {

    printf("Enter a number:");
    int num = atoi(argv[1]);

    if (num % 2 == 0) {
        printf("%d is even.\n", num);
    } else {
        printf("%d is odd.\n", num);
    }

    return 0;
}