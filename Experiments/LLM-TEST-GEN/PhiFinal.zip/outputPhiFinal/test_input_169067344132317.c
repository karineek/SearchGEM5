
#include <stdio.h>
#include <string.h>
#include <math.h>

int main(int argc, char *argv[]) {
    // Initialize input values from command line arguments
    int num1 = strtol(argv[1], NULL, 10);
    int num2 = strtol(argv[2], NULL, 10);

    // Perform arithmetic operations on the input values
    double result1 = modf(num1 / num2, &quotient);
    printf("Result 1: %lf\n", quotient);

    double result2 = sqrt(pow((num1 - num2), 2));
    printf("Result 2: %f\n", result2);

    return 0;
}