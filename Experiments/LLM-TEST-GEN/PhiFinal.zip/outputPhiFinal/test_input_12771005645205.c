
#include <stdio.h>

int main(int argc, char **argv) {
    char *name = "";

    if (argc == 2) {
        // 1st argument is the user's name
        name = strdup(argv[1]);
    } else {
        printf("Error: program requires a single argument\n");
        return 1;
    }

    printf("Hello, %s!\n", name);
    free(name); // don't forget to free the memory used by strdup() when you're done with it

    return 0;
}