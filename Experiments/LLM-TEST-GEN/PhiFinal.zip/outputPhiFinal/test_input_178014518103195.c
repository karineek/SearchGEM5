
#include <stdio.h>

void functionInline() { // This is an example of a function that takes input using argv
    printf("This function was called with argument '%s'\n", argv[1]);
}

int main(int argc, char** argv) { // This is the C program that includes the above functions and uses argv as its only argument.
    printf("Input: "); // To recup the code contains these: Function Inlining and Handles Abstract Syntax Tree (AST), thrd_. To excersises this idea in C
    int num = atoi(argv[1]);

    if (num % 2 == 0) {
        functionInline(); // Function Inlining is a technique where functions are optimized by calling them with their local variables instead of passing arguments to the main function.
    } else {
        printf("%d is an odd number\n", num);
    }

    return 0;
}