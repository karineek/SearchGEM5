
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAX_LINE 100
int main(int argc, char**argv){
    // Initialize variables to hold input from command line arguments
    char* fileName = "input";
    char* outputFile = NULL;
    int numLines = 0;
    // Check if enough command line arguments are provided for input and output files
    if (argc < 3){
        printf("Error: Please provide at least two command line arguments.\n");
        exit(EXIT_FAILURE);
    }
    // Get input file name from first command line argument
    fileName = argv[1];
    // Get output file name from second command line argument
    outputFile = argv[2];
    // Check if input file exists and is writable
    FILE* inp = fopen(fileName, "r");
    if (inp == NULL){
        printf("Error: Input file does not exist.\n");
        exit(EXIT_FAILURE);
    }
    // Read in input file line by line and output to specified file
    int c = 0;
    char line[MAX_LINE];
    while ((c < MAX_LINE) && (fgets(line, sizeof(line), inp)) != NULL){
        if (numLines == 0){
            // Write input file name to output file header
            fprintf(outputFile, "Input File: %s\n", fileName);
        }
        else if (numLines == 1){
            // Write input line number to output file header
            fprintf(outputFile, "Input Line: %d\n", c + 2);
        }
        else if (numLines == MAX_LINES){
            // Write input line number and current character in input to output file header
            fprintf(outputFile, "Input Line: %d\t%c\n", c + 2, (char)getc(inp));
        }
        else if (numLines > 1){
            // Write input line number and current character in input to output file header
            fprintf(outputFile, "Input Line: %d\t%c\n", c + 2, (char)getc(inp));
        }
        else if (numLines > 2){
            // Write input line number and current character in input to output file header
            fprintf(outputFile, "Input Line: %d\t%c\n", c + 2, (char)getc(inp));
        }
        else if (numLines > 3){
            // Write input line number and current character in input to output file header
            fprintf(outputFile, "Input Line: %d\t%c\n", c + 2, (char)getc(inp));
        }
        else if (numLines > 4){
            // Write input line number and current character in input to output file header
            fprintf(outputFile, "Input Line: %d\t%c\n", c + 2, (char)getc(inp));
        }
        else{
            // Write input line number and current character in input to output file header
            fprintf(outputFile, "Input Line: %d\t%c\n", c + 2, (char)getc(inp));
        }
        // Increment line count and output the current input line
        numLines++;
        fputs(line, stdout);
        c = 0;
    }
    // Close input file and output file
    fclose(inp);
    if (outputFile != NULL){
        fclose(outputFile);
    }
    return 0;