
#include <stdio.h>

int main(int argc, char* argv[]) {
    printf("%s\n", argv[1]); // vprintf uses the string to print
    return 0;
}