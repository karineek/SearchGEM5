
#include <stdio.h>
#include <string.h>

int main(int argc, char** argv) {

  printf("Input file name:\n");
  fgets(&argv[1], 100, stdin);
  char *file_name = strtok(argv[1], "\n");

  FILE* file = fopen(file_name, "r");
  if (file == NULL) {
    printf("Error: File not found.\n");
    return 1;
  }

  char line[1000];
  while (fgets(line, sizeof(line), file)) {
    int len = strlen(line);
    if (len > 0 && line[len-1] == '\n') {
      line[--len] = '\0';
    }

    // Perform optimization here
    printf("Processing line: %s\n", line);
  }

  fclose(file);

  return 0;
}