
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s string\n", argv[0]);
        return 1;
    }

    char src[] = argv[1];
    char dest[strlen(src) + 1];

    for (int i = 0, j = 0; i < strlen(src); i++, j++) {
        if (i % 2 == 0) {
            dest[j] = src[i];
        } else {
            dest[j + 1] = src[i];
        }
    }

    dest[strlen(dest) - 1] = '\0'; // add null terminator at end of string

    printf("Source: %s\n", argv[1]);
    printf("Destination: %s\n", dest);

    return 0;
}