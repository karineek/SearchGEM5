
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    // Check if there is only one argument passed to the program
    if (argc != 2) {
        printf("Usage: %s <input-string>\n", argv[0]);
        return 1;
    }

    // Read the input string from the command line argument
    char *inp = strdup(argv[1]);

    if (NULL == inp) {
        printf("Error: Could not allocate memory for input.\n");
        return 1;
    }

    // Convert the string to an unsigned int type and print it out
    int x = strtol(inp, NULL, 10);
    printf("%d\n", x);

    // Clean up memory for input string
    free(inp);

    return 0;
}