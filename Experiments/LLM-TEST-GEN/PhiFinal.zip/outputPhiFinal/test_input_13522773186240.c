
#include <iostream>
#include <vector>
#include <algorithm>
#include <chrono>
#include <stdlib.h>

using namespace std;

// Serialize an object to a string
string serialize(const vector<int>& obj) {
    stringstream ss;
    for (const auto& x : obj) {
        ss << static_cast<char>(x);
    }
    return ss.str();
}

// Deserialize a string back to an object
vector<int> deserialize(string s) {
    vector<int> v;
    for (const char c : s) {
        int x = static_cast<int>(c);
        v.push_back(x);
    }
    return v;
}

int main() {
    // Get input from command line arguments
    string argv[2];
    for (auto it = argv + 1; it < argv + 2; ++it) {
        cin.ignore(1, '\n'); // Ignore any newline characters
    }

    // Perform optimization using the serialized object
    vector<int> input = deserialize(argv[0]);
    string serialized_input = serialize(input);
    double best_value = 0;

    for (double epsilon : {1e-6, 1e-8, 1e-10}) {
        // Create a new object with the current value of FLT_EPSILON
        vector<int> input2 = deserialize(argv[0]);
        input2.push_back((double)FLT_EPSILON);

        // Serialize the new object and compare to the original object
        string serialized_input2 = serialize(input2);
        if (serialized_input == serialized_input2) {
            continue; // Skip this iteration since the objects are already equal
        }

        double value = 0.0;
        for (int i : input2) {
            // Simulate some computation here...
            value += abs(i);
        }

        if (value < best_value) {
            best_value = value;
        }
    }

    // Print out the best value and FLT_EPSILON
    cout << "Best value found: " << best_value << endl;
    cout << "FLT_EPSILON used: " << (double)FLT_EPSILON << endl;

    return 0;
}