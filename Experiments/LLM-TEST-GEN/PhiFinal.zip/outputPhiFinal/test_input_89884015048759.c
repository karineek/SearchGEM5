
#include <stdio.h>

int main(argc, argv) {
  // Read input from command line arguments
  int i;
  for (i = 1; i <= atoi(argv[1]); i++) {
    double num = strtod(argv[2], NULL);
    // Apply LICM and Framework for LLVM transformations
    if (i > 100) {
      num += 0.5;
    }
    printf("%d\n", round(num));
  }
  return 0;
}