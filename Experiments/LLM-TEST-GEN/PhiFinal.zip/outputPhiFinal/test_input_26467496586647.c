
#include <stdio.h>

int main(int argc, char *argv[]) {
    // Get the integer input from the command line argument
    int num = atoi(argv[1]);

    // Perform serialization on the number
    char *serialized_num = "0x" + std::to_string(num, 16);

    // Print out the serialized number
    printf("The serialized number is: %s\n", serialized_num);

    return 0;
}