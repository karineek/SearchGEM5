
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

int main(int argc, char* argv[]) {
    bool loop = true; // Loop invariant
    while (loop) {
        if (!strcmp(argv[1], "stop")) {
            printf("Loop stopped.\n");
            loop = false;
        } else {
            int value = atoi(argv[1]);
            printf("Input: %d\n", value);
            if (value > 100) {
                loop = false;
            } else {
                for (int i = 0; i < value; i++) {
                    // Loop invariant: the loop will always execute this part of the code at least once
                    printf("Looping...\n");
                }
            }
        }
    }

    return 0;
}