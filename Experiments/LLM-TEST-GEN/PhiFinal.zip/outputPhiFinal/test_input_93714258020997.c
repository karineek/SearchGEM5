
#include <stdio.h>

int main() {

  // Set up optimization profile based on user input
  const char *profile = argv[1];

  // Run compiler with specified profile
  clang --optimize --output=./output --profile=%s -o output.exe
  ./output.exe

}