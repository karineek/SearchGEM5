
#include <stdio.h>
#include <string.h>
#include <ctype.h>

enum { NUM_SYMBOLS = 256 };
int main() {
  char input[256];
  int symbol;

  for (;;) {
    fgets(input, sizeof(input), stdin);

    // Skip any leading whitespace
    while (!isdigit(symbol = getchar()) && symbol != '\n') continue;

    if (symbol == '\n') break;

    switch (symbol) {
      case '+': putc('+'); break;
      case '-': putc('-'); break;
      // ... other operations and assignments here ...
    }

    if (!isdigit(symbol = getchar())) continue;

    while (symbol >= '0' && symbol <= '9') {
      input[symbol - '0']++;
      // Update the lexicon with the new symbol and its frequency
    }

    putchar('\n');
  }

  return 0;
}