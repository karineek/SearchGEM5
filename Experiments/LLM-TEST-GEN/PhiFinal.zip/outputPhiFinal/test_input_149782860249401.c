
#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]) {

    // Check if there are at least two arguments (input and output files)
    if (argc != 3) {
        printf("Error: program requires 2 arguments.\n");
        return 1;
    }

    // Read input file and store its contents in a buffer
    FILE* fp = fopen(argv[1], "r");
    char buffer[1024];
    if (fp == NULL) {
        printf("Error: could not open %s.\n", argv[1]);
        return 1;
    }

    fread(buffer, sizeof buffer, 1, fp);

    // Read output file and store its contents in another buffer
    FILE* fp2 = fopen(argv[2], "w");
    if (fp2 == NULL) {
        printf("Error: could not open %s.\n", argv[2]);
        return 1;
    }

    // Write the input buffer to the output file
    fwrite(buffer, sizeof buffer, 1, fp2);

    // Close files and exit program
    fclose(fp);
    fclose(fp2);
    return 0;
}