
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    printf("Enter your name: ");
    scanf("%s", argv[1]); // input is taken via argv only
    printf("Hello %s!\n", argv[1]); // output string formatting
    return 0;
}