
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

// Define function specialization for sorting algorithm
void sort_numbers(int a[], int n) {
    if (n <= 1) return; // base case
    int pivot = a[0]; // set pivot to first element
    int i, j;
    for (i = 0; i < n-1; i++) {
        for (j = i+1; j < n; j++) {
            if (a[j] < pivot) { // compare elements and swap if necessary
                int temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }
    }
}

// Define function specialization for finding the maximum element in an array
void find_max(int a[], int n) {
    if (n == 0) return; // base case
    int max = a[0]; // set initial value of maximum to first element
    for (int i = 1; i < n; i++) {
        if (a[i] > max) { // compare elements and update maximum
            max = a[i];
        }
    }
}

int main(int argc, char* argv[]) {
    // Check if input is valid
    if (argc < 2) {
        printf("Error: Input must be a BASH command with one or more arguments.\n");
        return 1;
    }

    // Read input and store it in an array
    int numbers[argc-1];
    char* s = argv[2];
    for (int i = 3; i < argc; i++) {
        numbers[i-3] = atoi(s);
    }

    // Sort the array using function specialization
    sort_numbers(numbers, i);

    // Find the maximum element in the array
    find_max(numbers, i);

    // Print the sorted array and the maximum element
    printf("Sorted array: ");
    for (int j = 0; j < i; j++) {
        if (j > 0) printf(", ");
        printf("%d", numbers[j]);
    }
    printf("\nMaximum element: %d\n", numbers[i-1] == i? -1 : numbers[i-1]);

    // Return success code
    return 0;
}