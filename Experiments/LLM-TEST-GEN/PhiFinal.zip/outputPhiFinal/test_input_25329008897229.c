
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s input1 input2\n", argv[0]);
        return 1;
    }

    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);

    // Basic operations on the inputs
    if (num1 % 2 == 0) {
        printf("%d is even\n", num1);
    } else {
        printf("%d is odd\n", num1);
    }

    if (num2 > num1) {
        printf("%d is greater than %d\n", num2, num1);
    } else if (num2 < num1) {
        printf("%d is less than %d\n", num2, num1);
    } else {
        printf("%d and %d are equal\n", num2, num1);
    }

    return 0;