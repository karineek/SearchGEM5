
#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]) {
    // print all command-line arguments
    for (int i = 1; i <= argc; i++) {
        printf("arg%d: %s\n", i, argv[i]);
    }
    return 0;
}