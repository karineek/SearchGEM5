
#include <stdio.h>
int main(int argc, char** argv) {
  int a = atoi(argv[1]);
  printf("%d\n", a);
  return 0;
}