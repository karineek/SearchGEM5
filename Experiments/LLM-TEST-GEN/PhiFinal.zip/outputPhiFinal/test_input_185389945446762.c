
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {
    int num;
    if (argc == 2) {
        sscanf(argv[1], "%d", &num);
    } else {
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }

    // do something with the input number, e.g. print it or use it to perform a calculation

    return 0;
}