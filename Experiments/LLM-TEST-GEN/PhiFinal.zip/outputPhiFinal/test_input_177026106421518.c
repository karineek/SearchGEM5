
#include <stdio.h>

int main(int argc, char *argv[]) {
    int n = 0;
    for (int i = 1; i < argc; i++) {
        n += strlen(argv[i]);
    }
    printf("The length of the input is %d\n", n);
    return 0;
}