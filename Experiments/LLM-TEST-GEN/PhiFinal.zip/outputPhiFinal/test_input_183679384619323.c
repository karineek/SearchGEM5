
#include <stdio.h>

int main(int argc, char *argv[]) {

  int num;
  if (argc > 1) {
    num = atoi(argv[1]);
  }
  else {
    fprintf(stderr, "Please provide a number as an argument.\n");
    return 1;
  }

  if (num % 2 == 0) {
    printf("%d is even.\n", num);
  } else {
    printf("%d is odd.\n", num);
  }
}