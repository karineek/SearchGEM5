
#include <stdio.h>

// Common subexpression elimination (CSE) for iscntrl function
int iscntrl(int argv[]) {
    if (argc == 2) {
        return atoi(argv[1]);
    } else {
        printf("Invalid argument count. Usage: %s <number>\n", argv[0]);
        return 1;
    }
}

int main() {
    int num = iscntrl(argc, argv+1); // Example input: iscntrl 3
    printf("%d\n", num);
    return 0;
}