
#include <stdio.h>
#include <string.h>

int main(void) {
  int x, y;

  printf("Enter two numbers: ");
  scanf("%d %d", &x, &y);

  // This loop will run as many times as the user inputs,
  // which is determined by argv[1] and argv[2].
  for (int i = 0; i < strlen(argv[1]) + strlen(argv[2]); i++) {
    if (i % 2 == 0) {
      // Common subexpression elimination: calculate x^2 and y^2 before entering the loop.
      int x_squared = x * x;
      int y_squared = y * y;

      printf("%d %d\n", (x_squared >> 1), (y_squared >> 1));
    } else {
      // Use the input values instead of calculated values.
      printf("%d %d\n", x, y);
    }
  }

  return 0;
}