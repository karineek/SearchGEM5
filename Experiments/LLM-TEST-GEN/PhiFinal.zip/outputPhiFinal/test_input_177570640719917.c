
#include <stdio.h>
#include <math.h>

int main(int argc, char **argv) {
    double x = atof(argv[1]);
    double y = atof(argv[2]);
    double hypot = sqrt(x*x + y*y); // using constant folding to evaluate the square root of x^2 + y^2
    printf("The hypotenuse is: %f\n", hypot);
    return 0;
}