
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Please enter a file path as input\n");
        return 1;
    }

    FILE* fp = fopen(argv[1], "r");
    if (fp == NULL) {
        printf("Error: file cannot be opened\n");
        return 1;
    }

    int line_number = 0;
    while ((fgets(line, sizeof(line), fp)) != NULL) {
        printf("Line %d: %s\n", line_number++, line);
    }

    fclose(fp);
    return 0;
}