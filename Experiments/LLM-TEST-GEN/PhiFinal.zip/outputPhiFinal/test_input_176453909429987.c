
#include <stdio.h>
#include <string.h>

int main(int argc, char** argv) {
    // Check if enough arguments are provided
    if (argc < 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }

    // Open the file
    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        printf("Error: Could not open file %s.\n", argv[1]);
        return 2;
    }

    // Read the contents of the file
    char line[100];
    while (fgets(line, sizeof(line), fp)) {
        // Check if the line is empty or only contains whitespace
        if (!strlen(line) || isspace(line[0])) {
            continue;
        }

        // Print the line to the console
        printf("%s\n", line);
    }

    // Close the file
    fclose(fp);

    return 0;
}