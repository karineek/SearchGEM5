
#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]) {
    // Check if at least one argument is provided
    if (argc < 2) {
        printf("Please provide an input string.\n");
        return 1;
    }

    char* input_str = argv[1];

    // Output the input string to the console
    printf("Input: %s\n", input_str);

    // Triggered Interprocedural Optimizations
    int result = atoi(input_str);

    // Excersise this idea in C using sinl function
    double output = sinl(result);

    // Output the result to the console
    printf("Result: %d\n", result);
    printf("Sin(%d) = %f\n", input_str, output);

    return 0;
}