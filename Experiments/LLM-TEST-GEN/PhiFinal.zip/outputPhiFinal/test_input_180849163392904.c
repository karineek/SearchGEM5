
#include <stdio.h>

int main(int argc, char *argv[]) {
    // Initialize array to store library names
    struct library_name {
        char name[80];
    } libraries[256];

    // Iterate over all arguments and add their names to the array of libraries
    for (int i = 1; i < argc; i++) {
        strncpy(libraries[i - 1].name, argv[i], sizeof(libraries[i - 1].name));
    }

    // Output the names of all libraries included in the program
    for (int i = 0; i < 256; i++) {
        if (strncmp(&argv[1], libraries[i].name, strlen(libraries[i].name)) == 0) {
            printf("%s\n", argv[1] + strlen(argv[1]));
        }
    }

    return 0;
}