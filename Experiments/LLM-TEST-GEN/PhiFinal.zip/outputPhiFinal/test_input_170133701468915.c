
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
	// get input from command line arguments
	char *input_str = argv[1];
	// convert string to null-terminated C-style string
 	char *input_ptr;
 	input_ptr = strdup(input_str);
      // check if input is not too long (to avoid buffer overflow)
      int len = strlen(input_str);
      if (len > 1024) {
          printf("Error: Input is too long!\n");
          return 1;
      }
	// call strncpy_s function to copy input to C-style string
 	char output[len+1];
	strncpy_s(output, len + 1, input_ptr, 0);
	printf("C-style String: %s\n", output);
	return 0;
}