
#include <stdio.h>

int main(int argc, char *argv[]) {
  // check for valid number of arguments provided
  if (argc != 2) {
    printf("Error: Please provide exactly one argument\n");
    return 1;
  }

  // take input from command line
  int num = atoi(argv[1]);

  // check whether the number is even or odd
  if (num % 2 == 0) {
    printf("%d is an even number\n", num);
  } else {
    printf("%d is an odd number\n", num);
  }

  return 0;
}