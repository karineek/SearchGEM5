
#include <stdio.h>

int main(int argc, char **argv) {
    for (int i = 1; i < argc; i++) {
        int x = atoi(argv[i]);
        if (x % 2 == 0) {
            printf("%d is even\n", x);
        } else {
            printf("%d is odd\n", x);
        }
    }

    return 0;
}