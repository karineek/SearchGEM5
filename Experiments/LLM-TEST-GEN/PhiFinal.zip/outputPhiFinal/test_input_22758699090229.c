
#include <stdio.h>
#include <string.h>

int main( int argc, char **argv )
{
    if ( argc != 2 )
    {
        printf( "Usage: %s argument\n", argv[0] );
        return 1;
    }

    // Read the command-line argument into a string
    char* input_string = argv[1];

    // Do something with the input
    for ( int i=0; i<strlen( input_string ); ++i )
    {
        // If the character is a letter, increment it by 1 and convert back to ASCII code
        if ( 'a' <= input_string[i] && input_string[i] <= 'z' )
        {
            input_string[i] = input_string[i] + 1;
        }

        // If the character is a number, increment it by 2 and convert back to ASCII code
        else if ( '0' <= input_string[i] && input_string[i] <= '9' )
        {
            input_string[i] = input_string[i] + 2;
        }

        // Otherwise, do nothing
        else
        {
            input_string[i] = input_string[i];
        }
    }

    printf( "%s\n", input_string );

    // Return a success code
    return 0;
}