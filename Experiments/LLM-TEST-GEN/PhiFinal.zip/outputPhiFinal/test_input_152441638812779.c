
#include <stdio.h>
int main(int argc, char *argv[]) {
    int i;
    if (argc != 2) {
        printf("Usage: %s integer\n", argv[0]);
        return 1;
    }
    for (i = 0; i < strlen(argv[1]); i++) {
        int j;
        if (argc > 2) {
            printf("Usage: %s integer\n", argv[0]);
            return 1;
        }
        j = strtol(argv[1], NULL, 10);
        printf("%d\n", j);
    }
    return 0;
}