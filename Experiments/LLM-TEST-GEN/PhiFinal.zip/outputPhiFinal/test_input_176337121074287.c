
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>

void iswspace(int argc, char *argv[]) {
    // Check if the input is a valid command-line argument
    if (argc != 2) {
        printf("Usage: %s <filename>.txt\n", argv[0]);
        exit(1);
    }

    // Open the input file for reading
    FILE *fp = fopen(argv[1], "r");

    if (fp == NULL) {
        printf("Error: could not open file.\n");
        exit(2);
    }

    // Read the contents of the input file
    fseek(fp, 0L, SEEK_END);
    long fileSize = ftell(fp);
    fseek(fp, 0L, SEEK_SET);

    // Allocate space for the output buffer
    char *output = (char *)malloc(fileSize + 1);

    if (output == NULL) {
        printf("Error: could not allocate memory.\n");
        exit(3);
    }

    // Copy the contents of the input file to the output buffer
    fread(output, 1, fileSize, fp);

    // Close the input file
    fclose(fp);

    // Print out the contents of the output buffer
    printf("%s\n", output);

    // Free up memory for the output buffer
    free(output);
}