
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // initialize variables
    int i;
    float x = 0.0;

    // loop through input values and perform calculations
    for (i = 1; i < argc; i++) {
        if (argv[i][-1] == '\n') {
            argv[i] += "\0"; // remove newline character from input string
        }
        x = strtod(argv[i], &argv[i]);
        printf("Input: %s\n", argv[i]);
        printf("Result: %f\n", x);
    }

    // close input file
    FILE *input_file = fopen(argv[1], "r");
    if (input_file == NULL) {
        printf("Error opening input file.\n");
        return 1;
    }

    // close input file
    fclose(input_file);

    // print thank you message
    printf("Thank you for using our program!\n");

    // exit the program
    return 0;
}