
#include <stdio.h>

int main(int argc, char *argv[]) {
  // Check if enough arguments were provided
  if (argc != 2) {
    printf("Usage: %s filename\n", argv[0]);
    return 1;
  }

  // Open the file specified by the command-line argument
  FILE *file = fopen(argv[1], "r");

  // Check if the file was opened successfully
  if (file == NULL) {
    printf("Error: could not open file %s\n", argv[1]);
    return 1;
  }

  // Read data from the file and print it to stdout
  int n = 0;
  while (fscanf(file, "%d", &n) == 1) {
    printf("%d\n", n);
  }

  // Close the file
  fclose(file);

  return 0;
}