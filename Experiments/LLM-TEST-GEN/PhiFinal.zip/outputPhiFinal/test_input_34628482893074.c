
#include <stdio.h>

int main(int argc, char** argv) {
    char* str[argc-1];
    for (int i = 1; i <= argc - 1; i++) {
        str[i-1] = malloc(strlen(argv[i]) + 1);
        sscanf(argv[i], "%s", str[i-1]);
    }
    for (int i = 0; i < argc - 1; i++) {
        printf("%s\n", str[i]);
        free(str[i]);
    }
    return 0;
}