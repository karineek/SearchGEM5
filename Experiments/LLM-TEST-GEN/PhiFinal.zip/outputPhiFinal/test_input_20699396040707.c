
int power_usage(int power, int hours) {
  return (double)(power * hours / 1000); // Converting to kWh for better understanding
}