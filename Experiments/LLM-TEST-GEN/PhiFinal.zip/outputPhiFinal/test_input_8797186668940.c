
#include <stdio.h>
int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }
    int number = 0;
    FILE *file = fopen(argv[1], "r");
    if (file == NULL) {
        printf("Error: file not found\n");
        return 1;
    }
    while (fscanf(file, "%d", &number) == 1) {
        number += 1; // increment the number by one to get the next integer in the file
        if (ftell(file) != 0) { // check if we've reached the end of the file
            fseek(file, -1, SEEK_CUR); // move to the beginning of the file
        }
    }
    printf("%d\n", number);
    return 0;
}