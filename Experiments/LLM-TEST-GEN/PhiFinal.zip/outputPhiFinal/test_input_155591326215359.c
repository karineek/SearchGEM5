
import sys

file_name = sys.argv[1]
line_num = int(sys.argv[2]) - 1

with open(file_name, 'r') as f:
    for line_count, line in enumerate(f):
        if line_count == line_num:
            print(line.strip())