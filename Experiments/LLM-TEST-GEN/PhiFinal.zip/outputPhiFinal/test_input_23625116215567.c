
#include <stdio.h>

int main(int argc, char **argv) {
    // check if enough arguments were provided
    if (argc != 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    // read the input file and print it out
    FILE *fp = fopen(argv[1], "r");
    if (fp == NULL) {
        perror("Error opening file");
        return 1;
    }

    char input_str[256];
    fread(input_str, sizeof(char), 1024, fp); // read up to 1024 bytes at a time

    printf("Input: %s\n", input_str);

    fclose(fp);

    return 0;
}