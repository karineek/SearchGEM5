
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

int main(int argc, char **argv) {

    // Read input from the command line using argv
    if (argc != 2) {
        printf("Error: incorrect number of arguments\n");
        return 1;
    }

    char* filename = argv[1];

    // Check for any invalid characters in the file name
    if (filename == NULL) {
        printf("Error: invalid file name\n");
        return 1;
    }

    // Open the file and read its contents
    FILE* fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("Error: could not open file\n");
        return 1;
    }

    // Read the contents of the file line by line
    char* line = NULL;
    size_t len = 0;
    int c;
    while ((c = fgetc(fp)) != EOF) {
        if (line == NULL) {
            line = malloc(sizeof(char) * 256);
            if (line == NULL) {
                printf("Error: memory allocation failure\n");
                return 1;
            }
        }

        sscanf(line, "%s", argv);
    }

    // Free the memory used by the line buffer
    free(line);

    // Close the file
    fclose(fp);

    // Return success
    return 0;
}