
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    int n;
    char array[100];

    if (argc != 2) {
        printf("Usage: ./program input\n");
        return 1;
    }

    n = atoi(argv[1]);

    for (int i = 0; i < n; i++) {
        sscanf(array, "%s", argv[2+i]); // input is taken from argv[2 + i]
        printf("Input: %s\n", array);
    }

    for (int j = 0; j < n; j++) {
        printf("Output: %s\n", strrev(array)); // reversing the string
    }

    return 0;
}