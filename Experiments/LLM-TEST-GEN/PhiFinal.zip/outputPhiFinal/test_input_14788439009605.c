
#include <stdio.h> 
#define MAX_ARG 10
int main(int argc, char *argv[]) {
    for (int i = 1; i <= MAX_ARG; i++) {
        if (argv[i] == "-p") {
            printf("Pruning\n");
        } else if (argv[i] == "-f") {
            printf("Frontend implementation\n");
        } else if (argv[i] == "-l") {
            printf("Labeled statement\n");
        } else {
            printf("Invalid input: %s\n", argv[i]);
        }
    }
    return 0;
}