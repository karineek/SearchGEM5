
#include <stdio.h>
#include <stdbool.h>
#define MAX_INPUT 10
int main(int argc, char *argv[]) {
    // Check that the input is valid and within the allowed range (0-9)
    bool validInput = true;
    for (int i = 1; i < argc && argc > 1 && !validInput; i++) {
        if (atoi(argv[i]) <= 0 || atoi(argv[i]) >= 10) {
            validInput = false;
        }
    }
    // Tokenize the input using Lex
    char input[MAX_INPUT];
    for (int i = 1; i < argc && argc > 1 && strlen(argv[i]) <= MAX_INPUT - 2 && validInput; i++) {
        sscanf(argv[i], "%s", input);
    }
    // Convert the input to a short int and perform any necessary operations
    int result = atoi(input);
    if (result % 2 == 0) {
        printf("%d is even.\n", result);
    } else {
        printf("%d is odd.\n", result);
    }
    return 0;
}