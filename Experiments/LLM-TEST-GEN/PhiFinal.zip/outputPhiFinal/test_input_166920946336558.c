
#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]) {
    // Check if enough arguments were passed in
    if (argc < 3) {
        printf("Usage: %s input1 [input2]\n", argv[0]);
        return 1;
    }

    // Read the first two arguments as integers
    int a = strtol(argv[1], NULL, 0);
    int b = strtol(argv[2], NULL, 0);

    // Perform scalar optimizations using bitwise AND
    while (a && b) {
        a &= b;
        b >>= 1;
    }

    printf("Result: %d\n", a);

    // Release resources
    free(argv[1]);
    free(argv[2]);

    return 0;
}