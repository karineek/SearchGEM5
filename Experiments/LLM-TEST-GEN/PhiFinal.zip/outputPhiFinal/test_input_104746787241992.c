
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(int argc, char* argv[]) {

    // Check if the command line argument is valid
    if (argc != 2) {
        printf("Usage: %s input_file\n", argv[0]);
        return 1;
    }

    // Open the file and read in the input
    FILE* fp = fopen(argv[1], "r");
    if (fp == NULL) {
        perror("Error opening file: ");
        return 1;
    }

    // Read in the input and store it as a string
    char* line = strdup(fgets(fp, 100, stdin));
    if (line == NULL) {
        perror("Error reading input");
        return 1;
    }

    // Perform DCE to remove any unused or unreachable code
    line = realloc(line, strlen(line) + 1);
    for (int i = 0; i < strlen(line); i++) {
        if (!isalnum(line[i]) && !isspace(line[i])) {
            line[i] = '\0';
        }
    }

    // Write the output to a file
    FILE* fout = fopen("output.txt", "w");
    if (fout == NULL) {
        perror("Error writing to file");
        return 1;
    }

    // Write the output to the file
    fprintf(fout, "%s", line);
    fclose(fp);
    fclose(fout);

    return 0;
}