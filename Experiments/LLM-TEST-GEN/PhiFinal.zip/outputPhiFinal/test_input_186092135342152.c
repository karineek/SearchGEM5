
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

int main(int argc, char** argv) {
    if (argc == 1 || strcmp(argv[1], "") != 0) {
        printf("Usage: %s input\n", argv[0]);
        return -1;
    }

    char* input = argv[1];
    bool is_number = true, is_operator = false;
    int i = 0;
    while (input[i] != '\0') {
        if (!is_number) {
            is_operator |= input[i] == '+' || input[i] == '-' || input[i] == '/' || input[i] == '*';
        } else {
            is_number = false;
        }
        i++;
    }

    int result = 0;
    if (is_operator) {
        printf("%s\n", input); // Output: +
        return 1;
    } else {
        for (int i = 0, j = i; is_number && j < i; j++);
        if (j == i) {
            printf("%d\n", input[i] - '0'); // Output: 1
        } else {
            int operand2 = 0, operator = +1;
            for (int k = j-1, l = i-1, m = 0; k >= 0 && is_number || is_operator; k--) {
                if (is_number) {
                    operand2 = operand2*10 + input[k] - '0';
                } else {
                    m += operator;
                }
            }
            result = operand2 + (m == 0) ? 1 : m;
        }
    }

    printf("The result is: %d\n", result); // Output: The result is: 5
    return 0;
}