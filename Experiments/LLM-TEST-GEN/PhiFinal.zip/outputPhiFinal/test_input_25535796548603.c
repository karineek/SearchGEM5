
#include <stdio.h>

int main(int argc, char *argv[]) {
    int num;

    if (argc != 2) {
        printf("Please provide an input using the following format: 'num'.\n");
        return 1;
    } else {
        num = atoi(argv[1]);

        if (num > 0) {
            printf("Input: %d\n", num);
        } else if (num < 0) {
            printf("Input: %d is negative.\n", num);
        } else {
            printf("Invalid input. Please enter a positive integer.\n");
        }

        return 0;
    }
}