
#include <stdio.h>
#define MAX_ARGUMENTS 100

void p_sep_by_space(char* str, int i) {
  if (str[i] == '\0') return;
  if (str[i] != ' ' && str[i+1] == ' ') // Check for space between words
    while (str[++i]) ; // Skip any additional spaces after the word
}

int main(int argc, char* argv[]) {
  int i = 0;
  for (; i < MAX_ARGUMENTS && argv[i]; ++i) {
    p_sep_by_space(argv[i], i); // Optimize string splitting by space
  }

  printf("%s\n", argv[0]); // Print the original command-line input
}