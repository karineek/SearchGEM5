
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

// Function to check if a character is alphanumeric or not
bool isAlnum(char c) {
    if (isalpha(c)) return true;
    return isdigit(c);
}

int main() {
    char *argv[];
    argc = strlen(argv)+1;

    // Check if enough arguments are given, else print an error message
    if (argc < 2) {
        printf("Usage: program input\n");
        return 1;
    }

    // Convert command line argument to lower case for better comparison
    char *input = strtol(argv[1], NULL, 10);
    input = input.lower();

    // Remove redundant code using Dead Code Elimination (DCE)
    for (int i=0; i<strlen(input); i++) {
        if (!isAlnum(input[i])) {
            input = realloc(input, strlen(input+1));
        } else {
            input++;
        }
    }

    // Generate handles for different cases of input string using Handles code generation
    char *handle;
    if (strncmp(input, "case", 3) == 0) {
        handle = strdup("CASE: ");
    } else if (strncmp(input, "if", 4) == 0) {
        handle = strdup("IF: ");
    } else if (strncmp(input, "while", 5) == 0) {
        handle = strdup("WHILE: ");
    } else {
        handle = strdup("UNKNOWN: ");
    }

    // Set default label for the end of the program
    char *label = "END";
    input += strlen(handle) + strlen(label);

    // Print the processed string with handles and default label
    printf("%s\n", handle);
    for (int i=0; i<strlen(input); i++) {
        if (isAlnum(input[i])) {
            putchar(input[i]);
        } else {
            printf("%s", label);
        }
    }

    // Clean up the memory used by input and handle strings
    free(input);
    free(handle);

    return 0;
}