
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    if (argc != 3) {
        printf("Please provide two arguments: a filename and a file extension\n");
        return 1;
    }

    FILE *fp = fopen(argv[1], "r");
    if (!fp) {
        printf("Error: cannot open file %s\n", argv[1]);
        return 1;
    }

    char *filename = argv[2];
    fseek(fp, 0L, SEEK_END);
    int size = ftell(fp);
    fseek(fp, 0L, SEEK_SET);

    printf("%s\n", filename);
    for (int i = 0; i < size; i++) {
        if (!isinf(&i)) {
            fprintf(fp, "0x%.4LX ", &i);
        } else {
            fprintf(fp, "infinity\n");
        }
    }

    return 0;
}