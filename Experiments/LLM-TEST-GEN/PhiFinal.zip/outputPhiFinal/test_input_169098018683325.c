
#include <stdio.h>
#include <stdbool.h>
#include <ctype.h>

bool is_palindrome(char *str) {
  int len = strlen(str);

  // Compare first and last characters, then move inward until the middle of the string is reached
  for (int i = 0; i <= len/2; i++) {
    if (tolower(str[i]) != tolower(str[len-1-i])) {
      return false;
    }
  }

  return true;
}

int main(int argc, char *argv[]) {
  // Check if any input was given
  if (argc < 2) {
    printf("No input given.\n");
    return 1;
  }

  // Process the first argument as input and check if it is a palindrome
  char *input = argv[1];
  if (!is_palindrome(input)) {
    printf("%s is not a palindrome.\n", input);
  } else {
    printf("%s is a palindrome.\n", input);
  }

  // Output the program and an example of object file manipulation
  printf("Program: %s\n", argv[0]);
  printf("Example input: /path/to/objectfile.o\n");

  return 0;
}