
#include <stdio.h>
#include <math.h>
int main(int argc, char *argv[]) {

    if (argc != 2) { // if there is not enough input, display an error message and exit the program
        printf("Error: Invalid number of arguments\n");
        return 1;
    }

    double x = atof(argv[1]); // convert input to a floating-point variable
    if (x < 0.0) { // check if the input is negative and display an error message if it is
        printf("Error: Input must be non-negative\n");
        return 2;
    }

    double y = pow(x, 3); // calculate the cube of x
    printf("%f", y); // print the result with two decimal places

    return 0;
}