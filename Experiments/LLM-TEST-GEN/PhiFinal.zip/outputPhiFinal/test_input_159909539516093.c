
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

int main(int argc, char **argv) {
    int i;
    bool is_even = false;

    for (i = 1; i < argc; i++) {
        if (sscanf(argv[i], "%d", &number)) {
            if (number % 2 == 0) {
                is_even = true;
            }
        } else {
            printf("Invalid input: %s\n", argv[i]);
            break;
        }
    }

    if (is_even) {
        int sum = 0;

        for (i = 1; i < argc; i++) {
            sscanf(argv[i], "%d", &number);
            sum += number;
        }

        printf("Sum of even numbers: %d\n", sum);
    } else {
        printf("No even numbers found.\n");
    }

    return 0;
}