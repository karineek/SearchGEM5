
#include <stdio.h>
#define MAXLINE 100

int main(int argc, char **argv) {

    for (int i = 1; i < argc; i++) {
        char line[MAXLINE];
        fgets(line, MAXLINE, stdin);
        printf("%s\n", line);
    }

    return 0;
}