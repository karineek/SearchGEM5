
#include <stdio.h> 

int main(int argc, char* argv[]) { 
  int a; 
  if (argc == 2) { 
    a = atoi(argv[1]); 
    printf("%d\n", a); 
  } 
  return 0; 