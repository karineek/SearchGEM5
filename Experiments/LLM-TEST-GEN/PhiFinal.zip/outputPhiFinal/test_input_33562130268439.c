
#include <stdio.h>
int main(int argc, char *argv[]) {
  if (argc == 3) {
    int a = atoi(argv[1]);
    int b = atoi(argv[2]);
    printf("a is %d\n", a);
    printf("b is %d\n", b);
    if (eq(a, b)) {
      printf("The two numbers are equal.\n");
    } else {
      printf("The two numbers are not equal.\n");
    }
  } else {
    printf("Usage: %s a b\n", argv[0]);
    return 1;
  }
  return 0;
}