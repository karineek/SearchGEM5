
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
  int x = atoi(argv[1]);
  int y = atoi(argv[2]);
  printf("x is %d and y is %d\n", x, y);
  return 0;
}