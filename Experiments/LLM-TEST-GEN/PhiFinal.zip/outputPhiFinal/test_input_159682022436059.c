
#include <stdio.h>

int main(int argc, char *argv[]) {
    int num;

    if (argc != 2) {
        printf("Usage: program <number>\n");
        return 1;
    }

    num = atoi(argv[1]);
    printf("%d\n", num);
    return 0;
}