
#include <stdio.h>

int main(int argc, char* argv[]) {

    // Check if enough arguments were provided
    if (argc != 3) {
        printf("Error: insufficient input\n");
        return 1;
    }

    // Read the input and print it out
    char input_str[100];
    memcpy(input_str, argv[1], strlen(argv[1]) + 1);
    printf("Input: %s\n", input_str);

    // Run the program with a few different inputs to test its functionality
    char* test_strings[] = {"hello world", "coding is fun", "this is a longer string that might cause overflow"};
    for (int i = 0; i < sizeof(test_strings) / sizeof(*test_strings); i++) {
        char* test_input_str = malloc(strlen(test_strings[i]) + 1);
        memcpy(test_input_str, test_strings[i], strlen(test_strings[i]) + 1);
        printf("Output: %s\n", argv[2] % test_input_str);
    }

    // Release the input string and return success
    free(test_input_str);
    return 0;
}