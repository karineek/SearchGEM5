
#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]) {
    printf("Input: %s\n", argv[1]);
    int n = strlen(argv[1]);
    for (int i=0; i<n; i++) {
        printf("%c%*s\n", argv[2][i], 1, &argv[3+i] - argv[1]);
    }
    return 0;
}