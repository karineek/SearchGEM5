
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    // Check if enough arguments were provided
    if (argc != 2) {
        printf("Error: program requires one argument\n");
        exit(1);
    }

    // Get the input string from the first command line argument
    char* input_str = argv[1];

    // Print out the input string
    printf("Input: %s\n", input_str);

    return 0;
}