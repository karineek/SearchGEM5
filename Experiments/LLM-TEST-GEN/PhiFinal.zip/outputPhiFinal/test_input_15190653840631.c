
#include <stdio.h>
#include <math.h>
#include <assert.h>

int main(int argc, char *argv[]) {
    /* Check if the input is valid */
    assert(argc > 1);

    /* Get input and convert it to a float */
    double input = atof(argv[1]);

    /* Perform TSO by optimizing the Csqrtf function */
    if (input >= 0) {
        printf("The square root of %f is %f.\n", input, sqrtf(input));
    } else {
        /* Handle negative numbers in a specific way */
        printf("Invalid input! Cannot take the square root of a negative number.\n");
    }

    return 0;