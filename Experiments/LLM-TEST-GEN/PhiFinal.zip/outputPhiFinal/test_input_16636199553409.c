
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char* argv[]) {

  // Check if the program was called with exactly 2 arguments (input file and output file)
  if (argc != 3) {
    fprintf(stderr, "Usage: %s <inputfile> <outputfile>.\n", argv[0]);
    exit(EXIT_FAILURE);
  }

  // Open the input and output files in binary mode for efficiency
  FILE* ip = fopen(argv[1], "rb");
  FILE* op = fopen(argv[2], "wb");

  // Read the input file line by line and write each line to the output file
  while (fgets(input_line, 100, ip) != NULL) {
    char output_line[1024];
    memcpy(output_line, &input_line[0], strlen(&input_line));
    fwrite(output_line, 1, strlen(output_line), op);
  }

  // Close the input and output files to free up resources
  fclose(ip);
  fclose(op);

  return 0;
}