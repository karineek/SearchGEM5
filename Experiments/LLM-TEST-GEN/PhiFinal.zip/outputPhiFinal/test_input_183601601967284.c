
#include <stdio.h>

struct distance {
    int feet;
    int inches;
};

int main(int argc, char **argv) {
    struct distance d1 = {0, 0};
    struct distance d2 = {0, 0};

    if (argc == 3) {
        int feet1 = atoi(argv[1]);
        int inches1 = atoi(argv[2]);
        d1.feet = feet1;
        d1.inches = inches1;

        int feet2 = atoi(argv[3]);
        int inches2 = atoi(argv[4]);
        d2.feet = feet2;
        d2.inches = inches2;

        struct distance sum = {d1.feet + d2.feet, (d1.inches + d2.inches) / 12};

        printf("%d'l\n", sum.feet * 12);
    } else {
        printf("Usage: %s <number of feet> <number of inches> <number of feet> <number of inches>\n", argv[0]);
        return 1;
    }

    return 0;
}