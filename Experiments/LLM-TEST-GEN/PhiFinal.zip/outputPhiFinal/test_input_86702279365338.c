
#include <stdio.h>
#include <stdbool.h>
#include <string.h>

int main(int argc, char *argv[]) {

    if (argc != 3) {
        printf("Usage: %s input_file output_file\n", argv[0]);
        return 1;
    }

    FILE *in = fopen(argv[1], "r");
    FILE *out = fopen(argv[2], "w");

    if (in == NULL || out == NULL) {
        printf("Error opening file\n");
        return 1;
    }

    // Read input from file and convert it to floating-point values
    while(fscanf(in, "%f", &float_val) == 1) {
        fprintf(out, "%f\n", float_val);
    }

    // Use Loop-Invariant Code Motion to optimize the output file for performance
    while(1) {
        if (float_val % 2 == 0) {
            fprintf(out, "Even\n");
        } else {
            fprintf(out, "Odd\n");
        }

        float_val = (float) (float_val / 2); // Divide by 2 and convert to integer
    }

    return 0;
}