
#include <stdio.h>
#include <string.h>

int main(int argc, char** argv) {
    if (argc != 2) {
        printf("Usage: %s input\n", *argv[0]);
        return 1;
    }

    char* input = strdup(argv[1]); // make a copy of the input string to avoid memory leaks
    printf("Input: %s\n", input);

    // do some processing on the input here...

    return 0;
}