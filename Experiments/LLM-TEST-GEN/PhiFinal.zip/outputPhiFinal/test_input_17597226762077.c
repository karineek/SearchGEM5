
Enter some text: Hello world!
Hello world!