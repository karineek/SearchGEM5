
#include <stdio.h>
int main(int argc, char *argv[]) {
  // Convert input to upper case using the "isupper" function
  int i;
  for (i = 1; i <= argc - 1; i++) {
    if ((*argv[i] >= 'A') && (*argv[i] <= 'Z')) {
      *(--argv[i]) = *argv[i];
    }
  }

  // Print the modified input
  for (i = 1; i <= argc - 1; i++) {
    printf("%s\n", argv[i]);
  }
}