
#include <stdio.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Please provide one argument\n");
        return 1;
    }

    for (int i = 1; i < argc; i++) {
        if (!isalpha(argv[i][0])) {
            printf("Please provide a non-numeric argument\n");
            return 1;
        }
        int num = atoi(argv[i]);
        printf("%s: %d\n", argv[i], num);
    }

    return 0;
}