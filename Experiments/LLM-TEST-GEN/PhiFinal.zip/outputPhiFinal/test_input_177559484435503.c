
#include <stdio.h>
#include <math.h>

int main(int argc, char** argv) {
    // check if enough arguments are provided
    if (argc != 3) {
        printf("Usage: %s input_file output_file\n", argv[0]);
        return 1;
    }

    // open the input and output files
    FILE* in = fopen(argv[1], "r");
    FILE* out = fopen(argv[2], "w");

    // check if files were opened successfully
    if (in == NULL || out == NULL) {
        perror("Error opening file");
        return 1;
    }

    // read input from the command line and write output to a file
    while (fscanf(in, "%d", &a) == 1) {
        fprintf(out, "The square of %d is %d\n", a, a * a);
    }

    // close the files
    fclose(in);
    fclose(out);

    return 0;
}