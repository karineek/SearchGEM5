
#include <stdio.h>

int main(int argc, char* argv[]) {

  // Check if enough arguments are provided
  if (argc != 2) {
    printf("Please provide at least one argument.\n");
    return 1;
  }

  // Check if the first argument is valid and assign it to a variable
  char* filename = argv[1];

  // Open the file for reading
  FILE* fp = fopen(filename, "r");
  if (fp == NULL) {
    printf("Error: File not found or could not be opened.\n");
    return 1;
  }

  // Read the contents of the file and store them in a 2D array
  char line[1024];
  int arr_size = 0;
  while (fgets(line, sizeof(line), fp)) {
    arr_size++;
  }

  char** arr = malloc(arr_size * sizeof(*arr));
  for (int i = 0; i < arr_size; i++) {
    arr[i] = malloc(strlen(line) + 1);
    strcpy(arr[i], line);
  }

  // Display the array contents to the user
  for (int i = 0; i < arr_size; i++) {
    printf("%s\n", arr[i]);
  }

  // Check if there are any errors when freeing the memory allocated
  for (int i = 0; i < arr_size; i++) {
    free(arr[i]);
  }
  free(arr);

  return 0;
}