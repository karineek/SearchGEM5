
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    // Get user input using argv
    for (int i = 1; i <= argc; ++i) {
        printf("Input %d: ", i);
        scanf("%s", argv[i]);
    }

    // Loop through the user input and print each character
    for (int i = 0; i < strlen(argv[0]); ++i) {
        printf("%c\n", *(argv[0] + i));
    }

    return 0;
}