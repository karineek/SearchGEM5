
#include <stdio.h>

int main(int argc, char* argv[]) {

    // check number of arguments passed to the program
    if (argc != 2) {
        printf("Please provide a BASH file as input\n");
        return 1;
    }

    // open the BASH file for reading
    FILE* fp = fopen(argv[1], "r");
    if (fp == NULL) {
        printf("Error opening input file\n");
        return 2;
    }

    // read the lines of the BASH file into an array
    char* line = argv[1];
    char lines[100] = {0};
    while (fgets(line, sizeof(lines), fp) != NULL) {
        strcpy(lines + strlen(lines), line);
    }

    // close the file pointer
    fclose(fp);

    // print the lines of the BASH file as output
    printf("Input file:\n");
    for (int i = 0; i < strlen(lines); i++) {
        printf("%s\n", lines + i*100);
    }

    return 0;
}