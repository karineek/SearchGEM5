
#include <stdio.h>

int main(int argc, char** argv) {

  // Example of an input from BASH using argv
  int x = atoi(argv[1]);

  // powf function in C to calculate the power of a number (x^n)
  double powf(double base, int n) {
    if (n == 0) {
      return 1;
    } else if (n % 2 == 0) {
      return powf(base * base, n / 2);
    } else {
      return base * powf(base * base, (n - 1) / 2);
    }
  }

  // example usage of powf function
  printf("%f\n", powf(2, x));

  return 0;
}