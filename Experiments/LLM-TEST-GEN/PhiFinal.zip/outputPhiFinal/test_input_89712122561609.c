
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {

    if (argc != 3) {
        printf("Usage: %s input_file output_file\n", argv[0]);
        return 1;
    }

    FILE* fp = fopen(argv[1], "r");
    if (fp == NULL) {
        printf("Error: File not found.\n");
        return 1;
    }

    char* input = fgets(argv[2], 100, fp);
    if (input == NULL) {
        printf("Error: File read error.\n");
        return 1;
    }

    fclose(fp);

    char* output = strdup(input);
    if (output == NULL) {
        printf("Error: Memory allocation error.\n");
        return 1;
    }

    // Exercise the C: __FILE__ macro
    char* file_name = argv[0];
    size_t file_size = strlen(file_name);
    printf("File name: %s\n", file_name);
    printf("File size in bytes: %zu\n", file_size);

    return 0;
}