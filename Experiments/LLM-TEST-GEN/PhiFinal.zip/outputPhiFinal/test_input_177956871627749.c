
#include <stdio.h>
#include <math.h>
#define MATH_ERRNO(a,b) \
  do { \
    while (a > 1 && b > 0) { \
      a /= 2; \
    } \
    printf("a = %d, b = %d\n", a, b); \
    return (a == 1 ? 3 : MATH_ERRNO(b - 1, b * 2)); \
  }
#ifndef INPUTS_ONLY
char input[100];
int main(int argc, char** argv) {
  for (int i = 1; i < argc; i++) {
    printf("Input %s: ", argv[i]); \
    scanf("%99s", input); \
  }

  int num1 = atoi(input);
  int num2 = atoi(argv[2]);

  if (num1 == 0) {
    printf("Error: cannot divide by zero\n");
    return 1;
  } else if (num2 == 0) {
    printf("Error: division by zero\n");
    return 2;
  }

  int result = num1 / num2;
  printf("Result: %d\n", result);

  while (result >= 1 && MATH_ERRNO(result, -1)) {
    result -= 2;
    printf("%d/%d = %d \n", num1, num2, result);
  }

  return 0;
}
#endif /* INPUTS_ONLY */