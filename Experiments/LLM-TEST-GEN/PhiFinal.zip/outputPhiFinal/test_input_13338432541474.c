
#include <stdio.h>

int main( int argc, char **argv ) 
{
    // initialize input array with the number of arguments
    int* nums = (int*)malloc(sizeof(int)*argc);

    // check if any error occurred during allocation 
    for ( int i=0; i<argc; i++ )
    {
        if ( argv[i] == NULL) 
        {
            printf( "Error: Unable to allocate memory for argv[%d].\n", i );
        }
        else
        {
            nums[i] = atoi(argv[i]); // convert string to integer using strtol function
        }
    }

    // print out the user's inputs
    for ( int i=0; i<argc; i++ )
    {
        printf( "User input %d: %d\n", i+1, nums[i] );
    }

    // free up memory allocated for the array
    free( nums );

    return 0;