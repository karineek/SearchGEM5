
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAXLINE 1000

int main(int argc, char *argv[]) {

    /* check if the number of arguments is correct */
    if (argc != 2) {
        printf("Usage: %s <input-file>\n", argv[0]);
        return EXIT_SUCCESS;
    }

    /* open the input file */
    FILE *f = fopen(argv[1], "r");
    if (f == NULL) {
        printf("Error: could not open file %s\n", argv[1]);
        return EXIT_SUCCESS;
    }

    /* read input line by line */
    while (fgets(line, MAXLINE, f) != NULL) {
        printf("%s\n", line);
    }

    /* close the file */
    fclose(f);

    return EXIT_SUCCESS;
}