
#include <stdio.h>

int main(int argc, char *argv[]) {
    // Get the length of the input string from the first argument
    int len = strlen(argv[1]);

    // Print the input string to the console
    for (int i = 0; i < len; i++) {
        printf("%c", argv[1][i]);
    }
    return 0;
}