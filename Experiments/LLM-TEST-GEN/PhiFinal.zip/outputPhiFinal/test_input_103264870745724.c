
#include <stdio.h>

int main(int argc, char* argv[]) {
    int n;
    if (argc == 3) {
        n = atoi(argv[1]);
    } else {
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }

    for (int i = 1; i <= n; i++) {
        int sum = 0;
        for (int j = 1; j <= n - i + 1; j++) {
            sum += j;
        }

        printf("%d ", sum);
    }

    return 0;
}