
#include <stdio.h>
#include <stdbool.h>
#include <string.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Please provide a filename as input using the command line argument -h for help\n");
        return 1;
    }

    FILE *file = fopen(argv[1], "r");
    if (!file) {
        printf("Error: cannot open the file.\n");
        return 1;
    }

    while (fgets(arg, 100, file) != NULL) {
        printf("%s\n", arg);
    }

    fclose(file);
    return 0;
}