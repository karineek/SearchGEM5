
#include <stdio.h>

int main(int argc, char* argv[]) {

    printf("Input: ");
    scanf("%s", argv[1]);

    // Print the input to standard output
    puts(argv[1]);

    return 0;
}