
#include <stdio.h>
int main(int argc, char* argv[]) {
    int num = atoi(argv[1]); //convert first argument to integer
    double precision_num = 0;
    int i = 1;
    while (i <= 100) {
        precision_num = ((num + i)/2); //perform some operation on the input
        if (precision_num == (num + i)/2) break; //check if the precision is reached
        i++;
    }
    printf("The result of the operation is %.10f\n", precision_num); //print the final result
    return 0;
}