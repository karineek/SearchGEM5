
#include <stdio.h>

typedef struct {
  int val;
} pos_t;

int main(int argc, char** argv) {

    // Allocate memory for a variable
    pos_t* arr = (pos_t*)malloc(sizeof(pos_t)*argc);

    // Fill array with values using argv[i] as the value
    for (int i=0; i<argc; i++) {
        arr[i].val = atoi(argv[i+1]);
    }

    // Output the contents of the array
    for (int i=0; i<argc; i++) {
        printf("Value %d: %d\n", i, arr[i].val);
    }

    return 0;
}