
#include <stdio.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: ./program_name string\n");
        return 1;
    }

    char input[128];
    strncpy(input, argv[1], 128);
    input[strcspn(input, "\0")] = '\0'; // remove trailing null character

    printf("Hello world!\n");

    return 0;
}