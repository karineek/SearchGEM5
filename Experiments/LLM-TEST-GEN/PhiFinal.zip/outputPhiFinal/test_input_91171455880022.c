
#include <stdio.h>
#include <math.h>

int main(int argc, char **argv) {
    int x = atoi(argv[1]);
    int y = atoi(argv[2]);

    // common subexpression elimination
    x = x + 2 * y;
    y = 3 * x - 4 * y;

    printf("x: %d, y: %d\n", x, y);

    return 0;
}