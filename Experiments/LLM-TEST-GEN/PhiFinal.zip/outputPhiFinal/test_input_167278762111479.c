
#include <stdio.h>
int main(int argc, char **argv) {
    int i;
    char *input = argv[1];
    
    for (i=0; input[i] != '\0'; ++i) {
        printf("%d ", input[i]);
    }
    return 0;
}