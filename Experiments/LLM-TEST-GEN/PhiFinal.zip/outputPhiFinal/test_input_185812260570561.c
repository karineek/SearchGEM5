
#include <stdio.h>
#define ATAN_VALUE 1.0

int main(int argc, char* argv[]) {
  if (argc != 2) {
    printf("Usage: atanf.exe [input]\n");
    return 1;
  }
  double angle = strtod(argv[1], NULL);
  double result = M_PI * ATAN_VALUE / (double)angle;
  printf("The tangent of %d is %.10f\n", angle, result);
  return 0;
}