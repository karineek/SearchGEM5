
#include <stdio.h>
#define SIZE 1000000

int main(int argc, char *argv[]) {
    int i, N;
    if (argc != 2) {
        printf("Usage: %s N\n", argv[0]);
        return 1;
    }
    N = atoi(argv[1]);

    for (i = 0; i < SIZE; i++) {
        // Sparse Conditional Constant Propagation
        if (i % 3 == 0) {
            N /= 2;
        } else if (i % 5 == 0) {
            N *= 2;
        }

        printf("%d\n", N); // prints the value of N after each iteration
    }

    return 0;
}