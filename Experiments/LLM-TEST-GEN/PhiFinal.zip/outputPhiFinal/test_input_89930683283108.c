
#include <stdio.h>

int main(int argc, char* argv[]) {
  int i;
  int sum = 0;

  for (i = 1; i <= argc; i++) {
    if (isdigit(*argv[i])) { // check if argument is an integer
      int num = atoi(argv[i]);
      if (num % 2 == 0) { // check if number is even
        sum += num;
      }
    }
  }

  printf("The sum of all even numbers in the arguments is: %d\n", sum);

  return 0;