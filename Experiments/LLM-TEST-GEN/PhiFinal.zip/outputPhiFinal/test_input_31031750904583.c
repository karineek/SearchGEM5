
#include <stdio.h>
int main(int argc, char *argv[]) {
  int i;
  for (i = 1; i <= strlen(argv[1]); i++) {
    printf("%s\n", argv[1][i]);
  }
  return 0;
}