
#include <stdio.h>
int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s input_file\n", argv[0]);
        return 1;
    }
    int num = atoi(argv[1]);
    for (int i=2;i<argc-1;i++) {
        if (!strcmp(argv[i], "-h")) {
            break;
        } else {
            printf("Error: unknown flag '%s'\n", argv[i]);
            return 1;
        }
    }
    printf("The number is %d.\n", num);
    return 0;