
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    // Check if there is only one argument given as input (BASH)
    if (argc != 2) {
        printf("Please provide a single argument.\n");
        return 1;
    }

    // Get the input value from argv[1]
    char *input = argv[1];

    // Perform memory-to-register promotion on the input string
    for (int i = 0; i < strlen(input); i++) {
        input[i] = toupper(input[i]);
    }

    // Serialize the modified input string into a binary string
    char output[strlen(input) + 1];
    for (int i = 0; i < strlen(input); i++) {
        output[i] = input[i];
    }
    output[strlen(input)] = '\0';

    // Output the modified input and its serialized version
    printf("Input: %s \n", input);
    printf("Serialized: %s \n", output);

    return 0;
}