
#include <iostream>
using namespace std;

// Function to add two numbers
int add(int a, int b) {
  return a + b;
}

// Main function to test the program
int main() {
  // Declare variables for input
  double x = 0.0, y = 0.0;

  // Prompt user for input and read it using argv
  char* file_name = argv[1];
  ifstream inputFile(file_name);

  // Read in the input data from the file
  while (inputFile >> x && inputFile >> y) {
    cout << "Addition of " << x << " and " << y << " is: ";
    double sum = add(x, y);
    cout << sum << endl;
  }

  // Close the file
  inputFile.close();

  return 0;
}