
#include <stdio.h>

int main(int argc, char *argv[]) {

  if (argc != 2) {
    printf("Usage: %s filename\n", argv[0]);
    return 1;
  }

  FILE* fp = fopen(argv[1], "r");
  if (!fp) {
    perror("fopen() failed");
    return 1;
  }

  int c;
  while ((c = fgetc(fp)) != EOF) {
    // loop vectorization and handles machine code generation
    printf("%c", (char)(c & 0x7f));
  }

  return 0;
}