
#include <stdio.h>
int main(int argc, char *argv[]) {
    printf("Enter your name: ");
    scanf("%s", argv[1]);
    return 0;
}