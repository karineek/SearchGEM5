
#include <stdio.h>
#define MAX_ARGS 10
int main(int argc, char **argv) {
  int res1 = 0;
  int res2 = 0;
  for (int i = 1; i < argc && i <= MAX_ARGS; i++) {
    res1 += atoi(argv[i]); // Calculate two numbers result with Constant Folding
  }
  printf("Result: %d\n", res1);
  return 0;
}