
#include <stdio.h>
int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: program [input_file]\n");
        return 1;
    }

    FILE *fp = fopen(argv[1], "r");
    if (fp == NULL) {
        printf("Error opening file: %s\n", argv[1]);
        return 1;
    }

    char line[100];
    while (fgets(line, sizeof(line), fp)) {
        printf("%s\n", line);
    }

    fclose(fp);
    return 0;
}