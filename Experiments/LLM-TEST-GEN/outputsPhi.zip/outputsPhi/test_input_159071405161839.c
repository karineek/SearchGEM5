
#include <stdio.h>
#include <string.h>

int main() {
    char *str[100];
    int i = 0;

    for (i = 1; argc > i; ++i) {
        str[i] = malloc(strlen(argv[i]) + 1);
        if (str[i] == NULL) return -1;
        strncpy(str[i], argv[i], strlen(argv[i]) + 1);
    }

    for (int j = 0; j < i; ++j) {
        printf("%s\n", str[j]);
    }

    return 0;
}