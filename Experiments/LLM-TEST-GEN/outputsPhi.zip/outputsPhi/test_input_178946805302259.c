
#include <stdio.h>

int main(int argc, char *argv[]) {

    if (argc != 2) {
        printf("Usage: ./fibonacci INT\n");
        return 1;
    }

    int num = atoi(argv[1]);

    for (int i = 0; i < num; i++) {
        if (i == 0 || i == 1) {
            printf("%d ", i);
        } else {
            int a = 0, b = 1;
            for (int j = 2; j < num; j++) {
                int c = a + b;
                a = b;
                b = c;
            }
            printf("%d ", c);
        }
    }

    return 0;
}