
#include <stdio.h>

int main(int argc, char *argv[]) {
    // Check if correct number of arguments are passed
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }

    // Open the file and read its contents
    FILE *file = fopen(argv[1], "r");
    if (file == NULL) {
        printf("Error: cannot open file %s\n", argv[1]);
        return 1;
    }

    // Read the file contents line by line and store them in a buffer
    char buffer[100];
    while (fgets(buffer, 100, file) != NULL) {
        // Perform operations on the buffer here...
    }

    // Close the file
    fclose(file);

    return 0;
}