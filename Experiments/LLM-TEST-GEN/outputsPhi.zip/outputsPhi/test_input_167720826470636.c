
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main(int argc, char* argv[]) {

  // Check if the correct number of arguments were provided
  if (argc != 2) {
    printf("Usage: %s input_file\n", argv[0]);
    return 1;
  }

  // Open the file for reading and read the contents
  FILE* fp = fopen(argv[1], "r");
  if (!fp) {
    perror("Could not open input file.");
    return 2;
  }

  // Read each line of the file and print it to the console
  while (fgets(line, sizeof(line), fp)) {
    printf("%s\n", line);
  }

  // Close the file
  fclose(fp);

  return 0;
}