
#include <stdio.h>
int main(int argc, char *argv[]) {
    // Check for valid arguments
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }

    char *filename = argv[1];
    FILE* fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("Error opening file: %s\n", filename);
        return 1;
    }

    char c;
    while ((c = fgetc(fp)) != EOF) {
        if (isalpha(c)) {
            // Check if it's a vowel or consonant
            int isVowel = 0;
            for (int i = 'a'; i <= 'z'; i++) {
                if (tolower(c) == i) {
                    isVowel = 1;
                    break;
                }
            }
            if (isVowel == 0) {
                printf("%c is not a vowel or consonant.\n", c);
            } else {
                printf("%c is a %s.\n", c, "vowel" if isVowel == 1 else "consonant");
            }
        }
    }

    fclose(fp);
    return 0;
}