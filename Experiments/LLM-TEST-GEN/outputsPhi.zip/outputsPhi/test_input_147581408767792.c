
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char* argv[]) {
    // Initialize variables
    int a = atoi(argv[1]);
    char b[] = "hello";

    // Perform operation and return program code
    printf("The result is %d\n", a + b);
    printf("Program with all includes:\n");
    puts("#include <stdio.h>");
    puts("#include <stdlib.h>");
    puts("#include <string.h>");

    return 0;
}