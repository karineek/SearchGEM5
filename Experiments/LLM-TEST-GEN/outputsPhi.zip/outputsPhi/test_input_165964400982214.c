
#include <stdio.h>

int main(int argc, char* argv[]) {
    int num;

    if (argc != 2) {
        printf("Usage: %s [num]\n", argv[0]);
        return 1;
    }

    num = atoi(argv[1]);
    if (num >= 0) {
        printf("%d is a positive number\n", num);
    } else {
        printf("%d is a negative number\n", num);
    }

    return 0;
}