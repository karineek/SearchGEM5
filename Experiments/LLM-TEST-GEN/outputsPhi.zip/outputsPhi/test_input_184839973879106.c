
#include <stdio.h>

int main(int argc, char* argv[]) {
    int n;
    if (argc != 2) {
        printf("Usage: %s integer\n", argv[0]);
        return 1;
    }
    n = atoi(argv[1]);
    if (n < 0) {
        printf("Factorial of a negative number is not defined.\n");
        return 2;
    }
    int fact = 1;
    for (int i = 2; i <= n; ++i) {
        fact *= i;
    }
    printf("The factorial of %d is %d\n", n, fact);
    return 0;
}