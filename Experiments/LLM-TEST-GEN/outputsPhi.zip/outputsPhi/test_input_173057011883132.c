
#include <stdio.h>

int main(int argc, char* argv[]) {
    // Read input from stdin
    FILE* fp = fopen(argv[1], "r");
    if (fp == NULL) {
        printf("Error opening file %s.\n", argv[1]);
        return 1;
    }

    // Read the input line by line and process it
    char line[1024];
    while (fgets(line, 1024, fp)) {
        // Process the input here, for example by parsing it as a number or string
    }

    // Close the file when finished reading
    fclose(fp);

    return 0;
}