
#include <stdio.h>
#include <math.h>

int main() {
    int n, i, sum = 0, mean;
    float sigma2 = 0.0;

    printf("Enter the number of elements: ");
    scanf("%d", &n);

    // Get input from argv[] (if any)
    if(argc > 1){
        for(i = 2; i <= argc; ++i){
            sigma2 += atof(argv[i]) * atof(argv[i]);
        }
    }

    // Get input from stdin
    for(i = 1; i <= n; ++i){
        printf("Enter the %dth number: ", i);
        scanf("%f", &sum);
    }

    // Calculate mean
    mean = sum / n;

    // Calculate variance
    for(i = 1; i <= n; ++i){
        sigma2 += pow((sum - mean) * (n - i + 1), 2);
    }
    sigma2 /= n;

    // Calculate standard deviation
    printf("Standard Deviation: %.2f\n", sqrt(sigma2));

    return 0;
}