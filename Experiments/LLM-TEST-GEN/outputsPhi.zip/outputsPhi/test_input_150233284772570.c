
#include <stdio.h>
int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Please provide at least one argument.");
        return 1;
    }
    for (int i = 2; i < argc; i++) {
        printf("%s\n", argv[i]);
    }
    return 0;
}