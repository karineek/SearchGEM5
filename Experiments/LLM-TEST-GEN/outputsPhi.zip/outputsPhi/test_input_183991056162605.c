
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {
    long long int a, b;

    if (argc != 3) {
        printf("Usage: %s start end\n", argv[0]);
        return 1;
    }
    a = atol(argv[1]);
    b = atol(argv[2]);

    for (long long int i = a + 1; i <= b; i++) {
        if (!is_prime(i)) continue; // is_prime() is a function to check if a number is prime or not.
        printf("%lld\n", i);
    }

    return 0;
}