
#include <stdio.h>

int main(int argc, char *argv[]) {
    int a = atoi(argv[1]); // convert first argument to integer
    int b = atoi(argv[2]); // convert second argument to integer

    printf("The sum of a and b is %d\n", a + b);
    return 0;
}