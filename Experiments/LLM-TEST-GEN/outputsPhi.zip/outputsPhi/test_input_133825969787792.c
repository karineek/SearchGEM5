
#include <stdio.h>

int main(int argc, char* argv[]) {
    int n;

    // Check if enough arguments were provided
    if (argc != 2) {
        printf("Usage: %s <input>\n", argv[0]);
        return 1;
    }

    n = atoi(argv[1]); // Convert input to integer using atoi function

    // Print out the input
    printf("Input: %d\n", n);

    return 0;
}