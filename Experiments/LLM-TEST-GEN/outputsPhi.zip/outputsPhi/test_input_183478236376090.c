
#include <stdio.h>
#include <string.h>

int main(int argc, char** argv) {
    // Check if correct number of arguments has been provided
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }

    // Open file for reading
    FILE* fp = fopen(argv[1], "r");

    if (fp == NULL) {
        printf("Error: could not open file.\n");
        return 1;
    }

    // Read the file and print its contents to the console
    char line[100];
    while (fgets(line, sizeof(line), fp) != NULL) {
        printf("%s\n", line);
    }

    // Close file
    fclose(fp);

    return 0;
}