
#include <stdio.h>

int main(int argc, char **argv) {

  // Input is taken from command line arguments
  int i;
  for (i = 1; i <= argc; i++) {
    printf("%s", argv[i]);
  }

  return 0;
}