
#include <stdio.h>
int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <int1> <int2>\n", argv[0]);
        return 1;
    }

    int a = atoi(argv[1]), b = atoi(argv[2]);

    for (int i = 0; i < a; ++i) {
        printf("%d\t", ++a);
    }
    for (int j = 0; j < b; ++j) {
        printf("%d\n", ++b);
    }

    return 0;
}