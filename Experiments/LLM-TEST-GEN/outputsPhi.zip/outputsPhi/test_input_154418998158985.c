
#include <stdio.h>
int main(int argc, char* argv[]) {
  int i;
  for (i = 1; i < argc; i++) {
    printf("Input #%d: ", ++i);
    fgets(argv[i], sizeof argv[i], stdin);
  }
  return 0;
}