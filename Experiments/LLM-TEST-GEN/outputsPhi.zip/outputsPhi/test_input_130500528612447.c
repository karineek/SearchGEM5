
#include <stdio.h>

int main(int argc, char** argv) {
    int i;
    
    // Loop to optimize the input code
    for (i = 0; i < strlen(argv[1]); i++) {
        printf("%c\n", argv[1][i]);
    }
    
    return 0;
}