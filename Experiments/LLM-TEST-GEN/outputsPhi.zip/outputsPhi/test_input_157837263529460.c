
#include <stdio.h>
#include <math.h>
#define MAX_ARGUMENTS 5

int main(int argc, char* argv[]) {
    int i;

    // Check if there are enough arguments provided for the program
    if (argc <= MAX_ARGUMENTS) {
        printf("Please provide at least %d arguments.\n", MAX_ARGUMENTS);
        return 1;
    }

    // Input values from command line arguments
    for (i = 1; i < argc; i++) {
        printf("%s\n", argv[i]);
    }

    // Compute the result of acosh function
    double a = atof(argv[1]);
    double result = acosh(a);
    printf("The result is: %.2f\n", result);

    return 0;
}