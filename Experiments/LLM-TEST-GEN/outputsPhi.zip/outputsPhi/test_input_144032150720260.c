
#include <stdio.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    FILE* fp = stdin;
    if (argc == 2) {
        char input_str[] = argv[1];
        char output_str[128];
        fgets(output_str, sizeof(output_str), stdin);
        int len = strlen(input_str);
        for (int i=0; i<len; i++) {
            if (input_str[i] == '\n') {
                break;
            } else if (output_str[i] == ' ') {
                fprintf(fp, "%c", input_str[i]);
            } else {
                fprintf(fp, " ");
            }
        }
        fprintf(fp, "\n");
    }
    return 0;
}