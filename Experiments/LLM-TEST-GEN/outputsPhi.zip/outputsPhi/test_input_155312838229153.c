
#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]) {
    if (argc == 1) {
        // If the program is run without arguments, prompt for input using fgets()
        FILE* file = fopen("input.txt", "r");
        char line[100];
        while (fgets(line, sizeof(line), file)) {
            // Do something with the input data here
        }
        fclose(file);
    } else {
        // If arguments are provided, use argv[1] as input
        char* arg = argv[1];
        // Do something with the input data here
    }

    // Clear a flag using atomic_flag_clear()
    #ifdef __GNU__
    atomic_flag_clear(1);
    #else
    #define AF1 1
    #endif
}