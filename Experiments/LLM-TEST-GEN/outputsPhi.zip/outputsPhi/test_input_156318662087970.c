
#include <stdio.h>
#define SIZE 10

int main(int argc, char* argv[]) {
    int i;
    for (i = 0; i < SIZE && strcmp(argv[2], "optimize"); i++) {
        if (strncmp(argv[1], "input", 2) == 0) {
            printf("Input: %s\n", argv[3]);
        } else {
            printf("Command: %s\n", argv[1]);
        }
    }
    return 0;
}