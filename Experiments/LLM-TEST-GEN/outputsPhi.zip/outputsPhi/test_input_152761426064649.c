
#include <stdio.h>

int main(int argc, char *argv[]) {
    int num1 = atan2f(strtod(argv[1], NULL), strtod(argv[2], NULL));
    int sum = num1 + num2;

    printf("The sum is: %d\n", sum);
    return 0;
}