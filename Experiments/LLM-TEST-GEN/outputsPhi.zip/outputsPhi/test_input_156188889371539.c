
#include <stdio.h>

int main(int argc, char *argv[]) {

    int num = atoi(argv[1]);

    if (num == reverse(num)) {
        printf("%d is a palindrome", num);
    } else {
        printf("%d is not a palindrome", num);
    }

    return 0;
}