
#include <stdio.h>
#include <time.h>

int main(int argc, char* argv[]) {

    // Check if correct number of arguments provided
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }

    // Open file for reading
    FILE* fp = fopen(argv[1], "r");
    if (fp == NULL) {
        printf("Could not open file %s.\n", argv[1]);
        return 1;
    }

    // Get current date and time using asctime function
    struct tm *local = localtime(0);
    char st_year[2] = { 0 };
    strftime(st_year, sizeof(st_year), "%Y");

    printf("%s (%d) \n", argv[1], atoi(st_year));
    // Close file
    fclose(fp);

    return 0;
}