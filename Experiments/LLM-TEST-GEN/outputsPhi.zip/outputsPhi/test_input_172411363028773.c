
#include <stdio.h>

int main(int argc, char* argv[]) {

    if (argc == 2) {
        printf("You entered two arguments:\n");
        printf("1st argument: %s\n", argv[1]);
        printf("2nd argument: %s\n", argv[2]);
    } else {
        printf("You did not enter exactly two arguments.\n");
    }

    return 0;
}