
#include <stdio.h>

int main() {
    int argc;
    char* argv[];

    // Get the number of command-line arguments
    argc = (argc > 1) ? argc - 2 : 1;

    // Check if there are enough arguments for the program to execute
    if (argc < 2) {
        printf("Error: Not enough arguments.\n");
        return 1;
    }

    // Use argv[0] as the filename and argv[1] as the main program argument
    char* file = argv[0];
    char* main_arg = argv[1];

    // Prints the name of the program and its arguments
    printf("File: %s\n", file);
    printf("Main Arguments: %s\n", main_arg);

    return 0;
}