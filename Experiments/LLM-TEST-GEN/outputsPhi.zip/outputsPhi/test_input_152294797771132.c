
#include <stdio.h>
int main(int argc, char *argv[]) {
    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);
    int result;
    if (num1 > 0 && num2 > 0) {
        printf("The product of %d and %d is %d", num1, num2, num1 * num2);
    } else if (num1 < 0 || num2 < 0) {
        printf("Both numbers must be positive.\n");
    } else {
        result = num1 + num2;
        printf("The sum of %d and %d is %d", num1, num2, result);
    }
    return 0;
}