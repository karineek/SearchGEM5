
#include <stdio.h>

int main(int argc, char *argv[]) {

    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }

    int number = atoi(argv[1]);

    if (number <= 1) {
        printf("%d is not a prime number.\n", number);
        return 2;
    }

    for (int i = 2; i * i <= number; i++) {
        if (number % i == 0) {
            printf("%d is divisible by %d, which means it's not a prime number.\n", number, i);
            return 3;
        }
    }

    printf("%d is a prime number.\n", number);
    return 4;
}