
#include <stdio.h>

int main(int argc, char* argv[]) {
    printf("Enter a number: ");
    int num = atoi(argv[1]);

    // Check if the input is valid (e.g., not a negative number)
    if (num < 0) {
        fprintf(stderr, "Error: Number cannot be negative\n");
        return 1;
    }

    // Compute the square of the input number
    int result = num * num;

    // Print the result to the console
    printf("Square: %d\n", result);

    // Optimize the loop by using a constant expression for i instead of a variable
    const int i = argc > 1 ? atoi(argv[2]) : 10;

    // Compute the factorial of the input number using recursion and loop optimization
    if (i == 0) {
        return 1;
    } else {
        int result = i * fact(i - 1);

        // Print the result to the console
        printf("Factorial: %d\n", result);
        return 0;
    }
}