
#include <stdio.h>

int main(int argc, char** argv) {
  int n;
  if (argc > 1) {
    n = atoi(argv[1]);
  } else {
    printf("Usage: %s <n>\n", argv[0]);
    return 1;
  }

  int sum = 0;
  for (int i = 1; i <= n; i++) {
    sum += i;
  }

  printf("The sum of the first %d natural numbers is %d\n", n, sum);

  return 0;
}