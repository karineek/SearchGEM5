
#include <stdio.h>

int main(int argc, char *argv[]) {

  // Check if the number of arguments provided is correct
  if (argc != 2) {
    printf("Usage: %s <filename>.\n", argv[0]);
    return 1;
  }

  // Open the file and read its contents
  FILE *file = fopen(argv[1], "r");
  if (file == NULL) {
    printf("Error: File not found.\n");
    return 2;
  }

  char line[1024];
  while (fgets(line, sizeof(line), file)) {
    // Output the contents of the file to standard output
    printf("%s", line);
  }

  fclose(file);

  return 0;
}