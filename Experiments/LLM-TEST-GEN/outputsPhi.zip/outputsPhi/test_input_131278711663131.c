
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc == 1) {
        printf("Please provide input as a command line argument.\n");
        return 1;
    }

    char input_str[50];
    strcpy(input_str, argv[1]); // copy the first argument to a string variable

    printf("Input: %s\n", input_str);

    return 0;
}