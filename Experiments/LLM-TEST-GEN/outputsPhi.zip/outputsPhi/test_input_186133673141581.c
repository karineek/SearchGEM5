
#include <stdio.h>

int main(int argc, char* argv[]) {
    printf("Hello, %s\n", argv[1]); // print first argument as a string
    return 0;
}