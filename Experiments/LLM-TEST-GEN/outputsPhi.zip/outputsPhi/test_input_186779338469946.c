
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {
    int i;
    for (i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-v")) {
            printf("Version: %s\n", argv[1]);
        }
        else if (isatty(stdin)) {
            int num = atoi(argv[i+1]);
            for (int j = 2; j <= num; j++) {
                if (j % 3 == 0) {
                    printf("%d\n", j);
                }
            }
        }
    }
    return 0;
}