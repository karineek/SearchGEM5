
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // check if correct number of arguments is passed
    if (argc != 2) {
        printf("Usage: %s integer\n", argv[0]);
        return 1;
    }
    // convert the argument to an integer and compute its square using function inlining optimization
    int number = atoi(argv[1]);
    int squared_number = pow(number, 2);
    printf("The square of %d is %d\n", number, squared_number);
    return 0;
}