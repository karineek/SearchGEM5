
#include <stdio.h>

int main(int argc, char** argv) {
    int i;
    for (i = 1; i < argc; i++) {
        printf("Input: %s\n", argv[i]);
    }
    int decimal_num = 0;
    int base = 1;
    for (i = argc - 1; i >= 1; i--) {
        decimal_num += (argv[i] - '0') * base;
        base *= 2;
    }
    printf("Decimal: %d\n", decimal_num);
    return 0;
}