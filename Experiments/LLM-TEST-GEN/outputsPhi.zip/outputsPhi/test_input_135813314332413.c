
#include <stdio.h>

int main(int argc, char *argv[]) {
    // Check if there are at least 2 arguments passed in the command line
    if (argc < 2) {
        printf("Error: Not enough arguments provided.\n");
        return 1;
    }

    // Print out all input arguments
    for (int i = 1; i < argc; i++) {
        printf("Argument %d: %s\n", i, argv[i]);
    }

    return 0;
}