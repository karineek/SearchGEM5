
#include <stdio.h>

int main(int argc, char* argv[]) {
    // Get the size of the array from the first command-line argument
    size_t array_size = strtol(argv[1], NULL, 10);

    // Allocate an array of integers with the given size
    int arr[array_size];

    // Read in the values for each element in the array from the second command-line argument
    for (int i = 1; i < argc; i++) {
        arr[i - 1] = strtol(argv[i], NULL, 10);
    }

    // Find the largest element in the array using a loop and compare it to the current max value
    size_t max_index = 0;
    int max_value = arr[0];
    for (int i = 1; i < array_size; i++) {
        if (arr[i] > max_value) {
            max_value = arr[i];
            max_index = i;
        }
    }

    // Print out the largest element and its index
    printf("The largest element in the array is %d, which appears at index %zu.\n", max_value, max_index);

    return 0;
}