
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {

    // Initialize variables with provided arguments
    int i;
    char *str[10];

    for (i = 1; i <= 10; i++) {
        str[i - 1] = argv[i];
    }

    // Display input arguments
    printf("Input Arguments:\n");
    for (i = 1; i < argc; i++) {
        printf("Argument %d: %s\n", i, str[i - 1]);
    }

    return 0;
}