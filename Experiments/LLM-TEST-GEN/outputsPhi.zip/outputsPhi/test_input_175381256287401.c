
#include <stdio.h>

int main(int argc, char *argv[]) {
    double x;
    int i;

    if (argc != 2) {
        printf("Usage: %s x\n", argv[0]);
        return 1;
    }

    x = strtod(argv[1], NULL);

    for (i = 0; i < 1000; i++) {
        x = pow(x, 2);
    }

    printf("%.20f\n", x); // output the value of x^1000 as a float with 20 decimal places

    return 0;
}