
#include <stdio.h>

int main(int argc, char **argv) {
    double x;

    // check if enough arguments were provided
    if (argc != 2) {
        printf("Error: Please provide only one argument.\n");
        return 1;
    }

    // read the input from the command line
    x = atanhf(strtod(argv[1], NULL));

    printf("Input: %g \n", x);

    return 0;
}