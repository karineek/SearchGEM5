
#include <stdio.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input>\n", argv[0]);
        return 1;
    }

    for (int i = 0; i < strlen(argv[1]); i++) {
        printf("%c", argv[1][i]);
    }

    return 0;
}