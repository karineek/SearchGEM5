
#include <stdio.h>
int main(int argc, char **argv) {
    if (argc<2) {
        printf("Please provide at least one command line argument\n");
        return 1;
    }
    for (int i=1; i<argc; i++) {
        char *token = strtok(argv[i], " \t");
        if (token == NULL) {
            printf("Invalid input\n");
            return 1;
        }
        else {
            printf(token); //Encrypted data here
        }
    }
}