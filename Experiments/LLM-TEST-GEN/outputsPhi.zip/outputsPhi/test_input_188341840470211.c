
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {
    // Check that there are exactly two arguments (which should be integers)
    if (argc != 3) {
        printf("Usage: %s <num1> <num2>\n", argv[0]);
        return 1;
    }

    // Convert the arguments to integers and calculate their arctanh
    double num1 = strtod(argv[1], NULL);
    double num2 = strtod(argv[2], NULL);
    double result = atanh((num1 + num2) / 2.0);

    // Print the results
    printf("The arctangent inverse of (%f, %f) is %g\n", num1, num2, result);

    return 0;
}