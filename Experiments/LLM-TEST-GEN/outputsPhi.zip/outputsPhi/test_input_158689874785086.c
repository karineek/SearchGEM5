
#include <stdio.h>
#include <string.h>
int main(int argc, char *argv[]) {
    int a = atoi(argv[1]);
    int b = atoi(argv[2]);
    int lcm;
    if (a == 0)
        lcm = b;
    else if (b == 0)
        lcm = a;
    else {
        while (b != 0) {
            int temp = a % b;
            a = b;
            b = temp;
        }
        lcm = a;
    }
    printf("LCM of %d and %d is: %d\n", a, b, lcm);
    return 0;
}