
#include <stdio.h>
#define ARGV 10 // Maximum number of arguments to be read from command line
int main(int argc, char **argv) {
    // Check if the correct number of arguments is provided
    if (argc != ARGV + 1) {
        printf("Error: Incorrect number of arguments\n");
        return -1;
    }
    // Read the input from command line
    for (int i = 2; i <= ARGV; i++) {
        printf("Input %d: ", i);
        scanf("%s", argv[i]);
    }
    // Perform memory-to-register promotion optimisation
    for (int i = 1; i < ARGV; i++) {
        if (strlen(argv[i]) > 2) {
            argv[i] = strtok(argv[i], ":"); // Split the input by colon and store the remainder in a new variable
        }
    }
    // Print the output
    for (int i = 1; i <= ARGV; i++) {
        printf("%s\n", argv[i]);
    }
    return 0;
}