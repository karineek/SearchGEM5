
#include <stdio.h>
int main(int argc, char* argv[]) {
    // Check if enough arguments are provided
    if (argc != 3) {
        printf("Usage: %s <input> <output>\n", argv[0]);
        return 1;
    }

    // Read input file and output file from command line arguments
    FILE* in_file = fopen(argv[1], "r");
    FILE* out_file = fopen(argv[2], "w");

    // Check if files were opened successfully
    if (in_file == NULL || out_file == NULL) {
        printf("Error: Failed to open input or output file\n");
        return 1;
    }

    // Read data from input file and write it to output file with scalar optimization
    while (1) {
        // Read a line of input
        char line[256];
        fgets(line, 256, in_file);

        // Check if end of file is reached
        if (strcmp(line, "") == 0) {
            break;
        }

        // Apply scalar optimization using >= operator
        if (atoi(line) >= 100) {
            fputs(line, out_file);
        } else {
            printf("Error: Invalid input\n");
            return 1;
        }
    }

    // Close files
    fclose(in_file);
    fclose(out_file);

    // Return success code
    return 0;
}