
#include <stdio.h>
int main(int argc, char* argv[]) {
  int i;
  for (i=1; i<argc; i++) {
    if ((argc == 2 && strlen(argv[i]) > 1) || (strlen(argv[i]) == 1)) {
      printf("Invalid input: %s\n", argv[i]);
      return 1;
    }
    printf("Input in octal format:\t%s\n", argv[i]);
    int n = strtol(argv[i], NULL, 8);
    for (int j=0; j<strlen(argv[i]/2); j++) {
      printf("%c", ((n & 0x80) == 0x80 ? '\x1f' : '\x0f') + (n >> 6));
      n <<= 2;
    }
  }
  return 0;
}