
#include <stdio.h>
#define MAX_STUDENT 10
typedef struct {
    char name[MAX_STUDENT];
    int age;
    float grade;
} Student;

int main(int argc, char *argv[]) {
    // Initialize the student structure with some default values
    Student students[10] = {
        {"Alice", 18, 90.5},
        {"Bob", 17, 85.2},
        {"Charlie", 16, 92.3}
    };

    // Process the command line arguments to set the student's name, age, and grade
    if (argc == 3) {
        char *name = argv[1];
        int age = atoi(argv[2]);
        float grade = atof(argv[3]);

        // Check if the input is valid
        if (name == NULL || age < 0 || grade < 0) {
            printf("Invalid input\n");
            return 1;
        }

        // Update the student's information in the array of structures
        students[0].name = name;
        students[0].age = age;
        students[0].grade = grade;
    }

    // Display the student's information
    printf("Name: %s\n", students[0].name);
    printf("Age: %d\n", students[0].age);
    printf("Grade: %.1f\n", students[0].grade);

    return 0;
}