
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {

	if (argc != 3) {
		printf("Please provide two numbers as command line arguments.\n");
		return 1;
	}

	char op[3];
	int num1 = strtol(argv[1], NULL, 10);
	int num2 = strtol(argv[2], NULL, 10);

	switch (argv[3][0]) {
	case 'a':
		printf("%d + %d = %d\n", num1, num2, num1+num2);
		break;
	case 's':
		printf("%d - %d = %d\n", num1, num2, num1-num2);
		break;
	case 'm':
		printf("%d * %d = %d\n", num1, num2, num1*num2);
		break;
	case '/':
		if (num2 == 0) {
			printf("Error: division by zero is not allowed.\n");
			return 1;
		}
		else {
			printf("%d / %d = %d\n", num1, num2, num1/num2);
		}
	default:
		printf("Invalid operator. Please use 'a', 's', 'm' or '/'.");
		return 1;
	}

	return 0;
}