
#include <stdio.h>
#include <stdbool.h>

int main(int argc, char *argv[]) {
    // initialize variables with first argument as string
    char name[20];
    int age;

    if (argc == 2) {
        strncpy(name, argv[1], 20);
        age = atoi(argv[2]);
    } else {
        printf("Usage: %s name age\n", argv[0]);
        return 1;
    }

    // print out the input values
    printf("Name: %s\n", name);
    printf("Age: %d\n", age);

    return 0;
}