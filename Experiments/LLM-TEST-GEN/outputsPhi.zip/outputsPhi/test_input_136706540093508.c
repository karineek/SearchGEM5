
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    printf("Enter the first distance in inches: ");
    float d1 = atof(argv[1]);

    printf("Enter the second distance in inches: ");
    float d2 = atof(argv[2]);

    printf("The sum of the two distances is %f inches.\n", d1 + d2);

    return 0;
}