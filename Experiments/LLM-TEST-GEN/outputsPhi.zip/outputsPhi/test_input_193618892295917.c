
#include <stdio.h>

int main(int argc, char** argv) {
    // Get the first argument (the filename) using argv[1]
    FILE* file = fopen("inputfile.txt", "r");

    int a;
    int b;
    char c;

    if (!file || !fscanf(file, "%d %c %d\n", &a, &b, &c)) {
        printf("Error reading file!\n");
        return 1;
    }

    // Calculate the sum of a and b
    int result = a + b;

    // Output the results
    printf("a: %d, b: %c, c: %d\n", a, b, c);
    printf("Sum: %d\n", result);

    fclose(file);
    return 0;
}