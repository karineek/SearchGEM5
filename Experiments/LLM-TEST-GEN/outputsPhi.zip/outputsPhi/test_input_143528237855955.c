
#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]) {
    if(argc != 2) {
        printf("Usage: %s <filename>.txt\n", argv[0]);
        return 1;
    }

    FILE* file = fopen(argv[1], "r");
    if(file == NULL) {
        printf("Error: could not open file %s\n", argv[1]);
        return 1;
    }

    char line[1024];
    while((fgets(line, sizeof(line), file)) != NULL) {
        printf("%s\n", line);
    }

    fclose(file);

    return 0;
}