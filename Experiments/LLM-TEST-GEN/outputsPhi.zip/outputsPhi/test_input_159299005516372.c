
#include <stdio.h>
#include <string.h>

int main(int argc, char** argv) {

    // Initialize string variable with input argument
    char str[100];
    if (argc == 2) {
        sscanf(argv[1], "%99s", str);
    } else {
        printf("Please provide input argument using \"-i <filename>\" command.\n");
        return 1;
    }

    // Clear output buffer
    fflush(stdout);
    while (str[0] == '\0') {
        char c = getchar();
        if (c != EOF) {
            puts(c);
        } else {
            return -1;
        }
    }

    // Replace backspace with '\0' character and print out the modified string
    for (int i = 0; str[i] != '\0'; i++) {
        if (str[i] == '\b') {
            str[i] = '\0';
        } else {
            puts(str[i]);
        }
    }

    return 0;
}