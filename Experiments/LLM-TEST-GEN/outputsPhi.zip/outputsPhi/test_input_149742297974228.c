
#include <iostream>
using namespace std;
int main() {
    string input_str;
    for (size_t i = 1; i < argc; i++) {
        input_str += " " << argv[i];
    }
    cout << input_str << endl;
}