
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {
    // Check if we have enough arguments
    if (argc != 2) {
        printf("Usage: %s input\n", argv[0]);
        return 1;
    }

    // Get the input string from command line argument
    char *input = argv[1];

    // Do some processing with the input
    int length = strlen(input);
    printf("Input string: %s\n", input);
    printf("Length of input string: %d\n", length);

    // Output to stdout
    return 0;
}