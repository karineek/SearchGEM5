
#include <stdio.h>
#include <string.h>

int main() {
    char *input;
    input = (char *) malloc(strlen(argv[1]) + 1); // allocate memory for the string

    strcpy(input, argv[1]); // copy argv[1] to input

    printf("Input: %s\n", input);
    free(input); // release memory after use

    return 0;
}