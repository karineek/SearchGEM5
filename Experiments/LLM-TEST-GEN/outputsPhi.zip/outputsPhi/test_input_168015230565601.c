
#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]) {

    int num1 = atoi(argv[1]); //converts first argument to integer value and assigns it to 'num1' variable
    int num2 = atoi(argv[2]); //converts second argument to integer value and assigns it to 'num2' variable

    printf("Enter two numbers: ");
    char *input_str;
    fgets(input_str, 100, stdin); //read input from standard input (stdin)
    int num3 = atoi(strtok(input_str, " ")); //converts third argument to integer value and assigns it to 'num3' variable

    printf("\nEnter a string: ");
    char *string = fgets(stdin, 100, stdin); //read input from standard input (stdin)

    char *result;
    strcpy(result, string); //concatenates the string with itself and returns it as output

    printf("\nResult: %s", result); //outputs the concatenated string

    return 0;
}