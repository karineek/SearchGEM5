
#include <stdio.h>

int main(int argc, char **argv) {

    printf("Please enter your name:\n");
    scanf("%s", &argv[1]); // assuming we want to print the second argument as input
    puts(argv[1]); // putting the string in a message for debugging purposes

    return 0;
}