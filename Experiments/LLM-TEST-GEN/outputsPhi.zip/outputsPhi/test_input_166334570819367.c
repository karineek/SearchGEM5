
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    int input;
    if (argc == 2) {
        strtol(argv[1], NULL, 10);
        input = atoi(argv[1]);
    } else {
        fprintf(stderr, "Usage: %s <integer>\n", argv[0]);
        return 1;
    }

    printf("Square of %d is %d.\n", input, input * input);

    return 0;
}