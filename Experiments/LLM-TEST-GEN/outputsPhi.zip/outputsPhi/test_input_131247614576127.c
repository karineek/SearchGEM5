
#include <stdio.h>
int main(int argc, char** argv) {
    for (int i = 1; i < argc; i++) {
        if (!strcmp("-l", argv[i])) {
            include_dirs.push_back(argv[i+1]);
        } else if (strncmp("--optimize", argv[i], 4) == 0 && argc > i+2) {
            char *s = argv[i+1];
            s += strlen(s);
            if (strncmp("-", s, 1) == 0 && s[2] == '\0' && strncmp("--", argv[i+3], 2) == 0) {
                char *end = s + (s[1] == '-')?(argc > i+2):strlen(s);
                strncpy_s(&include_dirs.front(), s, end - s), end;
            }
        } else {
            include_dirs = std::vector<std::string>({argv[i]});
        }
    }

    printf("Included libraries: ");
    for (auto d : include_dirs) {
        printf("%s ", d.c_str());
    }
    printf("\n");

    return 0;