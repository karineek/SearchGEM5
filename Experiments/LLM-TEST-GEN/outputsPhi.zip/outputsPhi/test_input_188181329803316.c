
#include <stdio.h>
#include <string.h>
int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: program.exe [filename]\n");
        return 1;
    }
    // open file for reading
    FILE* fp = fopen(argv[1], "r");
    if (fp == NULL) {
        printf("Error: cannot open file %s\n", argv[1]);
        return 1;
    }
    // read contents of file
    char line[1024];
    int i = 0;
    while (fgets(line, 1024, fp)) {
        if (i == 0) {
            printf("Example input:\n");
            for (int j = 1; j <= argc; j++) {
                if (j == argc) {
                    printf("%s\n", argv[j]);
                } else {
                    printf("-%s\n", argv[j]);
                }
            }
        } else {
            printf("Input: %s\n", argv[i++]);
        }
    }
    // close file
    fclose(fp);
    return 0;
}