
#include <stdio.h>

int main(int argc, char* argv[]) {

   // check if there are any arguments passed in
   if (argc != 2) {
      printf("Please provide an argument\n");
      return 1;
   }

   // get the input from the command line
   char input[100];
   strncpy(input, argv[1], 100);

   // print out the input
   printf("%s\n", input);

   return 0;
}