
#include <stdio.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input_filename>\n", argv[0]);
        return 1;
    }

    FILE *file = fopen(argv[1], "r");
    if (file == NULL) {
        printf("Error: could not open file %s\n", argv[1]);
        return 2;
    }

    char input[256];
    while (!feof(file)) {
        fgets(input, 256, file);
        // Remove newline character at end of line
        if (strlen(input) > 0 && input[strlen(input)-1] == '\n') {
            input[strlen(input)-1] = '\0';
        }

        // Prints the input string
        printf("Input: %s\n", input);

        // Perform scalar optimization on the input string
        for (int i = 0; i < strlen(input); i++) {
            if (isupper(input[i])) {
                input[i] -= 32;
            }

            // Swap two numbers in the string using scalar optimization
            char a = input[0];
            char b = input[1];
            input[0] = b;
            input[1] = a;
        }

        // Prints the optimized string
        printf("Optimized Input: %s\n", input);

        fputc('\n', file);
    }

    fclose(file);
    return 0;
}