
#include <stdio.h>

int main(int argc, char *argv[]) {

    if (argc != 3) {
        printf("Error: Please provide two arguments.\n");
        return 1;
    }

    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);

    if (num1 < 0 || num2 < 0) {
        printf("Error: Please enter non-negative integers.\n");
        return 1;
    }

    int sum = num1 + num2;
    printf("Sum of %d and %d is %d.\n", num1, num2, sum);

    return 0;
}