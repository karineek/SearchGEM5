
#include <stdio.h>

int main(int argc, char* argv[]) {
    // Check if arguments are provided
    if (argc != 3) {
        printf("Usage: %s x y\n", argv[0]);
        return 1;
    }

    // Convert arguments to integers
    int a = atoi(argv[1]), b = atoi(argv[2]);

    // Check if arguments are valid (i.e., not too large)
    if (a > INT_MAX || b > INT_MAX) {
        printf("Error: Arguments must be less than %d\n", INT_MAX);
        return 1;
    }

    // Calculate absolute difference using custom-made abs function
    int result = abs(a - b);

    // Print out the result
    printf("Absolute difference between %d and %d is: %d\n", a, b, result);

    return 0;
}