
#include <stdio.h>

int main(int argc, char *argv[]) {
    // Check if input is provided
    if (argc != 2) {
        printf("Error: Insufficient input. Please provide a single argument.");
        return 1;
    }

    // Convert the first argument to integer
    int num = atoi(argv[1]);

    // Calculate the factorial of the number and print it
    if (num <= 0) {
        printf("Error: Number must be a positive integer.\n");
        return 1;
    }

    int fact = 1;
    for (int i = 1; i <= num; ++i) {
        fact *= i;
    }

    printf("Factorial of %d is: %d\n", num, fact);

    return 0;
}