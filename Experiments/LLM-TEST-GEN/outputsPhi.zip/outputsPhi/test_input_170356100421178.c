
#include <stdio.h>

int main(int argc, char* argv[]) {
    int a = atoi(argv[1]);
    int b = atoi(argv[2]);
    int c;
    if (strcmp("greater", argv[3]) == 0) {
        if (a > b) {
            printf("%d is greater than %d\n", a, b);
        } else {
            printf("%d is less than or equal to %d\n", a, b);
        }
    } else if (strcmp(argv[3], "greater") == 0) {
        if (b > a) {
            printf("%d is greater than %d\n", b, a);
        } else {
            printf("%d is less than or equal to %d\n", b, a);
        }
    }
    return 0;
}