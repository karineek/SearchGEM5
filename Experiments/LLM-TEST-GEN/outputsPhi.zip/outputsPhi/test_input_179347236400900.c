
#include <stdio.h>

int main() {
    char *argv[] = {"input", "string"};

    int i;
    for (i = 1; i < argc; i++) {
        printf("%s\n", argv[i]);
    }

    return 0;
}