
#include <iostream>
#include <string>

int main() {
    int num1 = atoi(argv[1]); //convert first argument to integer
    std::string name = argv[2]; //assign second argument to string variable

    cout << "Number 1: " << num1 << endl;
    cout << "Name: " << name << endl;

    return 0;
}