
#include <stdio.h>
#include <string.h>
#define MAX_ARGUMENTS 10

int main(int argc, char *argv[]) {
    int i;

    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-a") == 0) {
            printf("%d + %d = %d", atoi(argv[++i]), atoi(argv[++i]), atoi(argv[++i]));
        } else if (strcmp(argv[i], "-b") == 0) {
            printf("%d - %d = %d", atoi(argv[++i]), atoi(argv[++i]), atoi(argv[++i]));
        } else if (strcmp(argv[i], "-c") == 0) {
            printf("%d * %d = %d", atoi(argv[++i]), atoi(argv[++i]), atoi(argv[++i]));
        } else if (strcmp(argv[i], "-d") == 0) {
            printf("%d / %d = %f", atoi(argv[++i]), atoi(argv[++i]), atoi(argv[++i]));
        } else if (strcmp(argv[i], "-e") == 0) {
            printf("%d ** %d = %d", atoi(argv[++i]), atoi(argv[++i]), atoi(argv[++i]));
        } else if (strcmp(argv[i], "-f") == 0) {
            printf("%d %c %d = %d", atoi(argv[++i]), argv[++i][0], atoi(argv[++i]));
        } else if (strcmp(argv[i], "-g") == 0) {
            printf("%d %c %d = %s", atoi(argv[++i]), argv[++i][0], atoi(argv[++i]));
        } else if (strcmp(argv[i], "-h") == 0) {
            printf("\nUsage: %s [operation] [number1 number2 ...]", argv[0]);
        } else if (strcmp(argv[i], "-i") == 0) {
            printf("%d %c %d = %s\n", atoi(argv[++i]), argv[++i][0], atoi(argv[++i]));
        } else if (strcmp(argv[i], "-l") == 0) {
            printf("%d %c %d = %s\n", atoi(argv[++i]), argv[++i][0], atoi(argv[++i]));
        } else if (strcmp(argv[i], "-m") == 0) {
            printf("%d %c %d = %s\n", atoi(argv[++i]), argv[++i][0], atoi(argv[++i]));
        } else if (strcmp(argv[i], "-n") == 0) {
            printf("%d %c %d = %s\n", atoi(argv[++i]), argv[++i][0], atoi(argv[++i]));
        } else if (strcmp(argv[i], "-o") == 0) {
            printf("%d %c %d = %s\n", atoi(argv[++i]), argv[++i][0], atoi(argv[++i]));
        } else if (strcmp(argv[i], "-p") == 0) {
            printf("%d %c %d = %s\n", atoi(argv[++i]), argv[++i][0], atoi(argv[++i]));
        } else if (strcmp(argv[i], "-q") == 0) {
            printf("%d %c %d = %s\n", atoi(argv[++i]), argv[++i][0], atoi(argv[++i]));
        } else if (strcmp(argv[i], "-r") == 0) {
            printf("%d %c %d = %s\n", atoi(argv[++i]), argv[++i][0], atoi(argv[++i]));
        } else if (strcmp(argv[i], "-s") == 0) {
            printf("%d %c %d = %s\n", atoi(argv[++i]), argv[++i][0], atoi(argv[++i]));
        } else if (strcmp(argv[i], "-t") == 0) {
            printf("%d %c %d = %s\n", atoi(argv[++i]), argv[++i][0], atoi(argv[++i]));
        } else if (strcmp(argv[i], "-u") == 0) {
            printf("%d %c %d = %s\n", atoi(argv[++i]), argv[++i][0], atoi(argv[++i]));
        } else if (strcmp(argv[i], "-v") == 0) {
            printf("%d %c %d = %s\n", atoi(argv[++i]), argv[++i][0], atoi(argv[++i]));
        } else if (strcmp(argv[i], "-w") == 0) {
            printf("%d %c %d = %s\n", atoi(argv[++i]), argv[++i][0], atoi(argv[++i]));
        } else if (strcmp(argv[i], "-x") == 0) {
            printf("%d %c %d = %s\n", atoi(argv[++i]), argv[++i][0], atoi(argv[++i]));
        } else if (strcmp(argv[i], "-y") == 0) {
            printf("%d %c %d = %s\n", atoi(argv[++i]), argv[++i][0], atoi(argv[++i]));
        } else if (strcmp(argv[i], "-z") == 0) {
            printf("%d %c %d = %s\n\n", atoi(argv[++i]), argv[++i][0], atoi(argv[++i]));
        System.Exit();

   System.exit(1);
}

//Output:
#System.exit("10")