
#include <stdio.h>
int main(int argc, char **argv) {
    int num1 = atoi(argv[1]); // convert first argument to integer
    int num2 = atoi(argv[2]); // convert second argument to integer
    printf("The sum of %d and %d is %d.\n", num1, num2, num1 + num2);
    return 0;
}