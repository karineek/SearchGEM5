
#include <stdio.h>
#define SIZE 50
int main(int argc, char* argv[]) {

    float num;
    if (argc != 2) {
        printf("Usage: %s <float_number>", argv[0]);
        return 1;
    }
    else {
        num = atof(argv[1]);
        printf("Input: %f\n", num);
        printf("Output: %f\n", num * 2.0);
    }

    return 0;
}