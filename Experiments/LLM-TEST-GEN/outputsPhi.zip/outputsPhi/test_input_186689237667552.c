
#include <stdio.h>

int main(int argc, char* argv[]) {
    int a = atoi(argv[1]);
    int b = atoi(argv[2]);
    printf("Sum of %d and %d is %d", a, b, (a+b));
    return 0;
}