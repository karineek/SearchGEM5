
#include <stdio.h>

int main(int argc, char **argv) {
    int i;
    char *buffer = "";
    for (i = 1; i < argc; i++) {
        strcat(buffer, "include \"");
        strcat(buffer, argv[i]);
        strcat(buffer, "\"");
    }
    printf("Input: %s\n", buffer);

    return 0;