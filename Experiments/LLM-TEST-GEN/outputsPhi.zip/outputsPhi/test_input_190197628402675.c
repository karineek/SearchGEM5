
#include <stdio.h>
int main(int argc, char** argv) {
    int num1 = atoi(argv[1]); // Read the first argument as an integer
    int num2 = atoi(argv[2]); // Read the second argument as an integer

    printf("%d + %d = %d\n", num1, num2, num1 + num2); // Prints "num1" and "num2" followed by their sum
    printf("%d - %d = %d\n", num1, num2, num1 - num2); // Prints "num1" and "num2" followed by their difference
    printf("%d * %d = %d\n", num1, num2, num1 * num2); // Prints "num1" and "num2" followed by their product
    printf("%d / %d = %d\n", num1, num2, num1 / num2); // Prints "num1" and "num2" followed by their quotient

    return 0;
}