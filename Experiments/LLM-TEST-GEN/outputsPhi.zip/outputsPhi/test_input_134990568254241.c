
#include <stdio.h>

int main(int argc, char* argv[]) {
  // Example of how argv works
  printf("%s\n", argv[0]); // Prints the name of the program
  printf("The first command-line argument is %d\n", atoi(argv[1]);
  return 0;
}