
#include <stdio.h>
int main(int argc, char* argv[]) {
    int a = atoi(argv[1]);
    int b = atoi(argv[2]);
    printf("Sum: %d\n", a + b);
    return 0;
}