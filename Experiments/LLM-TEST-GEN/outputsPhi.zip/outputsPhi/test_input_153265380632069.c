
#include <stdio.h>
int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s input_file\n", *argv);
        return 1;
    }

    FILE* f = fopen(argv[1], "r");
    if (!f) {
        perror("Error opening file");
        return 2;
    }

    int a, b;
    char c;
    while (EOF != (c = fgetc(f))) {
        if (isspace(c)) {
            putchar(' ');
        } else if (c == '\n') {
            printf("%d\n", a + b); // output the sum of the two numbers read so far
            a = 0;
            b = 0;
        } else {
            if (isdigit(c)) {
                a = a * 10 + c - '0'; // add the digit to a and shift it left by one place
            } else if (c == '+') {
                printf("%d\n", a + b); // output the sum of the two numbers read so far
                break; // terminate the loop when the operator is encountered
            }
        }
    }

    fclose(f);
    return 0;
}