
#include <stdio.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s input\n", *argv[0]);
        return 1;
    }

    int value = strtol(argv[1], NULL, 10);
    if (value < 0) {
        printf("Input must be a non-negative integer.\n");
        return 1;
    }

    printf("The input is: %d\n", value);

    return 0;
}