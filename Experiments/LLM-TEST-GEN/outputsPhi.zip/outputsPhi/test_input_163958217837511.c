
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {
    // check if enough arguments are passed
    if (argc == 1) {
        printf("Please provide at least one argument\n");
        return -1;
    }

    int n = atoi(argv[2]); // convert the third argument to an integer

    for (int i = 0; i < n; i++) {
        // loop unrolling: expand the loop into multiple iterations with fewer statements
        printf("%d\n", i);
        if (i % 3 == 0) {
            printf("This is a multiple of three!\n"); // check if i is divisible by 3
        } else {
            printf("This is not a multiple of three.\n"); // do nothing for non-multiples of 3
        }
    }

    return 0;
}