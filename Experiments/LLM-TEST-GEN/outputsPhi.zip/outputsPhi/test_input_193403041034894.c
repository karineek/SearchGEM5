
#include <stdio.h>
#include <math.h>

int main(int argc, char* argv[]) {
  // loop invariant code motion optimization
  if (argc != 3) {
    printf("Usage: %s input_file output_file\n", argv[0]);
    return 1;
  }

  double complex a, b;
  FILE* in = fopen(argv[1], "rb");
  if (in == NULL) {
    perror("Error opening input file");
    return 2;
  }

  fread(&a, sizeof(double), 1, in);
  fread(&b, sizeof(double), 1, in);

  // complex number operations
  double real = (double) a.real * b.real - (double) a.imag * b.imag;
  double imag = (double) a.real * b.imag + (double) a.imag * b.real;

  printf("%f + %fi\n", real, imag);

  // binary formats
  fclose(in);

  return 0;
}