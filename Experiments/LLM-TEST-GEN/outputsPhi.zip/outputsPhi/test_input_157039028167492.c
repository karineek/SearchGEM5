
#include <stdio.h>

int main(int argc, char *argv[]) {
  int num = atoi(argv[1]);
  int reversed_num = 0;

  while (num > 0) {
    reversed_num = (reversed_num * 10) + (num % 10);
    num /= 10;
  }

  printf("%d\n", reversed_num);

  return 0;
}