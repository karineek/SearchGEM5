
#include<stdio.h>
int main(int argc, char *argv[]) {
    int n;
    if (argc != 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    } else {
        n = atoi(argv[1]);
        if (n <= 0) {
            printf("Input must be a positive integer\n");
            return 2;
        } else {
            for (int i = 0; i < n; ++i) {
                printf("%d ", (i+1)*n);
            }
            printf("\n");
        }
    }
    return 0;
}