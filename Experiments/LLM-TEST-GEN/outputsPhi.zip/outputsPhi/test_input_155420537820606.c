
#include <iostream>
using namespace std;

int main() {
    string str = ""; // empty string to hold the user input

    if (argc != 2) {
        cout << "Usage: " << argv[0] << " <string>" << endl;
        return 1;
    }

    str = argv[1]; // assign the first argument to str variable

    int num_chars = str.length(); // get the length of the string

    long int num = 0; // initialize an empty integer to store the converted value

    for (int i = 0; i < num_chars; i++) {
        if (isdigit(str[i])) {
            long int temp = str[i];
            while (str[++i]) {
                if (!isdigit(str[i])) break; // skip any non-digit characters after the last digit in the string
                temp = (temp * 10) + str[i++];
            }
            num += temp; // add the converted digit to the integer value
        }
    }

    cout << "The long integer representation of '" << str << "' is: " << num << endl;

    return 0;
}