
#include <stdio.h>
int main(int argc, char *argv[]) {
    int x = 0;

    for (int i = 1; i < argc; i++) {
        // Parse the input to get a number
        x |= (unsigned int)argv[i] - '0';
    }

    // Print the sum of all the numbers in the input
    printf("The sum is %d\n", x);

    return 0;
}