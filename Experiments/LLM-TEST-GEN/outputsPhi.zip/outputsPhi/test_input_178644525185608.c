
#include <stdio.h>

int main(int argc, char* argv[]) {

    if (argc == 1) {
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }

    int num = atoi(argv[1]);
    unsigned char *ptr = (unsigned char*) &num;
    printf("%d: 0x%.2x\n", num, *ptr);
    ptr++;
    printf("%d: 0x%.4x\n", num, *ptr);
    ptr++;
    printf("%d: 0x%.8x\n", num, *ptr);

    return 0;
}