
#include <stdio.h>
#define ARG_COUNT 4 
int main(int argc, char **argv) {
  int result;

  // Read input arguments
  for (int i = 1; i < ARG_COUNT + 1; i++) {
    result += atoi(argv[i]);
  }

  // Print the sum of the input numbers
  printf("The sum is: %d\n", result);

  return 0;
}