
#include <stdio.h>

int main(int argc, char *argv[]) {
  int i;

  printf("Welcome to the C program!\n");

  for (i = 1; i < argc; i++) {
    printf("Argument %d: %s\n", i, argv[i]);
  }

  return 0;
}