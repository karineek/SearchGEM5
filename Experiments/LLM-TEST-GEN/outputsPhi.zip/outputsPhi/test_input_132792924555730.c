
#include <stdio.h>
#include <math.h>
int main(int argc, char* argv[]) {
    int x = atoi(argv[1]);
    float y;
    if (sscanf(argv[2], "%f", &y) != 1) {
        printf("Invalid input. Please enter a valid number.");
        return 1;
    }
    float result = atan2f(x, y);
    printf("The arctangent of %d is: %.2f\n", x, result);
    return 0;
}