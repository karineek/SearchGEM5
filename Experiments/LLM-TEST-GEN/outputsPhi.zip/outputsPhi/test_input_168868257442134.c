
#include <stdio.h>

int main(int argc, char **argv) {
    int i;
    for (i = 1; i <= 26; i++) {
        printf("Character %d: %c\n", i, toupper((char)argv[i]));
    }
    return 0;
}