
#include <stdio.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }

    FILE* fp = fopen(argv[1], "r");
    if (fp == NULL) {
        perror("Failed to open file");
        return 1;
    }

    int c;
    while ((c = fgetc(fp)) != EOF) {
        if (c == '\n') {
            printf("%d\n", c);
        } else {
            printf("%c", c);
        }
    }

    fclose(fp);
    return 0;
}