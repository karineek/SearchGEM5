
#include <stdio.h>

int main(int argc, char *argv[]) {

    // Check if there is only one argument
    if (argc == 1) {
        printf("Please provide an input argument\n");
        return -1;
    }

    // Process the command-line argument using string functions
    char *input_str = argv[1];
    char output_str[100];

    strcpy(output_str, "Processing input: %s", input_str);
    printf("Output: \n%s\n", output_str);

    return 0;
}