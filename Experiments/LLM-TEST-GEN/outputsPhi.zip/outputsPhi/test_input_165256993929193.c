
#include <stdio.h>

int main(int argc, char* argv[]) {
    // Check if the number of arguments is correct
    if (argc != 2) {
        printf("Usage: %s <integer-value>\n", argv[0]);
        return 1;
    }

    // Convert the string argument to an integer
    int value = atoi(argv[1]);

    // Perform sparse conditional constant propagation optimization
    if (value % 2 == 0) {
        printf("The value is even.\n");
    } else {
        printf("The value is odd.\n");
    }

    return 0;
}