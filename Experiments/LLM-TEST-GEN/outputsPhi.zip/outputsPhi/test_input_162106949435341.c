
#include <stdio.h>
int main(int argc, char *argv[]) {
    // code triggering Loop-Invariant Code Motion optimizatios
    int a = atoi(argv[1]);
    int b = atoi(argv[2]);
    if (a > b) {
        int temp = a;
        a = b;
        b = temp;
    }
    // code triggering Loop-Invariant Code Motion optimizatios

    printf("%d %d\n", a, b); // output
    return 0;
}