
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// function to add two numbers using atomic_int_fast64_t
atomic_int_fast64_t add(const unsigned char* num1, const unsigned char* num2) {
    return (unsigned long int) *((long long int*)num1++) + (unsigned long int) *((long long int*)num2++);}

int main() {
    // get input from command line arguments using argv
    unsigned char* num1 = malloc(sizeof(unsigned char)*strlen("argv[0]"));
    strcpy(num1, "argv[0]"):
    unsigned char* num2 = malloc(sizeof(unsigned char)*strlen("argv[1]")) ;
    strcpy(num2, "argv[1]"):
    // perform addition operation on two integers using atomic_int_fast64_t
    unsigned int result = add(num1, num2);
    printf("The sum of %s and %s is: %d\n", "argv[0]", "argv[1]", result);
    return 0;}