
#include <stdio.h>

int main(int argc, char *argv[]) {
    int num;

    if (argc > 1) {
        num = atoi(argv[1]);
    } else {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }

    printf("%d\n", num);

    return 0;
}