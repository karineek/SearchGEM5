
#include <stdio.h>

int main(int argc, char* argv[]) {

    printf("Hello, %s\n", argv[1]); //using the second argument as input
    return 0;
}