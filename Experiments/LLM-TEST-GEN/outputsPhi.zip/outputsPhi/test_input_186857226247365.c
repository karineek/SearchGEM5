
#include <stdio.h>
#define MAX_ARGc 10

int main(int argc, char** argv) {

    // Check if there are enough arguments provided
    if (argc < 2) {
        printf("Error: You must provide at least one argument.\n");
        return 1;
    }

    // Get the first argument as input value
    char* input_str = argv[1];

    // Check if the input is valid (i.e., contains only letters and spaces)
    for(int i=0; i<strlen(input_str); i++) {
        if (!isalpha(input_str[i]) && input_str[i] != ' ') {
            printf("Error: Invalid input. Please enter only letters and spaces.\n");
            return 1;
        }
    }

    // Output the input as a string
    printf("Input: %s\n", input_str);

    return 0;
}