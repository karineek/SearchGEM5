
#include <stdio.h>
#include <string.h>
#define MAX_LENGTH 100

int main(int argc, char *argv[]) {
  // Check if enough arguments were provided
  if (argc != 2) {
    printf("Please provide a filename as an argument.\n");
    return 1;
  }

  // Read the file and print its contents
  char input[MAX_LENGTH];
  FILE* file = fopen(argv[1], "r");
  if (file == NULL) {
    printf("Error: could not open %s.\n", argv[1]);
    return 2;
  }

  while (fgets(input, MAX_LENGTH, file)) {
    // Check for EOF and end of file
    if (feof(file)) {
      break;
    }

    // Print the line with all comments removed
    char* p = strchr(input, '\n');
    while (*p != '\0') {
      if (*p == '/' && *(++p) == '/') {
        continue;
      } else if (*p == '/' && *(++p) == '*') {
        p++;
        while (isspace(*p)) {
          p++;
        }
        // Skip over the rest of the comment
        do {
          *p = '\0';
        } while (*++p == '/');
        p--;
      } else if (*p == '#') {
        // Ignore comments until the end of the line
        while (isspace(*p)) {
          p++;
        }
        p--;
      } else if (*p == '\0') {
        break;
      }

      // Remove the comment and print the line
      input[strcspn(input, "\r\n")] = 0;
      puts(input);
    } else if (*p == '\0') {
      break;
    }

    // Skip any whitespace until the end of line
    while (isspace(*p)) {
      p++;
    }

    // Read the next character
    input[strcspn(input, "\r\n")] = 0;
  }

  fclose(file);
  return 0;
}