
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>

bool is_even(int number) {
  return number % 2 == 0;
}

void print_hello(char* name) {
  printf("Hello, %s!\n", name);
}

int main() {
  int i, n = 0;
  char* filename = argv[1];

  if (argc != 2) {
    printf("Usage: program <filename>\n");
    return 1;
  }

  for(i=2; i<=strlen(argv); i++) {
    char* str = malloc(sizeof(*str));
    if (str == NULL) {
      fprintf(stderr, "Out of memory\n");
      return 1;
    }

    snprintf(str, sizeof(str), "%s", argv[i]);
    n += strlen(str);
  }

  printf("Total size used: %d\n", n);

  free(filename);
}