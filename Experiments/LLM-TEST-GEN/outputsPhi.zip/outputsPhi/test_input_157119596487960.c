
#include <stdio.h>
#define N 10

int main(int argc, char **argv) {
    if (argc == 1) {
        printf("Please provide an argument\n");
        return 1;
    }
    char *str = malloc(N);
    strncpy(str, argv[1], N - 1);
    str[N-1] = '\0';
    printf("The input is: %s\n", str);
    free(str);
    return 0;
}