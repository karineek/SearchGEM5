
#include <stdio.h>
#include <stdbool.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s input_file\n", argv[0]);
        return 1;
    }

    FILE* fp = fopen(argv[1], "r");
    if (fp == NULL) {
        printf("Error: unable to open file %s.\n", argv[1]);
        return 1;
    }

    int line_count = 0, char_count = 0;
    fseek(fp, 0L, SEEK_END);
    long file_length = ftell(fp);
    fseek(fp, 0L, SEEK_SET);

    while (1) {
        char c = fgetc(fp);
        char_count++;
        if (feof(fp)) break; // End of file reached.

        if (c == '\n') {
            line_count++;
        }
    }

    fclose(fp);

    printf("Number of lines: %d\n", line_count);
    printf("Number of characters: %ld\n", char_count);

    return 0;
}