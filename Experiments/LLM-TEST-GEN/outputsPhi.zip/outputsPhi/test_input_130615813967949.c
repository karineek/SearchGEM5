
#include <stdio.h>
#include <math.h>
#include <string.h>

int main(int argc, char* argv[]) {
    int num = atoi(argv[1]); // convert input to integer using strtol
    if (num <= 1) {
        printf("%d is not a prime number.\n", num);
        return 1;
    }
    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0) {
            printf("%d is not a prime number.\n", num);
            return 1;
        }
    }
    int primes[100];
    for (int i = 2; i <= 100; i++) {
        if (is_prime(i)) {
            primes[primes_count] = i;
            primes_count++;
        }
    }
    for (int i = 0; i < primes_count - 1; i++) {
        for (int j = i + 1; j < primes_count; j++) {
            if (primes[i] + primes[j] == num) {
                printf("%d can be expressed as the sum of two prime numbers: %d and %d.\n", num, primes[i], primes[j]);
                return 0;
            }
        }
    }
    printf("%d cannot be expressed as the sum of two prime numbers.\n", num);
    return 1;
}

int is_prime(int n) {
    if (n <= 1) {
        return 0;
    } else {
        for (int i = 2; i * i <= n; i++) {
            if (n % i == 0) {
                return 0;
            }
        }
        return 1;
    }
}