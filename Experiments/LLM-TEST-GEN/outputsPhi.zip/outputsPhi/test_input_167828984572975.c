
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#define LINE_NUMBER 1

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <file>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    FILE *input_file = fopen(argv[1], "r");
    if (input_file == NULL) {
        perror("Error opening file: ");
        exit(EXIT_FAILURE);
    }

    char line[BUFFER_SIZE];
    while (fgets(line, BUFFER_SIZE, input_file) != NULL) {
        int num_lines = ftell(input_file) / sizeof(int);
        for (int i = 0; i < num_lines; i++) {
            printf("%d: %s\n", LINE_NUMBER, line);
            LINE_NUMBER++;
        }
    }

    fclose(input_file);

    return 0;
}