
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input_file>, where input_file is a file containing long integers separated by spaces\n", argv[0]);
        return 1;
    }

    FILE *fp = fopen(argv[1], "r");
    if (fp == NULL) {
        printf("Error: could not open input file %s\n", argv[1]);
        return 2;
    }

    long num = 0;
    char str[100];
    fscanf(fp, "%d", &num);

    for (int i = 1; i < argc && fscanf(fp, "%s", str) == 1; i++) {
        num = (num << 8) | ((long)atoi(str));
    }

    printf("The converted string is: %s\n", str);

    fclose(fp);

    return 0;
}