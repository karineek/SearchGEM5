
#include <stdio.h>
#include <stdlib.h>
#define MAX_ARGS 20
int main(int argc, char* argv[]) {

  int i;
  char line[MAX_ARGS];
  printf("Enter a string: ");

  for (i=1; i<argc && strlen(argv[i]) < MAX_ARGS; ++i) {
    sscanf(argv[i], "%s", line);
  }

  if (i == argc) {
    printf("Not enough arguments provided\n");
    exit(EXIT_FAILURE);
  }

  puts(line);
}