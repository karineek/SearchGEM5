
#include <stdio.h>
#include <stdlib.h>

int main() {
    int n; // read input from argv[1]
    printf("Enter a number: ");
    scanf("%d", &n);
    
    int i, sum = 0;
    for (i = 1; i <= n; i++) { // loop through numbers from 1 to n
        if (i % 3 == 0 || i % 5 == 0) { // check if number is divisible by 3 or 5
            sum += i; // add the number to the sum
        }
    }
    printf("The sum of all numbers from 1 to %d that are divisible by 3 or 5 is: %d\n", n, sum);
    return 0;
}