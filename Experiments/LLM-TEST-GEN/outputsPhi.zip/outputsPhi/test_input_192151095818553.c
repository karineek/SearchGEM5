
#include <stdio.h>

int main(int argc, char **argv) {

    // check if the argument count is correct
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }

    // read the file name from the command line argument
    FILE *fp = fopen(argv[1], "r");
    if (fp == NULL) {
        printf("Error: could not open file %s.\n", argv[1]);
        return 1;
    }

    // read the contents of the file and print them on the screen
    char line[100];
    while (fgets(line, sizeof(line), fp)) {
        printf("%s\n", line);
    }

    // close the file
    fclose(fp);

    return 0;
}