
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {

    if (argc != 2) {
        printf("Usage: %s <input-file>\n", argv[0]);
        return 1;
    }

    // Read input from file
    FILE *fp = fopen(argv[1], "r");
    if (fp == NULL) {
        perror("Error opening file.");
        return 1;
    }

    // Read input line by line
    char input[100];
    while (fgets(input, 100, fp)) {

        // Call acoshl function and print result
        float x = atof(input);
        printf("Input: %s\n", input);
        printf("Result: %f\n", acoshl(x));

    }

    fclose(fp);

    return 0;
}