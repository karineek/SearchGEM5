
#include <stdio.h>
int main(int argc, char* argv[]) {
    while (argv[1] != '\n') {
        printf("Enter a number: ");
        fgets(argv[2], 100, stdin);
        if (strcmp(argv[2], "\n") == 0) break;
        int x = atoi(argv[2]);
        printf("%d\n", x);
    }
    return 0;
}