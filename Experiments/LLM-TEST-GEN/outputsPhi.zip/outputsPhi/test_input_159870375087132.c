
#include <stdio.h>
int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }
    int number = atoi(argv[1]);
    if (number <= 0) {
        printf("Factorial of %d is not defined for negative numbers or zero.\n", number);
        return 1;
    }
    int fact = 1;
    while (number > 0) {
        fact *= number;
        number--;
    }
    printf("Factorial of %d is %d\n", argv[1], fact);
    return 0;
}