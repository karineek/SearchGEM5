
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {
    printf("Input the file path of the assembly file you want to parse: ");
    FILE* fp = fopen(argv[1], "r");
    if (fp == NULL) {
        printf("Error: could not open file.\n");
        return 1;
    }

    char line[100];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, "MOV")) { // look for move instructions
            printf("\nMove instruction detected.\n");
        } else if (strstr(line, "ADD")) { // look for add instructions
            printf("\nAddition instruction detected.\n");
        } else if (strstr(line, "SUB")) { // look for subtract instructions
            printf("\nSubtraction instruction detected.\n");
        } else if (strstr(line, "MUL") || strstr(line, "DIV")) { // look for multiplication/division instructions
            printf("\nMultiplication/Division instruction detected.\n");
        } else if (strstr(line, "AND") || strstr(line, "OR")) { // look for AND/OR instructions
            printf("\nAnd/Or instruction detected.\n");
        } else if (strstr(line, "NOT")) { // look for NOT instruction
            printf("\nNot instruction detected.\n");
        } else { // all other instructions are ignored
            continue;
        }

        if (strstr(line, "MOV") && strstr(argv[1], "0")) { // check for specific input file path
            printf("\nFile path: %s\n", argv[1]);
        }

        fclose(fp);
    }

    return 0;
}