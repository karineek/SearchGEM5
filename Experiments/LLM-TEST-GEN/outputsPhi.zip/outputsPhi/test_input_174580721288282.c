
#include <stdio.h>

int main(int argc, char* argv[]) {
  int num1 = atoi(argv[1]); // convert first argument to integer
  int num2 = atoi(argv[2]); // convert second argument to integer

  if (num1 > 0 && num2 > 0) { // check if both numbers are positive
    printf("%d * %d = %d\n", num1, num2, num1 * num2);
  } else if (num1 < 0 || num2 < 0) { // check if either number is negative
    printf("Invalid input. Both numbers must be positive.\n");
  } else { // both numbers are zero or both are non-positive
    printf("Both numbers cannot be zero.\n");
  }

  return 0;
}