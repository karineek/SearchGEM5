
#include <stdio.h>
int main(int argc, char* argv[]) {
  int x = atoi(argv[1]);
  int y = atoi(argv[2]);
  
  printf("The sum of %d and %d is: %d\n", x, y, x+y);
  return 0;
}