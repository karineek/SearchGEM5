
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <sys/time.h>

int main(int argc, char *argv[]) {

    // Check if input has enough arguments
    if (argc != 2) {
        printf("Usage: %s <file_name>.\n", argv[0]);
        return 1;
    }

    // Read file and store its contents in a string variable
    char *filename = argv[1];
    FILE *fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("Error: can't open %s.\n", filename);
        return 2;
    }

    char str[100];
    fgets(str, sizeof(str), stdin); // Read one line of input from standard input
    fclose(fp);

    // Check if the string is empty or contains only whitespace characters
    if (str[0] == '\0' || ispace(str[0]) && strcmp(str, "") == 0) {
        printf("Input is empty or contains only whitespace. Please enter valid input.\n");
        return 3;
    }

    // Return the length of the string
    int len = strlen(str);

    // Close program if there are any errors
    return 0;
}