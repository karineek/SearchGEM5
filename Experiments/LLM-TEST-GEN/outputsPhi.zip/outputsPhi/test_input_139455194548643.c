
#include <stdio.h>

int main(int argc, char* argv[]) {

    int i = 0; // Loop counter
    double x = 0.0; // Initialize variables with default value
    double y = 0.0;
    double z = 0.0;

    while (i < argc) { // Loop through command line arguments until end of input
        if (argv[i] == "--x") { // If argument is x, set x to 1
            i++;
            x = 1.0;
        } else if (argv[i] == "--y") { // If argument is y, set y to 2
            i++;
            y = 2.0;
        } else if (argv[i] == "--z") { // If argument is z, set z to 3
            i++;
            z = 3.0;
        } else if (argv[i][0] == '-') { // If argument starts with -, it's a switch case
            char ch = argv[i++][0]; // Get first character of argument
            switch (ch) { // Switch on the first character of argument
                case 'x':
                    x = 1.0;
                    break;
                case 'y':
                    y = 2.0;
                    break;
                case 'z':
                    z = 3.0;
                    break;
                default:
                    printf("Invalid argument.\n"); // If invalid argument, print error message
                    break;
            }
        } else { // Otherwise, it's a normal input value
            fprintf(stdout, "%d %.2f %.2f\n", i - 1, x, y); // Print out the argument values
        }
    }

    return 0;
}