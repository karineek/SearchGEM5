
#include <stdio.h>

int main(int argc, char** argv) {

    int octal_num;
    char *octal = argv[1];

    // Convert octal to decimal
    octal_num = 0;
    for (int i = 1; i <= strlen(octal); i++) {
        octal_num = octal_num * 8 + (atoi(&octal[i-1]) - '0');
    }

    // Print the decimal number
    printf("The octal number %s is equivalent to decimal %d.\n", argv[1], octal_num);

    return 0;
}