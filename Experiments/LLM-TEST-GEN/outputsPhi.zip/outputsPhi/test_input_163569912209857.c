
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {
    double num;
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }
    num = atof(argv[1]);
    double sqrt_num = sqrtf(num);
    printf("The square root of %.2f is: %.4g\n", num, sqrt_num);
    return 0;
}