
#include <stdio.h>

int main(int argc, char* argv[]) {
    // Check the number of arguments provided
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }

    // Open the file and read its contents
    FILE* fp = fopen(argv[1], "r");
    if (fp == NULL) {
        printf("Error: could not open file %s\n", argv[1]);
        return 1;
    }

    // Read the contents of the file and close it
    char* text = fgets(argv[1], 100, fp);
    if (text == NULL) {
        printf("Error: file contains no data\n");
        return 1;
    }

    // Close the file
    fclose(fp);

    // Print the contents of the file
    printf("File Contents:\n%s", text);

    // Return 0 to indicate success
    return 0;
}