
#include <stdio.h>

int main(int argc, char *argv[]) {
  int i;

  printf("Arguments: ");

  // Loop through each argument using `i`
  for (i = 1; i <= argc; i++) {
    printf("%s ", argv[i]);
  }

  return 0;
}