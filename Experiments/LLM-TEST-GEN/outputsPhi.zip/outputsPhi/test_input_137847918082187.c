
#include <stdio.h>

int main(int argc, char *argv[]) {
    // Check if enough arguments were provided
    if (argc != 2) {
        printf("Usage: %s argument1\n", argv[0]);
        return 1;
    }

    // Read the input value from the command line
    int x = atoi(argv[1]);

    // Perform some calculations using the input value
    int y = 2 * x + 3;

    // Print the result
    printf("Result: %d\n", y);

    return 0;
}