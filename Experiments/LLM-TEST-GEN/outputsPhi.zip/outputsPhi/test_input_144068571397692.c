
#include <stdio.h>
int main(int argc, char* argv[]) {
    printf("Input: ");
    char input[100];
    fgets(input, 100, stdin);

    // remove trailing newline character
    input[strlen(input) - 1] = '\0';

    // check if argument is provided and read it in if so
    for (int i=1; i<argc; i++) {
        if (!strcmp(argv[i], "-h")) break;
        char input2[100];
        fgets(input2, 100, stdin);

        // remove trailing newline character
        input2[strlen(input2) - 1] = '\0';
        printf("Input 2: %s\n", input2);
    }

    return 0;
}