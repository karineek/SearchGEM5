
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#define MAX_WORD_LEN 50
int main(int argc, char** argv) {

    //Check if any arguments have been provided and extract them as strings
    if (argc > 1 && strlen(argv[1]) == MAX_WORD_LEN) {
        char* word = argv[1];
        int count = 0; //to keep track of how many characters in the string
        while (*word != '\0' && *word >= 'A' && *word <= 'Z')
            ++count, ++word;
        printf("Word: %s has %d characters.\n", argv[1], count);
    } else {
        //No arguments provided, just print a message saying so
        printf("You did not provide any arguments!\n");
    }

    return 0;
}