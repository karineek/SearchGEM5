
#include <stdio.h>
#define MAX_INPUT 100

int main(int argc, char* argv[]) {

  //initialize variables
  int num1 = 0;
  int num2 = 0;
  bool isGreater = false;

  //read input from user
  for (int i = 1; i < argc && strlen(argv[i]) > 0; i++) {
    if (strcmp(argv[i], "quit") == 0) {
      break;
    }

    //check input type and assign value
    switch (strlen(argv[i]) > 1) {
      case 2:
        num1 = atoi(argv[i++]);
        num2 = atoi(argv[i++]);
        isGreater = (num1 > num2);
      case 1:
        num1 = atoi(argv[i]) + 1;
        break;
    }

    //perform vectorization if applicable
    switch (strlen(argv[i])) {
      case 2:
        num1 = atoi(argv[i++]) * 2;
        num2 = atoi(argv[i++]) + 1;
        isGreater = (num1 > num2);
      case 1:
        num1 = atoi(argv[i]) * 2;
        break;
    }

    //output result to console
    if (isGreater) {
      printf("%d is greater than %d\n", num1, num2);
    } else {
      printf("%d is less than or equal to %d\n", num1, num2);
    }

    //check for quit command and exit program
    if (strcmp(argv[i], "quit") == 0) {
      break;
    }

  }

  return 0;
}