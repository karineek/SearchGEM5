
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int n;
    char input_str[256];

    printf("Enter a number: ");
    scanf("%s", input_str); // Input is taken via argv only.
    n = strlen(input_str);

    int *arr = malloc(n * sizeof(int)); // Dynamic memory allocation for input values

    printf("Input: ");
    fgets(input_str, 256, stdin); // Example of input (BASH)

    for (int i = 0; i < n; i++) {
        if (argv[1][i] == ',' && argv[1][i+1] >= '0' && argv[1][i+1] <= '9') { // Parsing input values from command line arguments
            arr[i] = atoi(argv[1]);
        } else if (input_str[i] == ',' && input_str[i+1] >= '0' && input_str[i+1] <= '9') { // Parsing input values from command line arguments
            arr[i] = atoi(input_str);
        } else if (input_str[i] == ',' && argv[1][i+1] >= '0' && argv[1][i+1] <= '9') { // Parsing input values from command line arguments
            arr[i] = atoi(argv[1]);
        } else if (input_str[i] == ',' && input_str[i+1] >= '0' && input_str[i+1] <= '9') { // Parsing input values from command line arguments
            arr[i] = atoi(input_str);
        } else {
            printf("Invalid input.\n");
            return 1;
        }
    }

    for (int i = 0; i < n; i++) {
        if (arr[i] > 100) {
            printf("%d is greater than 100.\n", arr[i]);
        } else if (arr[i] < 50) {
            printf("%d is less than 50.\n", arr[i]);
        } else {
            printf("%d is between 50 and 100 (inclusive).\n", arr[i]);
        }
    }

    return 0;
}