
#include <stdio.h>
int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s x y\n", argv[0]);
        return 1;
    }
    int a = atoi(argv[1]), b = atoi(argv[2]);
    if (a < 0 || b < 0) {
        printf("Input values should be non-negative integers.\n");
        return 1;
    }
    int result = a & b;
    printf("The bitwise AND of %d and %d is %d\n", a, b, result);
    return 0;
}