
#include <stdio.h>
#include <string.h>
#include <time.h>

int main(int argc, char* argv[]) {
    // Check if enough arguments have been passed in
    if (argc < 2) {
        printf("Usage: %s <date_format>\n", argv[0]);
        return 1;
    }

    // Get the current date using strptime
    struct tm *local = {0};
    local->tm_year = time(NULL);
    local->tm_mon = 1;
    local->tm_mday = 1;
    local->tm_hour = 0;
    local->tm_min = 0;
    local->tm_sec = 0;

    // Parse the date string using strptime and set the format based on argv[1]
    char date_format[] = "%d %B %Y";
    local = strptime(argv[2], date_format);

    // Print out the current date in a human-readable format
    printf("Today is %s.\n", asctime(&local));

    return 0;
}