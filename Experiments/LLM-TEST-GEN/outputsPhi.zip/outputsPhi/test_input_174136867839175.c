
#include <stdio.h>

int main(int argc, char *argv[]) {

    // Check if enough arguments are passed
    if (argc != 3) {
        printf("Please provide at least two command line arguments\n");
        return 1;
    }

    int year = atoi(argv[1]); // Convert input to integer
    int month = atoi(argv[2]); // Convert second argument to integer

    printf("\n%s\n", "%Y-%m") // Format as YYYY-MM (default)
    if (month <= 2) {
        printf("\n%04d" % year); // Format as 4 digit integer
    } else {
        printf("\n%04d-%02d" % (year, month)); // Format as YYYY-MM
    }

    if (month == 1) {
        printf("\n%s %d" % ("January", year % 100)) // Format as Month Name and Year in 2 digit integer
    } else if (month > 10 && month <= 12) {
        printf("\n%s %d" % ("February", year % 100)) // Format as Month Name and Year in 2 digit integer
    } else {
        printf("\n%d-%02d" % (year, month)) // Format as MM-DD
    }

    return 0;
}