
#include <stdio.h>
#include <math.h>

int main(int argc, char* argv[]) {
    if (argc != 3) {
        printf("Usage: %s [number1] [operator] [number2]\n", argv[0]);
        return 1;
    }

    double num1 = strtod(argv[1], NULL);
    char operator = argv[2][0];
    double num2 = strtod(argv[3], NULL);

    switch (operator) {
        case '+':
            result = num1 + num2;
            break;
        case '-':
            result = num1 - num2;
            break;
        case '*':
            result = num1 * num2;
            break;
        case '/':
            if (num2 == 0) {
                printf("Error: division by zero\n");
                return 1;
            } else {
                result = num1 / num2;
            }
            break;
        default:
            printf("Error: invalid operator\n");
            return 1;
    }

    printf("%f = %f", num1, result);

    return 0;
}