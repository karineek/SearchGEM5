
#include <stdio.h>

int main(int argc, char* argv[]) {
    // Check if enough arguments have been passed
    if (argc != 2) {
        printf("Usage: program input_file\n");
        return 1;
    }

    // Open the input file and read its contents
    FILE* fp = fopen(argv[1], "r");
    if (fp == NULL) {
        printf("Error: could not open file.\n");
        return 2;
    }

    // Read the input from the file and store it in a buffer
    char buffer[1024];
    fread(buffer, sizeof(char), 1024, fp);

    // Close the input file
    fclose(fp);

    // Print the contents of the buffer to the console
    printf("Input: %s\n", buffer);

    return 0;
}