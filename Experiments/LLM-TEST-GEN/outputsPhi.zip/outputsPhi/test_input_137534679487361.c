
#include <stdio.h>

int main(int argc, char* argv[]) {
    double num1 = strtod(argv[1], NULL); // Convert argument to a floating-point number
    double num2 = strtod(argv[2], NULL);

    // Perform some calculations
    double result = (num1 + num2) / 2;

    // Print out the result
    printf("The result is: %.2f\n", result);

    return 0;
}