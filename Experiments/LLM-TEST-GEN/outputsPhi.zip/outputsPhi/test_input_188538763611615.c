
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {
    // Check if enough arguments are provided
    if (argc != 3) {
        printf("Error: please provide two file names as command line arguments.\n");
        return 1;
    }

    // Open the first file and read its contents
    FILE *file1 = fopen(argv[1], "r");
    if (file1 == NULL) {
        printf("Error: could not open file %s.\n", argv[1]);
        return 1;
    }

    // Open the second file and read its contents
    FILE *file2 = fopen(argv[2], "r");
    if (file2 == NULL) {
        printf("Error: could not open file %s.\n", argv[2]);
        return 1;
    }

    // Read the contents of both files into memory
    char *file1_contents = malloc(sizeof(char) * 1024);
    if (file1_contents == NULL) {
        printf("Error: could not allocate memory for file 1.\n");
        return 1;
    }

    char *file2_contents = malloc(sizeof(char) * 1024);
    if (file2_contents == NULL) {
        printf("Error: could not allocate memory for file 2.\n");
        return 1;
    }

    fread(file1_contents, 1024, 1, file1);
    fread(file2_contents, 1024, 1, file2);

    // Compare the contents of both files and output any differences
    if (strcmp(file1_contents, file2_contents) != 0) {
        printf("File 1: %s\n", argv[1]);
        printf("File 2: %s\n", argv[2]);
        printf("Contents of both files are different.\n");
    } else {
        printf("Files are the same.\n");
    }

    // Free the memory allocated for the contents of both files
    free(file1_contents);
    free(file2_contents);

    return 0;
}