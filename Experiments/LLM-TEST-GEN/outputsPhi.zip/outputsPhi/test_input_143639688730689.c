
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {
    double radius;

    if (argc != 2) {
        printf("Usage: %s r\n", argv[0]);
        return 1;
    }

    // Check if the input is a valid number
    double num = strtod(argv[1], NULL);
    if (num == 0) {
        printf("Invalid input. Please enter a non-zero number.");
        return 1;
    }

    // Calculate the area of the circle
    double area = M_PI * pow(num, 2);

    // Display the result
    printf("The area of the circle with radius %.2f is %.3lf\n", num, area);

    return 0;
}