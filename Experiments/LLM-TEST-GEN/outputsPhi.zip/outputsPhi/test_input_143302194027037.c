
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {

    // Check if the input is valid (two or more arguments)
    if (argc < 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }

    // Get the name of the file from the first argument
    char *file_name = strdup(argv[1]);

    // Check if the file exists and is readable
    FILE* fp = fopen(file_name, "r");
    if (fp == NULL) {
        perror("Failed to open file");
        return 1;
    }

    // Read the contents of the file and print them
    char line[100];
    while (fgets(line, sizeof(line), fp)) {
        printf("%s\n", line);
    }

    // Close the file
    fclose(fp);

    return 0;
}