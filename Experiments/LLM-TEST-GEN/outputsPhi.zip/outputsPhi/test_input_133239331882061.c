
#include <stdio.h>

int main(int argc, char* argv[]) {
  int i;
  for (i = 1; i <= 5; i++) {
    printf("%d\n", atoi(argv[i]);
  }

  return 0;
}