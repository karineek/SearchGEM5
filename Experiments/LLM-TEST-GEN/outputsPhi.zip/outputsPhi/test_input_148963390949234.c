
#include <stdio.h>

int main(int argc, char **argv) {
    int i;
    if (argc == 1) {
        printf("Please provide input using the following format: 'program_name number'\n");
        return -1;
    }
    for (i = 2; i < argc; i++) {
        char *input = argv[i];
        int input_num = strtol(input, NULL, 10);
        printf("%s: %d\n", input, input_num);
    }
    return 0;
}