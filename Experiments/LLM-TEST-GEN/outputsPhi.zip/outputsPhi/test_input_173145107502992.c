
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    int i;
    if (argc != 2) {
        printf("Usage: %s <file_name>\n", argv[0]);
        return 1;
    }

    FILE *input_file = fopen(argv[1], "r");
    if (input_file == NULL) {
        printf("Error opening input file: %s\n", argv[1]);
        return 2;
    }

    char line[1024];
    while (fgets(line, sizeof(line), input_file)) {
        printf("%s\n", line);
    }

    fclose(input_file);

    return 0;
}