
#include <stdio.h>
int main(int argc, char *argv[]){

    for (i=1; i<argc; i++){
        printf("Argument %d is '%s'\n", i, argv[i]);
    }

    return 0;