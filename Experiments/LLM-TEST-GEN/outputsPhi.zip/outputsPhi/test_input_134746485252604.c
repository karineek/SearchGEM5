
#include <stdio.h>
#define ARG_COUNT 2

int main(int argc, char *argv[]) {

    // Check if correct number of arguments is provided
    if (argc != ARG_COUNT + 1) {
        printf("Usage: %s x y\n", argv[0]);
        return 1;
    }

    // Convert input arguments to integers
    int x = atoi(argv[1]);
    int y = atoi(argv[2]);

    // Perform some operations on the inputs
    float result_1 = sin(x) + cos(y);
    int result_2 = (int)fmod(x, 10);
    char result_3 = argv[3][0];

    // Print out the results
    printf("sin(%d) + cos(%d) = %f\n", x, y, result_1);
    printf("Remainder of x divided by 10 is %d\n", x, result_2);
    printf("The first character of the fourth argument is %c\n", result_3);

    return 0;
}