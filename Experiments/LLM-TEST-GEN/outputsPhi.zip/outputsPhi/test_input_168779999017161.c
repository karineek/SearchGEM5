
#include <stdio.h>
int main(int argc, char **argv) {

   // Check if enough arguments were passed to the program
   if (argc < 2) {
      fprintf(stderr, "Usage: %s input_file\n", argv[0]);
      return 1;
   }

   // Read the input file and print its contents to standard output
   char *input_file = argv[1];
   FILE *fp = fopen(input_file, "r");
   if (fp == NULL) {
      fprintf(stderr, "Error: could not open input file.\n");
      return 1;
   }

   while (fgets(line, sizeof line, fp)) {
      // Remove trailing newline character from the end of each line
      line[strcspn(line, "\n")] = '\0';

      // Print the contents of the file to standard output
      printf("%s", line);
   }

   fclose(fp);

   return 0;
}