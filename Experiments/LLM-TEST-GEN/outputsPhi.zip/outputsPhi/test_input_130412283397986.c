
#include <stdio.h>
int main(int argc, char* argv[]) {
    int len = 0; // variable to hold the length of the input string
    for (int i = 1; i <= argc; i++) { // loop through command line arguments
        if (*argv[i]) { // check if the character is not a null terminator
            len++; // increment length by one for each non-null character
        }
    }
    printf("Length of input string: %d\n", len); // output the length
    return 0;
}