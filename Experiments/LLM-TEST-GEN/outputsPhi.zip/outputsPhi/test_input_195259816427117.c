
#include <stdio.h>

int main(int argc, char *argv[]) {
    // Check if there are enough arguments passed to the script
    if (argc != 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    // Open the input file
    FILE *fp = fopen(argv[1], "r");

    // Read the contents of the file and print them to the console
    char line[100];
    while (fgets(line, sizeof(line), fp)) {
        printf("%s\n", line);
    }

    // Close the input file
    fclose(fp);

    return 0;
}