
#include <stdio.h>
int main(int argc, char *argv[]) {
    if (argc == 2) { // check for correct number of arguments
        printf("Hello, %s\n", argv[1]); // print user input with their name
    } else {
        printf("Usage: ./program <name>\n"); // display usage message if incorrect number of arguments
    }
    return 0;
}