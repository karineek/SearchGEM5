
#include <stdio.h>
#include <math.h>

int main(int argc, char* argv[]) {
    double x = atan2f(atoi(argv[1]), atoi(argv[2]));
    printf("The tangent of %lf is %g\n", atan2f(atoi(argv[1]), atoi(argv[2])), x);
    return 0;
}