
#include <stdio.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <input-string>\n", argv[0]);
        return 1;
    }

    char input_str[100];
    strncpy(input_str, argv[1], sizeof(input_str));
    printf("Input: %s\n", input_str);

    return 0;
}