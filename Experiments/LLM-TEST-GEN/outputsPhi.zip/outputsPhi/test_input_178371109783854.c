
#include <stdio.h>

int main(int argc, char* argv[]) {
    int num;
    if (argc > 1) {
        num = atoi(argv[1]);
    } else {
        printf("Please enter an integer as input.\n");
        return 1;
    }
    printf("Input: %d\n", num);
    return 0;
}