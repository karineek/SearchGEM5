
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    int i = atoi(argv[1]);
    printf("%d\n", i);

    // Memory-to-register promotion
    i = (i + 1) << 4;
    printf("%d\n", i);
    return 0;
}