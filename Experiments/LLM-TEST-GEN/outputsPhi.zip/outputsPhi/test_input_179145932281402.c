
#include <stdio.h>

int main(int argc, char** argv) {

    // check if the correct number of arguments are provided
    if (argc != 3) {
        printf("Usage: %s matrix1 matrix2\n", argv[0]);
        return 1;
    }

    // read the first matrix from command-line arguments
    int m_rows = atoi(argv[1]);
    char** mat1 = malloc(m_rows * sizeof(char*));
    for (int i = 0; i < m_rows; i++) {
        mat1[i] = malloc(m_rows * sizeof(char));
    }

    for (int i = 0; i < m_rows; i++) {
        for (int j = 0; j < m_rows; j++) {
            mat1[i][j] = argv[2][(i * m_rows + j)];
        }
    }

    // read the second matrix from command-line arguments
    int n_rows = atoi(argv[2]);
    char** mat2 = malloc(n_rows * sizeof(char*));
    for (int i = 0; i < n_rows; i++) {
        mat2[i] = malloc(m_rows * sizeof(char));
    }

    for (int i = 0; i < n_rows; i++) {
        for (int j = 0; j < m_rows; j++) {
            mat2[i][j] = argv[3][(i * m_rows + j)];
        }
    }

    // calculate the transpose of both matrices
    char** mat1_t = malloc(m_rows * sizeof(char*));
    for (int i = 0; i < m_rows; i++) {
        mat1_t[i] = malloc(m_rows * sizeof(char));
    }

    for (int i = 0; i < m_rows; i++) {
        for (int j = 0; j < n_rows; j++) {
            mat1_t[j][i] = mat2[i][j];
        }
    }

    char** mat2_t = malloc(n_rows * sizeof(char*));
    for (int i = 0; i < n_rows; i++) {
        mat2_t[i] = malloc(m_rows * sizeof(char));
    }

    for (int i = 0; i < m_rows; i++) {
        for (int j = 0; j < n_rows; j++) {
            mat2_t[j][i] = mat1[i][j];
        }
    }

    // print the transpose of both matrices
    for (int i = 0; i < m_rows; i++) {
        printf("Transpose of matrix 1:\n");
        for (int j = 0; j < n_rows; j++) {
            if (j == m_rows - 1) {
                printf("%s\n", mat1[i]);
            } else {
                printf(" %c ", mat1[i][j]);
            }
        }
        printf("\n");

        if (i == n_rows - 1) {
            printf("Transpose of matrix 2:\n");
            for (int j = 0; j < m_rows; j++) {
                if (j == n_rows - 1) {
                    printf("%s\n", mat2[i]);
                } else {
                    printf(" %c ", mat2[i][j]);
                }
            }
            printf("\n");
        } else {
            if (j == n_rows - 1) {
                printf("%s\n", mat2[i]);
            } else {
                printf(" %c ", mat2[i][j]);
            }
        }
    }

    // free the allocated memory
    for (int i = 0; i < m_rows; i++) {
        free(mat1[i]);
    }
    for (int i = 0; i < n_rows; i++) {
        free(mat2[i]);
    }

    free(mat1);
    free(mat2);

    return 0;
}