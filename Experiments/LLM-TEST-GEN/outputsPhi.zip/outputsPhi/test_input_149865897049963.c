
#include <stdio.h>

int main() {
    int bin_num;
    int oct_num;
    char *bin_input;
    char *oct_input;

    // Get binary and octal input from command line arguments
    bin_input = argv[1];
    oct_input = argv[2];

    // Check if the inputs are valid binary and octal numbers
    if (bin_input == NULL || oct_input == NULL) {
        printf("Error: Invalid input. Please provide two arguments as a binary number followed by an octal number on separate lines.");
        return 1;
    }

    // Convert the inputs to decimal format
    bin_num = strtol(bin_input, NULL, 2);
    oct_num = atoi(oct_input);

    // Add the two numbers together
    int sum = bin_num + oct_num;

    // Output the result
    printf("%d + %d = %d\n", bin_num, oct_num, sum);

    return 0;
}