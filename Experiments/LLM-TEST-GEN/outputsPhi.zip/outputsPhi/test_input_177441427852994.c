
#include <stdio.h>
#define SIZE 10
int main(int argc, char *argv[]) {
    int i;
    for (i = 1; i <= SIZE && i < argc; ++i) {
        printf("Argument %d: %s\n", i, argv[i]);
    }
    return 0;
}