
#include <stdio.h>

int main(int argc, char* argv[]) {
    int dec_num;

    // Check if valid input is provided
    if (argc != 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }

    dec_num = atoi(argv[1]);

    // Convert decimal to binary using shifting and addition
    int pow = 0, res = 0;
    while (dec_num) {
        res += (dec_num % 2) * (int)pow(10, pow);
        dec_num /= 2;
        pow++;
    }

    // Print the binary representation of the input
    printf("%d in binary is: %d\n", atoi(argv[1]), res);

    return 0;
}