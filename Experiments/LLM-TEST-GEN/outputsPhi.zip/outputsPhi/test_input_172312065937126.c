
#include <stdio.h>
int main(int argc, char *argv[]) {
  int num = atoi(argv[1]); // convert the first argument (which is expected to be an integer) to an integer value

  printf("Input: %d\n", num); // print the input to the console

  return 0;
}