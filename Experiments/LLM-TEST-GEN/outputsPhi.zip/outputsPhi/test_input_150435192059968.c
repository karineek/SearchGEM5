
#include <stdio.h>
int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }
    char* input_str = argv[1];
    int i = 0;
    while (i < strlen(input_str) && input_str[i] == '\n') {
        ++i;
    }
    if (i >= strlen(input_str)) {
        printf("Error: Empty file.\n");
        return 1;
    }
    char output_str[strlen(input_str) + 1];
    strcpy(output_str, input_str);
    printf("%s", output_str);
    return 0;
}