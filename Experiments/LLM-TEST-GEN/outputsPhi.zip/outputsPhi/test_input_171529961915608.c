
#include <stdio.h>

int main() {
    int i = 0;

    for (i = 0; i < argc; i++) {
        printf("argv[%d] is %s\n", i, argv[i]);
    }

    printf("\n");

    for (int j = 0; j < argc; j++) {
        if (strcmp(argv[j], "hello") == 0) {
            i = strlen(argv[j]) + 1;
        }

        printf("argv[%d] is now %s\n", j, argv[j]);
    }

    return 0;
}