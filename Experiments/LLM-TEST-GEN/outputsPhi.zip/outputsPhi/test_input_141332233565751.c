
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {

    // Check if enough arguments were passed
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }

    // Open the file specified by the user and read its contents
    FILE *fp = fopen(argv[1], "r");
    if (!fp) {
        perror("Error opening file.");
        return 1;
    }

    // Read each line of the file and print it to standard output
    int c;
    while ((c = fgetc(fp)) != EOF) {
        printf("%c\n", c);
    }

    // Close the file
    fclose(fp);

    return 0;
}