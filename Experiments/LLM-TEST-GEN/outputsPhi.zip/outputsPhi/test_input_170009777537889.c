
#include <stdio.h>
int main(int argc, char *argv[]) {
  int num1, num2;

  // Parse command line arguments for two inputs
  num1 = atoi(argv[1]);
  num2 = atoi(argv[2]);

  // Add the numbers and print the result
  printf("The sum is %d\n", num1 + num2);

  return 0;
}