
#include <stdio.h>
int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    char *filename = argv[1];

    FILE* fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("Error opening file: %s\n", filename);
        return 1;
    }

    int i, x = 0, y = 0;
    for (i = 0; fscanf(fp, "%d%*c") == 1; ++i) {
        x |= (1 << i);
    }

    fclose(fp);

    printf("x: %u\n", x);

    return 0;
}