
#include <stdio.h>
#define MAX_ARGUMENTS 10
int main(int argc, char *argv[]) {
    if (argc > MAX_ARGUMENTS) {
        printf("Error: Too many arguments entered.\n");
        return 1;
    }
    // code to parse and execute input here
    int i = 0;
    for (i = 1; i < argc; i++) {
        printf("Argument %d: %s\n", i, argv[i]);
    }
    return 0;
}