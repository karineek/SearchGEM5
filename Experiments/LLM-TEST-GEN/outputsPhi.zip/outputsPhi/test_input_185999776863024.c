
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s integer\n", argv[0]);
        return 1;
    }

    unsigned int n = atoi(argv[1]);
    int factorial = 1;

    for (int i = 2; i <= n; ++i) {
        factorial *= i;
    }

    printf("Factorial of %d is: %u\n", n, factorial);

    return 0;
}