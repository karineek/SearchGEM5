
#include <stdio.h>
int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }

    FILE* file = fopen(argv[1], "r");
    if (file == NULL) {
        printf("Error opening file: %s\n", argv[1]);
        return 1;
    }

    char line[BUFSIZ];
    int length = 0;

    while (fgets(line, BUFSIZ, file)) {
        for (int i = 0; line[i] != '\0'; i++) {
            if (line[i] == '\n') {
                length++;
            }
        }
    }

    fclose(file);

    printf("The file %s contains %d characters\n", argv[1], length);
    return 0;
}