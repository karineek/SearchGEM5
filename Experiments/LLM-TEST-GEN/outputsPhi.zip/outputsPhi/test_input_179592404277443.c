
#include <stdio.h>

int main(int argc, char *argv[]) {
    // Check if enough arguments were passed in
    if (argc != 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    // Open the input file
    FILE *input = fopen(argv[1], "r");

    // Read in the input from the file
    char line[100];
    while (fgets(line, sizeof(line), input)) {
        // Print out each line of the file
        printf("%s\n", line);
    }

    // Close the input file
    fclose(input);

    return 0;
}