
#include <stdio.h>
int main(int argc, char *argv[]) {
    printf("Enter some text: ");
    fgets(argv[1], 100, stdin);
    printf("You entered: %s\n", argv[1]);
    return 0;
}