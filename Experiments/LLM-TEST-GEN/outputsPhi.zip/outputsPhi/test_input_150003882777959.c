
#include <stdio.h>

int main(int argc, char* argv[]) {
  // Check if enough arguments were provided
  if (argc != 2) {
    printf("Usage: %s filename\n", argv[0]);
    return 1;
  }

  // Get the name of the file from the command line argument
  char* filename = argv[1];

  // Open the file for reading
  FILE* fp = fopen(filename, "r");

  // Read each line of the file and store it in an array
  int lines[MAX_LINES] = {0};
  size_t i = 0;
  char line[MAX_LINE_LENGTH];
  while (fgets(line, sizeof(line), fp)) {
    if (i >= MAX_LINES) {
      break; // If the array is full, exit the loop
    }
    lines[i] = line;
    i++;
  }

  // Close the file
  fclose(fp);

  // Print the contents of the file to the console
  printf("Contents of %s:\n", filename);
  for (size_t j = 0; j < i; j++) {
    printf("Line %zu: %s\n", j + 1, lines[j]);
  }

  return 0;
}