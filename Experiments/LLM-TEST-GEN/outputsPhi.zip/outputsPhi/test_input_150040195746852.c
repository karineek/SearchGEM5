
#include <stdio.h>
int main(int argc, char *argv[]) {
    int num;
    if (argc == 2) {
        num = atoi(argv[1]);
    } else {
        printf("Please provide an argument for input.\n");
        return 1;
    }
    printf("Input: %d\n", num);
    return 0;
}