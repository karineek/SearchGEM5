
#include <stdio.h>

int main(int argc, char *argv[]) {
  int n;

  if (argc != 2) {
    printf("Usage: %s integer\n", argv[0]);
    return 1;
  }

  n = atoi(argv[1]);
  printf("%x\n", n);

  return 0;
}