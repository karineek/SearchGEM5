
#include <stdio.h>
int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s integer\n", argv[0]);
        return 1;
    }
    int num = atoi(argv[1]);
    printf("The input is: %d\n", num);
    return 0;
}