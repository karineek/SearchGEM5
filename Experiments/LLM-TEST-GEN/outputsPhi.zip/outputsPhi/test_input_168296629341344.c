
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(int argc, char* argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s input_file\n", argv[0]);
        return 1;
    }

    FILE* file = fopen(argv[1], "r");
    if (file == NULL) {
        perror("Error opening input file.");
        return 2;
    }

    char line[BUF_SIZE];
    while (fgets(line, BUF_SIZE, file)) {
        if (!feof(file)) {
            for (int i = 0; i < strlen(line); i++) {
                char c = tolower(line[i]);
                if (!isalpha(c)) continue; // skip non-alphabetic characters
            }

            printf("%s\n", line); // print input to stdout
        } else {
            break; // read EOF or other error condition
        }
    }

    return 0;
}