
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    int num = atoi(argv[1]); // convert the first command-line argument to an integer
    printf("The input number is: %d\n", num); // print the input number
    return 0;
}