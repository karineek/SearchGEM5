
#include <stdio.h>

int main(int argc, char** argv) {

    int input;
    if (argc != 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }

    // Read input from command line argument
    input = atoi(argv[1]);

    // Output the input to the console
    printf("Input: %d\n", input);

    // Return 0 for success
    return 0;
}