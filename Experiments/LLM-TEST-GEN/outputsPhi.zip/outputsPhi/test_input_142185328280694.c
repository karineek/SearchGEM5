
#include <stdio.h>

int main(int argc, char **argv) {
    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);

    printf("Input values:\n");
    printf("num1: %d\n", num1);
    printf("num2: %d\n", num2);

    int product = num1 * num2;

    printf("Output value:\n");
    printf("product: %d\n", product);

    return 0;
}