
#include <stdio.h>
int main(int argc, char *argv[]) {
	if (argc != 2) {
		fprintf(stderr, "Usage: %s filename\n", argv[0]);
		return 1;
	}
	FILE* file = fopen(argv[1], "r");
	if (!file) {
		perror("Could not open file");
		return 2;
	}
	fgets(argv[2], 100, file); // Reads input from the command line and stores it in argv[3]
	printf("Input: %s\n", argv[3]);
	fclose(file);
	return 0;