
#include <stdio.h>
int main(int argc, char* argv[]) {
    int num;
    if (argc == 2) {
        num = atoi(argv[1]);
    } else {
        printf("Usage: ./program <number>\n");
        return 1;
    }
    printf("Input number: %d\n", num);
    return 0;
}