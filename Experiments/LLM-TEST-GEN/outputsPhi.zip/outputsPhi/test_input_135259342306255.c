
#include <stdio.h>
int main(int argc, char **argv) {
    int i = 0;
    if (argc == 1) {
        printf("Please provide an argument\n");
        return -1;
    } else {
        for (i = 1; i < argc; i++) {
            if (strcmp(argv[i], "-d") == 0) {
                printf("\nPlease provide a value for the dead code elimination.\n");
                return -1;
            } else if (strcmp(argv[i], "-s") == 0) {
                printf("\nPlease provide a value for the static analysis.\n");
                return -1;
            } else {
                printf("%s\n", argv[i]);
            }
        }
    }
    return 0;
}