
#include <stdio.h>

int main(int argc, char **argv) {
    // Prints out all arguments passed into the command line
    for (int i = 1; i < argc; i++) {
        printf("Argument %d: %s\n", i, argv[i]);
    }

    // Exit with code 0 if no arguments were passed in
    return 0;
}