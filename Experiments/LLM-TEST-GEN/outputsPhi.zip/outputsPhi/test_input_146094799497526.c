
#include <stdio.h>
#include <string.h>
#include <unistd.h>

/* Function to allocate register for a given subexpression */
void alloca_reg(char *subexpr) {
    int reg = 1; /* Initialize the register as unused */
    if (strncmp(subexpr, "x", 2)) {
        reg += 8; /* Allocate a larger register for x */
    }
    else if (strncmp(subexpr, "y", 3)) {
        reg *= 4; /* Allocate a larger register for y */
    }
    printf("Allocated register %d\n", reg);
}

/* Function to read input and check for common subexpressions */
void cse(char *argv[]) {
    static char expr[20]; /* Store the expression in memory */
    static int regs[8][2]; /* Store the register allocation for each subexpression */

    while (strncmp(argv[0], "x", 1) != 0 || strncmp(argv[0], "y", 3)) {
        printf("Enter expression: ");
        fgets(expr, 20, stdin);

        /* Check for common subexpressions */
        int i;
        for (i = 1; i < argc; i++) {
            if (strncmp(argv[0], "x", 1) == 0 && strncmp(argv[i], "y", 3)) {
                printf("Found common subexpression!\n");
                regs[0][0] = 8; /* Allocate register for x */
                regs[0][1] = i - 1; /* Store the index of the common subexpression */
                break;
            } else if (strncmp(argv[0], "y", 3) == 0 && strncmp(argv[i], "x", 1)) {
                printf("Found common subexpression!\n");
                regs[1][0] = 4; /* Allocate register for y */
                regs[1][1] = i - 1; /* Store the index of the common subexpression */
                break;
            }
        }

        printf("Register allocation for %s: \n", expr);
        for (i = 0; i < 2; i++) {
            if (regs[0][0] != 8 || regs[0][1] == -1) {
                printf("%d: %d\n", i + 1, regs[0][1]);
            } else if (regs[1][0] != 4 || regs[1][1] == -1) {
                printf("%d: %d\n", i + 1, regs[1][1]);
            }
        }

        fflush(stdout);
    }
}

int main(int argc, char* argv[]) {
    cse(argv + 1);
    return 0;
}