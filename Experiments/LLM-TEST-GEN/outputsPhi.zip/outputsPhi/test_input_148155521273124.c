
#include <iostream>
#include <cstring>
#include <stdio.h>
#include <string.h>
using namespace std;
/* Function to check if command is valid */
bool is_valid(char* arg) { 
    return strcmp(arg, "optimize") == 0 || strcmp(arg, "malloc") == 0 || strcmp(arg, "object_format") == 0;
}
int main(int argc, char** argv) {
    // Check number of arguments provided
    if (argc < 2) { 
        printf("Invalid number of arguments. Please provide at least one command.");
        return 1;
    }

    for (int i = 1; i <= argc -1; i++) { // Iterate over all arguments
        char* currentArgument = argv[i];
        if (!is_valid(currentArgument)) { 
            printf("Invalid command: %s\n", currentArgument);
            continue;
        }

        // Code for the specific command goes here...
    }
    return 0;
}