
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int n = atoi(argv[1]); // read input integer from command line argument
    printf("Input: %d\n", n);

    if (n < 10) {
        printf("This number is less than 10.\n");
    } else {
        int sum = 0;
        for (int i = 2; i <= n; i++) {
            if (n % i == 0) {
                printf("This number is divisible by %d.\n", i);
            } else {
                sum += i;
            }
        }

        printf("Sum of divisors: %d\n", sum);
    }

    return 0;
}