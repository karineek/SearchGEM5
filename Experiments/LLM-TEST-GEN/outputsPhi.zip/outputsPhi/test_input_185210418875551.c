
#include <stdio.h>
#include <limits.h>

int main(int argc, char* argv[]) {
    int x = 0;
    for (int i=1; i<argc; i++) {
        if (isdigit(argv[i][0])) {
            x += atoi(argv[i]);
        } else {
            printf("Invalid input: %s\n", argv[i]);
            return 1;
        }
    }
    printf("The sum is: %d\n", x);
    return 0;
}