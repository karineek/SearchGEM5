
#include <stdio.h>
#include <string.h>

struct Person {
    char name[30];
    int age;
};

int main(int argc, char* argv[]) {
    struct Person *person = NULL;

    if (argc != 2) {
        printf("Usage: %s <name> [age]\n", argv[0]);
        return 1;
    }

    char *p = strdup(argv[1]);
    char *a = argv[2];

    person = malloc(sizeof(*person));
    if (person == NULL) {
        perror("Memory allocation failed");
        return 1;
    }

    sscanf(p, "%s", person->name); // read name
    sscanf(a, "%d", &person->age); // read age

    printf("Person's name is: %s\n", person->name);
    printf("Person's age is: %d\n", person->age);

    free(p); // release memory
    return 0;
}