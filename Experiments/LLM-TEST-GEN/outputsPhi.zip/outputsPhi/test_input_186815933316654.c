
#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]) {
    // Get input arguments from user
    if (argc != 2) {
        printf("Error: expected one argument.\n");
        return 1;
    }

    char* file_name = argv[1];

    // Open the file and read its contents into a buffer
    FILE* fp = fopen(file_name, "r");
    if (fp == NULL) {
        printf("Error: could not open %s.\n", file_name);
        return 1;
    }

    char* buffer = malloc(sizeof(char) * 100);
    fread(buffer, sizeof(char), 100, fp);
    fclose(fp);

    // Print the contents of the file
    printf("%s\n", buffer);

    return 0;
}