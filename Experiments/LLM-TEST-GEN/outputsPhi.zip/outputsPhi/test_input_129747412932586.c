
#include <stdio.h>

int main(int argc, char* argv[]) {
  int num1 = atoi(argv[1]); // convert first argument to integer
  int num2 = atoi(argv[2]); // convert second argument to integer
  int sum = num1 + num2; // add the numbers together
  printf("The sum of %d and %d is %d\n", num1, num2, sum); // print out the result
  return 0;
}