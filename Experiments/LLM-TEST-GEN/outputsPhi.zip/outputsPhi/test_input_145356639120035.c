
#include <stdio.h>
#include <string.h>

int main(int argc, char**argv) {

    // Print out all command line arguments
    for (int i = 1; i <= argc; i++) {
        printf("%s\n", argv[i]);
    }

    // Prompt the user to enter two integers
    printf("Enter two numbers: ");
    scanf("%d %d", &num1, &num2);

    // Add and assign the sum of num1 and num2
    int sum = num1 + num2;
    num1 += sum;

    // Print out the result
    printf("The sum is %d.\n", sum);

    return 0;
}