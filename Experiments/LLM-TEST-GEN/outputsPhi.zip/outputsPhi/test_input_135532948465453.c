
#include <stdio.h>

int main(int argc, char* argv[]) {
    int n = atoi(argv[1]); // Get the value of n from command line argument
    int i;

    for (i = 2; i <= n/2; i++) {
        if (n % i == 0) {
            printf("%d is not a prime number.\n", n);
            break;
        }
    }

    if (i == n/2) {
        printf("%d is a prime number.\n", n);
    }

    return 0;
}