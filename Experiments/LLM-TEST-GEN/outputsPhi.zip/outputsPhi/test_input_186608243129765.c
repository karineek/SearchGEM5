
#include <stdio.h>

int main(int argc, char *argv[]) {

    int n;

    if (argc != 2) {
        printf("Usage: %s input_file\n", argv[0]);
        return 1;
    }

    FILE *f = fopen(argv[1], "r");
    if (f == NULL) {
        printf("Error opening file: %s\n", argv[1]);
        return 1;
    }

    fscanf(f, "%d", &n);

    for (int i = 0; i < n; i++) {
        fscanf(f, " %c", &char_in_line[i]);
    }

    printf("The input file contains: \n");

    for (int i = 0; i < n; i++) {
        printf("%s ", char_in_line[i]);
    }

    fclose(f);

    return 0;
}