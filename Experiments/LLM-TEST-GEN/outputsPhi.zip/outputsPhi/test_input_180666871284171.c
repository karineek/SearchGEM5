
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    int i;
    int nums[] = { 0 }; // Initialize the array to hold integers
    for (i = 1; i < argc; i++) { // Read in the list of integers from command line arguments
        nums[i - 1] = atoi(argv[i]); // Convert each argument to an integer and store it in the array
    }
    qsort(nums, argc - 1, sizeof(int), cmp_ints); // Sort the array using qsort
    for (i = 0; i < argc - 1; i++) {
        printf("%d ", nums[i]); // Print out the sorted list
    }
    printf("\n");
    return 0;
}

// Implementation of cmp_ints comparison function for qsort:
int cmp_ints(const void *a, const void *b) {
    int x = (int *)a; // Cast to int to avoid casting errors
    int y = (int *)b;
    return (*x < *y)? -1 : ((*x > *y)? 1: 0); // Compare the two integers and return -1, 0 or 1 depending on their relative values
}