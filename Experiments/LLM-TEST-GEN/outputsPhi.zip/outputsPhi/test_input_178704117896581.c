
#include <stdio.h>
int main(int argc, char *argv[]) {
    // print input from command line
    printf("Input: %s\n", argv[1]);
    return 0;
}