
#include <stdio.h>
int main(int argc, char** argv) {
    for (int i = 1; i <= argc; i++) {
        printf("Input argument %d: ", i);
        fgets(argv[i], 100, stdin);
    }
    return 0;
}