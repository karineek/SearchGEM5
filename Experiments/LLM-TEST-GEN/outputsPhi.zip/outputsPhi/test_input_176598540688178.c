
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {

    int i, j;
    double m1[3][3], m2[3][3];
    double result[3][3];

    // read input from command line arguments
    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-m1") == 0) {
            fscanf(stdin, "%lf %lf %lf\n", &m1[0][0], &m1[0][1], &m1[0][2]);
        } else if (strcmp(argv[i], "-m2") == 0) {
            fscanf(stdin, "%lf %lf %lf\n", &m2[0][0], &m2[0][1], &m2[0][2]);
        } else if (strcmp(argv[i], "-res") == 0) {
            fscanf(stdin, "%lf %lf %lf\n", &result[0][0], &result[0][1], &result[0][2]);
        } else if (strcmp(argv[i], "-exit") == 0) {
            exit(EXIT_SUCCESS);
        } else {
            fprintf(stderr, "Invalid argument: %s\n", argv[i]);
            exit(EXIT_FAILURE);
        }
    }

    // multiply matrices using function specialization
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            result[i][j] = m1[i][0] * m2[0][j] + m1[i][1] * m2[1][j] + m1[i][2] * m2[2][j];
        }
    }

    // print result
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            printf("%f ", result[i][j]);
        }
        printf("\n");
    }

    return 0;
}