
#include <stdio.h>
int main(int argc, char* argv[]) {
  // Initialize variables
  int i;
  char name[100];

  // Loop through arguments to get user input and print output
  for (i = 1; i < argc; ++i) {
    sscanf(argv[i], "%s", name);
    printf("%s\n", name);
  }
  return 0;
}