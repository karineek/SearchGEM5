
#include <stdio.h>

int main(int argc, char *argv[]) {

  int num1 = atoi(argv[1]); // convert first argument to integer
  int num2 = atoi(argv[2]); // convert second argument to integer

  printf("The LCM of %d and %d is: ", num1, num2);
  if (num1 > num2) {
    while (true) {
      int rem = num1 % num2;
      if (rem == 0) {
        printf("%d\n", num1);
        break;
      } else {
        num1 = num2;
        num2 = rem;
      }
    }
  } else {
    while (true) {
      int rem = num2 % num1;
      if (rem == 0) {
        printf("%d\n", num2);
        break;
      } else {
        num2 = num1;
        num1 = rem;
      }
    }
  }

  return 0;
}