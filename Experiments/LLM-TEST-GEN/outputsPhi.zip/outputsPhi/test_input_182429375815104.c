
#include <stdio.h>

int main(int argc, char** argv) {
  int a = atoi(argv[1]);
  int b = atoi(argv[2]);

  // Add the two numbers together and store the result in 'c'
  int c = a + b;

  // Print the value of 'c' to standard output
  printf("The sum is %d\n", c);

  return 0;
}