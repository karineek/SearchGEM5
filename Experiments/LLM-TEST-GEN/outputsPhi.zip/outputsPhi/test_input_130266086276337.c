
#include <stdio.h>

int main(int argc, char* argv[]) {
    // Check if the correct number of arguments were passed
    if (argc != 2) {
        printf("Usage: %s hexadecimal_number\n", argv[0]);
        return 1;
    }

    // Convert the input string to a decimal number using base 16 (hexadecimal)
    int num = strtol(argv[1], NULL, 16);

    printf("The decimal representation of %s is %d\n", argv[1], num);

    return 0;
}