
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    // Check if the user has provided a valid number of arguments
    if (argc != 2) {
        printf("Please provide an integer argument.");
        return 1;
    }

    // Convert the input from string to integer using strtol() function
    int input = strtol(argv[1], NULL, 10);

    // Print the converted integer
    printf("Input: %d\n", input);

    return 0;
}