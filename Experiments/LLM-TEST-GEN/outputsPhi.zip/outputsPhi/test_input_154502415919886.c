
#include <stdio.h>
int main(int argc, char** argv) {
    printf("Enter a number: ");
    int num = atoi(argv[1]);
    for (int i=2; i<argc; i++) {
        if (atoi(argv[i]) == num) {
            printf("The number %d appears in position %d.\n", num, i);
        } else {
            break;
        }
    }
    return 0;
}