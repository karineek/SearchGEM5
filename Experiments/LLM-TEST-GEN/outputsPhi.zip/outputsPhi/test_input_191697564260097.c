
#include <stdio.h>
int main(int argc, char* argv[]) {
  int b; //binary input from user
  int dec = 0; //decimal output

  printf("Enter a binary number: ");
  scanf("%d", &b); //read binary input from user

  while (b != 0) {
    dec = dec * 2 + b % 10; //convert binary to decimal
    b /= 10; //remove the last digit of binary number
  }

  printf("%d in decimal is: ", argc > 1 ? argv[1] : "0");
  printf("%d\n", dec);

  return 0;
}