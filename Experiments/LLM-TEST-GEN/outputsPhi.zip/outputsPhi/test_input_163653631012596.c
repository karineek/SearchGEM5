
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
 
int main(int argc, char *argv[]) {
    FILE *fp;
    int i = 0;
    char *file_name = "";
    fp = fopen("/proc/self/status", "r");
    if (fp == NULL) {
        printf("Error opening file\n");
        return -1;
    }
    while (fgets(argv[i], 100, stdin) != NULL) {
        i++;
        if (strcmp(argv[i],"include") == 0) {
            file_name = argv[i+1];
            fclose(fp);
            break;
        }
    }
    fclose(fp);
    printf("Included files: \n");
    while (file_name != "") {
        printf("%s\n", file_name);
        char *next;
        next = strstr(file_name, ".h");
        if (next != NULL) {
            file_name = next + 1;
        } else {
            file_name = "";
        }
    }
    return 0;
}