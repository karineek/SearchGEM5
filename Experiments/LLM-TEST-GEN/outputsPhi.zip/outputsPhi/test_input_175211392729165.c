
#include <stdio.h>
int main(int argc, char* argv[]) {
    int num;
    if (argc != 2) {
        printf("Usage: %s integer\n", argv[0]);
        return 1;
    }
    else {
        num = atoi(argv[1]);
        printf("Input: %d\n", num);
        printf("Output: %.2f\n", acoshf(num)); //acoshf is a hypothetical function that computes the inverse hyperbolic cosine of its argument, in this case the result will be the number itself if it's real and finite
    }
    return 0;
}