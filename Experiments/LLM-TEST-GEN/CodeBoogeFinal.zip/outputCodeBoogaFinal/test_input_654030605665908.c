
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int add_numbers(int a, int b);

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <integer1> <integer2>\n", argv[0]);
        return 1;
    }
    
    int num1, num2;
    sscanf(argv[1], "%d", &num1); // SCNd identifier prefix - using sscanf to parse command line argument as an integer
    sscanf(argv[2], "%d", &num2);

    int sum = add_numbers(num1, num2); // Interprocedural Optimization - calling a separate function to perform operation on the input numbers
    
    printf("Sum of %d and %d is: %d\n", num1, num2, sum);
    
    return 0;
}

int add_numbers(int a, int b) {
    return a + b; // Simple addition operation that can be optimized by the compiler
}