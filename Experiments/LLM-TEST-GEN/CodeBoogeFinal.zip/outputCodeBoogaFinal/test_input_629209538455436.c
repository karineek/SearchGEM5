
#include <stdio.h>
#include <float.h>
#include <math.h>

int main(int argc, char *argv[]) {
    double a = strtod(argv[1], NULL);
    double b = strtod(argv[2], NULL);
    
    // Common subexpression: (a + b) is used twice in the following calculations
    double c = sqrt((a + b) * (a + b));
    double d = log10(a + b);
    
    printf("sqrt((%f + %f)^2) = %f\n", a, b, c);
    printf("log10(%f + %f) = %f\n", a, b, d);

    // Using HUGE_VAL macro to compare two values
    if (c > HUGE_VAL) {
        printf("The value of c is too large.\n");
    } else {
        printf("The value of c is within the range of double precision.\n");
    }
    
    return 0;
}