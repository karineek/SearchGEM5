
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program input_num1 input_num2\n");
        return 1;
    }
    
    double num1 = atof(argv[1]);
    double num2 = atof(argv[2]);
    int sum = 0, i;

    for (i = 1; i <= num1; i++) {
        sum += i;
    }
    
    for (i = 1; i <= num2; i++) {
        sum += ceil(i);
    }

    printf("The result of the loop fusion and ceil function is: %d\n", sum);

    return 0;
}