
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int num1;
    int num2;
} Numbers;

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <num1> <num2>\n", argv[0]);
        return 1;
    }
    
    Numbers numbers;
    numbers.num1 = atoi(argv[1]);
    numbers.num2 = atoi(argv[2]);
    
    int sum = numbers.num1 + numbers.num2;
    int product = numbers.num1 * numbers.num2;
    
    printf("Sum: %d\n", sum);
    printf("Product: %d\n", product);
    
    return 0;
}