
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <limits.h>

int square(int x) {
    return x * x;
}

__attribute__((const))
bool is_positive_even(int x) {
    return (x > 0) && (x % 2 == 0);
}

int square_strict(int x) {
    _Static_assert(sizeof(int) <= sizeof(long long), "integer type too large");
    
    if (!is_positive_even(x)) {
        fprintf(stderr, "Error: input must be a positive even integer\n");
        exit(EXIT_FAILURE);
    }
    
    return square(x);
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <integer>\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    errno = 0;
    long x = strtol(argv[1], NULL, 10);
    if (errno != 0 || x < INT_MIN || x > INT_MAX) {
        perror("strtol");
        return EXIT_FAILURE;
    }
    
    int input = (int)x;
    printf("%d squared is %d\n", input, square_strict(input));
    
    return 0;
}