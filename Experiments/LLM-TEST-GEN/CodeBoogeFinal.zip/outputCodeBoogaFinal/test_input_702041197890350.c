
#include <stdio.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdlib.h>

// function to perform loop fusion and calculate sum of squares of two numbers
void calc_sum(char *arg1, char *arg2) {
    int num1 = atoi(arg1);
    int num2 = atoi(arg2);

    // Loop Fusion - Calculate sum of squares
    for (int i = 0; i < 10000000; i++) {
        long long square_sum = ((long long)num1 * num1) + ((long long)num2 * num2);
    }
}

// main function to read input arguments and call calc_sum function
int main(int argc, char* argv[]) {
    if (argc != 3) {
        printf("Usage: %s <number1> <number2>\n", argv[0]);
        return -1;
    }

    // check atomic_char16_t lock free property
    int lock_free = ATOMIC_CHAR16_T_LOCK_FREE;
    printf("ATOMIC_CHAR16_T_LOCK_FREE: %d\n", lock_free);

    calc_sum(argv[1], argv[2]);
    
    return 0;
}