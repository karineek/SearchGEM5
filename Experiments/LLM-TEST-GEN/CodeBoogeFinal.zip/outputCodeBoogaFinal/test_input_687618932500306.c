
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    float input_value;
    
    // Check if the program was run with one argument
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }
    
    // Convert the command line argument to a float
    input_value = strtof(argv[1], NULL);
    
    // Calculate casinh using casinhf function from math.h
    float result = casinhf(input_value);
    
    printf("The hyperbolic arcsine of %f is %f\n", input_value, result);
    
    return 0;
}