
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }

    int n = atoi(argv[1]);
    
    // Loop with loop optimizations
    for (int i = 0; i < n; ++i) {
        printf("Loop iteration %d\n", i);
    }

    // Using 'f' identifier suffix to represent a float value
    float f_num = 3.14159265358979f;
    printf("The value of Pi is approximately %.10f\n", f_num);

    return 0;
}