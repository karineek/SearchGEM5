
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./program n\n");
        return 1;
    }
    
    int n = atoi(argv[1]);
    long long sum = 0;
    for (int i = 1; i <= n; ++i) {
        int square = i * i; // loop invariant code motion
        sum += square;
    }
    
    printf("Sum of squares: %lld\n", sum);
    return 0;
}