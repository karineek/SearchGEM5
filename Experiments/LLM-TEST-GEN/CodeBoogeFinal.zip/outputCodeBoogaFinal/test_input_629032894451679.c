
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input_number>\n", argv[0]);
        return 1;
    }

    int input_number = 0;
    swscanf_s(argv[1], L"%d", &input_number); // Reading the input number and converting it to integer

    printf("Input number is: %d\n", input_number); // Printing the input number

    return 0;
}