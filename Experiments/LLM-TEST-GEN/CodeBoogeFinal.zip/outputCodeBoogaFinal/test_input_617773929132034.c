
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

// Function to calculate factorial using inliner heuristic optimization
inline uint_least32_t factorial(uint_least32_t n) {
    return (n <= 1) ? 1 : n * factorial(n - 1);
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }
    
    uint_least32_t num = strtoul(argv[1], NULL, 10);
    if (num > 12) {
        printf("Input number should be less than or equal to 12.\n");
        return 1;
    }
    
    uint_least32_t result = factorial(num);
    printf("Factorial of %u: %u\n", num, result);
    return 0;
}