
#include <stdio.h>
#include <stdlib.h>
#include <complex.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 4) {
        printf("Usage: ./program <real_part> <imaginary_part> <operation>\n");
        return 1;
    }

    double real = atof(argv[1]);
    double imag = atof(argv[2]);
    char *operation = argv[3];

    double complex z1 = real + imag * I;
    double complex z2 = 0 + 0 * I;

    if (strcmp(operation, "conjugate") == 0) {
        z2 = conj(z1);
    } else if (strcmp(operation, "square") == 0) {
        z2 = cpow(z1, 2.0);
    } else if (strcmp(operation, "sqrt") == 0) {
        z2 = cpow(z1, 0.5);
    } else {
        printf("Invalid operation.\n");
        return 1;
    }

    printf("%f + %fi\n", creal(z2), cimag(z2));
    return 0;
}