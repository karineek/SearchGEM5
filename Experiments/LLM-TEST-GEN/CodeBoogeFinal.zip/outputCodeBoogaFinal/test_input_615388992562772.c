
#include <stdio.h>
#include <stdlib.h>
#include <fenv.h>

inline int div(int a, int b) {
    return a / b;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program num1 num2\n");
        exit(EXIT_FAILURE);
    }

    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);

    feenableexcept(FE_DIVBYZERO);

    int result;
    if (num2 == 0) {
        printf("Error: division by zero\n");
        exit(EXIT_FAILURE);
    } else {
        result = div(num1, num2);
        printf("%d / %d = %d\n", num1, num2, result);
    }

    return 0;
}