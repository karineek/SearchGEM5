
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <float_number>\n", argv[0]);
        return -1;
    }
    
    float input = atof(argv[1]);
    long int result = lrintl(input);
    printf("%f rounded to the nearest integer is %ld\n", input, result);
    
    // Loop optimization example
    for (long int i = 0; i < 100000000; ++i) {
        // Do some operations here that can be optimized by the compiler
    }
    
    return 0;
}