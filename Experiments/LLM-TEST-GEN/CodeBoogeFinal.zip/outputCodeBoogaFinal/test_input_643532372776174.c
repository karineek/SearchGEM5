
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <locale.h>

void print_wide_string(const wchar_t *str) {
    setlocale(LC_ALL, "");
    while (*str) {
        fputwc(*str++, stdout);
    }
}

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("No input provided.\n");
        return 1;
    }
    
    wchar_t *wide_string = malloc((strlen(argv[1]) + 1) * sizeof(wchar_t));
    mbstowcs(wide_string, argv[1], strlen(argv[1]) + 1);
    
    print_wide_string(wide_string);
    printf("\n");
    
    free(wide_string);
    return 0;
}