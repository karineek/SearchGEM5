
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s string\n", argv[0]);
        return 1;
    }
    
    const char *input = argv[1];
    while (*input) {
        if (!isgraph(*input)) {
            putchar(*input);
        }
        input++;
    }
    putchar('\n');
    
    return 0;
}