
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <filename>\n", argv[0]);
        return 1;
    }

    FILE *file = fopen(argv[1], "r");
    if (!file) {
        perror("fopen");
        return 2;
    }

    char line[512];
    int line_count = 0;
    int inst_count = 0;
    while (fgets(line, sizeof(line), file)) {
        line_count++;
        if (strstr(line, " %") && strstr(line, ", !dbg")) {
            // Count instructions with debug metadata
            inst_count++;
        }
    }

    fclose(file);

    printf("There are %d instructions in the file.\n", inst_count);
    printf("The file has %d lines.\n", line_count);

    return 0;
}