
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int unary_add(int n) {
    if (n == 0) return 0;
    else return unary_add(n - 1) + n;
}

int main(int argc, char *argv[]) {
    int sum = 0;
    for (int i = 1; i < argc; ++i) {
        if (isdigit(argv[i][0])) { // Check if argument is a number
            sum += unary_add(atoi(argv[i]));
        } else {
            printf("Invalid input: %s\n", argv[i]);
            return 1; // Exit with error code
        }
    }
    printf("Sum = %d\n", sum);
    return 0;
}