
#include <stdio.h>
#include <stdlib.h>
#include <tgmath.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <number1> <operator> <number2>\n", argv[0]);
        return 1;
    }

    double num1 = strtod(argv[1], NULL);
    char *op = argv[2];
    double num2 = strtod(argv[3], NULL);

    if (strcmp(op, "+") == 0) {
        printf("%g + %g = %g\n", num1, num2, add(num1, num2));
    } else if (strcmp(op, "-") == 0) {
        printf("%g - %g = %g\n", num1, num2, sub(num1, num2));
    } else if (strcmp(op, "*") == 0) {
        printf("%g * %g = %g\n", num1, num2, mul(num1, num2));
    } else if (strcmp(op, "/") == 0) {
        if (num2 != 0.0) {
            printf("%g / %g = %g\n", num1, num2, div(num1, num2));
        } else {
            printf("Error: division by zero is not allowed.\n");
        }
    } else {
        printf("Invalid operator: %s\n", op);
    }

    return 0;
}