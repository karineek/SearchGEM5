
#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>

// Function to calculate the square of a number
uint64_t square(uint32_t num) {
    return num * num;
}

int main(int argc, char* argv[]) {
    // Check if there are enough command line arguments
    if (argc < 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }

    // Convert the input argument to an integer
    uint32_t num = strtoul(argv[1], NULL, 10);

    // Calculate the square of the number and print it in binary format
    uint64_t squared = square(num);
    printf("The square of %u is %" PRIu64 " (%" PRIX64 " in hexadecimal)\n", num, squared, squared);

    return 0;
}