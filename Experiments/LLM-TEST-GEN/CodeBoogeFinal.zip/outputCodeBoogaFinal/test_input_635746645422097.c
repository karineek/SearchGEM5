
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input_string>\n", argv[0]);
        return 1;
    }
    
    // Memory optimization using AST and line number
    char *input = argv[1];
    int input_length = strlen(input);
    printf("Input length: %d\n", input_length);
    
    for (int i = 0; i < input_length; i++) {
        if (!isalpha((unsigned char)input[i])) {
            printf("Invalid character '%c' at line %d\n", input[i], __LINE__ - 2);
            return 1;
        }
    }
    
    printf("Input is valid\n");
    return 0;
}