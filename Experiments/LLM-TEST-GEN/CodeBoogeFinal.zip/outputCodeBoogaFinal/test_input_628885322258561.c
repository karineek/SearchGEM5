
// main.c
#include <stdio.h>
#include <stdlib.h>
#include "clang-c/Index.h"

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input>\n", argv[0]);
        return EXIT_FAILURE;
    }

    CXIndex index = clang_createIndex(0, 0);
    CXTranslationUnit tu = clang_parseTranslationUnit(index, "test.c", NULL, 0, NULL, 0, CXTranslationUnit_None);

    if (tu == NULL) {
        printf("Unable to load translation unit from test.c\n");
        return EXIT_FAILURE;
    }

    CXCursor cursor = clang_getTranslationUnitCursor(tu);
    clang_visitChildren(cursor, print_node, argv[1]);

    clang_disposeTranslationUnit(tu);
    clang_disposeIndex(index);
    return EXIT_SUCCESS;
}

void print_node(CXCursor cursor, CXCursor parent, CXClientData client_data) {
    if (clang_Location_isFromMainFile(clang_getCursorLocation(cursor)) && clang_getCursorKind(cursor) == CXCursor_FunctionDecl) {
        CXString func_name = clang_getCursorDisplayName(cursor);
        printf("Found function: %s\n", clang_getCString(func_name));
        clang_disposeString(func_name);
    }
}