
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <errno.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <seconds_since_epoch>\n", argv[0]);
        return 1;
    }
    
    errno = 0;
    unsigned long epoch_time = strtoul(argv[1], NULL, 10);
    
    if (errno != 0) {
        perror("strtoul");
        return 1;
    }
    
    struct tm time_info;
    gmtime_s(&time_info, &epoch_time);
    
    printf("UTC time: %d-%02d-%02d %02d:%02d:%02d\n", 
           time_info.tm_year + 1900, time_info.tm_mon + 1, time_info.tm_mday,
           time_info.tm_hour, time_info.tm_min, time_info.tm_sec);
    
    return 0;
}