
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    // Check if there are exactly two arguments provided
    if (argc != 3) {
        printf("Usage: %s <num1> <num2>\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    // Convert the input strings to integers
    int num1, num2;
    if (sscanf(argv[1], "%d", &num1) != 1 || sscanf(argv[2], "%d", &num2) != 1) {
        printf("Invalid arguments. Please enter two integers.\n");
        return EXIT_FAILURE;
    }
    
    // Perform the addition using registers
    register int result = num1 + num2;
    
    // Print out the result
    printf("%d + %d = %d\n", num1, num2, result);
    
    return EXIT_SUCCESS;
}