
#include <stdio.h>
#include <errno.h>

int main(int argc, char* argv[]) {
    FILE *fp;
    
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return -1;
    }

    errno_t result = freopen_s(&fp, argv[1], "r", stdin);
    if (result != 0) {
        printf("Error opening file: %d\n", errno);
        return -2;
    }

    char buffer[100];
    while (fgets(buffer, sizeof(buffer), fp)) {
        printf("%s", buffer);
    }

    fclose(fp);
    
    return 0;
}