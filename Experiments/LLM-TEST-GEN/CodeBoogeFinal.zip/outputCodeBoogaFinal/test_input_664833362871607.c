
#include <stdio.h>
#include <math.h>
#include <fenv.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }
    
    int input = atoi(argv[1]);
    
    fenv_t envp;
    feholdexcept(&envp); // create non-stop mode for floating point exceptions
    
    double result = sqrt((double)input); // calculate square root of the input number
    
    if (fetestexcept(FE_INVALID)) {
        printf("Error: Input must be a positive integer.\n");
    } else {
        printf("Square root of %d is %.2lf\n", input, result);
    }
    
    return 0;
}