
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./program float_value\n");
        return -1;
    }
    
    float input = atof(argv[1]);
    int result = ceilf(input);

    printf("%.1f rounded up to the nearest integer is %d.\n", input, result);
    
    return 0;
}