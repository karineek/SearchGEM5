
#include <stdio.h>
#include <stdatomic.h>
#include <stdlib.h>
#include <time.h>

atomic_int_least32_t counter;

void increment_counter(void) {
    int val = atomic_load_explicit(&counter, memory_order_relaxed);
    while (!atomic_compare_exchange_weak_explicit(&counter, &val, val + 1, memory_order_release, memory_order_relaxed)) {
        ; // Do nothing
    }
}

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: ./program <number>\n");
        return -1;
    }
    
    srand(time(NULL));
    
    for (int i = 0; i < atoi(argv[1]); ++i) {
        increment_counter();
        int sleep_time = rand() % 5 + 1; // Sleep for a random time between 1 and 5 seconds
        sleep(sleep_time);
    }
    
    printf("Counter value: %d\n", atomic_load_explicit(&counter, memory_order_relaxed));
    
    return 0;
}