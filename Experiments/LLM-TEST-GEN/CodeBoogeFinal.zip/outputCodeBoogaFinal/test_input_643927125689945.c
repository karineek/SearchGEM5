
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program <numerator> <denominator>\n");
        return 1;
    }

    double num = atof(argv[1]);
    double den = atof(argv[2]);

    if (den == 0.0) {
        printf("Denominator cannot be zero!\n");
        return 1;
    }

    double result = __builtin_atan2(num, den);
    printf("The arctangent of %f/%f is: %f\n", num, den, result);

    return 0;
}