
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

static pthread_once_t once_control = PTHREAD_ONCE_INIT;
static void init_function(void) {
    // Code to be executed only once during the first call of pthread_once()
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }
    
    int num = atoi(argv[1]);
    int square;

    pthread_once(&once_control, init_function);

    square = num * num;

    printf("The square of %d is: %d\n", num, square);
    
    return 0;
}