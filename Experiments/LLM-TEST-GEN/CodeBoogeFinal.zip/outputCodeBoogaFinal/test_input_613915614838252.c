
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/resource.h>

int main(int argc, char *argv[]) {
    // Check if input is provided
    if (argc != 2) {
        printf("Please provide a number as command line argument.\n");
        return 1;
    }
    
    int n = atoi(argv[1]);
    int arr[n];
    int *ptr_arr = arr; // pointer to array

    srand(time(NULL)); // Seed the random number generator with current time

    // Fill the array with random numbers
    for (int i = 0; i < n; i++) {
        arr[i] = rand() % 100;
    }

    printf("Array elements accessed using pointer:\n");
    for (int i = 0; i < n; i++) {
        printf("%d ", *(ptr_arr + i)); // Access array element using pointer
    }

    return 0;
}