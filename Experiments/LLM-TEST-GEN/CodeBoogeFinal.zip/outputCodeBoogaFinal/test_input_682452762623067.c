
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <immintrin.h> // includes AVX2 intrinsics

// Function to calculate the dot product of two vectors using AVX2 instructions and auto-vectorization
double avx2_dot(int n, double *a, double *b) {
    int i;
    __m256d sum = _mm256_setzero_pd();  // initial sum vector
    
    for (i=0; i<n-7; i+=8) {
        __m256d a_vec = _mm256_loadu_pd(a + i);
        __m256d b_vec = _mm256_loadu_pd(b + i);
        sum = _mm256_add_pd(sum, _mm256_mul_pd(a_vec, b_vec));  // sum += a * b
    }
    
    double result[4];
    _mm256_storeu_pd(result, sum);
    
    double dot = result[0] + result[1] + result[2] + result[3];
    for (; i<n; ++i) {
        dot += a[i]*b[i];  // finish off any remaining elements
    }
    
    return dot;
}

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <n>\n", argv[0]);
        exit(1);
    }
    
    int n = atoi(argv[1]);
    
    // Allocate and initialize vectors a and b
    double *a = (double*) malloc(n*sizeof(double));
    double *b = (double*) malloc(n*sizeof(double));
    for (int i=0; i<n; ++i) {
        a[i] = 1.0/(i+1);
        b[i] = 2.0/(i+1);
    }
    
    // Calculate the dot product using AVX2 instructions and auto-vectorization
    double start_time = (double)get_wall_time();
    double dot = avx2_dot(n, a, b);
    double end_time = (double)get_wall_time();
    
    // Print results
    printf("Dot product: %f\n", dot);
    printf("Time elapsed: %f seconds\n", end_time - start_time);
    
    free(a);
    free(b);
    return 0;
}