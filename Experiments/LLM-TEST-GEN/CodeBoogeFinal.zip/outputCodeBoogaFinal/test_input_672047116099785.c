
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to calculate the sum of digits in a number
int sum_digits(int num) {
    int sum = 0;
    while (num > 0) {
        sum += num % 10;
        num /= 10;
    }
    return sum;
}

// Function to read characters from input and print their ASCII values and sum of digits if they are digits
void process_input(char *str) {
    for (int i = 0; str[i] != '\0'; i++) {
        int c = fgetc(stdin);
        printf("ASCII value: %d\n", c);
        if (c >= '0' && c <= '9') {
            int digit = c - '0';
            printf("Sum of digits: %d\n", sum_digits(digit));
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: ./program <input_string>\n");
        return 1;
    }

    process_input(argv[1]);

    return 0;
}