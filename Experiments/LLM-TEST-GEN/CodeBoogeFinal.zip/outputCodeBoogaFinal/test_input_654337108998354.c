
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

int main(int argc, char *argv[]) {
    if (argc <= 1) {
        printf("Please provide at least one command as argument.\n");
        return 1;
    }

    for (int i = 1; i < argc; ++i) {
        // Memory-to-Register Promotion optimization: using strlen instead of storing the length in a variable
        if (strcmp(argv[i], "length") == 0 && i + 1 < argc) {
            printf("The length of '%s' is %lu.\n", argv[i+1], strlen(argv[i+1]));
            ++i; // Skip the next argument as it has been processed
        } else if (strcmp(argv[i], "tolower") == 0 && i + 1 < argc) {
            char *str = argv[i+1];
            while (*str != '\0') {
                *str = tolower((unsigned char)*str);
                ++str;
            }
            printf("The lowercase of '%s' is '%s'.\n", argv[i+1], argv[i+1]);
            ++i; // Skip the next argument as it has been processed
        } else {
            printf("Unknown command: %s.\n", argv[i]);
        }
    }
    
    return 0;
}