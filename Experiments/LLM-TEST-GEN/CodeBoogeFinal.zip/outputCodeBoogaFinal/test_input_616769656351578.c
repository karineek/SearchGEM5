
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <immintrin.h> // Header for AVX intrinsics

// Function to calculate casinh using Taylor series expansion
double my_casinh(double x) {
    double result = 0.0;
    int i, factorial = 1;
    for (i = 0; i < 10; ++i) {
        result += pow(-1, i) * pow(x, 2*i + 1) / (factorial * (2*i + 1));
        factorial *= (2*i + 2) * (2*i + 3);
    }
    return result;
}

// Function to calculate casinh using AVX intrinsics
__m256d avx_my_casinh(__m256d x) {
    __m256d one = _mm256_set1_pd(1.0);
    __m256d two = _mm256_set1_pd(2.0);
    __m256d three = _mm256_set1_pd(3.0);
    __m256d four = _mm256_set1_pd(4.0);
    __m256d x_squared = _mm256_mul_pd(x, x);
    __m256d result = _mm256_sqrt_pd(_mm256_add_pd(one, x_squared)); // sqrt(1 + x^2)
    result = _mm256_div_pd(x, result); // x / sqrt(1 + x^2)
    __m256d factorial = one;
    for (int i = 0; i < 3; ++i) {
        factorial = _mm256_mul_pd(factorial, _mm256_fmadd_pd(two, four, three)); // n! = n * (n-1) * (n-2) * ... * 2 * 1
        result = _mm256_fmadd_pd(_mm256_mul_pd(result, x_squared), _mm256_div_pd(one, factorial), result); // result += (-1)^n * x^(2n+1) / n!
    }
    return result;
}

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    double x = strtod(argv[1], NULL);
    __m256d avx_result = avx_my_casinh(_mm256_set1_pd(x));
    double result[4];
    _mm256_storeu_pd(result, avx_result);
    printf("Casinh of %lf using Taylor series: %lf\n", x, my_casinh(x));
    printf("Casinh of %lf using AVX intrinsics: %lf\n", x, result[0]);

    return 0;
}