
#include <stdio.h>
#include <float.h>
#include <limits.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }

    double input_num = strtod(argv[1], NULL);
    int exponent = (int)(log(input_num)/log(2.0));

    printf("Input number: %f\n", input_num);
    printf("Exponent of 2 closest to the input number: %d\n", exponent);
    printf("Maximum exponent for double: %d\n", DBL_MAX_EXP);
    return 0;
}