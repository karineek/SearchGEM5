
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to check if input is valid
int is_valid(char *str) {
    int i;
    for (i = 0; str[i] != '\0'; ++i) {
        if (!isdigit(str[i])) {
            return 0;
        }
    }
    return 1;
}

// Function to add two integers
int add_integers(int a, int b) {
    return a + b;
}

// Main function
int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <integer1> <integer2>\n", argv[0]);
        return EXIT_FAILURE;
    }

    if (!is_valid(argv[1]) || !is_valid(argv[2])) {
        fprintf(stderr, "Error: Input should be valid integers\n");
        return EXIT_FAILURE;
    }

    int a = atoi(argv[1]);
    int b = atoi(argv[2]);

    int result = add_integers(a, b);

    printf("Result: %d\n", result);
    return EXIT_SUCCESS;
}