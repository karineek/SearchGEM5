
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int i;
    long sum = 0;
    for (i = 1; i < argc; i++) { // Loop Optimization: loop starts from index 1 as index 0 contains the program name
        sum += atol(argv[i]); // Handles Code Generation: converting string to long integer
    }
    
    printf("Sum of all numbers: %ld\n", sum);
    return 0;
}