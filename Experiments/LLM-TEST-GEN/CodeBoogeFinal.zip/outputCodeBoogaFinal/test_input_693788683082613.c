
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s x\n", argv[0]);
        return 1;
    }
    
    double x = atof(argv[1]);
    double result = asinh(x);
    
    printf("asinh(%lf) = %lf\n", x, result);
    
    return 0;
}