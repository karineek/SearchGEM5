
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>

void sigill_handler(int signum) {
    printf("Invalid input! Please provide an integer.\n");
    exit(1);
}

long square(long x) {
    return x * x;
}

int main(int argc, char **argv) {
    long num;
    struct sigaction sa;

    // Set up SIGILL handler
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = sigill_handler;
    sigaction(SIGILL, &sa, NULL);

    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }

    // Convert input to long integer
    char *endptr;
    num = strtol(argv[1], &endptr, 10);

    if (*endptr != '\0') {
        raise(SIGILL);
    }

    printf("Square of %ld is %ld\n", num, square(num));

    return 0;
}