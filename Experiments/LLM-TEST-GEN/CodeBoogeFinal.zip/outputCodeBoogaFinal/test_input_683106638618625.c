
#include <stdio.h>
#include <stdalign.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s num1 num2\n", argv[0]);
        return 1;
    }
    
    int a __attribute__((aligned(8))) = atoi(argv[1]); // variable 'a' is not used and will be eliminated by the compiler due to Dead Code Elimination optimization
    int b = atoi(argv[2]);
    int sum = a + b;
    
    printf("The sum of %d and %d is: %d\n", a, b, sum);
    
    return 0;
}