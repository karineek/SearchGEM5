
#include <stdio.h>
#include <fenv.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // Check if there is exactly one argument
    if (argc != 2) {
        printf("Usage: %s rounding_mode\n", argv[0]);
        return EXIT_FAILURE;
    }

    int rounding_mode = atoi(argv[1]);

    // Set the rounding mode using fesetenv
    fenv_t env;
    if (fegetenv(&env) != 0) {
        perror("Failed to get current environment");
        return EXIT_FAILURE;
    }

    switch(rounding_mode) {
        case FE_TONEAREST:
            printf("Rounding mode set to 'FE_TONEAREST'\n");
            break;
        case FE_DOWNWARD:
            printf("Rounding mode set to 'FE_DOWNWARD'\n");
            break;
        case FE_UPWARD:
            printf("Rounding mode set to 'FE_UPWARD'\n");
            break;
        case FE_TOWARDZERO:
            printf("Rounding mode set to 'FE_TOWARDZERO'\n");
            break;
        default:
            printf("Invalid rounding mode\n");
            return EXIT_FAILURE;
    }

    if (fesetenv(&env) != 0) {
        perror("Failed to set environment");
        return EXIT_FAILURE;
    }

    fesetround(rounding_mode);
    
    double a = 1.5, b = 2.5;
    printf("%f / %f = %.2f\n", a, b, a/b);

    return EXIT_SUCCESS;
}