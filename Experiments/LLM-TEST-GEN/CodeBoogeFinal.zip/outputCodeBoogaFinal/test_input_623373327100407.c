
// Includes necessary headers
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <math.h>

// Declares function prototype for square root specialization
double sqrt_specialized(double x);

int main(int argc, char *argv[]) {
    // Checks if input is provided via command line argument
    if (argc != 2) {
        printf("Please provide an input number.\n");
        return 1;
    }
    
    // Converts input string to double
    double input = atof(argv[1]);
    
    // Calls specialized square root function and prints result
    errno = 0;
    double result = sqrt_specialized(input);
    if (errno == EDOM) {
        printf("Error: Negative number provided.\n");
    } else {
        printf("Square root of %f is %f\n", input, result);
    }
    
    return 0;
}

// Specialized function for square root that checks for negative numbers
double sqrt_specialized(double x) {
    #ifdef MATH_ERRNO
        errno = 0;
    #endif
    
    if (x < 0.0) {
        #ifdef MATH_ERRNO
            errno = EDOM;
        #endif
        return NAN;
    } else {
        return sqrt(x);
    }
}