
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h> // For profiling purposes
#include <unistd.h>  // For profiling purposes

int main(int argc, char *argv[]) {
    int sum = 0;
    
    for (int i=1; i<argc; ++i) {
        sum += atoi(argv[i]);
    }

    printf("Sum of the integers: %d\n", sum);

    // Code to trigger profile-guided optimization
    struct timeval tv;
    gettimeofday(&tv, NULL);
    srand((unsigned int)tv.tv_usec);
    int random = rand()%10 + 1;
    
    if (random > argc/2) {
        printf("Taking the high road...\n");
    } else {
        printf("Taking the low road...\n");
    }
    
    return 0;
}