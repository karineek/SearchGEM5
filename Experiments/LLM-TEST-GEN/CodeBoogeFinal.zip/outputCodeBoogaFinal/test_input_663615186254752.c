
#include <stdio.h>
#include <stdint.h>
#include <stdatomic.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <value1> <value2>\n", argv[0]);
        return 1;
    }

    atomic_char32_t value1, value2;
    value1 = atoi(argv[1]);
    value2 = atoi(argv[2]);

    printf("Before add: Value1=%d, Value2=%d\n", value1, value2);

    // Perform Memory-to-Register Promotion optimization
    __atomic_add_fetch(&value1, value2, __ATOMIC_SEQ_CST);

    printf("After add: Value1=%d, Value2=%d\n", value1, value2);

    return 0;
}