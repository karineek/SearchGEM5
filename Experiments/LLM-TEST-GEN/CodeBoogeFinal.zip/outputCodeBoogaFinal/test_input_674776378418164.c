
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input_string>\n", argv[0]);
        return 1;
    }

    clock_t start = clock();

    // Memory optimization using pointers instead of copying entire strings
    char *input = argv[1];

    printf("Input string: %s\n", input);

    int len = strlen(input);
    for (int i = 0; i < len; i++) {
        input[i] = toupper((unsigned char)input[i]);
    }

    printf("Modified string: %s\n", input);

    clock_t end = clock();
    double time_spent = (double)(end - start) / CLOCKS_PER_SEC;
    printf("Execution time: %.2lf seconds.\n", time_spent);

    return 0;
}