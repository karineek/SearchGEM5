
#include <stdio.h>
#include <stdlib.h>

int gcd(int a, int b) {
    if (b == 0) return a;
    else return gcd(b, a % b);
}

int lcm(int a, int b) {
    return (a * b) / gcd(a, b);
}

int main(int argc, char **argv) {
    if (argc != 3) {
        printf("Usage: ./program <num1> <num2>\n");
        exit(1);
    }
    
    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);

    if (num1 <= 0 || num2 <= 0) {
        printf("Inputs must be positive integers\n");
        exit(1);
    }
    
    int result = lcm(num1, num2);
    printf("LCM of %d and %d is: %d\n", num1, num2, result);
    return 0;
}