
./a.out 5