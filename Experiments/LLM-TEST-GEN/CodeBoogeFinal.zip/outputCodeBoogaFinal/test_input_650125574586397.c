
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./program <float_number>\n");
        return 1;
    }
    
    float x = atof(argv[1]);
    float result = asinhf(x);
    
    printf("The inverse hyperbolic sine of %f is %f\n", x, result);
    return 0;
}