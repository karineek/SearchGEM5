
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <immintrin.h> // include header for AVX intrinsics

int main(int argc, char* argv[]) {
    if (argc != 6) {
        printf("Usage: %s num1 num2 num3 num4 num5 num6\n", argv[0]);
        return -1;
    }
    
    double arr[argc-1]; // create an array to hold the input numbers
    
    for (int i = 1; i < argc; i++) {
        arr[i-1] = atof(argv[i]); // convert string inputs to double and store in array
    }
    
    __m256d max_vals, cur_max, input_vec;
    max_vals = _mm256_set1_pd(-DBL_MAX); // initialize with the smallest possible double value
    
    for (int i = 0; i < argc-1; i+=4) {
        input_vec = _mm256_loadu_pd(arr + i); // load 4 doubles from arr into a vector register
        cur_max = _mm256_max_pd(input_vec, max_vals); // find the maximum of the current vector and previous maximums
        max_vals = cur_max; // update the running maximum
    }
    
    double max_nums[4];
    _mm256_storeu_pd(max_nums, max_vals); // store the 4 doubles from the vector register into an array
    
    double final_max = max_nums[0];
    for (int i = 1; i < 4; i++) {
        if (max_nums[i] > final_max) {
            final_max = max_nums[i]; // find the maximum of the 4 values in the array
        }
    }
    
    printf("The maximum number is: %f\n", final_max);
    printf("DBL_MAX_EXP value is: %d\n", DBL_MAX_EXP);
    
    return 0;
}