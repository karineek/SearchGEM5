
#include <stdio.h> // Header file for standard input/output functions
#include <stdint.h> // Header file for integer types
#include <limits.h> // Header file for numerical limits

int main(int argc, char *argv[]) {
    if (argc != 2) { // Check if the number of command line arguments is not equal to two
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }
    intmax_t input = INTMAX_C(strtol(argv[1], NULL, 10)); // Convert the input string to a long integer using strtol function and store it in input variable
    intmax_t square = input * input; // Calculate the square of the input
    printf("The square of %jd is %jd\n", input, square); // Print the result
    return 0;
}