
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#define WEOF ((wint_t)-1)

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <string>\n", argv[0]);
        return 1;
    }

    int count = 0;
    wchar_t wc;
    mbstate_t mbs;
    memset(&mbs, 0, sizeof(mbstate_t));
    const char *s = argv[1];
    while ((wc = (wchar_t) mbrtowc(&wc, s, MB_CUR_MAX, &mbs)) != WEOF) {
        if (iswalnum(wc)) {
            count++;
        }
        s += wc < 0x100 ? 1 : 2; // ASCII characters take one byte, others take two
    }

    printf("Number of alphanumeric characters: %d\n", count);
    return 0;
}