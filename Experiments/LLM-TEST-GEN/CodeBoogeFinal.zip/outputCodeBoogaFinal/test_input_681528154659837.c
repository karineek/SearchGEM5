
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Matrix {
    int rows;
    int cols;
    int **data;
} Matrix;

Matrix *parse_matrix(char *input) {
    int rows = 0, cols = 0;
    char *token, *rest = input;
    Matrix *mtx = (Matrix *)malloc(sizeof(Matrix));
    
    while ((token = strtok_r(rest, ";", &rest))) {
        if (!cols) {
            cols = count_tokens(token, ",") + 1;
        }
        rows++;
    }
    mtx->rows = rows;
    mtx->cols = cols;
    
    int i = 0, j = 0;
    rest = input;
    mtx->data = (int **)malloc(rows * sizeof(int *));
    for (i = 0; i < rows; i++) {
        mtx->data[i] = (int *)malloc(cols * sizeof(int));
        token = strtok_r(rest, ";", &rest);
        j = 0;
        while ((token = strtok_r(token, ",", &token))) {
            mtx->data[i][j++] = atoi(token);
        }
    }
    
    return mtx;
}

int count_tokens(char *str, char delim) {
    int count = 0;
    for (int i = 0; str[i]; i++) {
        if (str[i] == delim) {
            count++;
        }
    }
    return count + 1;
}

Matrix *multiply_matrices(Matrix *a, Matrix *b) {
    if (a->cols != b->rows) {
        printf("Matrices cannot be multiplied.\n");
        exit(1);
    }
    
    Matrix *c = (Matrix *)malloc(sizeof(Matrix));
    c->rows = a->rows;
    c->cols = b->cols;
    c->data = (int **)malloc(a->rows * sizeof(int *));
    for (int i = 0; i < a->rows; i++) {
        c->data[i] = (int *)malloc(b->cols * sizeof(int));
        for (int j = 0; j < b->cols; j++) {
            int sum = 0;
            for (int k = 0; k < a->cols; k++) {
                sum += a->data[i][k] * b->data[k][j];
            }
            c->data[i][j] = sum;
        }
    }
    
    return c;
}

void print_matrix(Matrix *mtx) {
    for (int i = 0; i < mtx->rows; i++) {
        for (int j = 0; j < mtx->cols; j++) {
            printf("%d ", mtx->data[i][j]);
        }
        printf("\n");
    }
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <matrix1> <matrix2>\n", argv[0]);
        return 1;
    }
    
    Matrix *mtx_a = parse_matrix(argv[1]);
    Matrix *mtx_b = parse_matrix(argv[2]);
    Matrix *mtx_c = multiply_matrices(mtx_a, mtx_b);
    
    printf("Matrix A:\n");
    print_matrix(mtx_a);
    printf("\nMatrix B:\n");
    print_matrix(mtx_b);
    printf("\nProduct of A and B:\n");
    print_matrix(mtx_c);
    
    return 0;
}