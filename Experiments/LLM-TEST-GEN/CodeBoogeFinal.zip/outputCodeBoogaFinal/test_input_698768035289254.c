
#include <stdio.h>
#include <stdlib.h>
#include <complex.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 5) {
        printf("Usage: ./program <real1> <imaginary1> <real2> <imaginary2>\n");
        return 1;
    }
    
    double real1 = atof(argv[1]);
    double imaginary1 = atof(argv[2]);
    double real2 = atof(argv[3]);
    double imaginary2 = atof(argv[4]);
    
    doublecomplex c1 = real1 + I * imaginary1;
    doublecomplex c2 = real2 + I * imaginary2;
    doublecomplex sum = c1 + c2;
    
    printf("Sum of (%f, %fi) and (%f, %fi) is: (%f, %fi)\n", 
            creal(c1), cimag(c1), creal(c2), cimag(c2), 
            creal(sum), cimag(sum));
    
    return 0;
}