
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <letter>\n", argv[0]);
        return 1;
    }

    // Common Subexpression Elimination optimization example
    int length = strlen(argv[1]);
    int i, j, k;
    for (i = 0; i < length - 2; i++) {
        for (j = i + 1; j < length - 1; j++) {
            for (k = j + 1; k < length; k++) {
                printf("%c%c%c\n", argv[1][i], argv[1][j], argv[1][k]);
            }
        }
    }

    return 0;
}