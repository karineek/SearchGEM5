
#include <stdio.h>
#include <math.h>

#define ITMAX 100
#define EPS 3.0e-7

double tgammal(double x);

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./program <positive_number>\n");
        return 1;
    }

    double x = atof(argv[1]);
    if (x <= 0) {
        printf("Error: input must be a positive number\n");
        return 1;
    }

    double result = tgammal(x);
    printf("Gamma(%f) = %f\n", x, result);

    return 0;
}

double tgammal(double x) {
    static double coeff[6] = {
        76.180009172947146,
        -86.50532032941677,
        24.01409824083091,
        -1.231739572450155,
        0.1208650973866179e-2,
        -0.5395239384953e-5
    };

    double tmp = x + 5.5;
    tmp -= (x + 0.5) * log(tmp);
    double ser = 1.00000000000190015;

    for (int j = 0; j < 6; ++j) {
        ser += coeff[j] / (x + j + 1);
    }

    return exp(-tmp + log(2.5066282746310002 * ser / x));
}