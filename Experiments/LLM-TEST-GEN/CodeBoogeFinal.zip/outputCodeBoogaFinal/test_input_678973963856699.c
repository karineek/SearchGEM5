
#include <stdio.h>
#include <stdatomic.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./program <integer>\n");
        return 1;
    }

    int input = atoi(argv[1]);
    atomic_int counter = ATOMIC_VAR_INIT(0);

    for (int i = 0; i < input; i++) {
        atomic_store_explicit(&counter, i + 1, memory_order_relaxed);
    }

    int result = atomic_load_explicit(&counter, memory_order_relaxed);

    printf("The final value of the counter is: %d\n", result);

    return 0;
}