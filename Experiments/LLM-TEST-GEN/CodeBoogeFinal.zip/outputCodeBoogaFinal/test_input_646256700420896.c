
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

bool is_even(int n) {
    atomic_flag lock = ATOMIC_FLAG_INIT;
    bool result;
    while (atomic_flag_test_and_set_explicit(&lock, memory_order_acquire)) {}
    result = (n % 2 == 0);
    atomic_flag_clear_explicit(&lock, memory_order_release);
    return result;
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./program <integer>\n");
        exit(1);
    }

    int n = atoi(argv[1]);
    if (is_even(n)) {
        printf("%d is even.\n", n);
    } else {
        printf("%d is odd.\n", n);
    }
    
    return 0;
}