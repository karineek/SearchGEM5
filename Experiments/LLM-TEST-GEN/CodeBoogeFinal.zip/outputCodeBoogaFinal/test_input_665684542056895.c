
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <numerator> <denominator>\n", argv[0]);
        return -1;
    }

    double num = atof(argv[1]);
    double denom = atof(argv[2]);

    if (denom == 0) {
        printf("Division by zero is not allowed.\n");
        return -2;
    }

    double result = fmod(num, denom);

    printf("%f mod %f = %f\n", num, denom, result);

    return 0;
}