
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }

    long double num = strtold(argv[1], NULL);
    
    // Loop Optimizations - Using a for loop to calculate powers of 2 and binary representation
    int i, j = 0;
    char bin_rep[64] = {0};
    for (i = 63; num && i >= 0; --i) {
        bin_rep[i] = (num & 1) + '0';
        num /= 2.0L;
    }
    
    printf("Binary representation: ");
    for (j = 0; j < 64 && bin_rep[j]; ++j) {
        printf("%c", bin_rep[j]);
    }
    printf("\n");
    
    return 0;
}