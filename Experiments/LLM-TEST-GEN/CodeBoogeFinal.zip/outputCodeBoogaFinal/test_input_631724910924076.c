
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

void *print_thread(void *arg) {
    printf("Thread %ld: %s\n", (long int)pthread_self(), (char *)arg);
    pthread_exit(NULL);
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: %s <input>\n", argv[0]);
        return 1;
    }

    pthread_t thread;
    int status = pthread_create(&thread, NULL, print_thread, argv[1]);
    if (status != 0) {
        perror("pthread_create");
        return 2;
    }

    sleep(1);
    printf("Main: Waiting for thread to finish...\n");
    pthread_join(thread, NULL);
    printf("Main: Done.\n");

    return 0;
}