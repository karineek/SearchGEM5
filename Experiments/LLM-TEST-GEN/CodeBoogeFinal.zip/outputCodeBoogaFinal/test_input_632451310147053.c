
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

void sigint_handler(int signum) {
    printf("SIGINT received, exiting...\n");
    exit(signum);
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return EXIT_FAILURE;
    }

    int number = atoi(argv[1]);
    
    // Register SIGINT handler
    signal(SIGINT, sigint_handler);

    printf("Calculating factorial of %d\n", number);

    unsigned long long factorial = 1;
    for (int i = 1; i <= number; ++i) {
        // Check if the multiplication will cause overflow
        if (ULLONG_MAX / i < factorial) {
            printf("Overflow error\n");
            return EXIT_FAILURE;
        }
        factorial *= i;
    }

    printf("Factorial of %d is: %llu\n", number, factorial);

    return EXIT_SUCCESS;
}