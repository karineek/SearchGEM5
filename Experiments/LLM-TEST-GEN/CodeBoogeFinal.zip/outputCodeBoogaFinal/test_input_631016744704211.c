
#include <stdio.h>
#include <threads.h>
#include <stdatomic.h>

// Vectorization example using OpenMP
#ifdef _OPENMP
    #pragma omp declare simd
#endif
int vector_add(int a, int b) {
    return a + b;
}

// Serialization example using atomic operations
void increment_counter(atomic_int *counter) {
    atomic_fetch_add(counter, 1);
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Usage: %s <num1> <num2>\n", argv[0]);
        return -1;
    }
    
    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);
    int result = vector_add(num1, num2);

    printf("Result of %d + %d is: %d\n", num1, num2, result);

    // Parallel execution example using threads
    thrd_t thread;
    atomic_int counter = 0;
    thrd_create(&thread, (thrd_start_t)increment_counter, &counter);
    for (int i = 0; i < 100000000; ++i) {
        increment_counter(&counter);
    }
    thrd_join(thread, NULL);
    
    printf("Counter after parallel execution: %u\n", atomic_load(&counter));

    return 0;
}