
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    // Check for correct number of arguments
    if (argc != 3) {
        printf("Usage: %s <loop iterations> <operation>\n", argv[0]);
        return -1;
    }

    int iter = atoi(argv[1]);
    char *op = argv[2];

    // Loop fusion and common warnings handling
    #pragma GCC diagnostic push
    #pragma GCC diagnostic ignored "-Wunused-variable"
    for (int i = 0; i < iter; i++) {
        int a = i * 2;
        if (!strcmp(op, "add")) {
            int b = a + i;
            printf("Result: %d\n", b);
        } else if (!strcmp(op, "subtract")) {
            int c = a - i;
            printf("Result: %d\n", c);
        } else {
            printf("Invalid operation!\n");
        }
    }
    #pragma GCC diagnostic pop

    // Execute generated code (example: ls command)
    if (!fork()) {
        execl("/bin/ls", "ls", NULL);
    }

    return 0;
}