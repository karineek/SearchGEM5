
#include <stdio.h>
#include <stdlib.h>
#include "llvm-c/Core.h"
#include "llvm-c/ExecutionEngine.h"

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <num1> <num2>\n", argv[0]);
        return 1;
    }

    LLVMModuleRef module = LLVMModuleCreateWithName("sum");
    LLVMTypeRef int_type = LLVMInt32Type();
    LLVMTypeRef func_type = LLVMFunctionType(int_type, NULL, 0, false);
    LLVMValueRef sum_func = LLVMAddFunction(module, "sum", func_type);
    LLVMBuilderRef builder = LLVMCreateBuilder();
    LLVMBasicBlockRef entry_bb = LLVMAppendBasicBlock(sum_func, "entry");
    
    LLVMValueRef arg1 = LLVMGetParam(sum_func, 0);
    LLVMValueRef arg2 = LLVMGetParam(sum_func, 1);
    
    LLVMPositionBuilderAtEnd(builder, entry_bb);
    LLVMValueRef sum_val = LLVMBuildAdd(builder, arg1, arg2, "sum"); // Common subexpression elimination
    LLVMBuildRet(builder, sum_val);
    
    char *error = NULL;
    LLVMExecutionEngineRef engine;
    if (LLVMCreateExecutionEngineForModule(&engine, module, &error) != 0) {
        printf("Failed to create execution engine: %s\n", error);
        return 1;
    }
    
    int (*sum_func_ptr)(int, int) = LLVMGetFunctionAddress(engine, "sum");
    if (sum_func_ptr == NULL) {
        printf("Failed to get function address\n");
        return 1;
    }

    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);
    int result = sum_func_ptr(num1, num2);
    
    printf("Sum: %d\n", result);
    
    LLVMDisposeExecutionEngine(engine);
    return 0;
}