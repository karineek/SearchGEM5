
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program num1 num2\n");
        return 1;
    }
    
    int a = atoi(argv[1]);
    int b = atoi(argv[2]);
    int c = 5 + 7; // Constant folding optimization, as 5+7 is calculated at compile time
    int d = a * b; // Supports execution of generated code
    int e; // Implicit initialization to zero

    printf("a: %d\nb: %d\nc: %d\nd: %d\ne: %d\n", a, b, c, d, e);
    return 0;
}