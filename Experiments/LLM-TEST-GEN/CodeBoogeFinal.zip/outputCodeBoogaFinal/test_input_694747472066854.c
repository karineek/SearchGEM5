
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>

// Function to check if a number is prime
bool is_prime(int n) {
    if (n <= 1) return false;
    if (n == 2) return true;
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) return false;
    }
    return true;
}

// Function to print prime numbers between the given interval
void print_primes(int lower, int upper) {
    for (int i = lower; i <= upper; i++) {
        if (is_prime(i)) {
            printf("%d\n", i);
        }
    }
}

int main(int argc, char *argv[]) {
    // Check if there are exactly two command-line arguments
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <lower> <upper>\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    // Convert the command-line arguments to integers
    int lower = strtol(argv[1], NULL, 10);
    int upper = strtol(argv[2], NULL, 10);

    if (lower > upper) {
        fprintf(stderr, "Lower bound must be less than or equal to upper bound.\n");
        return EXIT_FAILURE;
    }

    // Print the prime numbers between the given interval
    print_primes(lower, upper);

    return EXIT_SUCCESS;
}