
#include <stdio.h>
#include <fenv.h>

inline int check_fe_exceptions() {
    int excepts = fetestexcept(FE_ALL_EXCEPT);
    if (excepts & FE_DIVBYZERO) printf("Division by zero exception occurred.\n");
    if (excepts & FE_INVALID ) printf("Invalid operation exception occurred.\n");
    if (excepts & FE_OVERFLOW) printf("Overflow exception occurred.\n");
    if (excepts & FE_UNDERFLOW) printf("Underflow exception occurred.\n");
    return excepts;
}

int main(int argc, char *argv[]) {
    float a = strtof(argv[1], NULL);
    float b = strtof(argv[2], NULL);
    
    printf("a / b = %.2f\n", a / b);
    
    check_fe_exceptions();
    
    return 0;
}