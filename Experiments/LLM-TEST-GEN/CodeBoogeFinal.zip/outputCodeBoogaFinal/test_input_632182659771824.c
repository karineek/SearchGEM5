
#include <stdio.h>
#include <stdlib.h>

unsigned long long int factorial(int n) {
    return (n == 0 || n == 1) ? 1 : n * factorial(n - 1);
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }
    
    int num = atoi(argv[1]);
    unsigned long long int result = factorial(num);
    
    if (!(num & 1)) { // check if number is even using bitwise AND operator and logical negation "!"
        printf("%d! = %llu, which is an even number\n", num, result);
    } else {
        printf("%d! = %llu, which is an odd number\n", num, result);
    }
    
    return 0;
}