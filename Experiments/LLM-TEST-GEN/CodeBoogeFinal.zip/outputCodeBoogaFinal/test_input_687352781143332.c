
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <wchar.h>

int main(int argc, char *argv[]) {
    setlocale(LC_ALL, ""); // Set locale for multibyte character support
    
    if (argc != 2) {
        printf("Usage: %s <string>\n", argv[0]);
        return 1;
    }
    
    const char *input = argv[1]; // Input string from command line argument
    size_t len = strlen(input);
    size_t mbsize = len + 1; // Allocate space for null terminator
    wchar_t *output = (wchar_t *) malloc(mbsize * sizeof(wchar_t));
    
    if (!output) {
        perror("malloc");
        return 1;
    }
    
    mbstate_t state;
    memset(&state, 0, sizeof(state)); // Initialize conversion state
    
    const char *mbp = input; // Multibyte string pointer
    size_t converted = 0;
    
    while (converted < len) {
        size_t result = mbsrtowcs(output + converted, &mbp, mbsize - converted, &state);
        
        if (result == (size_t)(-1)) { // Conversion error
            perror("mbsrtowcs");
            free(output);
            return 1;
        } else if (result == 0) { // End of string
            break;
        }
        
        converted += result;
    }
    
    printf("Input: %s\nOutput: ", input);
    for (size_t i = 0; i < converted; ++i) {
        putwchar(output[i]);
    }
    putwchar('\n');
    
    free(output);
    return 0;
}