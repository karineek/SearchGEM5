
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program <number1> <number2>\n");
        return -1;
    }

    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);
    
    // Target-Specific Optimizations and -= subtraction assignment operator
    for (int i = num1; i >= num2; i -= 5) {
        printf("%d\n", i);
    }

    return 0;
}