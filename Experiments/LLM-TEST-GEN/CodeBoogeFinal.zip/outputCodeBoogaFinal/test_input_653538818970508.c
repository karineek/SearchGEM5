
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program string1 string2\n");
        return 1;
    }

    wchar_t *string1 = malloc((wcslen(argv[1]) + 1) * sizeof(wchar_t));
    if (string1 == NULL) {
        perror("malloc");
        return -1;
    }

    mbstowcs(string1, argv[1], strlen(argv[1]) + 1);

    wchar_t *string2 = malloc((wcslen(argv[2]) + 1) * sizeof(wchar_t));
    if (string2 == NULL) {
        perror("malloc");
        return -1;
    }

    mbstowcs(string2, argv[2], strlen(argv[2]) + 1);

    wcscpy(string2, string1);
    printf("After copying: %ls\n", string2);

    free(string1);
    free(string2);
    return 0;
}