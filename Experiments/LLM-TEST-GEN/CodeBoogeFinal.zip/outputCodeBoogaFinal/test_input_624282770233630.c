
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    FILE *input_file, *output_file;
    long int position;
    char line[1024];
    
    if (argc != 3) {
        printf("Usage: %s <input file> <output file>\n", argv[0]);
        exit(1);
    }
    
    input_file = fopen(argv[1], "r");
    output_file = fopen(argv[2], "w");
    
    if (input_file == NULL || output_file == NULL) {
        perror("Failed to open file");
        exit(1);
    }
    
    while (fgets(line, sizeof(line), input_file)) {
        position = ftell(input_file); // Get the current position in the file
        printf("Current position: %ld\n", position);
        fputs(line, output_file);   // Write the line to the output file
    }
    
    fclose(input_file);
    fclose(output_file);
    
    return 0;
}