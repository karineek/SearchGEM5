
#include <stdio.h>
#include <stdlib.h>
#include <stdatomic.h>
#include <inttypes.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }

    int input = atoi(argv[1]);
    atomic_int_fast8_t counter = 0;

    for (int i = 0; i < input; ++i) {
        __atomic_add_fetch(&counter, 1, __ATOMIC_SEQ_CST);
    }

    printf("The input number is %d and the counter value after loop optimization is %" PRIdFAST8 "\n", input, counter);

    return 0;
}