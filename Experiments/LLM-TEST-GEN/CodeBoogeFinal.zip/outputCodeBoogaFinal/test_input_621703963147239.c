
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }
    
    FILE *file = fopen(argv[1], "r");
    if (!file) {
        perror("fopen");
        return 1;
    }
    
    char line[1024];
    while (fgets(line, sizeof(line), file)) {
        int vowel_count = 0;
        for (char *c = line; *c; c++) {
            if (*c == 'a' || *c == 'e' || *c == 'i' || *c == 'o' || *c == 'u' ||
                *c == 'A' || *c == 'E' || *c == 'I' || *c == 'O' || *c == 'U') {
                vowel_count++;
            }
        }
        
        printf("Vowel count in line %d: %d\n", getline(file), vowel_count);
    }
    
    fclose(file);
    return 0;
}