
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <smmintrin.h> // SSE4.1 intrinsics

int main(int argc, char *argv[]) {
    if (argc != 5) {
        printf("Usage: %s a b c d e\n", argv[0]);
        return -1;
    }

    float a = atof(argv[1]), b = atof(argv[2]), c = atof(argv[3]), d = atof(argv[4]);
    __m128 xmm_a, xmm_b, xmm_c, xmm_d;

    xmm_a = _mm_set_ps1(a);
    xmm_b = _mm_set_ps1(b);
    xmm_c = _mm_set_ps1(c);
    xmm_d = _mm_set_ps1(d);

    __m128 xmm_res = _mm_dp_ps(xmm_a, xmm_b, 0xFF); // dot product instruction
    float result[4];
    _mm_storeu_ps(result, xmm_res);

    printf("Dot product of %f and %f: %f\n", a, b, result[0]);
    printf("Dot product of %f and %f: %f\n", c, d, result[1]);

    return 0;
}