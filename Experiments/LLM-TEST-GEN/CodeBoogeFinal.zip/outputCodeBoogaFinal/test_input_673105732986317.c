
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <xmmintrin.h> // SSE2 intrinsics

int main(int argc, char **argv) {
    if (argc != 4) {
        printf("Usage: %s array_size input_file1 input_file2 output_file\n", argv[0]);
        return -1;
    }

    int n = atoi(argv[1]);
    float *a = (float *)malloc(n * sizeof(float));
    float *b = (float *)malloc(n * sizeof(float));
    float *c = (float *)malloc(n * sizeof(float));
    
    // Read input arrays from files
    FILE *file1, *file2;
    file1 = fopen(argv[2], "r");
    if (!file1) {
        printf("Error opening input file %s\n", argv[2]);
        return -1;
    }
    for (int i = 0; i < n; i++) {
        fscanf(file1, "%f", &a[i]);
    }
    fclose(file1);
    
    file2 = fopen(argv[3], "r");
    if (!file2) {
        printf("Error opening input file %s\n", argv[3]);
        return -1;
    }
    for (int i = 0; i < n; i++) {
        fscanf(file2, "%f", &b[i]);
    }
    fclose(file2);
    
    // Vectorized addition using SSE2 intrinsics
    __m128 *va = (__m128 *)a;
    __m128 *vb = (__m128 *)b;
    __m128 *vc = (__m128 *)c;
    
    for (int i = 0; i < n / 4; i++) {
        vc[i] = _mm_add_ps(va[i], vb[i]);
    }
    
    // Write result array to output file
    FILE *file3;
    file3 = fopen(argv[4], "w");
    if (!file3) {
        printf("Error opening output file %s\n", argv[4]);
        return -1;
    }
    for (int i = 0; i < n; i++) {
        fprintf(file3, "%f ", c[i]);
    }
    fclose(file3);
    
    free(a);
    free(b);
    free(c);
    
    return 0;
}