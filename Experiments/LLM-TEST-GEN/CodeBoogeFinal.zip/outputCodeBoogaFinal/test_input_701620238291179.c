
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <angle_in_radians>\n", argv[0]);
        return -1;
    }

    double angle = atof(argv[1]);
    double sinh, cosh;
    double e_powx, e_negx;

    // Memory to register promotion optimization for tanh calculation
    e_powx = exp(angle);
    e_negx = 1.0 / e_powx;
    sinh = (e_powx - e_negx) / 2.0;
    cosh = (e_powx + e_negx) / 2.0;
    double tanh = sinh / cosh;

    printf("tanh(%lf) = %lf\n", angle, tanh);

    return 0;
}