
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <immintrin.h>

// Function to calculate the remainder of two vectors using SSE intrinsics
void vector_remainder(__m256d *a, __m256d *b) {
    *a = _mm256_div_pd(*a, *b);
    *a = _mm256_round_pd(*a, _MM_FROUND_TO_NEAREST_INT | _MM_FROUND_NO_EXC);
    *a = _mm256_mul_pd(*a, *b);
}

int main(int argc, char **argv) {
    // Check for valid input
    if (argc != 3) {
        printf("Usage: ./program <vector1> <vector2>\n");
        return 1;
    }

    // Convert inputs to double vectors
    __m256d vec1 = _mm256_set_pd(atof(argv[1]), atof(argv[1]), atof(argv[1]), atof(argv[1]));
    __m256d vec2 = _mm256_set_pd(atof(argv[2]), atof(argv[2]), atof(argv[2]), atof(argv[2]));

    // Calculate the remainder of the two vectors
    vector_remainder(&vec1, &vec2);

    // Print the result
    double result[4];
    _mm256_storeu_pd(result, vec1);
    printf("The remainder of %s divided by %s is: %.2lf\n", argv[1], argv[2], result[0]);

    return 0;
}