
#include <stdio.h>
#include <threads.h>
#include <stdatomic.h>

// Function to be executed in parallel
void do_work(int *result) {
    for (int i = 0; i < 10000000000; ++i) {
        atomic_fetch_add(result, 1);
    }
}

int main(int argc, char **argv) {
    // Check if input is provided
    if (argc != 2) {
        printf("Usage: %s <number of threads>\n", argv[0]);
        return 1;
    }
    
    int num_threads = atoi(argv[1]);

    // Create threads and join them
    thrd_t threads[num_threads];
    atomic_int result = 0;
    for (int i = 0; i < num_threads; ++i) {
        thrd_create(&threads[i], do_work, &result);
    }
    for (int i = 0; i < num_threads; ++i) {
        thrd_join(threads[i], NULL);
    }
    
    printf("Result: %d\n", result);
    return 0;
}