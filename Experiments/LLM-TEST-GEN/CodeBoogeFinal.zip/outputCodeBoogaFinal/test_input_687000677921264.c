
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }

    double x = atof(argv[1]);
    double result = clog1p(x);

    printf("The value of log1p(%f) is %f\n", x, result);

    return 0;
}