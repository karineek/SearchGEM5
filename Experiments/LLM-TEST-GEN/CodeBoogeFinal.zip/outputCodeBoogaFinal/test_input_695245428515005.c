
#include <stdio.h>
#include <stdint.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }
    
    uintmax_t num = strtoumax(argv[1], NULL, 10); // Convert input to UINTMAX_C type
    uintmax_t sum = 0;
    
    for (uintmax_t i = 0; i <= num / 2; ++i) { // Loop optimization: only iterate up to half of the number
        if (num % i == 0) { // Check if i is a factor of the input number
            sum += i;
        }
    }
    
    printf("Sum of factors for %ju is %ju\n", num, sum + num); // Add the number itself to the sum and print it
    
    return 0;
}