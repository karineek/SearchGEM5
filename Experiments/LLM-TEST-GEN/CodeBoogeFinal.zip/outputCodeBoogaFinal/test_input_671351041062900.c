
#include <stdio.h>
#include <stdlib.h>
#include <stdatomic.h>

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        return EXIT_FAILURE;
    }

    int input = atoi(argv[1]);
    atomic_int sum = ATOMIC_VAR_INIT(0);
    for (int i = 0; i < input; ++i) {
        atomic_fetch_add(&sum, i + 1);
    }

    printf("The sum is: %d\n", atomic_load(&sum));
    return EXIT_SUCCESS;
}