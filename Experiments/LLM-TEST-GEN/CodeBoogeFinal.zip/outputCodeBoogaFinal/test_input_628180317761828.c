
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef enum {
    ADD,
    SUBTRACT,
    MULTIPLY,
    DIVIDE
} Operation;

double perform_operation(Operation op, double a, double b) {
    switch (op) {
        case ADD:
            return a + b;
        case SUBTRACT:
            return a - b;
        case MULTIPLY:
            return a * b;
        case DIVIDE:
            if (b == 0) {
                fprintf(stderr, "Error: division by zero.\n");
                exit(1);
            }
            return a / b;
    }
}

int main(int argc, char *argv[]) {
    // Check for correct number of arguments
    if (argc != 4) {
        fprintf(stderr, "Usage: %s <operation> <operand1> <operand2>\n", argv[0]);
        return 1;
    }

    // Convert operation argument to enumeration value
    Operation op;
    if (strcmp(argv[1], "add") == 0) {
        op = ADD;
    } else if (strcmp(argv[1], "subtract") == 0) {
        op = SUBTRACT;
    } else if (strcmp(argv[1], "multiply") == 0) {
        op = MULTIPLY;
    } else if (strcmp(argv[1], "divide") == 0) {
        op = DIVIDE;
    } else {
        fprintf(stderr, "Invalid operation.\n");
        return 1;
    }

    // Convert operand arguments to double values
    char *endptr;
    double a = strtod(argv[2], &endptr);
    if (*endptr != '\0') {
        fprintf(stderr, "Invalid operand: %s\n", argv[2]);
        return 1;
    }
    double b = strtod(argv[3], &endptr);
    if (*endptr != '\0') {
        fprintf(stderr, "Invalid operand: %s\n", argv[3]);
        return 1;
    }

    // Perform the operation and print the result
    double result = perform_operation(op, a, b);
    printf("%f\n", result);

    return 0;
}