
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    // Check if the number of arguments is correct
    if (argc != 3) {
        printf("Usage: %s [string] [integer]\n", argv[0]);
        return 1;
    }
    
    // Print the input string and integer
    char *input_str = argv[1];
    int input_int = atoi(argv[2]);
    printf("Input String: %s\n", input_str);
    printf("Input Integer: %d\n", input_int);

    // Loop to print the string n times, where n is the integer input
    for (int i = 0; i < input_int; i++) {
        printf("%s\n", input_str);
    }

    return 0;
}