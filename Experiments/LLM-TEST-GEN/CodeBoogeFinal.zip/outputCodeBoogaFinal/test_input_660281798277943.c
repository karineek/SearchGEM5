
#include <stdio.h>
#include <stdlib.h>

// Function for adding two numbers using function inlining
__attribute__((always_inline)) static inline int add(int a, int b) {
    return a + b;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <number1> <number2>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);
    
    // Check if __alignas_is_defined is defined
#ifdef __alignas_is_defined
    printf("__alignas_is_defined is defined.\n");
#else
    printf("__alignas_is_defined is not defined.\n");
#endif
    
    // Calculate the sum of two numbers and print it
    int sum = add(num1, num2);
    printf("The sum of %d and %d is: %d\n", num1, num2, sum);

    return 0;
}