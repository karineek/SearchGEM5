
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <string> <character>\n", argv[0]);
        return 1;
    }

    char *str = argv[1];
    char ch = argv[2][0]; // get the first character from the input string

    char *last_occurrence = strrchr(str, ch);
    if (last_occurrence != NULL) {
        printf("The last occurrence of '%c' in '%s' is at position %ld\n", ch, str, last_occurrence - str + 1);
    } else {
        printf("Character '%c' not found in string '%s'\n", ch, str);
    }

    return 0;
}