
#include <stdio.h>
#include <stdlib.h>
#include <math.h> // for nanl() function

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s num1 num2\n", argv[0]);
        return 1;
    }
    
    long double num1 = strtold(argv[1], NULL); // convert string to long double
    long double num2 = strtold(argv[2], NULL);
    
    if (isnanl(num1) || isnanl(num2)) {
        printf("Invalid input: %s or %s is not a number\n", argv[1], argv[2]);
        return 1;
    }
    
    long double result = num1 + num2; // perform addition operation
    
    if (isnanl(result)) {
        printf("Result: nan\n"); // print the result if it's a number
    } else {
        printf("Result: %Lf\n", result);
    }
    
    return 0;
}