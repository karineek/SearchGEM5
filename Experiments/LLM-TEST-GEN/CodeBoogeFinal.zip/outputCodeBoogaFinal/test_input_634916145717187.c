
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s [integer]\n", argv[0]);
        return EXIT_FAILURE;
    }

    int input = atoi(argv[1]);
    int output = input + 1;

    printf("Input: %d\nOutput: %d\n", input, output);

    return EXIT_SUCCESS;
}