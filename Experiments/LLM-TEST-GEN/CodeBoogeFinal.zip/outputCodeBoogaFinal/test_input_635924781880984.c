
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <float>\n", argv[0]);
        return 1;
    }
    
    float x = atof(argv[1]);
    float result = acoshf(x);
    printf("acosh(%f) = %f\n", x, result);
    return 0;
}