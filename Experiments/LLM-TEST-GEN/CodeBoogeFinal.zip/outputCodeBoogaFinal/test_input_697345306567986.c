
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <immintrin.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <num1> <num2>\n", argv[0]);
        return -1;
    }
    int n = atoi(argv[1]);
    float sum = 0.0f, nums[4];
    __m128 sums = _mm_setzero_ps();
    for (int i=0; i<n/4; i++) {
        for (int j=0; j<4; j++) {
            nums[j] = rand() % 10;
        }
        __m128 num = _mm_loadu_ps(nums);
        sums = _mm_add_ps(sums, _mm_mul_ps(num, num));
    }
    float *result = (float*)&sums;
    for (int i=0; i<4; i++) {
        sum += result[i];
    }
    printf("Sum of squares: %f\n", sum);
    return 0;
}