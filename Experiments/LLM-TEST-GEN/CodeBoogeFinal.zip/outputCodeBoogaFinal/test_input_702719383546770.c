
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 4) {
        printf("Usage: ./inline_example float base exponent\n");
        return 1;
    }
    
    double x = strtod(argv[1], NULL);
    int base = atoi(argv[2]);
    long exponent = strtol(argv[3], NULL, 10);

    double result = scalblnl(x, exponent);

    printf("Result: %f\n", result);
    return 0;
}