
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <inttypes.h>

// Function to perform Loop Invariant Code Motion optimization
void loop_invariant_code_motion(int *arr, int n) {
    int i;
    int sum = 0; // This line can be moved outside the loop as it is invariant
    for (i=0; i<n; ++i) {
        arr[i] += 2*sum + 1; // Loop-variant code
        sum += arr[i]; // Loop-invariant code
    }
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <array size>\n", argv[0]);
        return -1;
    }
    int n = atoi(argv[1]); // Get the array size from command line argument
    
    // Allocate memory for an integer array of given size
    int *arr = (int*) malloc(n * sizeof(int)); 
    
    // Initialize the array with some values
    for (int i=0; i<n; ++i) {
        arr[i] = i+1;
    }
    
    loop_invariant_code_motion(arr, n);
    
    // Print the modified array elements
    printf("Modified array: \n");
    for (int i=0; i<n; ++i) {
        printf("%" PRIdMAX "\n", arr[i]);
    }
    
    free(arr);
    return 0;
}