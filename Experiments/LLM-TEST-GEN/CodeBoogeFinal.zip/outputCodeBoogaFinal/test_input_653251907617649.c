
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }
    
    double number = atof(argv[1]);
    double result = sqrt(number);
    printf("Square root of %.2f is %.2f\n", number, result);
    
    return 0;
}