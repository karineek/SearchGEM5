
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

int main(int argc, char *argv[]) {
    // Check if there are enough arguments
    if (argc != 3) {
        printf("Usage: ./program <integer1> <integer2>\n");
        return 1;
    }
    
    int num1, num2;
    bool valid_input = true;

    // Parse the input integers
    if (sscanf(argv[1], "%d", &num1) != 1 || sscanf(argv[2], "%d", &num2) != 1) {
        printf("Invalid input. Please enter two valid integers.\n");
        valid_input = false;
    } else if (num1 < 0 || num2 < 0) {
        printf("Inputs must be non-negative integers.\n");
        valid_input = false;
    }
    
    // Perform the calculation and print the result
    if (valid_input) {
        int sum = num1 + num2;
        printf("The sum of %d and %d is: %d\n", num1, num2, sum);
    }

    return 0;
}