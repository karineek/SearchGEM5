
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s base exponent\n", argv[0]);
        return 1;
    }
    
    double base = atof(argv[1]);
    int exponent = atoi(argv[2]);
    
    double result = scalbn(base, exponent);
    
    printf("%lf times 2 raised to the power of %d is: %lf\n", base, exponent, result);
    
    return 0;
}