
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define _GNU_SOURCE         /* See feature_test_macros(7) */
#include <sys/types.h>
#include <unistd.h>
#include <math.h>

int main(int argc, char *argv[]) {
    int i;
    double num, result[argc - 1];
    
    // Set stdout to line buffered mode
    setvbuf(stdout, NULL, _IOLBF, BUFSIZ);
    
    for (i = 1; i < argc; i++) {
        num = atof(argv[i]);
        
        // Vectorization happens here using GCC pragma
        #pragma GCC ivdep
        for (int j = 0; j < 100000000; j++) {
            result[i - 1] += pow(num, 2);
        }
    }
    
    // Output the squares of each input number
    for (i = 0; i < argc - 1; i++) {
        printf("%lf\n", result[i]);
    }

    return 0;
}