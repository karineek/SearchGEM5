
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

struct Person; // incomplete type declaration
typedef struct Person Person;

Person *create_person(char *name, int age);
void print_person(Person *p);
int compare_persons(const void *a, const void *b);

int main(int argc, char **argv) {
    if (argc != 3) {
        printf("Usage: %s <name> <age>\n", argv[0]);
        return 1;
    }

    srand(time(NULL)); // seed random number generator for PGO

    Person *p = create_person(argv[1], atoi(argv[2]));
    print_person(p);

    return 0;
}

struct Person {
    char *name;
    int age;
};

Person *create_person(char *name, int age) {
    Person *p = malloc(sizeof(Person));
    p->name = strdup(name);
    p->age = age + (rand() % 10 - 5); // add some random noise for PGO
    return p;
}

void print_person(Person *p) {
    printf("Name: %s\n", p->name);
    printf("Age: %d\n", p->age);
}

int compare_persons(const void *a, const void *b) {
    Person *pa = (Person *)a;
    Person *pb = (Person *)b;
    return strcmp(pa->name, pb->name);
}