
#include <stdio.h>
#include <stdlib.h>
#include <float.h>

long double min(long double a, long double b) {
    return (a < b) ? a : b;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s num1 num2\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    long double a = strtold(argv[1], NULL);
    long double b = strtold(argv[2], NULL);
    
    if (a == LDBL_MIN || b == LDBL_MIN) {
        printf("Error: Input value is too small.\n");
        exit(EXIT_FAILURE);
    }

    long double result = min(a, b);
    printf("The minimum value is %.10Lf\n", result);

    return 0;
}