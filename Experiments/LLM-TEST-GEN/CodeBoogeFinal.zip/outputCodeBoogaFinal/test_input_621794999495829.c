
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h> // for isdigit function
#include <assert.h> // for assert macro

// dummy struct to represent an AST node
typedef struct {
    int value;
} ASTNode;

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }
    
    int input = atoi(argv[1]);
    
    // create AST node and initialize its value
    ASTNode *node = (ASTNode *) malloc(sizeof(ASTNode));
    assert(node != NULL);
    node->value = 0;
    
    // modify the AST using vertical-line-equal punctuator
    for (int i = 1; i <= input; i++) {
        if (isdigit(i)) {
            node->value |= i;
        }
    }
    
    printf("Result: %d\n", node->value);
    
    free(node);
    return 0;
}