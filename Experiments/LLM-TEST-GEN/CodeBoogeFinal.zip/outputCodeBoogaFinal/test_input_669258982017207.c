
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <llvm-c/Core.h>
#include <llvm-c/Analysis.h>
#include <llvm-c/ExecutionEngine.h>
#include <llvm-c/Target.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <numerator> <denominator>\n", argv[0]);
        return -1;
    }

    LLVMModuleRef module = LLVMModuleCreateWithName("division");
    LLVMTypeRef arg_types[] = {LLVMInt32Type(), LLVMInt32Type()};
    LLVMTypeRef func_type = LLVMFunctionType(LLVMInt32Type(), arg_types, 2, 0);
    LLVMValueRef function = LLVMAddFunction(module, "divide", func_type);
    LLVMBasicBlockRef entry_block = LLVMAppendBasicBlock(function, "entry");

    LLVMBuilderRef builder = LLVMCreateBuilder();
    LLVMPositionBuilderAtEnd(builder, entry_block);

    LLVMValueRef numerator = LLVMGetParam(function, 0);
    LLVMValueRef denominator = LLVMGetParam(function, 1);

    // Constant Folding optimization: divide by a constant value (2)
    LLVMValueRef two = LLVMConstInt(LLVMInt32Type(), 2, 0);
    LLVMValueRef div_result = LLVMBuildSDiv(builder, numerator, two, "div_result");
    LLVMValueRef mul_result = LLVMBuildMul(builder, div_result, denominator, "mul_result");

    LLVMBuildRet(builder, mul_result);

    // Create an execution engine and optimize the module
    char *error = NULL;
    LLVMMCJITCompilerOptions options;
    memset(&options, 0, sizeof(options));
    options.OptLevel = 3; // Optimization level 3 for constant folding

    LLVMExecutionEngineRef engine;
    if (LLVMCreateMCJITCompiler(&engine, module, &options) != 0) {
        printf("Failed to create execution engine\n");
        return -1;
    }

    LLVMOptimizeModule(engine, module, LLVM_PASS_CONSTANT_PROPAGATION, 0); // Apply constant propagation optimization pass

    // Get the function pointer and call the function with the provided arguments
    int (*divide)(int, int) = (int (*)(int, int))LLVMGetFunctionAddress(engine, "divide");
    if (!divide) {
        printf("Failed to get function address\n");
        return -1;
    }

    int num = atoi(argv[1]);
    int den = atoi(argv[2]);
    printf("%d / 2 * %d = %d\n", num, den, divide(num, den));

    // Clean up
    LLVMDisposeExecutionEngine(engine);
    return 0;
}