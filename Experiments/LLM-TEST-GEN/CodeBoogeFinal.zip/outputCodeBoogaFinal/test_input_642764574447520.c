
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int evaluate_postfix(char *expression);
void push(int value);
int pop();
int is_empty();
int top();

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <postfix expression>\n", argv[0]);
        return 1;
    }
    
    int result = evaluate_postfix(argv[1]);
    printf("Result: %d\n", result);
    return 0;
}

int stack[100];
int top_of_stack = -1;

void push(int value) {
    if (top_of_stack < 99) {
        top_of_stack++;
        stack[top_of_stack] = value;
    } else {
        printf("Error: Stack overflow\n");
    }
}

int pop() {
    if (!is_empty()) {
        int value = stack[top_of_stack];
        top_of_stack--;
        return value;
    } else {
        printf("Error: Stack underflow\n");
        return 0;
    }
}

int is_empty() {
    return (top_of_stack == -1);
}

int top() {
    if (!is_empty()) {
        return stack[top_of_stack];
    } else {
        printf("Error: Stack is empty\n");
        return 0;
    }
}

int evaluate_postfix(char *expression) {
    int i, value1, value2;
    
    for (i = 0; expression[i]; i++) {
        if (isdigit(expression[i])) {
            push(expression[i] - '0');
        } else {
            value2 = pop();
            value1 = pop();
            
            switch (expression[i]) {
                case '+': push(value1 + value2); break;
                case '-': push(value1 - value2); break;
                case '*': push(value1 * value2); break;
                case '/': push(value1 / value2); break;
            }
        }
    }
    
    return top();
}