
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <integer1> <integer2>\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    int a = atoi(argv[1]);
    int b = atoi(argv[2]);
    
    if (a == 0 || b == 0) {
        printf("Invalid input. Both values must be non-zero.\n");
        return EXIT_FAILURE;
    }
    
    long long sum = (long long)a + b;
    long long product = (long long)a * b;
    
    if (sum > INT_MAX || sum < INT_MIN || product > INT_MAX || product < INT_MIN) {
        printf("The result is too large to represent as an integer.\n");
        return EXIT_FAILURE;
    }
    
    printf("Sum: %lld\n", sum);
    printf("Product: %lld\n", product);
    
    return EXIT_SUCCESS;
}