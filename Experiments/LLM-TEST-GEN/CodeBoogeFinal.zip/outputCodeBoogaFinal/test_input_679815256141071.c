
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    FILE *file;

    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        exit(1);
    }

    file = fopen(argv[1], "r");
    if (!file) {
        perror("Failed to open file");
        exit(1);
    }

    // Read some data from the file
    char buffer[256];
    while (fgets(buffer, sizeof(buffer), file)) {
        printf("%s", buffer);
    }

    if (ferror(file)) {
        perror("Error reading file");
        clearerr(file); // Clear the error indicator for the stream
    }

    fclose(file);
    return 0;
}