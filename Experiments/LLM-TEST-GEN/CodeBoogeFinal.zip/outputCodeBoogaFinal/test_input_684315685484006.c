
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

void register_allocation(int x, int y) {
    int result;
    asm("movl %1, %%eax;" // move x into eax
        "addl %2, %%eax"  // add y to eax
        : "=a" (result)
        : "r" (x), "r" (y));
    printf("The result of the addition is: %d\n", result);
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        perror("Usage: ./register_optimization <x> <y>\n");
        exit(1);
    }
    
    int x = atoi(argv[1]);
    int y = atoi(argv[2]);
    register_allocation(x, y);
    
    // Object file manipulation
    const char *obj_file = "output.o";
    int fd = open(obj_file, O_CREAT | O_WRONLY, 0644); // create and write to output.o
    if (fd == -1) {
        perror("Error opening file");
        exit(2);
    }
    
    char buffer[] = "Hello, World!";
    ssize_t bytes_written = write(fd, buffer, strlen(buffer));
    if (bytes_written == -1) {
        perror("Error writing to file");
        exit(3);
    }
    
    close(fd);
    return 0;
}