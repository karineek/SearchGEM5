
#include <stdio.h> // for printf and fprintf
#include <stdlib.h> // for atoi function
#include <string.h> // for strlen function

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <number>\n", argv[0]);
        return 1;
    }
    
    int number = atoi(argv[1]);
    int length = strlen(argv[1]);
    char extended_characters[] = "!@#$%^&*()"; // example of extended characters

    printf("Input: %s\n", argv[1]);
    printf("Number: %d\n", number);
    printf("Length: %d\n", length);
    printf("Extended characters: %s\n", extended_characters);
    
    return 0;
}