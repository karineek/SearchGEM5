
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <emmintrin.h> // include header file for SSE2 intrinsics

int main(int argc, char *argv[]) {
    int sum = 0;
    int i;
    __m128i *vsum = (__m128i *)&sum; // vectorized sum variable
    
    for (i = 1; i < argc; i += 4) {
        __m128i num1, num2, num3, num4;
        
        if (i + 3 < argc) {
            num1 = _mm_set1_epi32(atoi(argv[i])); // load and broadcast first argument
            num2 = _mm_set1_epi32(atoi(argv[i+1])); // load and broadcast second argument
            num3 = _mm_set1_epi32(atoi(argv[i+2])); // load and broadcast third argument
            num4 = _mm_set1_epi32(atoi(argv[i+3])); // load and broadcast fourth argument
            
            *vsum = _mm_add_epi32(*vsum, _mm_add_epi32(_mm_add_epi32(num1, num2), _mm_add_epi32(num3, num4)); // vectorized addition
        } else {
            for (; i < argc; ++i) {
                sum += atoi(argv[i]); // process remaining arguments one by one
            }
            break;
        }
    }
    
    if (argc > 1 && strcmp(argv[1], "-o") == 0) {
        printf("Generated code:\n");
        for (i = 2; i < argc - 3; i += 4) {
            printf("%s + %s + %s + %s\n", argv[i], argv[i+1], argv[i+2], argv[i+3]); // print generated code
        }
    }
    
    for (; i < argc; ++i) {
        sum += atoi(argv[i]); // process remaining arguments one by one
    }
    
    printf("Sum: %d\n", sum);
    return 0;
}