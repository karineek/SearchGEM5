
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 4) {
        printf("Usage: %s num1 operation num2\n", argv[0]);
        return 1;
    }

    double num1 = atof(argv[1]);
    double num2 = atof(argv[3]);
    char op = argv[2][0];

    switch (op) {
        case '+':
            printf("%f + %f = %f\n", num1, num2, num1 + num2);
            break;
        case '-':
            printf("%f - %f = %f\n", num1, num2, num1 - num2);
            break;
        case '*':
            printf("%f * %f = %f\n", num1, num2, num1 * num2);
            break;
        case '/':
            if (num2 == 0) {
                printf("Error: division by zero.\n");
            } else {
                printf("%f / %f = %f\n", num1, num2, num1 / num2);
            }
            break;
        case '^':
            if (num2 < 0 && num1 == 0) {
                printf("Error: 0 raised to a negative power.\n");
            } else {
                printf("%f ^ %f = %f\n", num1, num2, pow(num1, num2));
            }
            break;
        default:
            printf("Error: invalid operation '%c'.\n", op);
    }

    return 0;
}