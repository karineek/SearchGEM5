
#include <stdio.h>
#include "llvm/Analysis/LoopInfo.h"
#include "llvm/Transforms/Scalar.h"
#include "llvm/IR/LegacyPassManager.h"
#include "llvm/Support/Debug.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/Function.h"
#include "llvm/IRReader/IRReader.h"
#include "llvm/Support/SourceMgr.h"
#include "llvm/Pass.h"
#include "llvm/IR/LLVMContext.h"
#include "llvm/Bitcode/BitcodeReader.h"
#include "llvm/Support/FileSystem.h"
#include "llvm/Support/raw_ostream.h"

using namespace llvm;

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input_bitcode_file>\n", argv[0]);
        return 1;
    }

    LLVMContext context;
    SMDiagnostic error;
    std::unique_ptr<Module> module = parseIRFile(argv[1], error, context);
    if (!module) {
        error.print(argv[0], errs());
        return 1;
    }

    legacy::PassManager passManager;
    passManager.add(createLoopInfoWrapperPass()); // Loop fusion analysis
    passManager.add(new LoopFusePass());       // Loop fusion transformation
    passManager.run(*module);

    std::error_code ec;
    raw_fd_ostream os("output.bc", ec, sys::fs::OF_None);
    WriteBitcodeToFile(module.get(), os);

    return 0;
}