
#include <stdio.h>
#include <stdlib.h>

// Function for checking if two integers are equal
int is_equal(int a, int b) {
    return (a == b);
}

// Main function
int main(int argc, char *argv[]) {
    // Check if the number of arguments is correct
    if (argc != 3) {
        printf("Usage: ./program <num1> <num2>\n");
        return 0;
    }
    
    // Convert the input strings to integers
    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);

    // Check if the two numbers are equal using a function call (function inlining optimization)
    int result = is_equal(num1, num2);

    // Print the result
    if (result == 0) {
        printf("%d and %d are not equal\n", num1, num2);
    } else {
        printf("%d and %d are equal\n", num1, num2);
    }
    
    return 0;
}