
#include <stdio.h>
#include <stdlib.h>
#include <immintrin.h> // AVX intrinsics
#include <smmintrin.h> // SSE4.2 intrinsics
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s input_file\n", argv[0]);
        return -1;
    }
    
    FILE *fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen");
        return -1;
    }
    
    int n, count = 0;
    long sum = 0;
    while (fscanf(fp, "%d", &n) == 1) {
        sum += n;
        count++;
    }
    
    if (!feof(fp)) {
        perror("fscanf");
        fclose(fp);
        return -1;
    }
    fclose(fp);
    
    printf("Sum of %d integers: %ld\n", count, sum);
    return 0;
}