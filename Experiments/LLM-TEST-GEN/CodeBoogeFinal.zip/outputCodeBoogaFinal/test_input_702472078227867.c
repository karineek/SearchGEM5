
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

inline int bitand(int a, int b) {
    return a & b;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s num1 num2\n", argv[0]);
        exit(1);
    }

    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);

    int result = bitand(num1, num2);

    printf("Bitwise AND of %d and %d: %d\n", num1, num2, result);

    return 0;
}