
#include <stdio.h>
#include <stdlib.h>

int sum_recursive(int arr[], int start, int end) {
    if (start == end) {
        return arr[start];
    } else {
        return arr[start] + sum_recursive(arr, start+1, end);
    }
}

int main(int argc, char *argv[]) {
    int arr[] = {5, 7, 3, 2, 8};
    int n = sizeof(arr) / sizeof(arr[0]);
    
    if (argc != 3) {
        printf("Usage: %s <index> <value>\n", argv[0]);
        return 1;
    }
    
    int index = atoi(argv[1]);
    int value = atoi(argv[2]);
    
    if (index >= n || index < 0) {
        printf("Index out of range.\n");
    } else {
        printf("Sum: %d\n", sum_recursive(arr, 0, n-1));
        
        if (value > arr[index]) {
            printf("%d is greater than the value at index %d (%d).\n", value, index, arr[index]);
        } else if (value < arr[index]) {
            printf("%d is less than the value at index %d (%d).\n", value, index, arr[index]);
        } else {
            printf("%d is equal to the value at index %d.\n", value, index);
        }
    }
    
    return 0;
}