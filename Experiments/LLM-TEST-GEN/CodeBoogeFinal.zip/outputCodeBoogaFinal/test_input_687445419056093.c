
#include <stdio.h>

int main(int argc, char *argv[]) {
    int num1 = atoi(argv[1]); // Convert the first argument to an integer
    int num2 = atoi(argv[2]); // Convert the second argument to an integer
    
    // Constant folding optimization: the result of this operation is known at compile time,
    // so the compiler can replace it with the actual value (10)
    const int ten = 5 + 5;

    printf("The sum of %d and %d is: %d\n", num1, num2, num1 + num2);
    printf("The value of ten is: %d\n", ten);

    return 0;
}