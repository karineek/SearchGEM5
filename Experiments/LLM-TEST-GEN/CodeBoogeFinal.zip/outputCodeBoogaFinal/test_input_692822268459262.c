
#include <stdio.h>
#include <stdlib.h>

void convert_seconds(int seconds) {
    int hrs = seconds / 3600;
    int mins = (seconds % 3600) / 60;
    int secs = seconds % 60;

    printf("%d seconds is equivalent to %d hours, %d minutes, and %d seconds\n", seconds, hrs, mins, secs);
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./program <seconds>\n");
        return 1;
    }

    int input_seconds = atoi(argv[1]); // Convert the input string to an integer
    convert_seconds(input_seconds);

    return 0;
}