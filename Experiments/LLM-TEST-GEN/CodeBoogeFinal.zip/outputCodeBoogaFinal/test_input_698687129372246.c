
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <num1> <num2>\n", argv[0]);
        return 1;
    }

    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);
    int sum = num1 + num2; // constant folding optimization: the result of this expression is known at compile time, so it will be computed by the compiler
    
    printf("The sum of %d and %d is %d\n", num1, num2, sum);

    char buffer[32] __attribute__((aligned(64))); // fundamental alignment: the 'buffer' array will be aligned to a 64-byte boundary

    strcpy(buffer, "This is an example of constant folding and fundamental alignment in C.");
    printf("%s\n", buffer);

    return 0;
}