
#include <stdio.h>
#include <stdlib.h>
#include <stdatomic.h>
#include <assert.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        return EXIT_FAILURE;
    }
    int n = atoi(argv[1]);
    if (n < 0) {
        printf("Error: Input must be a non-negative integer.\n");
        return EXIT_FAILURE;
    }
    
    // Memory-to-Register Promotion
    register int result = 1;
    register int i;
    
    // Serialization
    atomic_int fact = ATOMIC_VAR_INIT(1);
    
    for (i = 1; i <= n; ++i) {
        fact = fact * i;
    }
    
#if ATOMIC_BOOL_LOCK_FREE == 2
    printf("ATOMIC_BOOL_LOCK_FREE: Yes\n");
#else
    printf("ATOMIC_BOOL_LOCK_FREE: No\n");
#endif
    
    printf("Factorial of %d is %u\n", n, fact);
    return EXIT_SUCCESS;
}