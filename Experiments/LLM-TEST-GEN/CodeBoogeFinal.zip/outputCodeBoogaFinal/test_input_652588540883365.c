
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program <number1> <number2>\n");
        return 1;
    }
    
    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);
    
    if (num2 > num1) {
        printf("The positive difference is: %d\n", num2 - num1);
    } else {
        printf("%d is not greater than %d.\n", num2, num1);
    }
    
    return 0;
}