
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./multiplication_table <start> <end>\n");
        return -1;
    }

    int start = atoi(argv[1]);
    int end = atoi(argv[2]);

    if (start <= 0 || end <= 0) {
        printf("Start and end values must be positive integers.\n");
        return -1;
    }

    for (int i = start; i <= end; ++i) {
        for (int j = start; j <= end; ++j) {
            int product = i * j;
            printf("%d x %d = %d\n", i, j, product);
        }
    }

    return 0;
}