
#include <stdio.h>
#include <stdlib.h>
#include <complex.h>
#include "clang-c/Index.h" // Include clang header file for C Index API

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <real> <imaginary>\n", argv[0]);
        return 1;
    }

    double real = atof(argv[1]), imag = atof(argv[2]);
    double _Complex c1 = real + imag * I; // Constant Folding optimization triggered here (real + imaginary)

    printf("Sum of complex numbers: %f + %fi\n", creal(c1), cimag(c1));

    double result = cabs(c1); // Conversion from double _Complex to double
    printf("Absolute value (double): %f\n", result);

    return 0;
}