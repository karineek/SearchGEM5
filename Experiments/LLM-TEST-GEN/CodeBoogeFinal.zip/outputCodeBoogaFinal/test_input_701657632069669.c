
#include <stdio.h>
#include <string.h>
#include <ctype.h> // Character handling header
#include <stdlib.h> // For exit() function

// Target specific architecture - x86_64
#ifdef __x86_64__
    #define HAS_TARGET_SPECIFIC_OPTIMIZATIONS 1
#else
    #define HAS_TARGET_SPECIFIC_OPTIMIZATIONS 0
#endif

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input_string>\n", argv[0]);
        exit(1);
    }

    const char* input = argv[1];
    int length = strlen(input);

    for (int i = 0; i < length; i++) {
#if HAS_TARGET_SPECIFIC_OPTIMIZATIONS
        // Loop optimization - unrolling by a factor of 2
        if (i + 1 < length) {
            input[i] = toupper((unsigned char)input[i]);
            input[i+1] = toupper((unsigned char)input[i+1]);
            i++;
        } else {
            input[i] = toupper((unsigned char)input[i]);
        }
#else
        input[i] = toupper((unsigned char)input[i]);
#endif
    }

    printf("Converted string: %s\n", input);

    return 0;
}