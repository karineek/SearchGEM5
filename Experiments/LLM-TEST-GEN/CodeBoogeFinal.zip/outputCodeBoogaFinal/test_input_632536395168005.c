
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // Check if the user provided an argument
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }
    
    int num = atoi(argv[1]);
    if (is_even(num)) {
        printf("%d is even\n", num);
    } else {
        printf("%d is odd\n", num);
    }
    
    return 0;
}

int is_even(int num) {
    // Dead Code Elimination optimization: the condition "num % 2 == 0" will be computed at compile time
    if (num % 2 == 0) {
        return 1;
    } else {
        return 0;
    }
}