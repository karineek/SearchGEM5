
#include <stdio.h>
#include <stdlib.h>
#include <immintrin.h> // include header for AVX intrinsics

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        return -1;
    }
    int input = atoi(argv[1]);
    __m256i vinput = _mm256_set1_epi32(input); // load input into vector register
    __m256i vresult = _mm256_mullo_epi32(vinput, vinput); // square the integer using AVX instruction
    int result[8];
    _mm256_storeu_si256((__m256i*)result, vresult); // store vector register to memory
    printf("Square of %d is: %d\n", input, result[0]);
    return 0;
}