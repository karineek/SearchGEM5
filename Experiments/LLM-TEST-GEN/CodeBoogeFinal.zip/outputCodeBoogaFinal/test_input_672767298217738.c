
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program num1 num2\n");
        return 1;
    }
    
    double a = atof(argv[1]);
    double b = atof(argv[2]);
    
    // Common subexpression elimination example
    double c = a + b;
    printf("a + b = %lf\n", c);
    printf("a * b = %lf\n", a * b);
    
    // Static analysis in Clang example
    double max = fmaxl(a, b);
    printf("The maximum value is: %lf\n", max);
    
    return 0;
}