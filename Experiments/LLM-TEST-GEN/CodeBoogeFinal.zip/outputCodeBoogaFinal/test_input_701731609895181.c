
#include <stdio.h>
#include <stdarg.h>

int sum(int count, ...) {
    int total = 0;
    va_list ap;
    va_start(ap, count);
    
    for (int i = 0; i < count; i++) {
        int num = va_arg(ap, int);
        total += num;
    }
    
    va_end(ap);
    return total;
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: ./program <num1> <num2> <num3>\n");
        return 1;
    }
    
    int total = sum(argc - 1, argv[1], argv[2], argv[3]);
    printf("Sum of the given numbers: %d\n", total);
    return 0;
}