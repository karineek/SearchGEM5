
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "clang-c/Index.h" // Header file for Clang frontend

// Function specialization using C11 _Generic keyword
int add(int a, int b) {
    return a + b;
}
double add(double a, double b) {
    return a + b;
}

typedef struct { // Structure definition
    char name[50];
    int age;
} Person;

int main(int argc, char *argv[]) {
    if (argc != 4) {
        printf("Usage: %s <name> <age> <double_num1> <double_num2>\n", argv[0]);
        return 1;
    }
    
    Person p;
    strcpy(p.name, argv[1]);
    p.age = atoi(argv[2]);

    double num1 = atof(argv[3]);
    double num2 = atof(argv[4]);

    printf("Name: %s\n", p.name);
    printf("Age: %d\n", p.age);
    printf("%f + %f = %f\n", num1, num2, add(num1, num2));
    
    return 0;
}