
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <num1> <num2>\n", argv[0]);
        return 1;
    }
    
    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);

    // Scalar optimizations with contracted expression (num1 + num2) * 2
    int result = (num1 + num2) << 1;
    
    printf("Result: %d\n", result);

    return 0;
}