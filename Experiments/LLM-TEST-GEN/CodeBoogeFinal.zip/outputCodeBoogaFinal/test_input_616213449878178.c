
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }
    
    char* token = strtok(argv[1], " ");
    while (token != NULL) {
        int num = atoi(token);
        
        if (num > 0) {
            printf("%d is positive.\n", num);
        } else if (num < 0) {
            printf("%d is negative.\n", num);
        } else {
            printf("%d is zero.\n", num);
        }
        
        token = strtok(NULL, " ");
    }
    
    return 0;
}