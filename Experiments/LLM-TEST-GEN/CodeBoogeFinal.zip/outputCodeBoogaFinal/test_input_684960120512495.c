
#include <stdio.h>

const int add(int a, int b) {
    return a + b;
}

const int multiply(int a, int b) {
    return a * b;
}

int main(int argc, char* argv[]) {
    if (argc < 4) {
        printf("Usage: %s num1 operation num2\n", argv[0]);
        return 1;
    }
    
    int a = atoi(argv[1]);
    int b = atoi(argv[3]);
    
    if (strcmp(argv[2], "+") == 0) {
        printf("%d\n", add(a, b));
    } else if (strcmp(argv[2], "*") == 0) {
        printf("%d\n", multiply(a, b));
    } else {
        printf("Invalid operation.\n");
    }
    
    return 0;
}