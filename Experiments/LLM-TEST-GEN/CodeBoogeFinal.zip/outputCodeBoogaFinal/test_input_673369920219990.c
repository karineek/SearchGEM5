
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

// Function to be inlined
static inline int add(int a, int b) {
    return a + b;
}

// Main function
int main(int argc, char *argv[]) {
    // Ensure correct number of arguments are passed
    assert(argc == 3);
    
    // Convert input to integers
    int x = atoi(argv[1]);
    int y = atoi(argv[2]);

    // Perform addition using inline function
    int result = add(x, y);

    printf("The sum of %d and %d is: %d\n", x, y, result);
    
    return 0;
}