
#include <stdio.h> // standard input/output library
#include <stdlib.h> // standard library

int main(int argc, char *argv[]) {
    int num = atoi(argv[1]); // convert string argument to integer
    printf("Original number: %d\n", num); // print original number
    
    --num; // prefix decrement operator
    printf("After prefix decrement: %d\n", num); // print decremented number
    
    int sum = num + 5; // constant folding example, sum is calculated at compile time
    printf("Sum of decremented number and 5: %d\n", sum); // print the sum
    
    return 0;
}