
#include <stdio.h>
#include <time.h>

struct tm {
    int tm_sec;   // Seconds (0-60)
    int tm_min;  // Minutes (0-59)
    int tm_hour; // Hours (0-23)
    int tm_mday; // Day of the month (1-31)
    int tm_mon;  // Month (0-11)
    int tm_year; // Year - 1900
    int tm_wday; // Day of the week (0-6, Sunday = 0)
    int tm_yday; // Day in the year (0-365)
    int tm_isdst;// Daylight saving time
};

struct tm *get_time(int argc, char **argv);

int main(int argc, char **argv) {
    struct tm *tm_ptr = get_time(argc, argv);
    
    if (tm_ptr != NULL) {
        printf("Time: %d:%02d:%02d\n", tm_ptr->tm_hour, tm_ptr->tm_min, tm_ptr->tm_sec);
        printf("Date: %d/%d/%d\n", tm_ptr->tm_mon + 1, tm_ptr->tm_mday, tm_ptr->tm_year + 1900);
    } else {
        printf("Invalid input format. Please enter time in HH:MM:SS format.\n");
    }
    
    return 0;
}

struct tm *get_time(int argc, char **argv) {
    if (argc != 2) {
        return NULL;
    }
    
    time_t rawtime = time(NULL);
    struct tm *tm_ptr = localtime(&rawtime);
    
    int hour, min, sec;
    sscanf(argv[1], "%d:%d:%d", &hour, &min, &sec);
    
    if (hour >= 0 && hour < 24 && min >= 0 && min < 60 && sec >= 0 && sec < 60) {
        tm_ptr->tm_sec = sec;
        tm_ptr->tm_min = min;
        tm_ptr->tm_hour = hour;
    } else {
        return NULL;
    }
    
    return tm_ptr;
}