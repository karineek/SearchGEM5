
#include <stdio.h>

// Function specialization for int data type
int func_specialization(int a, int b) {
    return a + b;
}

// Function that calls the specialized function based on input arguments
int func(int argc, char *argv[]) {
    // Check if there are two command-line arguments
    if (argc != 3) {
        printf("Usage: %s <num1> <num2>\n", argv[0]);
        return -1;
    }

    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);

    // Call the function specialized for int data type
    int result = func_specialization<%int>(num1, num2);

    printf("Result: %d\n", result);

    return 0;
}

int main(int argc, char *argv[]) {
    return func(argc, argv);
}