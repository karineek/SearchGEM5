
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

// Function to calculate 2 raised to a given power using Taylor series expansion
double cexp2(int n) {
    double sum = 1; // Initialize sum as 1 (e^0 = 1)
    int i, factorial = 1;
    
    for (i = 1; i <= n; i++) {
        factorial *= i; // Calculate the factorial of the current iteration
        double term = pow(2, i) / factorial; // Calculate the current term in the series
        sum += term; // Add the term to the sum
    }
    
    return sum;
}

int main(int argc, char *argv[]) {
    if (argc != 2) { // Check that there is exactly one command line argument
        printf("Usage: ./program <n>\n");
        return 1;
    }
    
    int n = atoi(argv[1]); // Convert the input string to an integer
    
    if (n < 0) { // Check that the input is non-negative
        printf("Error: Input must be a non-negative integer.\n");
        return 1;
    }
    
    double result = cexp2(n); // Calculate 2 raised to the power of n using cexp2 function
    printf("2^%d = %.15f\n", n, result); // Print the result with 15 decimal places
    
    return 0;
}