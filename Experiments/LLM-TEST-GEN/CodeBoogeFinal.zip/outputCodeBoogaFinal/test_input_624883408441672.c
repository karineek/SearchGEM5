
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

int main(int argc, char *argv[]) {
    int a, b;
    
    if (argc != 3) {
        printf("Usage: %s <num1> <num2>\n", argv[0]);
        return 1;
    }
    
    a = atoi(argv[1]);
    b = atoi(argv[2]);
    
#ifndef NDEBUG
    printf("Debug: a = %d, b = %d\n", a, b);
#endif

    int sum = a + b;
    printf("Sum of %d and %d is %d\n", a, b, sum);
    
    return 0;
}