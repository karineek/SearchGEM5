
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <ctype.h>

// Function to perform left shift assignment operation
void left_shift_assignment(uint32_t *num, int count) {
    *num <<= count;
}

// Function to reverse a string in-place
char* reverse_string(char *str) {
    int len = strlen(str);
    for (int i = 0; i < len / 2; ++i) {
        char temp = str[i];
        str[i] = str[len - i - 1];
        str[len - i - 1] = temp;
    }
    return str;
}

// Function to convert string to uppercase
char* to_upper(char *str) {
    for (int i = 0; i < strlen(str); ++i) {
        str[i] = toupper(str[i]);
    }
    return str;
}

// Main function that uses the above functions and performs operations on input string
int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <string>\n", argv[0]);
        exit(1);
    }

    // Input validation
    for (int i = 0; i < strlen(argv[1]); ++i) {
        if (!isalpha(argv[1][i])) {
            printf("Input should only contain alphabets.\n");
            exit(1);
        }
    }
    
    // Reverse the input string and convert to uppercase
    char *input_str = argv[1];
    reverse_string(input_str);
    to_upper(input_str);

    uint32_t num = 0;
    for (int i = 0; i < strlen(input_str); ++i) {
        left_shift_assignment(&num, input_str[i] - 'A' + 1);
    }

    printf("Result: %u\n", num);
    return 0;
}