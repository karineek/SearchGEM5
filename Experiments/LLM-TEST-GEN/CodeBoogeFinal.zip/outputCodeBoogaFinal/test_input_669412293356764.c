
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to calculate the sum of two integers
int add(int a, int b) {
    return a + b;
}

// Function to print an integer
void print_integer(int num) {
    printf("The result is: %d\n", num);
}

// Function to calculate the product of two integers
int multiply(int a, int b) {
    return a * b;
}

// Main function that takes input from argv and performs operations on it
int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program <num1> <num2>\n");
        return -1;
    }
    
    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);
    
    // Interprocedural Optimization example
    int sum = add(num1, num2);
    print_integer(sum);
    
    // Serialization example
    char buffer[100];
    sprintf(buffer, "%d", sum);
    printf("The serialized number is: %s\n", buffer);
    
    // Constant expression example
    const int constant = 10;
    int product = multiply(sum, constant);
    print_integer(product);

    return 0;
}