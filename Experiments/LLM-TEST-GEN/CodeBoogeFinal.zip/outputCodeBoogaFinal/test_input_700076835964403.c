
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

int main(int argc, char* argv[]) {
    if (argc != 3) {
        printf("Usage: %s num1 num2\n", argv[0]);
        return 1;
    }

    int a = atoi(argv[1]), b = atoi(argv[2]);
    assert(a >= 0 && b >= 0);

    int sum = 0;
    for (int i = 0; i <= a; ++i) {
        if (a % i == 0 && b % i == 0) { // Check before dividing
            sum += i;
        }
    }

    printf("Sum of common divisors: %d\n", sum);
    return 0;
}