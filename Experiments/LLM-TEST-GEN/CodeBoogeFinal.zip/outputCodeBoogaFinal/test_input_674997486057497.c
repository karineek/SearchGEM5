
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }

    int num = atoi(argv[1]);
    register int a asm("eax") = num, b asm("ebx") = num, square asm("ecx");
    square = (a * b); // using cast operator to perform multiplication

    printf("%d^2 = %d\n", num, square);
    return 0;
}