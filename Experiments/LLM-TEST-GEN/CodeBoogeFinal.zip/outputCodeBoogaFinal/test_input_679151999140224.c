
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <num1> <num2>\n", argv[0]);
        return 1;
    }

    int num1 = atoi(argv[1]), num2 = atoi(argv[2]);
    if (num1 > INT_MAX || num2 > INT_MAX) {
        printf("Error: Inputs must be integers.\n");
        return 1;
    }

    int sum = num1 + num2, diff = num1 - num2;
    printf("Sum: %d\n", sum);
    printf("Difference: %d\n", diff);

    return 0;
}