
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <immintrin.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program source_string destination_string\n");
        return 1;
    }

    // Ensure that both input strings are 64 bytes aligned for vectorization
    const size_t len = strlen(argv[1]);
    char *source = (char *) _mm_malloc(len + 63, 64);
    char *dest = (char *) _mm_malloc(len + 63, 64);

    if (!source || !dest) {
        printf("Failed to allocate memory\n");
        return 1;
    }

    strcpy(source, argv[1]);

    // Vectorized implementation of strcpy using AVX instructions
    size_t i = 0;
    for (; i < len - 63; i += 64) {
        __m256i *s = (__m256i *)(source + i);
        __m256i *d = (__m256i *)(dest + i);

        d[0] = _mm256_loadu_si256(s);
    }

    // Copy the remaining bytes that are less than 64
    for (; i < len; i++) {
        dest[i] = source[i];
    }

    dest[len] = '\0';

    printf("Vectorized strcpy result: %s\n", dest);

    _mm_free(source);
    _mm_free(dest);

    return 0;
}