
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h> // For target-specific optimizations

// Function declarations
int is_valid(const char *input);
void print_hello();
void print_world();

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input>\n", argv[0]);
        return 1;
    }

    const char *input = argv[1];
    
    // Check if the input is valid
    if (is_valid(input)) {
        print_hello();
        
        // Execute print_world() only if print_hello() was successful
        __builtin_expect(print_world(), 0);
    } else {
        printf("Invalid input\n");
    }
    
    return 0;
}

int is_valid(const char *input) {
    // Check if the input contains only alphabetic characters and underscores
    for (size_t i = 0; i < strlen(input); i++) {
        if (!((input[i] >= 'A' && input[i] <= 'Z') || (input[i] >= 'a' && input[i] <= 'z') || input[i] == '_')) {
            return 0;
        }
    }
    
    return 1;
}

void print_hello() {
    printf("Hello\n");
}

void print_world() {
    printf("World\n");
}