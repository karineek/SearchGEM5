
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s input_string\n", argv[0]);
        return -1;
    }

    char *input = argv[1];
    int length = strlen(input);

    // Register allocation optimization example: copy string to register
    char register *reg_str = input;

    printf("Input string: %s\n", reg_str);
    printf("Length of input string: %d\tAddress of input string in memory: %p\n", length, (void *)input);
    printf("Register optimized: Address of register string: %p\n", (void *)reg_str);

    return 0;
}