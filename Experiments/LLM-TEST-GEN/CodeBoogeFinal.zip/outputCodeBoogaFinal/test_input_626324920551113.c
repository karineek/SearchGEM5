
#include <stdio.h>
#include <stdlib.h>

// Declare square as an inline function
static inline int square(int x) {
    return x * x;
}

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        exit(1);
    }

    int num = atoi(argv[1]);
    int result = square(num);
    printf("The square of %d is %d\n", num, result);

    return 0;
}