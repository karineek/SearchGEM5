
#include <stdio.h>
#include <float.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <number1> <number2>\n", argv[0]);
        return -1;
    }
    
    float num1 = atof(argv[1]);
    float num2 = atof(argv[2]);
    
    if (FLT_HAS_SUBNORM == 0) {
        printf("The platform does not support subnormal numbers.\n");
    } else {
        printf("The platform supports subnormal numbers.\n");
    }
    
    float sum = num1 + num2;
    printf("Sum: %f\n", sum);
    
    return 0;
}