
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s n\n", argv[0]);
        return -1;
    }

    int n = atoi(argv[1]);
    long long sum = 0;

    for (int i = 1; i <= n; i++) {
        sum += i * i;
    }

    printf("Sum of squares from 1 to %d: %lld\n", n, sum);
    return 0;
}