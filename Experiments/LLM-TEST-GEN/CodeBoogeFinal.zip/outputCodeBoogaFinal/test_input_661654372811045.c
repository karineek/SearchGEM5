
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

int main(int argc, char **argv) {
    // Check if the input is valid (at least one argument is provided)
    if (argc < 2) {
        printf("Please provide an input string.\n");
        return 1;
    }
    
    char *input = argv[1];
    
    // Calculate the length of the input string
    size_t len = strlen(input);
    
    // Allocate memory for a new string to store the reversed input
    char *reversed = (char *)malloc((len + 1) * sizeof(char));
    if (!reversed) {
        perror("Memory allocation failed");
        return 1;
    }
    
    // Loop through the input string and store it in reversed order
    for (int i = len - 1, j = 0; i >= 0; i--, j++) {
        reversed[j] = input[i];
    }
    reversed[len] = '\0'; // Add null terminator to the end of the string
    
    printf("Reversed input: %s\n", reversed);
    
    free(reversed); // Free allocated memory
    return 0;
}