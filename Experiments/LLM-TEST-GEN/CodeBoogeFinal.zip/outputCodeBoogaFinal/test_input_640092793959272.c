
#include <stdio.h>
#include <stdlib.h>
#include <immintrin.h>

typedef struct {
    int sign;
    unsigned n;
} n_sign_posn;

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }
    
    int num = atoi(argv[1]);
    n_sign_posn input;
    input.sign = (num >= 0) - (num < 0); // Store the sign of the input number
    input.n = abs(num);               // Store the absolute value of the input number
    
    __m128i vnum = _mm_set1_epi32(input.sign * input.n);  // Load the input number into an SSE register as a vector
    __m128i square = _mm_mullo_epi32(vnum, vnum);     // Calculate the square of the input number using vector multiplication
    
    int result[4];
    _mm_storeu_si128((__m128i*)result, square);  // Store the result vector back into an array
    
    printf("The square of %d is: %d\n", num, result[0]); // Print the first (and only) element of the result array
    
    return 0;
}