
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input_string>\n", argv[0]);
        return 1;
    }

    int i = 0, j = 0, count = 0, len = strlen(argv[1]);

    // Loop Optimizations
    for (i = 0; i < len - 1; i++) {
        if (argv[1][i] == ' ') {
            count++;
        }
    }

    printf("Number of spaces in the input string: %d\n", count);

    // Object and Binary Format
    int binary_len = 8 * sizeof(int) * len;  
    unsigned char *binary = (unsigned char *)malloc(binary_len);

    for (i = 0; i < len; i++) {
        for (j = 0; j < 8; j++) {
            binary[8 * i + j] = ((argv[1][i] >> j) & 1);
        }
    }

    printf("Binary representation of input string: ");
    for (i = 0; i < binary_len; i++) {
        printf("%d", binary[i]);
    }
    printf("\n");

    free(binary);

    return 0;
}