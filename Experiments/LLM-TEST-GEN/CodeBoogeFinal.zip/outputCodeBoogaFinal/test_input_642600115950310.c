
#include <stdio.h>
#include <wchar.h>
#include <stdlib.h>
#include <errno.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s number\n", argv[0]);
        return 1;
    }

    errno = 0;
    unsigned long long int num = wcstoull(argv[1], NULL, 10);

    if (errno != 0) {
        perror("wcstoull");
        return 1;
    }

    printf("Converted number: %llu\n", num);

    return 0;
}