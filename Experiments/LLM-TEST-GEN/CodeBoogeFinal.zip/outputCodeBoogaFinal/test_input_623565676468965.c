
#include <stdio.h>
#include <stdlib.h>

// Function to calculate square of a number
int square(int num) {
    return num * num;
}

int main(int argc, char **argv) {
    // Check if the input argument is provided
    if (argc != 2) {
        printf("Usage: ./program <integer>\n");
        return 1;
    }

    // Convert the input string to integer
    int num = atoi(argv[1]);

    // Calculate square using Common Subexpression Elimination optimization
    int result = square(num);

    // Print the result
    printf("Square of %d is %d\n", num, result);

    return 0;
}