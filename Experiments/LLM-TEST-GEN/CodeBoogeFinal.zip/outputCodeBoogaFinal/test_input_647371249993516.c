
#include <stdio.h>
#include <stdlib.h>
#include <stdatomic.h>
#include <inttypes.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return -1;
    }

    int64_t input = strtol(argv[1], NULL, 10);
    atomic_int64_t counter;
    atomic_init(&counter, 0);
    
    if (atomic_is_lock_free(&counter)) {
        printf("The counter is lock-free.\n");
    } else {
        printf("The counter is not lock-free.\n");
    }
    
    for(int64_t i = 0; i < input; ++i) {
        atomic_fetch_add(&counter, 1);
    }

    int64_t final_value = atomic_load(&counter);
    printf("Final value of counter: %" PRId64 "\n", final_value);
    
    return 0;
}