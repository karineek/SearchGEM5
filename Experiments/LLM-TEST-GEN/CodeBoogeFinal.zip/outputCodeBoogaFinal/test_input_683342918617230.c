
#include <stdio.h>
#include <stdlib.h>
#include <stdatomic.h>
#include <omp.h>

int main(int argc, char *argv[]) {
    int n = atoi(argv[1]); // Get input size from command line argument
    double *a = (double *) malloc(n * sizeof(double));
    double *b = (double *) malloc(n * sizeof(double));
    double *c = (double *) malloc(n * sizeof(double));

    for (int i = 0; i < n; i++) {
        a[i] = i + 1.0;
        b[i] = 2 * i + 1.0;
    }

    #pragma omp parallel for simd
    for (int i = 0; i < n; i++) {
        c[i] = a[i] + b[i]; // Vectorized operation
    }

    atomic_int sum = 0;
    #pragma omp parallel for reduction(+:sum)
    for (int i = 0; i < n; i++) {
        sum += c[i]; // Atomic operation
    }

    printf("Sum of elements in array c is %d\n", sum);

    free(a);
    free(b);
    free(c);
    return 0;
}