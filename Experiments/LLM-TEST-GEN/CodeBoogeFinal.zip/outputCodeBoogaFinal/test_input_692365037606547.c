
#include <stdio.h>
#include <math.h>
#include <tgmath.h>

// Type-Generic Macro for Arithmetic Operations
#define ARITHMETIC_OP(op, a, b) \
    _Generic((a), \
        double: _Generic((b), \
            double: (double)(a) op (double)(b), \
            float: (double)(a) op (float)(b), \
            int: (double)(a) op (int)(b)), \
        float: _Generic((b), \
            double: (float)(a) op (double)(b), \
            float: (float)(a) op (float)(b), \
            int: (float)(a) op (int)(b)), \
        int: _Generic((b), \
            double: (int)op(double)(a) op (double)(b), \
            float: (int)(a) op (float)(b), \
            int: (int)(a) op (int)(b)) \
    )

// Common Subexpression Elimination Optimization for Sum of Two Values
#define SUM(a, b) ARITHMETIC_OP(+, a, b)

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program <value1> <value2>\n");
        return 1;
    }
    
    double val1 = atof(argv[1]);
    double val2 = atof(argv[2]);
    
    // Calculate sum and store it in a variable to eliminate common subexpression
    double sum = SUM(val1, val2);
    
    // Find logarithm of absolute value of Gamma function for both values
    printf("lgamma(%f) + lgamma(%f) = %f\n", val1, val2, lgamma(sum));
    
    return 0;
}