
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int integer_part;
    int frac_digits; // fractional digits
} Fraction;

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <integer> <fraction>\n", argv[0]);
        return 1;
    }

    Fraction frac;
    frac.integer_part = atoi(argv[1]);
    frac.frac_digits = atoi(argv[2]);

    printf("Input: %d.%d\n", frac.integer_part, frac.frac_digits);

    return 0;
}