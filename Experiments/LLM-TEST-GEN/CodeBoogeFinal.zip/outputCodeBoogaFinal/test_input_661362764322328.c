
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <errno.h>

// Comparison function for qsort_s
int cmpfunc(const void *a, const void *b, void *ctx) {
    int diff = *(int *)a - *(int *)b;
    if (diff > 0) {
        return 1;
    } else if (diff < 0) {
        return -1;
    } else {
        return 0;
    }
}

// Checks if the input string can be converted to an integer
bool is_integer(const char *str) {
    for (int i = 0; str[i] != '\0'; i++) {
        if (!isdigit(str[i])) {
            return false;
        }
    }
    return true;
}

int main(int argc, char *argv[]) {
    // Check if the number of arguments is at least 2 (including program name)
    if (argc < 2) {
        printf("Please provide at least one integer argument\n");
        return 1;
    }

    int arr[argc - 1];
    int n = 0;

    // Convert the command line arguments to integers and store them in an array
    for (int i = 1; i < argc; i++) {
        if (!is_integer(argv[i])) {
            printf("Invalid input: %s is not an integer\n", argv[i]);
            return 2;
        }
        arr[n++] = atoi(argv[i]);
    }

    // Sort the array using qsort_s
    qsort_s(arr, n, sizeof(int), cmpfunc, NULL);

    // Print the sorted array
    printf("Sorted array: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    return 0;
}