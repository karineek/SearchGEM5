
#include <stdio.h>
#include <stdlib.h>
#include <float.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./program [input]\n");
        return 1;
    }
    
    double input = atof(argv[1]);
    
    // Code using input goes here
    
    printf("DBL_MANT_DIG macro: %d\n", DBL_MANT_DIG);
    return 0;
}