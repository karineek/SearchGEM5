
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    float real;
    float imag;
} complex_t;

complex_t add(complex_t a, complex_t b) {
    complex_t sum = {a.real + b.real, a.imag + b.imag};
    return sum;
}

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: %s <complex_number1> <complex_number2>\n", argv[0]);
        return 1;
    }

    complex_t num1 = {.real = atof(argv[1])}; // constant folding
    complex_t num2 = {.real = atof(argv[2])};
    complex_t result = add(num1, num2);

    printf("The sum of %f + %f is %f\n", num1.real, num2.real, result.real);

    return 0;
}