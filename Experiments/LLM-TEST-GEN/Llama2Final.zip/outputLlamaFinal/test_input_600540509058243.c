
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>

#define MAX_INPUT_LEN 1024

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: %s <input_string>\n", argv[0]);
        return 1;
    }

    char input_string[MAX_INPUT_LEN];
    sprintf(input_string, "%s ", argv[1]); // constant folding

    int result = wscanf_s(input_string, sizeof(input_string), "%d", &x);
    if (result != 1) {
        printf("Error: %s\n", strerror(errno));
        return 1;
    }

    printf("%d\n", x);

    return 0;
}