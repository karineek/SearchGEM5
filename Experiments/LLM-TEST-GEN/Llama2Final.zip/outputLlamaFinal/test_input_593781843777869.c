
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "llvm-inliner.h"

// Define a function to inline
void foo(int x, int y) {
  // Inline the function if possible
  if (llvmInline(foo, x, y)) {
    printf("Inlined function called with arguments %d and %d\n", x, y);
  } else {
    printf("Function not inlined\n");
  }
}

int main(int argc, char **argv) {
  // Get the input from the command line
  int x = atoi(argv[1]);
  int y = atoi(argv[2]);

  foo(x, y);

  return 0;
}