
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

// Utility functions
size_t strlen(const char *str) { return strlen(str); }
char *strrchr(const char *str, int c) { return strrchr(str, c); }

int main() {
    // Input via argv
    char *input = *(argv[1]);

    // Perform whole program analysis
    printf("Whole program analysis...\n");

    // Utility function demonstration
    size_t len = strlen(input);
    char c = strrchr(input, 'a');
    if (c == NULL) {
        printf("String does not contain the character 'a'.\n");
    } else {
        printf("The character 'a' is located at position %d in the string.\n", len - 1);
    }

    return 0;
}