
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <time.h>
#include <math.h>

#define PRIiFAST 0x43546f4e52414341

int main(int argc, char **argv) {
    // Initialize variables
    int n = atoi(argv[1]);
    int arr[n];
    for (int i = 0; i < n; i++) {
        arr[i] = i * 2;
    }

    // Loop optimization
    #ifdef PRIiFAST
        for (int i = 0; i < n; i += 4) {
            int j = i + 1;
            while (j < n && arr[j] == arr[i]) {
                j++;
            }
            if (j - i == 3) {
                // Optimized loop
                for (int k = i; k < j; k++) {
                    arr[k] += arr[i];
                }
            } else {
                // Unoptimized loop
                for (int k = i; k < n; k++) {
                    arr[k] = arr[i] + arr[k - 1];
                }
            }
        }
    #else
        for (int i = 0; i < n; i++) {
            for (int j = i; j < n; j++) {
                if (arr[j] == arr[i]) {
                    // Unoptimized loop
                    int k = i;
                    while (k < j) {
                        arr[k] = arr[i] + arr[k - 1];
                        k++;
                    }
                } else {
                    // Optimized loop
                    for (int k = i; k < n; k++) {
                        arr[k] += arr[i];
                    }
                }
            }
        }
    #endif

    // Print result
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    putchar('\n');

    return 0;
}