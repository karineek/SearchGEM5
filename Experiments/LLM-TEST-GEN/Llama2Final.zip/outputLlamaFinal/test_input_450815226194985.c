
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int main(int argc, char **argv) {
    // Input from command line arguments
    int n = atoi(argv[1]);
    float a[] = {1, 2, 3, 4, 5};

    // Example of automatic vectorization using lex compiler
    int size = n * sizeof(float);
    float* data = malloc(size);
    memcpy(data, a, size);
    for (int i = 0; i < n; i++) {
        printf("%f ", data[i]);
    }
    free(data);

    return 0;
}