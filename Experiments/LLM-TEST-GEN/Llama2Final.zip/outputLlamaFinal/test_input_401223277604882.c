
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "register_allocation.h"

int main(int argc, char **argv) {
    // Initialize the register allocation algorithm
    RegisterAllocation *ra = create_register_allocation();

    // Process the input arguments
    if (argc == 1) {
        // Handle a single argument
        int value = atoi(argv[0]);
        ra->insert(value, "local");
    } else if (argc == 2) {
        // Handle two arguments
        int value1 = atoi(argv[0]), value2 = atoi(argv[1]);
        ra->insert(value1, "local");
        ra->insert(value2, "local");
    } else {
        // Handle more than two arguments
        for (int i = 0; i < argc; i++) {
            int value = atoi(argv[i]);
            ra->insert(value, "local");
        }
    }

    // Print the register allocation
    print_register_allocation(ra);

    // Free resources
    destroy_register_allocation(ra);

    return 0;
}