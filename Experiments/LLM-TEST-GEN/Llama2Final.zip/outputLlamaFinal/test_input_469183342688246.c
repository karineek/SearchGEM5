
#include <stdio.h>
#include <stdlib.h>
#include <float.h>

int main(int argc, char *argv[]) {
    float a = 1.0f;
    float b = 2.0f;
    int i = 0;

    while (a <= b) {
        printf("Value of a: %f\n", a);
        a += FLT_TRUE_MIN;
        i++;
    }

    return 0;
}