
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to test LICM optimization
void licm_test(int *arr, int n) {
  int i;
  
  // Loop-invariant code motion
  for (i = 0; i < n; i++) {
    arr[i] = i * 2;
  }
  
  // Print the updated array
  for (i = 0; i < n; i++) {
    printf("%d ", arr[i]);
  }
}

int main(int argc, char **argv) {
  int n = atoi(argv[1]);
  int *arr = malloc(n * sizeof(int));
  
  // Call the LICM test function
  licm_test(arr, n);
  
  // Print the result
  printf("Array: ");
  for (int i = 0; i < n; i++) {
    printf("%d ", arr[i]);
  }
  printf("\n");
  
  return 0;
}