
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/wait.h>

// Function to evaluate the input string and return the result
int evaluate(char *input) {
  // Implement your logic here to evaluate the input string
  int result = 0;
  char op1, op2;
  float num1, num2;

  // Parse the input string into operands and operator
  sscanf(input, "%c%f%c", &op1, &num1, &op2);

  // Perform the operation and store the result
  if (op1 == '+') {
    result = num1 + num2;
  } else if (op1 == '-') {
    result = num1 - num2;
  } else if (op1 == '*') {
    result = num1 * num2;
  } else if (op1 == '/') {
    result = num1 / num2;
  }

  return result;
}

int main(int argc, char **argv) {
  // Check if the input is provided
  if (argc < 2) {
    printf("Usage: %s <input>\n", argv[0]);
    exit(1);
  }

  // Evaluate the input and print the result
  char input[100];
  strcpy(input, argv[1]);
  int result = evaluate(input);
  printf("%f\n", result);

  return 0;
}