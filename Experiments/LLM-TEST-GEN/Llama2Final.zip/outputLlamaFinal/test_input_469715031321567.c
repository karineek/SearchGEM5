
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

// Function specialization for optimization
void foo(int x) {
    if (x == 0) {
        printf("x is 0\n");
    } else {
        printf("x is not 0\n");
    }
}

int main(int argc, char **argv) {
    int x = atoi(argv[1]);
    foo(x);
    return 0;
}