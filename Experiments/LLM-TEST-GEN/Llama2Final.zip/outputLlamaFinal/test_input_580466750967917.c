
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

// Utility function to convert a string to uppercase
void uppercase(char *str) {
    int i;
    for (i = 0; str[i]; i++) {
        str[i] = toupper(str[i]);
    }
}

// Utility function to find the longest common prefix between two strings
int longest_common_prefix(char *str1, char *str2) {
    int i;
    for (i = 0; str1[i] && str2[i]; i++) {
        if (str1[i] != str2[i]) {
            return i;
        }
    }
    return i;
}

int main(int argc, char *argv[]) {
    // Check the number of arguments passed to the program
    if (argc < 3) {
        printf("Usage: %s <string1> <string2>\n", argv[0]);
        return 1;
    }

    // Convert the input strings to uppercase using the utility function
    char str1[10];
    strcpy(str1, argv[1]);
    uppercase(str1);

    char str2[10];
    strcpy(str2, argv[2]);
    uppercase(str2);

    // Find the longest common prefix between the two strings using the utility function
    int longest_prefix = longest_common_prefix(str1, str2);
    if (longest_prefix == 0) {
        printf("The strings do not have a common prefix.\n");
    } else {
        printf("The longest common prefix is %d characters long.\n", longest_prefix);
    }

    return 0;
}