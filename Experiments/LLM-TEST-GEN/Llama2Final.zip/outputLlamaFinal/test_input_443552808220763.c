
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double multiply(double a, double b) {
  // Use the Taylor series expansion of the logarithm function to perform the multiplication efficiently
  return logb(a) * logb(b);
}

int main(int argc, char **argv) {
  if (argc < 3) {
    printf("Usage: %s <number1> <number2>\n", argv[0]);
    return 1;
  }

  double number1 = strtod(argv[1], NULL); // Convert string to double
  double number2 = strtod(argv[2], NULL);

  double result = multiply(number1, number2);
  printf("The result is %f\n", result);

  return 0;
}