
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Define an inline function to demonstrate inline expansion
inline int square(int x) { return x * x; }

int main() {
    // Take input from the command line using argc and argv
    int n = atoi(argv[1]);
    printf("Squaring %d gives %d\n", n, square(n));
    return 0;
}