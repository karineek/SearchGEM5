
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv) {
    // Example input: "42 3.14159"
    char *str = argv[1]; // str is a pointer to the input string
    int num_digits = strlen(str); // Get the number of digits in the input string
    float val; // Initialize the value to be parsed

    // Perform MTP promotion
    while (num_digits > 0) {
        val = strtof(str, &str[num_digits]); // Parse the next digit
        num_digits -= 1; // Decrease the number of digits by 1
    }

    // Print the result
    printf("The value is: %f\n", val); // Output the parsed value

    return 0; // Successful exit
}