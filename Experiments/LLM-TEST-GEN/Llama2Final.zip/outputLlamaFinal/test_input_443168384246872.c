
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: %s character\n", argv[0]);
        return 1;
    }

    char ch = argv[1][0];
    if (isalpha(ch)) {
        printf("The character %c is an alphabet\n", ch);
    } else {
        printf("The character %c is not an alphabet\n", ch);
    }

    return 0;
}