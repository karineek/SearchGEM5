
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// Define a struct to hold the loop fusion information
typedef struct {
    int numLoops;
    int *loopIndices;
} loop_fusion_info_t;

// Function to perform loop fusion
void fusion_loops(loop_fusion_info_t *inf) {
    // Loop over the loops in the input program
    for (int i = 0; i < inf->numLoops; i++) {
        // Find the index of the current loop in the fusion list
        int index = -1;
        for (int j = 0; j < inf->numLoops; j++) {
            if (inf->loopIndices[j] == i) {
                index = j;
                break;
            }
        }
        
        // If the loop is not already part of a fusion, try to add it
        if (index == -1) {
            inf->numLoops++;
            inf->loopIndices = realloc(inf->loopIndices, sizeof(int) * inf->numLoops);
            inf->loopIndices[inf->numLoops - 1] = i;
        }
    }
}

// Function to parse the input program from argv
void parse_program(int argc, char **argv) {
    // Check if there are any arguments
    if (argc < 2) {
        printf("Usage: %s <input.c>\n", argv[0]);
        exit(1);
    }
    
    // Open the input program for reading
    FILE *file = fopen(argv[1], "r");
    if (!file) {
        perror("Error opening input file");
        exit(1);
    }
    
    // Read the program and allocate memory for the fusion list
    loop_fusion_info_t inf;
    inf.numLoops = 0;
    inf.loopIndices = malloc(sizeof(int) * 8);
    while (fscanf(file, "%d", &inf.numLoops) == 1 && inf.numLoops > 0) {
        inf.loopIndices = realloc(inf.loopIndices, sizeof(int) * inf.numLoops);
        inf.loopIndices[inf.numLoops - 1] = inf.numLoops - 1; // Initialize to -1 for now
    }
    
    // Close the input file and return
    fclose(file);
}

int main(int argc, char **argv) {
    // Parse the input program
    parse_program(argc, argv);
    
    // Perform loop fusion on the input program
    loop_fusion_info_t inf;
    fusion_loops(&inf);
    
    // Print the resulting fusion list
    int *fusedLoops = inf.loopIndices;
    printf("Fused loops: ");
    for (int i = 0; i < inf.numLoops; i++) {
        printf("%d ", fusedLoops[i]);
    }
    printf("\n");
    
    return 0;
}