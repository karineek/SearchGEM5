
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Function to inline and manipulate IR
void exp2f(float x) {
  // Inline computation
  float result = x * x;
  
  // Manipulate IR
  result = result + 1.0f;
  
  // Return result
  printf("exp2f(%.2f) = %.2f\n", x, result);
}

int main(int argc, char **argv) {
  if (argc < 2) {
    printf("Usage: %s <float>\n", argv[0]);
    return 1;
  }
  
  float x = atof(argv[1]);
  exp2f(x);
  return 0;
}