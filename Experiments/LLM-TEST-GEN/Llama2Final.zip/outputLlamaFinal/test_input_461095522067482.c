
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <support/SupportLibraries.h>

int main(int argc, char **argv) {
    // Example input: "hello world"
    char *input = argv[1];

    // Perform Loop-Invariant Code Motion optimization
    lexical_elements_t *elements = llex_init();
    llex_add_string(elements, input);

    // Print the optimized code
    printf("Optimized code: \n");
    llex_print_code(elements);

    // Clean up
    llex_destroy(elements);

    return 0;
}