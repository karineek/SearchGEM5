
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

// Automatic Vectorization
#define VECTORIZABLE(type, name) \
  type name[__vector_size__]; \
  void name##__init(void) { \
    for (int i = 0; i < __vector_size__; i++) { \
      name[i] = (type)(i); \
    } \
  } \
  type name##__func(void) { \
    int result = 0; \
    for (int i = 0; i < __vector_size_; i++) { \
      result += name[i]; \
    } \
    return result; \
  }

// Handles Abstract Syntax Tree (AST)
#define AST(type, name) \
  type name##__ast(void) { \
    return *((type*)&name); \
  } \
  type name##__func(void) { \
    return *((type*)&name); \
  }

// atomic_int_least16_t type
#define ATOMIC_INT_LEAST16_T(name) \
  int name##_var; \
  volatile int name##_mutex; \
  void name##__init(void) { \
    name##_var = 0; \
    name##_mutex = 0; \
  } \
  int name##__func(void) { \
    int result = name##_var; \
    while (name##_mutex != 0) { \
      // spin lock
    } \
    return result; \
  }

int main(void) {
  // Input taken via argv only
  int numElements = atoi(argv[1]);

  VECTORIZABLE(int, vectornumElements);
  AST(int, astnumElements);
  atomic_int_least16_t atomicnumElements;

  vectornumElements##__init();
  astnumElements##__init();
  atomicnumElements##__init();

  for (int i = 0; i < numElements; i++) {
    vectornumElements[i] = i * 2;
    astnumElements[i] = i * 3;
    atomicnumElements.store(i * 4, true);
  }

  printf("Vectorized result: ");
  for (int i = 0; i < numElements; i++) {
    printf("%d ", vectornumElements[i]);
  }
  printf("\n");

  printf("AST result: ");
  for (int i = 0; i < numElements; i++) {
    printf("%d ", astnumElements[i]);
  }
  printf("\n");

  return 0;
}