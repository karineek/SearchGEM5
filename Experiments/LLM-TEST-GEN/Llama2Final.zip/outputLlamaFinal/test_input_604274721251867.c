
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>

// Macro to test the "islessequal" optimization
#define ISLESSEQUAL(a, b) (((a) == (b)) || ((a) == (-(b))))

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: %s <expression1> <expression2>\n", argv[0]);
        return 1;
    }

    // Expression 1
    double expression1 = atof(argv[1]);
    // Expression 2
    double expression2 = atof(argv[2]);

    // Test the "islessequal" macro
    if (ISLESSEQUAL(expression1, expression2)) {
        printf("True\n");
    } else {
        printf("False\n");
    }

    return 0;
}