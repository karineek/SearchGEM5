
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Define a structure to hold the input data
typedef struct {
    int arr[10];
} input_t;

int main(int argc, char *argv[]) {
    // Check if the user provided an input file
    if (argc < 2) {
        printf("Usage: %s <input-file>\n", argv[0]);
        return 1;
    }

    // Load the input data from the file
    FILE *file = fopen(argv[1], "r");
    if (!file) {
        perror("Error opening input file");
        return 2;
    }

    // Create a struct to hold the input data
    input_t input;
    fread(&input, sizeof(input_t), 1, file);

    // Analyze the input data for Memory-to-Register Promotion
    printf("Memory-to-Register Promotion: ");
    for (int i = 0; i < 10; i++) {
        if (input.arr[i] == 0) {
            continue; // Skip non-zero elements
        }
        int reg = ffs(input.arr[i]) - 1; // Find the first bit set in the integer
        printf("%d -> %d\n", input.arr[i], reg);
    }

    // Print the result of the analysis
    printf("Result: %d\n", input.arr[9]); // Use the last non-zero element as a test case

    return 0;
}