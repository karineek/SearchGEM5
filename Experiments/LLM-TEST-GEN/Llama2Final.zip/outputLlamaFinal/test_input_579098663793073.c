
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <clang/clang.h>

int main(int argc, char *argv[]) {
    // Check if the input is a C++ file
    if (argc < 2) {
        printf("Usage: %s <C++ file>\n", argv[0]);
        return 1;
    }

    // Load the C++ code from the file
    std::string src = argv[1];
    ClangImporter importer;
    importer.parse(src, true);

    // Compile the C++ code using the Clang frontend
    ClangFrontend frontend;
    frontend.setSourceFile(importer.getClangModule(), src);
    frontend.parse();

    // Print the optimized assembly code
    std::string assembly = frontend.getOptimizedAssembly();
    printf("Optimized assembly code:\n%s\n", assembly.c_str());

    return 0;
}