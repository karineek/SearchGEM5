
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    // Parse the command line argument
    if (argc > 1) {
        // Parse the assembly file contents
        char *assembly = argv[1];
        int len = strlen(assembly);
        char *token;
        uint32_t address = 0;
        uint32_t value = 0;

        // Loop through the assembly file contents
        for (int i = 0; i < len; i++) {
            token = strtok(assembly + i, " ");
            if (token == NULL) {
                break; // Reach end of assembly file
            }

            // Check if this is a memory address or value
            if (strcmp(token, "address") == 0 || strcmp(token, "value") == 0) {
                // If it's an address, parse the hexadecimal number and store it in 'address'
                address = strtol(token + 7, NULL, 16);
            } else if (strcmp(token, "value") == 0) {
                value = strtol(token + 7, NULL, 16);
            }
        }

        // If we reached the end of the assembly file without encountering an error,
        // execute the assembled code and print the result
        if (i == len - 1) {
            int result = assembly_executor(address, value);
            printf("Result: %d\n", result);
        } else {
            fprintf(stderr, "Error: Could not parse assembly file\n");
        }
    } else {
        // Print usage message if no arguments were provided
        printf("Usage: %s <assembly_file>\n", argv[0]);
    }

    return 0;
}