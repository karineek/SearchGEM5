
#include <stdio.h>
#include <stdint.h>
#include <vector>
#include <iostream>

using namespace std;

int main(int argc, char **argv) {
    int n = atoi(argv[1]); // Get the number of integers from the command line argument
    vector<int> v(n); // Create a vector of integers

    // Fill the vector with random values
    srand(time(0));
    for (int i = 0; i < n;++i) {
        v[i] = rand() % 10;
    }

    // Use Automatic Vectorization to perform a calculation on the entire vector
    int sum = v.sum(); // Compute the sum of all the values in the vector
    printf("The sum of the integers is: %d\n", sum);

    return 0;
}