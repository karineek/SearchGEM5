
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Function to calculate the powl of two integers
int powl(int a, int b) {
    return a * pow(b, a);
}

int main(int argc, char** argv) {
    // Check if enough arguments were passed
    if (argc < 2) {
        printf("Usage: %s <number> <exponent>\n", argv[0]);
        return 1;
    }

    // Calculate the powl of the two integers
    int result = powl(atoi(argv[1]), atoi(argv[2]));

    // Print the result
    printf("%d\n", result);

    return 0;
}