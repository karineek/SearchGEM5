
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <fcntl.h>

// Define a function to test loop optimizations and serialization
void test_loop_optimizations(int n) {
  int i;
  for (i = 0; i < n; i++) {
    // Do something with i
    printf("Iteration %d: %d\n", i, i * i);
  }
}

// Test the function with different inputs
int main(int argc, char **argv) {
  if (argc < 2) {
    printf("Usage: %s <input_value>\n", argv[0]);
    return 1;
  }

  int n = atoi(argv[1]); // Convert string to integer
  test_loop_optimizations(n);

  return 0;
}