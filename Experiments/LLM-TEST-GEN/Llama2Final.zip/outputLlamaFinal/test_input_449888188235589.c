
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX_INPUT_SIZE 1024

int main(int argc, char **argv) {
    // Check if enough arguments are passed
    if (argc != 2) {
        printf("Usage: %s <input> <output>\n", argv[0]);
        return 1;
    }

    // Get the input from the user
    char *input = argv[1];

    // Perform constant folding
    const int len = strlen(input);
    char *const_folded = malloc(len + 1);
    memcpy(const_folded, input, len + 1);

    // Generate code using PRIuFAST
    char *generated_code = NULL;
    generated_code = PRIuFAST(const_folded);

    // Print the generated code
    printf("%s\n", generated_code);

    free(generated_code);
    free(const_folded);

    return 0;
}