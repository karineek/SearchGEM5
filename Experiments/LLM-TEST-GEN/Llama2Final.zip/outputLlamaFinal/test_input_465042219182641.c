
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <termios.h>
#include <math.h>

// Function to parse an assembly file and perform loop fusion
void parse_assembly(char *filename) {
  FILE *file = fopen(filename, "r"); // Open the assembly file for reading
  char line[1024]; // Buffer for reading lines from the file
  int num_loops = 0; // Number of loops found in the assembly file
  int i = 0; // Iterator for loop fusion

  // Read the assembly file and find all loops
  while (fgets(line, 1024, file) != NULL) {
    // Skip comments and empty lines
    if (strncmp(line, "#", 1) == 0 || line[0] == '\n') continue;

    // Split the line into tokens using space as the delimiter
    char *tokens[10];
    tokenize_line(line, tokens);

    // Check if the current line is a loop
    if (strcmp(tokens[0], "loop") == 0) {
      // Increment the number of loops found
      num_loops++;

      // Perform loop fusion by iterating over the remaining tokens
      for (i = 1; i < sizeof(tokens) / sizeof(tokens[0]); i++) {
        // If the current token is a register or label, skip it
        if (strcmp(tokens[i], "register") == 0 || strcmp(tokens[i], ":label") == 0) continue;

        // Otherwise, combine the current token with the previous one
        tokens[i - 1] = tokens[i];
      }

      // Print the resulting token sequence
      printf("%s\n", tokens[0]);
    }
  }

  // Print the number of loops found in the assembly file
  printf("Number of loops found: %d\n", num_loops);
}

// Tokenize a line of text using space as the delimiter
void tokenize_line(char *line, char *tokens[10]) {
  int i = 0;
  while (line[i] != ' ' && line[i] != '\n') i++;
  tokens[0] = line + i - 1; // Token 0 is the entire line
  for (i++; i < sizeof(tokens) / sizeof(tokens[0]); i++) {
    if (line[i] == ' ' || line[i] == '\n') {
      tokens[i] = line + i - 1; // Token i is a space or newline
    } else {
      tokens[i] = line + i - 1; // Token i is the next word
    }
  }
}

// Main function to parse an assembly file and perform loop fusion
int main(int argc, char **argv) {
  if (argc < 2) {
    printf("Usage: %s <assembly_file>\n", argv[0]);
    return 1;
  }

  // Parse the assembly file using the loop fusion optimization
  parse_assembly(argv[1]);

  return 0;
}