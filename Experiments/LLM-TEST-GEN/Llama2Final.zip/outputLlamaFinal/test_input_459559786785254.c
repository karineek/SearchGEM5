
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/wait.h>

// Define a function that uses scalar optimizations
void foo(int a, int b) {
    // Check if a and b are the same value
    if (a == b) {
        // Use the conditional operator to simplify the expression
        printf("a and b are the same value\n");
    } else {
        // Perform an operation that depends on the difference between a and b
        int result = a - b;
        printf("The difference between a and b is %d\n", result);
    }
}

int main(int argc, char **argv) {
    // Parse the command line arguments
    int a = atoi(argv[1]);
    int b = atoi(argv[2]);

    // Call the function that uses scalar optimizations
    foo(a, b);

    return 0;
}