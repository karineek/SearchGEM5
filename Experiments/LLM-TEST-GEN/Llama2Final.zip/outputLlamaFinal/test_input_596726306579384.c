
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Function to promote memory to registers
void promote_memory_to_registers(int *mem, int size) {
    for (int i = 0; i < size; i++) {
        // Promote the memory location to a register
        register int reg = mem[i];
    }
}

// Example input: "Hello World!"
int main(int argc, char **argv) {
    // Initialize the input string in memory
    char *str = argv[1]; // str is a pointer to the input string in memory

    // Promote the memory location to registers
    promote_memory_to_registers(str, strlen(str));

    // Print the promoted register values
    for (int i = 0; i < strlen(str); i++) {
        printf("%d ", *(int *)&str[i]);
    }

    return 0;
}