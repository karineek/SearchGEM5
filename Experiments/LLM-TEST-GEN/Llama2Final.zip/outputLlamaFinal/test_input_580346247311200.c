
#include <stdio.h>
#include <string.h>
#include <llvm/llvm.h>

// TSO optimization: fold constant 4 into a single instruction
void foo(int x) {
  if (x == 4) {
    // optimize away the comparison and use a constant fold instead
    x = 1;
  }
  printf("x = %d\n", x);
}

int main(int argc, char **argv) {
  int x = atoi(argv[1]); // parse command line argument as integer
  foo(x);            // apply TSO optimization and call foo()
  return 0;
}