
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

// Define a function that takes two integers and computes their sum
void add(int a, int b, uint8_t* output) {
    *output = a + b;
}

int main(int argc, char** argv) {
    // Parse command line arguments
    int num_args = argc - 1;
    if (num_args < 2) {
        printf("Usage: %s <integer1> <integer2>\n", argv[0]);
        return 1;
    }

    // Vectorize the add function using the __builtin_va_list macro
    uint8_t buffer[num_args];
    __builtin_va_list args;
    va_start(args, argv[1]);
    add((int)va_arg(args, int), (int)va_arg(args, int), buffer);
    va_end(args);

    // Print the result
    for (int i = 0; i < num_args; i++) {
        printf("%d ", buffer[i]);
    }
    printf("\n");

    return 0;
}