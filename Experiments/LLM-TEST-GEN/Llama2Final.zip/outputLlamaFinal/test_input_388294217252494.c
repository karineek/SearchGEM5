
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <asm/assembler.h>

int main(int argc, char *argv[]) {
    // Parse input from command line arguments
    if (argc < 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    // Parse assembly file using asm library
    FILE *file = fopen(argv[1], "r");
    if (!file) {
        perror("Error opening input file");
        return 2;
    }
    AssemblyFile af;
    af.file = file;
    af.section = NULL;
    af.cur_insn = NULL;
    af.cur_ip = 0;

    // Apply Constant Folding
    ConstantFolding(af);

    // Print assembly code after constant folding
    PrintInstructions(af);

    // Clean up
    af.file = NULL;
    af.section = NULL;
    af.cur_insn = NULL;
    af.cur_ip = 0;

    return 0;
}