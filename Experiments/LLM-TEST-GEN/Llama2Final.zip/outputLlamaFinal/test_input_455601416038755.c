
#include <iostream>
#include <vector>
#include <type_traits>

// Type-generic macro for hypot
#define HYPOT(a, b) typedefface(std::hypot<decltype(a), decltype(b)>)

int main(int argc, char** argv) {
    // Get the input data from command line arguments
    int num_values = atoi(argv[1]);
    double* values = malloc(num_values * sizeof(double));
    for (int i = 0; i < num_values; i++) {
        values[i] = strtod(argv[2 + i], NULL);
    }

    // Perform hypot calculation on the input data using vectorization
    std::vector<double> hypot_vect(num_values);
    for (int i = 0; i < num_values; i++) {
        hypot_vect[i] = HYPOT(values[i * 2], values[i * 2 + 1]);
    }

    // Print the results
    for (int i = 0; i < num_values; i++) {
        std::cout << hypot_vect[i] << " ";
    }

    return 0;
}