
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
  // Scalar Optimization: simplify the code by removing unnecessary variables
  int len = strlen(argv[1]);
  putwc(argv[1], &len);
  return 0;
}