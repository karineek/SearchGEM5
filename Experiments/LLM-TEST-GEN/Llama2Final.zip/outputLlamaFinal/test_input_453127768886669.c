
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Scalar optimization: eliminate dead code
void elim_dead_code(int x) {
    if (x == 0) {
        return; // Eliminate unnecessary code
    }
    printf("The value of x is %d\n", x);
}

// IR manipulation: promote literals to const
void promote_literals(int x, int y) {
    if (x == 5 && y == 10) {
        // Promote literals to const
        printf("The product of x and y is %d\n", x * y);
    } else {
        // Eliminate unnecessary code
        return;
    }
}

int main(int argc, char **argv) {
    int x = atoi(argv[1]);
    int y = atoi(argv[2]);

    // IR manipulation: apply precedence of syntax rules
    if (x > 0 && y > 0) {
        promote_literals(x, y);
    } else {
        elim_dead_code(x);
    }

    return 0;
}