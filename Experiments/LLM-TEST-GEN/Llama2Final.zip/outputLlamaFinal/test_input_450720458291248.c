
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int main(int argc, char *argv[]) {
    // Loop optimization example
    int n = atoi(argv[1]);
    for (int i = 0; i < n; i++) {
        printf("Hello, world!\n");
    }

    // Object file manipulation example
    char objfile[] = "myobject.o";
    FILE *f = fopen(objfile, "wb");
    fprintf(f, "Hello, world!");
    fclose(f);

    // strftime function example
    time_t now = time(NULL);
    char buffer[26];
    strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", &now);
    printf("Current time is: %s\n", buffer);

    return 0;
}