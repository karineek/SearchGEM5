
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Utility functions
double square(double x) { return x * x; }
float   pow(float x, float y) { return fpow(x, y); }
int     abs(int x)      { return x > 0 ? x : -x; }

// Memory-to-register promotion
#define MEM_TO_REG(x)    ({ register int _x = (int)(x); _x; })

int main() {
    double x = atof(argv[1]); // argv[1] contains the input from the user
    double y = square(x);      // use utility function to compute y = x^2
    float z = pow(x, 2.0f);   // use utility function to compute z = x^2
    int k = abs(-4);          // use utility function to compute k = -4

    // Print the results
    printf("x = %lf, y = %lf, z = %f, k = %d\n", x, y, z, k);

    return 0;
}