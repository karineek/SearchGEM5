
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <math.h>

int main(int argc, char **argv) {
  // Example input:
  int n = atoi(argv[1]);
  float a[] = {1, 2, 3, 4, 5};
  float *p = a;
  
  // Loop vectorization using the "llvm-gcc" compiler
  for (int i = 0; i < n; ++i) {
    float sum = 0;
    for (int j = 0; j < 5; ++j) {
      sum += *p++;
    }
    printf("%f\n", sum);
  }
  
  return 0;
}