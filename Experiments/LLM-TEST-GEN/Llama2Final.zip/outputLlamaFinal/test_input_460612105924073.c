
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

// Function to inline
void inline_func(int x, int y) {
    printf("Inlined function: x = %d, y = %d\n", x, y);
}

int main() {
    // Input via argv
    int x = atoi(argv[1]);
    int y = atoi(argv[2]);

    // Inline the function
    inline_func(x, y);

    // Check for null pointer
    void *p = NULL;
    assert(p != NULL);

    return 0;
}