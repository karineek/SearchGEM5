
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Define a macro to compare two values and return -1 if the first is less than the second, 1 if the first is greater than the second, and 0 if they are equal
#define islessgreater(a, b) \
    ((a) > (b)) ? 1 : ((a) == (b)) ? 0 : -1

int main(int argc, char **argv) {
    // Check the number of arguments passed to the program
    if (argc != 3) {
        printf("Usage: %s <num1> <num2>\n", argv[0]);
        return 1;
    }

    // Parse the input numbers from the command line arguments
    double num1 = strtod(argv[1], NULL);
    double num2 = strtod(argv[2], NULL);

    // Use the islessgreater macro to compare the two numbers and print the result
    if (islessgreater(num1, num2)) {
        printf("Num1 is less than Num2\n");
    } else {
        printf("Num1 is greater than Num2\n");
    }

    return 0;
}