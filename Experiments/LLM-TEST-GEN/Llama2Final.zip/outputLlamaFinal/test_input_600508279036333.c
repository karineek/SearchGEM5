
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

// Function to compute the sum of two vectors of floats
void sumVectors(float *a, int na, float *b, int nb) {
  // Initialize result vector with size of (na + nb) * sizeof(float)
  float *result = malloc(na + nb * sizeof(float));
  
  // Loop over elements in a and b, computing sum using vectorized operations
  #pragma omp parallel for default(none) shared(a, b, result)
  for (int i = 0; i < na + nb; ++i) {
    result[i] = a[i] + b[i];
  }
  
  // Print result vector
  for (int i = 0; i < na + nb; ++i) {
    printf("%f ", result[i]);
  }
}

int main(void) {
  // Input from command line
  int na = atoi(argv[1]);
  int nb = atoi(argv[2]);
  
  // Allocate memory for input vectors
  float *a = malloc(na * sizeof(float));
  float *b = malloc(nb * sizeof(float));
  
  // Initialize input vectors
  for (int i = 0; i < na; ++i) {
    a[i] = (float)rand() / RAND_MAX;
  }
  for (int i = 0; i < nb; ++i) {
    b[i] = (float)rand() / RAND_MAX;
  }
  
  // Call function to compute sum of vectors
  sumVectors(a, na, b, nb);
  
  return 0;
}