
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Define a function that takes a string as input and returns its length
int strlen(char *str) {
    return strlen(str);
}

// Define a function that takes a string and returns true if it is empty, false otherwise
int is_empty(char *str) {
    return str == NULL || *str == '\0';
}

// Demonstrate Dead Code Elimination by removing the unreachable code
void main() {
    char *str = argv[1]; // Get the input string from the command line
    printf("The length of %s is %d\n", str, strlen(str));
}