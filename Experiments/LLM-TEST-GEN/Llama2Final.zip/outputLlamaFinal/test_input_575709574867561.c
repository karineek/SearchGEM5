
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <float.h>

// Function specialization for cacoshf
double cacoshf(double x) {
    return coshf(x) / sinhf(x);
}

int main(int argc, char **argv) {
    double x = atof(argv[1]); // Get input from command line
    double y = cacoshf(x);      // Evaluate cacoshf function
    printf("cacoshf(%.2f) = %.2f\n", x, y);  // Print result
    return 0;
}