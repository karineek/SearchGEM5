
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define N 100

int main(int argc, char **argv) {
    int n = atoi(argv[1]); // Get the number of iterations from command line argument

    int arr[n]; // Array to hold the results
    for (int i = 0; i < n; i++) {
        arr[i] = i * 2; // Simple loop that can be vectorized
    }

    __attribute__((__vector_size__("int"))) int vecArr[n]; // Vectorize the loop using the "vec" attribute
    for (int i = 0; i < n; i++) {
        vecArr[i] = i * 2; // The vectorized loop will be optimized by the compiler
    }

    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]); // Print the results of both loops
    }

    return 0;
}