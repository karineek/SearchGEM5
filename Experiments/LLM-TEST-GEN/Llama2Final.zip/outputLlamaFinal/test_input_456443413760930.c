
#include <stdio.h>
#include <stdint.h>
#include <vector>
#include <iostream>
#include <algorithm>

// Function to perform vectorized operations on input values
void vecOp(uint64_t* inputs, uint64_t size) {
    // Use vectorized operations on the input values
    for (int i = 0; i < size; ++i) {
        inputs[i] = inputs[i] * 2;
    }
}

int main(int argc, char** argv) {
    // Get the number of input values from the command line arguments
    uint64_t numInputs = atoll(argv[1]);

    // Allocate memory for the input values
    uint64_t* inputs = new uint64_t[numInputs];

    // Read the input values from the command line arguments
    for (int i = 0; i < numInputs; ++i) {
        inputs[i] = strtoul(argv[2 + i], NULL, 10);
    }

    // Perform vectorized operations on the input values
    vecOp(inputs, numInputs);

    // Print the results
    for (int i = 0; i < numInputs; ++i) {
        printf("%lld ", inputs[i]);
    }

    return 0;
}