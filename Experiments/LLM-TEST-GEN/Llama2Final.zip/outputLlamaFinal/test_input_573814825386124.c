
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "instruction_scheduling.h"

int main(int argc, char *argv[]) {
    // Initialize instruction scheduling
    init_instruction_scheduling();

    // Parse command line arguments
    int num_instructions = parse_command_line_arguments(argc, argv);

    // Create a list of instructions
    struct instruction *instructions = malloc(num_instructions * sizeof(struct instruction));
    for (int i = 0; i < num_instructions; i++) {
        instructions[i].opcode = get_opcode_from_command_line(argv[i]);
        instructions[i].operands = malloc(num_operands * sizeof(struct operand));
        for (int j = 0; j < num_operands; j++) {
            instructions[i].operands[j].name = argv[i + j];
            instructions[i].operands[j].value = strtol(argv[i + j], NULL, 10);
        }
    }

    // Schedule the instructions
    schedule_instructions(instructions, num_instructions);

    // Print the scheduled instructions
    print_scheduled_instructions();

    return 0;
}