
#include <stdio.h>
#include <string.h>
#include <semant.h>

int main(int argc, char **argv) {
    // Initialize the semantic analysis module
    sem_init(&sem, NULL);

    // Parse the command line arguments
    int numArgs = argc;
    char *args[numArgs];
    for (int i = 0; i < numArgs; i++) {
        args[i] = argv[i];
    }

    // Perform semantic analysis on the input
    sem_analyze(sem, args, NULL);

    // Use the Inliner Heuristics optimization
    sem_perform_inlining(sem, NULL);

    // Print the optimized code
    char *optimizedCode = sem_get_code(sem);
    printf("Optimized code: %s\n", optimizedCode);

    return 0;
}