
#include <stdio.h>
#include <stdarg.h>

// Function to swap numbers in a cyclic order using call-by-reference
void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

int main(int argc, char **argv) {
    // Input from command line
    if (argc < 3) {
        fprintf(stderr, "Usage: %s <n1> <n2>\n", argv[0]);
        return 1;
    }
    int n1 = atoi(argv[1]);
    int n2 = atoi(argv[2]);

    // Propagate constants to reduce computation
    swap(n1, n2);

    return 0;
}