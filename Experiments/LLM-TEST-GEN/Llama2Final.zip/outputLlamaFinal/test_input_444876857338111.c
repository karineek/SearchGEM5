
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv) {
    int n = atoi(argv[1]); // argv[1] contains the input from the user

    // Perform common subexpression elimination optimization
    n = n / 2;

    printf("The result is: %d\n", n);

    return 0;
}