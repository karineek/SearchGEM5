
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// Function to eliminate common subexpressions
void eliminate_common_subexpressions(int a, int b, int c) {
    int result = a + b + c;
    if (result == 0) {
        // Eliminate common subexpression by assigning the value of a+b to a
        a = b = c = result;
    }
}

int main() {
    int a = 5, b = 3, c = 2;
    char input[] = "5 3 2";
    // Take input from argc[1] and argv[1]
    int n = atoi(input);
    eliminate_common_subexpressions(n, n, n);
    printf("Result: %d\n", a);
    return 0;
}