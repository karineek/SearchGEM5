
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>

// Function to trigger Sparse Conditional Constant Propagation optimizations
void truncl(int n, int a[n]) {
  // Initialize variables
  int i;
  
  // Perform sparse conditional constant propagation
  for (i = 0; i < n; i++) {
    if (a[i] > 0) {
      a[i] = a[i] * 2;
    } else {
      a[i] = -a[i];
    }
  }
  
  // Print the result
  for (i = 0; i < n; i++) {
    printf("%d ", a[i]);
  }
}

int main(int argc, char *argv[]) {
  // Parse input from command line
  int n = atoi(argv[1]);
  int a[] = malloc(n * sizeof(int));
  
  // Fill in the array with random values
  for (int i = 0; i < n; i++) {
    a[i] = rand() % 2;
  }
  
  // Call the truncl function
  truncl(n, a);
  
  return 0;
}