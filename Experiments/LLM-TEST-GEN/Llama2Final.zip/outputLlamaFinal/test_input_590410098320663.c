
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "lex.h"

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <character>\n", argv[0]);
        return 1;
    }

    // Parse input using Lex
    yy_parse(stdin);

    // Get the ASCII value of the character
    int ascii = get_ascii(yytext[0]);

    // Print the result
    printf("The ASCII value of %s is %d\n", argv[1], ascii);

    return 0;
}