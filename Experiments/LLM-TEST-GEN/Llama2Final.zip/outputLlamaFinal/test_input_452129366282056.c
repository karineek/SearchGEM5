
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

// Utility functions
int my_sqrt(float x) { return sqrtf(x); }
double my_exp(double x) { return exp(x); }

// Library function calls
void print_message(char *message) { printf("%s\n", message); }

int main(int argc, char **argv) {
    // Loop optimization example 1: Use of loop unrolling
    int n = atoi(argv[1]);
    for (int i = 0; i < n;++i) {
        for (int j = 0; j < 10;++j) {
            printf("Hello, world!\n");
        }
    }

    // Utility function example: My own square root implementation
    float result = my_sqrt(4.0f);
    printf("The square root of 4 is %f\n", result);

    // Library function call example: Printing a message to the console
    print_message("This is a message from a utility function");

    return 0;
}