
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ast.h>
#include <inliner.h>

// Function to inline a function call
void inline_function(int a, int b) {
  // Body of the inlined function
  printf("Inlined function called with arguments %d and %d\n", a, b);
}

// Function to handle an AST node
void handle_ast(struct ast *ast) {
  // Print the AST node
  printf("AST node: %s\n", ast->type);
}

int main(int argc, char **argv) {
  // Initialize the AST parser and inliner
  ast_parser_init();
  inliner_init();

  // Parse the input string as an AST
  struct ast *ast = ast_parse(argv[1]);

  // Inline the function call
  inlineer_inline(ast, "inline_function", 2);

  // Handle the AST node
  handle_ast(ast);

  // Clean up
  ast_free(ast);
  inliner_deinit();

  return 0;
}