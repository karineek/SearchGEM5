
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <asm/assemble.h>
#include <stdnoreturn.h>

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    // Load the assembler code from the input file
    FILE *input_file = fopen(argv[1], "rb");
    if (!input_file) {
        perror("Error opening input file");
        return 1;
    }

    // Parse the assembler code and execute it
    const char *assembler_code = fread(input_file, 1, FileSize(input_file), NULL);
    if (assembler_code == NULL) {
        perror("Error reading input file");
        return 1;
    }
    assembler_code = assemble(assembler_code, argv[0]);
    if (assembler_code == NULL) {
        perror("Error assembling code");
        return 1;
    }

    // Execute the assembler code using loop optimizations
    for (int i = 0; i < 10; i++) {
        execute(assembler_code);
    }

    return 0;
}