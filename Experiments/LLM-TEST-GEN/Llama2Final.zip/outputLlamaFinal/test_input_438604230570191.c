
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

#define STRING_SIZE 1024
#define ARRAY_SIZE 64

int main(int argc, char **argv) {
    // Initialize variables
    int numElements = atoi(argv[1]);
    float *data = malloc(numElements * sizeof(float));
    char *string = malloc(STRING_SIZE * sizeof(char));

    // Read input from user
    printf("Enter %d elements of floating-point numbers: \n", numElements);
    for (int i = 0; i < numElements; i++) {
        printf("Element %d: ", i + 1);
        scanf("%f", &data[i]);
    }

    // Perform automatic vectorization
    #pragma omp parallel default(none) shared(data)
    {
        #pragma omp for schedule(static)
        for (int i = 0; i < numElements; i++) {
            data[i] *= 2.0f;
        }
    }

    // Save output to file
    FILE *file = fopen("output.bin", "wb");
    for (int i = 0; i < numElements; i++) {
        fwrite(&data[i], sizeof(float), 1, file);
    }
    fclose(file);

    // Print result
    printf("Original values: ");
    for (int i = 0; i < numElements; i++) {
        printf("%f ", data[i]);
    }
    printf("\nAfter vectorization: ");
    for (int i = 0; i < numElements; i++) {
        printf("%f ", data[i] * 2.0f);
    }

    return 0;
}