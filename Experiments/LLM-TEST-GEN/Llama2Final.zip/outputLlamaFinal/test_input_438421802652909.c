
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define MAX_INPUT_SIZE 1024

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: %s <input>\n", argv[0]);
        return 1;
    }

    char *input = argv[1];
    size_t input_size = strlen(input);

    // Trigger Target-Specific Optimizations
    __target_specific_optimization();

    // Reads LLVM IR
    uint32_t ir[] = {0x12345678, 0x90123456, 0x78563412};
    size_t ir_size = sizeof(ir);

    // Exercise PRIXFAST
    printf("Input: %s\n", input);
    printf("Output: %s\n", pixfast(input, ir, ir_size));

    return 0;
}