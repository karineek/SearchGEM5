
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

// Function to handle the AST
void handle_ast(struct node *ast) {
  // Handle each node in the AST
  switch (ast->type) {
    case NODE_TYPE_VARIABLE:
      // Print the name of the variable
      printf("Variable %s\n", ast->name);
      break;
    case NODE_TYPE_FUNCTION:
      // Print the name of the function
      printf("Function %s\n", ast->name);
      break;
    case NODE_TYPE_OPERATION:
      // Print the operation being performed
      printf("Operation %s\n", ast->operation);
      break;
  }
}

// Function to perform register allocation
void allocate_registers(struct node *ast) {
  int i = 0;
  for (i = 0; i < ast->size; i++) {
    // Allocate a register for each variable in the AST
    printf("Allocating register %d for variable %s\n", i, ast->variables[i]);
  }
}

// Main function to handle input and execute the program
int main(int argc, char *argv[]) {
  // Check if only one argument was passed
  if (argc != 2) {
    printf("Usage: %s <AST>\n", argv[0]);
    return 1;
  }

  // Get the AST from the user
  char *ast_str = argv[1];
  struct node *ast = parse_ast(ast_str);

  // Handle the AST and allocate registers
  handle_ast(ast);
  allocate_registers(ast);

  return 0;
}