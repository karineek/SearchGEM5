
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to fusion loops
void loopFusion(int *a, int *b, int *c) {
    int sum = a[0] + b[0];
    for (int i = 1; i < sizeof(a) / sizeof(a[0]); i++) {
        sum += a[i] + b[i];
    }
    c[0] = sum;
}

int main() {
    // Get input from argv
    int n = atoi(argv[1]);
    int *a = (int *)malloc(n * sizeof(int));
    for (int i = 0; i < n; i++) {
        a[i] = atoi(argv[2 + i]);
    }
    int *b = (int *)malloc(n * sizeof(int));
    for (int i = 0; i < n; i++) {
        b[i] = atoi(argv[3 + i]);
    }
    int *c = (int *)malloc(n * sizeof(int));

    loopFusion(a, b, c);

    // Print result
    for (int i = 0; i < n; i++) {
        printf("%d ", c[i]);
    }

    return 0;
}