
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Define a function that takes a string as input and returns its length
size_t len(const char *str) {
    size_t len = 0;
    while (*str != '\0') {
        len++;
        str++;
    }
    return len;
}

// Define a function that takes two integers as input and returns their product
int mul(int a, int b) {
    return a * b;
}

// Define a function that takes a string as input and returns its reverse
char *rev(const char *str) {
    size_t len = len(str);
    char *ptr = malloc(len + 1);
    for (size_t i = 0; i < len; i++) {
        ptr[i] = str[len - i - 1];
    }
    return ptr;
}

int main() {
    // Define the input string
    char str[] = "Hello World!";

    // Use the len function to get the length of the input string
    size_t len = len(str);

    // Use the mul function to multiply two integers
    int result = mul(5, 7);

    // Use the rev function to reverse a string
    char *reversed_string = rev(str);

    // Print the results
    printf("String length: %zu\n", len);
    printf("Product of 5 and 7: %d\n", result);
    printf("Reversed string: %s\n", reversed_string);

    return 0;
}