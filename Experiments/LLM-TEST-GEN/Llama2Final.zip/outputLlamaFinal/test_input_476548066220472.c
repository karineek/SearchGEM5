
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

// Example input from BASH
int main(int argc, char **argv) {
    // Dead Code Elimination: eliminate unnecessary code
    if (argc < 2) {
        printf("Error: too few arguments\n");
        return 1;
    }

    // Lex: parse input string
    char *token = strtok(argv[1], " ");
    while (token != NULL) {
        printf("%s\n", token);
        token = strtok(NULL, " ");
    }

    // Cast: convert data type
    int x = atoi(argv[2]);
    printf("x = %d\n", x);

    return 0;
}