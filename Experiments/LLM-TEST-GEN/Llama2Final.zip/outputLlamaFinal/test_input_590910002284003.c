
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <iostream>

// Function to perform vectorized arithmetic operations
void vecArith(int *arr, int n) {
    std::vector<int> vec(n);
    for (int i = 0; i < n; i++) {
        vec[i] = arr[i]; // Copy the input numbers into a vector
    }
    std::cout << "Vectorized result: ";
    for (int i : vec) {
        std::cout << i << " ";
    }
    std::cout << std::endl;
}

int main(int argc, char *argv[]) {
    // Parse the input from the command line arguments
    int n = atoi(argv[1]);
    int arr[n];
    for (int i = 0; i < n; i++) {
        arr[i] = atoi(argv[2 + i]); // Initialize the array with input numbers
    }
    vecArith(arr, n); // Perform vectorized arithmetic operations
    return 0;
}