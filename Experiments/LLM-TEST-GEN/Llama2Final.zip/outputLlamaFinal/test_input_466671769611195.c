
#include <stdio.h>
#include <string.h>
#include "ProfileGuidedInstrumentation.h"
#include "Lex.h"
#include "UINT64_C.h"

int main(int argc, char **argv) {
    // Initialize the profile-guided instrumentation system
    pgis_init();

    // Load the Lex program from the input file
    Lex *lex = lex_load(argv[1]);

    // Generate the UINT64_C macro for the program
    UINT64_C macro = uint64c_gen(lex);

    // Print the generated macro
    printf("%s\n", macro);

    // Free resources
    pgis_free();
    lex_free(lex);

    return 0;
}