
#include <iostream>
#include <vector>
#include <climits>

int main(int argc, char** argv) {
  int n = atoi(argv[1]); // get the number of days from the user

  std::vector<int> v(n); // create a vector of integers to store the days of the week

  for (int i = 0; i < n; ++i) {
    int day = i + 1; // map the index to the corresponding day of the week (1 = Monday, etc.)
    v[i] = day * 2 - 1; // calculate the day of the week as a integer (0 = Sunday, etc.)
  }

  for (const int& day : v) {
    std::cout << day << " "; // print each day of the week separated by a space
  }

  return 0;
}