
#include <stdio.h>
#include <stdint.h>
#include <pthread.h>

// Function to demonstrate Memory-to-Register Promotion optimization
void* thread_function(void*) {
    atomic_uint_fast64_t* shared_variable = (atomic_uint_fast64_t*)argv[1];
    *shared_variable += 1;
    return NULL;
}

int main() {
    // Initialize the shared variable with a non-zero value
    atomic_uint_fast64_t shared_variable = 0x123456789abcdef;

    // Create a thread that modifies the shared variable using Memory-to-Register Promotion optimization
    pthread_t thread;
    pthread_create(&thread, NULL);

    // Wait for the thread to finish
    pthread_join(thread, NULL);

    // Print the final value of the shared variable
    printf("Final value of shared variable: %lu\n", shared_variable);

    return 0;
}