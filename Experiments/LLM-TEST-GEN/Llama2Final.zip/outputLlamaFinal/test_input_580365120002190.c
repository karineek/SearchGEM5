
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to fusion loops
void loopFusion(int *a, int *b, int *c) {
  int i, j;
  for (i = 0; i < sizeof(a) / sizeof(*a); i++) {
    for (j = 0; j < sizeof(b) / sizeof(*b); j++) {
      c[i * sizeof(b) + j] = a[i] + b[j];
    }
  }
}

int main(int argc, char **argv) {
  int numElements = atoi(argv[1]);
  int *a = malloc(numElements * sizeof(int));
  int *b = malloc(numElements * sizeof(int));
  int *c = malloc(numElements * sizeof(int));
  
  for (int i = 0; i < numElements; i++) {
    a[i] = i * 2;
    b[i] = i * 3;
  }
  
  loopFusion(a, b, c);
  
  // Print the results
  for (int i = 0; i < numElements; i++) {
    printf("%d ", c[i]);
  }
  
  return 0;
}