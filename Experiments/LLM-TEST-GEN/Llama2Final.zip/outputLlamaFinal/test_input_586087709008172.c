
#include <stdio.h>
#include <string.h>
#include <ast.h>

// Define a function to inline using heuristics
void inline_function(int x, int y) {
  // Inline if the call is likely to be profitable
  if (x > 0 && y > 0 && x + y <= 100) {
    printf("Inlined function\n");
  } else {
    // Otherwise, don't inline
    printf("Did not inline\n");
  }
}

int main(int argc, char **argv) {
  // Parse the command line arguments
  int x = atoi(argv[1]);
  int y = atoi(argv[2]);

  // Call the inline function
  inline_function(x, y);

  return 0;
}