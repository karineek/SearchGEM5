
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Function to demonstrate loop optimizations
void optimize_loops(int n) {
  int i, j;
  for (i = 0; i < n; i++) {
    for (j = 0; j < n; j++) {
      if (i == j) {
        // Do something with i and j
        printf("i and j are equal: %d\n", i);
      } else {
        // Do something else
        printf("i and j are not equal: %d vs. %d\n", i, j);
      }
    }
  }
}

// Function to demonstrate rounding mode and floating point
void test_rounding(int num) {
  float f = (float)num;
  int i;
  for (i = 0; i < 10; i++) {
    printf("Rounding %f to %d: %f\n", f, (int)f, f);
  }
}

int main(int argc, char *argv[]) {
  int n = atoi(argv[1]); // Get the value of 'n' from the command line

  optimize_loops(n); // Demonstrate loop optimizations
  test_rounding(n); // Demonstrate rounding mode and floating point

  return 0;
}