
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv) {
  // Whole Program Analysis optimization
  if (argc > 1) {
    for (int i = 0; i < argc; i++) {
      printf("Arg %d: %s\n", i, argv[i]);
    }
  }
  
  // Frontend optimization
  char *str = "Hello, world!";
  fwprintf(stdout, "%s", str);
  
  return 0;
}