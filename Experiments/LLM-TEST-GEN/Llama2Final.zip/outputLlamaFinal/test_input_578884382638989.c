
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <support/ScalarOptimizations.h>
#include <support/SupportLibraries.h>

int main(int argc, char *argv[]) {
    // Check if the input is a string
    if (strcmp(argv[1], "string") == 0) {
        // Load the string into a pointer
        char *ptr = argv[2];
        // Perform pointer arithmetic
        printf("Result: %s\n", *ptr);
    } else {
        // Print an error message if the input is not a string
        printf("Invalid input\n");
    }
    return 0;
}