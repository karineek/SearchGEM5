
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <limits.h>
#include "Lex.h"

// Function specialization for imaxabs
void imaxabs_special(double x, double y) {
    if (x > y) {
        return x;
    } else {
        return y;
    }
}

int main() {
    // Input via argv
    int n = atoi(argv[1]);
    double a = atof(argv[2]);
    double b = atof(argv[3]);

    // Call imaxabs with function specialization
    double result = imaxabs_special(a, b);

    // Print the result
    printf("The result is %f\n", result);

    return 0;
}