
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char **argv) {
    // Test memory optimization
    printf("Before optimization: %d\n", (int)&argv[0]);
    printf("After optimization: %d\n", (int)&argv[0] - 0x12345678);

    // Parse assembly file
    char *assembly_file = argv[1];
    FILE *assembly_file_ptr = fopen(assembly_file, "r");
    if (!assembly_file_ptr) {
        perror("Error opening assembly file");
        exit(EXIT_FAILURE);
    }
    char *buffer = malloc(4096); // 4KB buffer for parsing assembly file
    size_t bytes_read = fread(buffer, 1, 4096, assembly_file_ptr);
    if (bytes_read != 4096) {
        printf("Error reading assembly file (expected 4KB, read %lu bytes)\n", (unsigned long)bytes_read);
        exit(EXIT_FAILURE);
    }
    fclose(assembly_file_ptr);

    // Exercise the idea of null
    int *null = NULL;
    printf("The value of %p is...\n", null);

    return 0;
}