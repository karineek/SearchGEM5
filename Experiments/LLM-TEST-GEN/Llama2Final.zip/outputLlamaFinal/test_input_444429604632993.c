
#include <stdio.h>
#include <string.h>

int main(int argc, char** argv) {
    // Loop vectorization optimization
    for (size_t i = 0; i < strlen(argv[1]); ++i) {
        printf("%c", *(uchar*)((char*)argv[2] + i));
    }

    return 0;
}