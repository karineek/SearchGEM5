
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <profileguidedoptimization/pgopt.h>
#include <lex/lex.h>

int main(int argc, char **argv) {
    // Initialize the Lex parser
    lex_t *lex = lex_create();
    if (!lex) {
        fprintf(stderr, "Failed to create Lex parser\n");
        return 1;
    }

    // Initialize the Profile-Guided Optimization engine
    pg_opt_t *pg_opt = pg_opt_create();
    if (!pg_opt) {
        fprintf(stderr, "Failed to create Profile-Guided Optimization engine\n");
        return 1;
    }

    // Parse the input string using the Lex parser
    char *input = argv[1];
    lex_parse(lex, input);

    // Perform profile-guided optimization on the parsed tree
    pg_opt_perform(pg_opt, lex->tree);

    // Print the optimized tree
    char *output = pg_opt_get_output(pg_opt, NULL);
    if (output) {
        printf("Optimized tree: %s\n", output);
    } else {
        printf("No optimization was performed\n");
    }

    // Clean up the Lex and Profile-Guided Optimization objects
    lex_destroy(lex);
    pg_opt_destroy(pg_opt);

    return 0;
}