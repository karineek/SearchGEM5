
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <iostream>
#include <map>
#include <utility>

// Macro to expand double-minimum expression
#define DBL_MIN_EXP(a, b) (std::min(a, b))

int main(int argc, char** argv) {
  // Check for enough arguments
  if (argc < 2) {
    std::cerr << "Usage: " << argv[0] << " <expression1> <expression2>\n";
    return 1;
  }

  // Get the expressions from the command line
  std::vector<std::string> expressions = {argv[1], argv[2]};

  // Initialize the vector of doubles
  double* values = new double[expressions.size()];

  // Loop through the expressions and calculate the result
  for (int i = 0; i < expressions.size(); i++) {
    std::string expression = expressions[i];
    double result = 0;
    int pos = expression.find("*");
    if (pos != -1) {
      // Handle multiplication
      double a = strtod(expression.c_str(), NULL), b = strtod(expression.c_str() + pos + 1, NULL);
      result = DBL_MIN_EXP(a, b);
    } else {
      // Handle addition
      double a = strtod(expression.c_str(), NULL);
      result = a;
    }
    values[i] = result;
  }

  // Print the results
  for (int i = 0; i < expressions.size(); i++) {
    std::cout << "Result: " << values[i] << "\n";
  }

  // Clean up
  delete[] values;

  return 0;
}