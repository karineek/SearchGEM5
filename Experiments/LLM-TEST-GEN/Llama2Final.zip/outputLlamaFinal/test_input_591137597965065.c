
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <clang/clang.h>

// Function to optimize with LICM
void foo(void) {
  // Body of the function
  bar();
}

// Function to trigger LICM optimization
void bar(void) {
  // Code that can be inlined or moved
  printf("Hello, world!\n");
}

int main(int argc, char **argv) {
  // Check if the -licm flag is given
  if (strcmp(argv[1], "-licm") == 0) {
    // Enable LICM optimization
    clang_discard_output;
    foo();
  } else {
    // Disable LICM optimization
    clang_keep_output;
    foo();
  }
  
  return 0;
}