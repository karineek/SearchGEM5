
#include <stdint.h>
#include <support/vector.h>

int main(int argc, char** argv) {
    // Initialize vector of 32-bit integers
    uint_least16_t vectors[ARRAY_SIZE];
    for (size_t i = 0; i < ARRAY_SIZE; ++i) {
        vectors[i] = *(uint_least16_t*)argv[i];
    }

    // Perform some operation on the vector of integers
    for (size_t i = 0; i < ARRAY_SIZE; ++i) {
        vectors[i] += vectors[i];
    }

    // Print the result to the console
    for (size_t i = 0; i < ARRAY_SIZE; ++i) {
        printf("%d ", vectors[i]);
    }

    return 0;
}