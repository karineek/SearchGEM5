
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

double expf(double x) {
    return exp(x);
}

int main(int argc, char **argv) {
    double x = atof(argv[1]);
    double y = expf(x);
    printf("The value of y is %lf\n", y);
    return 0;
}