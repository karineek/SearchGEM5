
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <support/SupportLibraries.h>

double loopFusion(int n) {
    double result = 0;
    for (int i = 0; i < n; i++) {
        result += pow(i, 2);
    }
    return result;
}

int main(int argc, char **argv) {
    int n = atoi(argv[1]);
    double result = loopFusion(n);
    printf("Result: %f\n", result);
    return 0;
}