
#include <stdio.h>
#include <string.h>
#include <semantics.h>

// Function specialization example 1
int add_int(int x, int y) {
    return x + y;
}

// Function specialization example 2
double add_double(double x, double y) {
    return x + y;
}

int main(int argc, char **argv) {
    // Parse command line arguments
    int num_args = argc;
    char *args[num_args];
    for (int i = 0; i < num_args; i++) {
        args[i] = argv[i];
    }

    // Use function specialization to evaluate arguments
    int result1 = add_int(atof(args[0]), atof(args[1]));
    double result2 = add_double(atof(args[0]), atof(args[1]));

    // Print results
    printf("Result of function specialization: %d\n", result1);
    printf("Result of function specialization (double): %f\n", result2);

    return 0;
}