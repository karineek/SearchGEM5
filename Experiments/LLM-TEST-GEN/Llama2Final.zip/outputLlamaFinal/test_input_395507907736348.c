
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Define a macro for instruction scheduling
#define SCHEDULE(inst) \
    do { \
        int j = 0; \
        for (int i = 0; i < ARRAY_SIZE; i++) { \
            if (inst[i] == inst[j]) { \
                j++; \
                if (j == ARRAY_SIZE) { \
                    printf("Duplicate instruction found at index %d\n", j); \
                    return 1; \
                } \
            } \
        } \
        if (j == ARRAY_SIZE) { \
            printf("No duplicates found\n"); \
            return 0; \
        } \
    } while (0)

int main(int argc, char *argv[]) {
    // Check for correct number of arguments
    if (argc != 2) {
        printf("Usage: %s <instructions>\n", argv[0]);
        return 1;
    }

    // Read instructions from command line
    char *instructions = argv[1];

    // Initialize instruction array
    int inst[ARRAY_SIZE];
    for (int i = 0; i < ARRAY_SIZE; i++) {
        inst[i] = -1;
    }

    // Schedule instructions
    SCHEDULE(instructions);

    return 0;
}