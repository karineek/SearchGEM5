
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

// Define a function to be inlined
void foo(int x, int y) {
    printf("x = %d, y = %d\n", x, y);
}

int main() {
    // Call the inlined function with arguments passed via argc and argv
    foo(argc > 1 ? *argv[1] : 42, *argv[2]);
    return 0;
}