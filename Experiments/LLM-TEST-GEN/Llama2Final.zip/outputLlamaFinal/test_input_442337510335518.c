
#include <iostream>
#include <vector>
#include <functional>
#include <chrono>

// Function specialization for each argument
template<typename... Args>
void f(Args...) {
  std::cout << "F(..." << std::endl;
}

int main(int argc, char** argv) {
  if (argc < 2) {
    std::cerr << "Usage: " << argv[0] << " <arguments>" << std::endl;
    return 1;
  }

  // Function specialization for each argument
  f(argv[1], argv[2], ...);

  return 0;
}