
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "lex.h"
#include "wctob.h"

int main(int argc, char *argv[]) {
    // Input from command line
    if (argc < 2) {
        printf("Usage: %s <input_string>\n", argv[0]);
        return 1;
    }

    // Lexical analysis
    Token token = lex(argv[1]);

    // Whole program analysis
    int result = wctob(token);

    printf("Result: %d\n", result);

    return 0;
}