
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include < LLVM/OpenSSL.h>

int main(int argc, char **argv) {
    // Take input from the command line
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    // Load the input file into a LLVM bitstream
    std::string input = argv[1];
    llvm::Module module;
    llvm::parse assemblyString(input, module);

    // Perform instruction scheduling optimizations
    module.optimize(llvm::OptLevel::Aggressive, true);

    // Print the optimized module
    llvm::verify(module);
    std::string optimizedModule = module.getBinary().getAsString();
    printf("Optimized module:\n%s\n", optimizedModule.c_str());

    return 0;
}