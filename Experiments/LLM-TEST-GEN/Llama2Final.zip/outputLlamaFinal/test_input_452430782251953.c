
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// Inline function to demonstrate inlining optimization
void foo(int x, int y) {
    printf("Inlined function called with arguments %d and %d\n", x, y);
}

int main(int argc, char **argv) {
    if (argc >= 2) {
        int x = atoi(argv[1]);
        int y = atoi(argv[2]);
        foo(x, y); // Inline function call
    } else {
        printf("Error: too few arguments\n");
    }
    return 0;
}