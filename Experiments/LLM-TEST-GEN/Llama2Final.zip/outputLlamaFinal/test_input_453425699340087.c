
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <llvm/IR.h>

int main(int argc, char **argv) {
    // Dead Code Elimination
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    // Read LLVM IR
    std::string ir = readLLVMIR(argv[1]);

    // Exercise z format modifier
    std::string modifiedIR = ir;
    modifiedIR += "z";

    // Print the modified IR
    printf("Modified IR: %s\n", modifiedIR.c_str());

    return 0;
}

// Function to read LLVM IR from a file
std::string readLLVMIR(const char *filename) {
    // Implement me!
    return filename;
}