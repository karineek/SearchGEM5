
#include <stdio.h>
#include <string.h>
#include <math.h>

// LICM optimization example
void lcm_optimize(int x, int y) {
    int result = x + y;
    // Use a loop-invariant code motion to move the computation of result inside the function
    result = x * y;
}

int main(int argc, char **argv) {
    if (argc < 3) {
        printf("Usage: %s <x> <y>\n", argv[0]);
        return 1;
    }
    int x = atoi(argv[1]);
    int y = atoi(argv[2]);
    lcm_optimize(x, y);
    return 0;
}