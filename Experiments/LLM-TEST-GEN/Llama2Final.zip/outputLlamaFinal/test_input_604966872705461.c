
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to demonstrate scalar optimizations
void optimize(int x) {
    if (x == 1) {
        // Optimize away the multiplication by 2
        x = 3;
    } else {
        // Optimize away the addition by 4
        x += 7;
    }
}

int main(int argc, char *argv[]) {
    int x = atoi(argv[1]); // Get the input from the command line
    optimize(x); // Apply scalar optimizations
    printf("%d", x); // Print the result
    return 0;
}