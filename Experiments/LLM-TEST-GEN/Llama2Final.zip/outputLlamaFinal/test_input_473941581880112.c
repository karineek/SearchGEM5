
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Function to perform constant folding optimization
void foldConstants(char *str) {
  int numValues = 0;
  char *values = strtok(str, " "); // Tokenize the input string into individual words
  while (values != NULL) {
    if (strcmp(values, "1") == 0) {
      numValues++;
    } else if (strcmp(values, "2") == 0) {
      numValues++;
    } else if (strcmp(values, "3") == 0) {
      numValues++;
    }
    values = strtok(NULL, " "); // Move to the next token
  }

  // Perform constant folding optimization
  char *result = malloc(numValues * sizeof(char));
  int i = 0;
  for (i = 0; i < numValues; i++) {
    result[i] = values[i];
  }

  free(values); // Release memory allocated for the tokenized input

  printf("Results: %s\n", result);
}

int main(int argc, char **argv) {
  if (argc < 2) {
    printf("Usage: %s <input_string>\n", argv[0]);
    return 1;
  }

  // Perform constant folding optimization on the input string
  foldConstants(argv[1]);

  return 0;
}