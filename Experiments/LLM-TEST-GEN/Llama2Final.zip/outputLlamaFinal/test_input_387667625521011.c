
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// Function to demonstrate dead code elimination
int main(void) {
    // Dead code elimination: the following line is not executed, so it can be removed
    printf("Hello, world!\n");

    // Real code starts here
    int input = atoi(argv[1]);
    if (input > UINTPTR_MAX) {
        printf("Input value exceeds maximum value of %u\n", UINTPTR_MAX);
    } else {
        printf("Input value is: %d\n", input);
    }

    return 0;
}