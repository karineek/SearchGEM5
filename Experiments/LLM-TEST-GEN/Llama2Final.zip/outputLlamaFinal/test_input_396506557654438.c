
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <iostream>

// Function to demonstrate vectorization
void vecAdd(float* arr, int size) {
    for (int i = 0; i < size; i++) {
        arr[i] = arr[i] + 1.0f;
    }
}

int main(int argc, char** argv) {
    // Check if vectorization is enabled
    if (getenv("VECTORIZATION") != nullptr) {
        // Enable vectorization for the vecAdd function
        std::vector<float> vec(argv[1]);
        vecAdd(&vec[0], vec.size());
    } else {
        // Disable vectorization and perform the operation manually
        float arr[10];
        for (int i = 0; i < 10; i++) {
            arr[i] = atof(argv[2]);
        }
        for (int i = 0; i < 10; i++) {
            arr[i] += 1.0f;
        }
    }
    return 0;
}