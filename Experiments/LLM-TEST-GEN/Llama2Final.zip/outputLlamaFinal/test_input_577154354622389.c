
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <llvm/Bitcode.h>

// Function to parse input from command line
int main(int argc, char **argv) {
    // Parse input from command line
    int num_ints = 0;
    int *ints = NULL;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-n")) {
            num_ints++;
        } else if (!strcmp(argv[i], "-i")) {
            // Allocate memory for integers
            ints = realloc(ints, num_ints * sizeof(int));
            if (ints == NULL) {
                perror("reallocation failed");
                return 1;
            }
        } else {
            // Ignore other options
        }
    }

    // Parse input integers
    for (int i = 0; i < num_ints; i++) {
        int temp = strtol(argv[i + 1], NULL, 10);
        ints[i] = temp;
    }

    // Print the parsed integers
    for (int i = 0; i < num_ints; i++) {
        printf("%d ", ints[i]);
    }
    puts("");

    return 0;
}