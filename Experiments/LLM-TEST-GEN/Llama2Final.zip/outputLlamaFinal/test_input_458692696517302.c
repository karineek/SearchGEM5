
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

// Function to test loop optimizations
void testLoops(int n) {
  int i;
  for (i = 0; i < n; ++i) {
    // Do some work here...
    printf("Loop %d: ", i);
    for (int j = 0; j < 10; ++j) {
      printf("Inner loop ");
      if (j % 2 == 0) {
        printf("even\n");
      } else {
        printf("odd\n");
      }
    }
  }
}

int main(int argc, char *argv[]) {
  // Check if the user provided an input
  if (argc < 2) {
    printf("Usage: %s <n>\n", argv[0]);
    return 1;
  }

  int n = atoi(argv[1]);

  testLoops(n);

  // Return 0 to indicate success
  return 0;
}