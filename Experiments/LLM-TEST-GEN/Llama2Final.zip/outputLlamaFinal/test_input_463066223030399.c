
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

// Function Specialization
void print_binary(const char *data, size_t len) {
    for (size_t i = 0; i < len; i++) {
        printf("%02x", data[i]);
    }
}

int main() {
    // Input taken via argv only
    const char *binary_data = argv[1];
    size_t binary_len = strlen(binary_data);

    // Call the specialized print_binary function with the binary data
    print_binary(binary_data, binary_len);

    return 0;
}