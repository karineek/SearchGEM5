
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>

// Function to test loop optimizations
void optimize_loops(int n) {
  int i, j;
  for (i = 0; i < n; i++) {
    for (j = 0; j < n; j++) {
      if (i == j) {
        printf("Hello, World!\n");
      }
    }
  }
}

int main(int argc, char *argv[]) {
  int n = atoi(argv[1]);
  optimize_loops(n);
  return 0;
}