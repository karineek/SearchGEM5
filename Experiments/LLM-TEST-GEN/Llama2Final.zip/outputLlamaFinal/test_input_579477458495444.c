
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Dead code elimination example
void foo() {
    if (argv[1][0] == 'f') {
        // do nothing
    } else {
        printf("Hello, world!\n");
    }
}

// Assembly-level optimization example
#define MAX_STRLEN 128
char str[MAX_STRLEN];
void bar() {
    snprintf(str, MAX_STRLEN, "%s", "Hello, world!");
    printf("%s\n", str);
}

// SCHAR_MIN example
#define SCHAR_MIN (-128)
int main() {
    int x = SCHAR_MIN;
    printf("x = %d\n", x);
    return 0;
}

// BASH example
int main(int argc, char *argv[]) {
    if (argc > 1 && strcmp(argv[1], "--foo") == 0) {
        foo();
    } else {
        bar();
    }
    return 0;
}