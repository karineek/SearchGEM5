
#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Define a structure to hold the input data
typedef struct {
    int x[3];
} my_struct;

// Function to demonstrate automatic vectorization using <<=
void foo(my_struct arr) {
    // Initialize the array with some random values
    for (int i = 0; i < 3; i++) {
        arr.x[i] = rand() % 10;
    }

    // Perform a left-shift assignment using <<=
    for (int i = 0; i < 3; i++) {
        arr.x[i] <<= 2;
    }

    // Print the resulting array
    printf("Array after left-shift assignment: ");
    for (int i = 0; i < 3; i++) {
        printf("%d ", arr.x[i]);
    }
    printf("\n");
}

// Example input data
my_struct arr;
for (int i = 0; i < 3; i++) {
    arr.x[i] = i * 10 + 10;
}

int main(int argc, char** argv) {
    if (argc < 2) {
        printf("Usage: %s <input_data>\n", argv[0]);
        return 1;
    }

    // Parse the input data from the command line
    my_struct arr = *(my_struct*)malloc(sizeof(my_struct));
    sscanf(argv[1], "%x", &arr);

    // Call the function to demonstrate automatic vectorization
    foo(arr);

    return 0;
}