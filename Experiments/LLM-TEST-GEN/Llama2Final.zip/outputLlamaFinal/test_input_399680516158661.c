
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Definition of atan2 type-generic macro
#define atan2(x, y) \
    (((double)(x)) * sin(y)) / (cos(x) * cos(y))

int main(int argc, char **argv) {
    double x = strtof(argv[1], NULL); // Argument from command line
    double y = strtof(argv[2], NULL);
    double result = atan2(x, y);
    printf("%lf\n", result);
    return 0;
}