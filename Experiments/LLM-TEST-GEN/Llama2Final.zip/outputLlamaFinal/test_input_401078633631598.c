
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <inttypes.h>
#include "object.h"
#include "binary_format.h"

int main(int argc, char *argv[]) {
    // Initialize the object and binary format
    Object *obj = object_init();
    BinaryFormat *bin = binary_format_init();

    // Load the input from the command line
    char *input = argv[1];

    // Parse the input using the object and binary format
    int ret = parse_input(input, obj, bin);

    // Check for errors
    if (ret != 0) {
        fprintf(stderr, "Error parsing input: %s\n", strerror(errno));
        return 1;
    }

    // Schedule the instructions using the SEEK_CUR macro
    macro_t mac = {
        .op = OP_SEEK_CUR,
        .arg1 = (intptr_t)bin->cur,
        .arg2 = (intptr_t)input + 1, // offset from the beginning of the input to the next instruction
    };
    schedule_instructions(obj, &mac);

    // Print the scheduled instructions
    print_scheduled_instructions(obj);

    // Clean up
    object_free(obj);
    binary_format_free(bin);

    return 0;
}