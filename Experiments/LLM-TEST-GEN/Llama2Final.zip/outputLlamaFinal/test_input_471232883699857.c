
#include <stdio.h>
#include <clang/parse.h>
#include <clang/ISPunct.h>

int main(int argc, char **argv) {
    // Input string from command line argument
    const char *input = argv[1];

    // Parse the input string using Clang's parse function
    ClangModule module;
    module.Parse(input);

    // Exercise the ispunct function
    for (ClangToken token = module.token_begin; token != module.token_end; token++) {
        if (token.kind == ClangTokenKind::ISPUNCT) {
            printf("Found punctuation token %c\n", token.text[0]);
        }
    }

    return 0;
}