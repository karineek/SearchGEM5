
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(int argc, char *argv[]) {
  // Initialize profiling data structure
  struct {
    int cnt;
    double sum;
  } profile;

  // Parse assembly file
  char *assembly_file = argv[1];
  FILE *assembly_file_ptr = fopen(assembly_file, "r");
  if (assembly_file_ptr == NULL) {
    printf("Error: Could not open assembly file %s\n", assembly_file);
    return 1;
  }

  // Read assembly code from file
  char *line = NULL;
  size_t len = 0;
  while ((line = fgets(assembly_file_ptr,len,assembly_file)) != NULL) {
    // Ignore comments and empty lines
    if (line[0] == '#' || line[0] == '\n') continue;

    // Add to profiling data structure
    profile.cnt++;
    profile.sum += strtod(line,NULL);
  }

  // Print profiling results
  printf("Profiling Results:\n");
  printf("Total instructions: %d\n", profile.cnt);
  printf("Average instruction size: %f\n", profile.sum / profile.cnt);

  return 0;
}