
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>

// Definition of an atomic integer type that uses least 8 bits
atomic_int_least8_t {
    int val;
    uint8_t flag;
} atomic;

// Function to perform constant folding on a expression
#define CF(exp) (__builtin_constant_p(exp) ? exp : 0)

int main(int argc, char **argv) {
    // Check if the input file exists and is a binary format
    if (argc < 2 || !strcmp(argv[1], "--binary")) {
        fprintf(stderr, "Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    // Open the input file in binary format
    FILE *fp = fopen(argv[1], "rb");
    if (!fp) {
        fprintf(stderr, "Error: unable to open %s\n", argv[1]);
        return 1;
    }

    // Read the input file and perform constant folding
    uint8_t buffer[4];
    size_t len = fread(buffer, 1, sizeof(buffer), fp);
    if (len < sizeof(atomic_int_least8_t)) {
        fprintf(stderr, "Error: input file is too small\n");
        return 1;
    }

    atomic_int_least8_t *data = (atomic_int_least8_t *)buffer;
    data->val = CF(data->val); // Perform constant folding on the value field

    // Print the modified input file
    printf("Original: %02x%02x\n", buffer[0], buffer[1]);
    printf("Modified: %02x%02x\n", data->val, data->flag);

    // Close the input file
    fclose(fp);

    return 0;
}