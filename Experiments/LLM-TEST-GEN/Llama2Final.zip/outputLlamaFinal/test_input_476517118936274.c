
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/wait.h>

// Inline function to test inlining optimization
int inline_function(int x, int y) {
    return x + y;
}

int main() {
    // Take input from command line arguments
    int num_args = sizeof(argv) / sizeof(argv[0]);
    for (int i = 0; i < num_args; i++) {
        printf("Argument %d: %s\n", i, argv[i]);
    }

    // Call the inline function with inlining optimization enabled
    int result = inline_function(10, 20);
    printf("Result: %d\n", result);

    // Test code generation using WEOF
    char* buffer = malloc(100);
    strcpy(buffer, "WEOF");
    printf("%s\n", buffer);

    return 0;
}