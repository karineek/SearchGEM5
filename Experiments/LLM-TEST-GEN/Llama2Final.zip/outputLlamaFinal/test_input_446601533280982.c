
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/wait.h>

// Function to inline and exercise the idea of thrd_equal
void thrd_equal(int a, int b) {
    if (a == b) {
        printf("a and b are equal\n");
    } else {
        printf("a and b are not equal\n");
    }
}

// Function to deal with binary formats
void process_binary(char *data, int len) {
    // Do something with the binary data
    char *ptr = data;
    while (len-- > 0) {
        printf("%d: %x\n", len, *ptr);
        ptr++;
    }
}

int main(int argc, char **argv) {
    // Check if the input is binary data
    if (strcmp(argv[1], "-b") == 0) {
        // Process the binary data
        process_binary(argv[2], strlen(argv[2]));
    } else {
        // Inline the thrd_equal function and exercise the idea of thrd_equal
        thrd_equal(atoi(argv[1]), atoi(argv[3]));
    }
    return 0;
}