
#include <iostream>
#include <clang/clang.h>

double truncf(double x) {
  return floor(x + 0.5);
}

int main(int argc, char** argv) {
  // Inline the truncf function to reduce overhead
  inline double truncf(double x) { return floor(x + 0.5); }

  double input = atoi(argv[1]); // BASH example: $ ./a.out 4.5
  double result = truncf(input);
  std::cout << "Result: " << result << std::endl;

  return 0;
}