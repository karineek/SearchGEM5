
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Definition of the tm_year function
int tm_year(int day, int month, int year) {
  // SCCP optimization: propagate constants to reduce computations
  if (month == 2 || month == 4 || month == 6 || month == 9 || month == 11) {
    return year * 3 + day;
  } else {
    return year * 2 + day;
  }
}

int main(int argc, char **argv) {
  // Input: day = 5, month = 7, year = 1980
  int day = atoi(argv[1]);
  int month = atoi(argv[2]);
  int year = atoi(argv[3]);

  printf("tm_year(%d, %d, %d) = %d\n", day, month, year, tm_year(day, month, year));

  return 0;
}