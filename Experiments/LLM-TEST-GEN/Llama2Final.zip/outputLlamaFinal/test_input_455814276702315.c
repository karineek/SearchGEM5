
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Define a simple function for demonstration purposes
double my_function(double x) {
    return x * 2;
}

int main() {
    // Take input from command line using argc and argv
    int argc = sizeof(argv) / sizeof(argv[0]);
    char* argv[] = {"Hello", "World!"};

    // Inline the my_function function into the main function
    double result = my_function(argv[1]);

    // Print the result to the console
    printf("The result is %f\n", result);

    return 0;
}