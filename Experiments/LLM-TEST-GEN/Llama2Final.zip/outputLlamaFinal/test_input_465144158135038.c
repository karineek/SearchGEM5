
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// Function inlining example
void inline_example(int x, int y) {
    printf("Inlined function: %d + %d = %d\n", x, y, x + y);
}

int main(int argc, char **argv) {
    if (argc < 3) {
        fprintf(stderr, "Usage: %s <input_value> <output_value>\n", argv[0]);
        return 1;
    }

    int x = atoi(argv[1]);
    int y = atoi(argv[2]);

    // Inline the example function
    inline_example(x, y);

    // Print the result of the inlined function
    printf("Inlined result: %d\n", x + y);

    return 0;
}