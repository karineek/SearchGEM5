
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_INPUT_LENGTH 1024

int main(int argc, char *argv[]) {
    // Initialize variables
    int num_instructions = 0;
    int num_registers = 0;
    int max_num_registers = 0;
    int current_instruction = 0;

    // Read input from command line
    if (argc > 1) {
        char *input = argv[1];
        size_t input_length = strlen(input);
        while (current_instruction < input_length) {
            int instruction = atoi(input + current_instruction);
            switch (instruction) {
                case 1: // Increment counter
                    num_instructions++;
                    break;
                case 2: // Decrement counter
                    num_instructions--;
                    break;
                case 3: // Set register to value
                    max_num_registers = atoi(input + current_instruction + 1);
                    break;
            }
            current_instruction += 2;
        }
    } else {
        printf("Error: Please provide an input\n");
        return 1;
    }

    // Print output
    printf(" num_instructions = %d\n", num_instructions);
    printf(" max_num_registers = %d\n", max_num_registers);

    return 0;
}