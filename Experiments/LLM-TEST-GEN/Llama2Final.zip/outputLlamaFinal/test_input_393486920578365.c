
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Function to demonstrate constant folding
int add(int a, int b) {
    return a + b;
}

// Function to demonstrate serialization
char* serialize(int x) {
    char buffer[20];
    snprintf(buffer, sizeof(buffer), "%d", x);
    return buffer;
}

int main(int argc, char** argv) {
    int x = atoi(argv[1]); // Parse input from command line
    char* serialized_x = serialize(x); // Serialize the integer value
    printf("Serialized value: %s\n", serialized_x); // Print the serialized value
    int y = add(3, 4); // Use constant folding to compute the result
    printf("Result of addition: %d\n", y); // Print the result of the addition
    free(serialized_x); // Free the memory allocated for the serialized value
    return 0;
}