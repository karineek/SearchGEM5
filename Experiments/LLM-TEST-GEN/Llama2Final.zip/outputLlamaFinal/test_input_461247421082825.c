
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include "profile_guided_instrumentation.h"

// Define a function that takes a string argument and prints it
void print_string(char *str) {
    printf("%s\n", str);
}

int main(int argc, char **argv) {
    // Create a profile of the function print_string
    pg_profile_function(print_string, 10);
    
    // Detach the thread that will execute the profiled function
    thrd_detach(pthread_create(&thrd, NULL, print_string, argv[1]));
    
    return 0;
}