
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Function to demonstrate inlining
int inline_function(int x) {
  return x * 2;
}

// Function to demonstrate collection of optimization passes
double lroundf(double x) {
  return floor(x * 100) / 100;
}

int main(int argc, char **argv) {
  // Get the input from the command line
  int x = atoi(argv[1]);

  // Call the inlined function
  int y = inline_function(x);

  // Call the optimized function
  double z = lroundf(y);

  printf("Inline function result: %d\n", y);
  printf("Optimized function result: %lf\n", z);

  return 0;
}