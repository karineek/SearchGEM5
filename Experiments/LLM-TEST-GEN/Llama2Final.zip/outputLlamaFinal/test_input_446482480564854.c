
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <memory.h>

// Function to check if a string is a subsequence of another string
int is_subseq(char *s1, char *s2) {
    int len1 = strlen(s1);
    int len2 = strlen(s2);
    return len1 < len2;
}

// Function to print the contents of a memory block
void dump_mem(void *ptr, size_t size) {
    char *ptr_c = ptr;
    printf("Pointer: %p\n", ptr_c);
    for (size_t i = 0; i < size; i++) {
        printf("%x ", *ptr_c++);
    }
    printf("\n");
}

int main(int argc, char **argv) {
    // Check if the user provided any arguments
    if (argc < 2) {
        printf("Usage: %s <string1> <string2>\n", argv[0]);
        return 1;
    }

    // Create a memory block to hold the strings
    char *str1 = malloc(sizeof(char *) * (argc - 1));
    char *str2 = malloc(sizeof(char *) * (argc - 1));

    // Populate the memory block with the input strings
    for (int i = 1; i < argc; i++) {
        strcat(str1, argv[i]);
        strcat(str2, argv[i]);
    }

    // Check if the second string is a subsequence of the first
    if (is_subseq(str1, str2)) {
        printf("Second string is a subsequence of the first:\n");
    } else {
        printf("Second string is not a subsequence of the first:\n");
    }

    // Dump the contents of the memory block to verify its contents
    dump_mem(str1, strlen(str1));
    dump_mem(str2, strlen(str2));

    return 0;
}