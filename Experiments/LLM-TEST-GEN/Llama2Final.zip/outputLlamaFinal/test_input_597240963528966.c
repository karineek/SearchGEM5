
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv) {
    // Get the number of arguments from the command line
    int num_args = argc;

    // Loop through each argument and perform operations
    for (int i = 0; i < num_args; i++) {
        // Get the value of the current argument
        char *arg = argv[i];

        // Perform an operation on the argument using the addition assignment operator (+=)
        int num = atoi(arg);
        num += 5;

        // Print the result
        printf("The result is %d\n", num);
    }

    return 0;
}