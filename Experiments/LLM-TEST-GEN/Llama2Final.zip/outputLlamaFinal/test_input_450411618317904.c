
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

// Define a type for the input size
typedef long rsize_t;

int main(int argc, char **argv) {
    // Check if enough arguments were passed
    if (argc < 2) {
        printf("Usage: %s <input_size>\n", argv[0]);
        return 1;
    }

    // Get the input size from the user
    rsize_t size = strtol(argv[1], NULL, 10);

    // Trigger register allocation optimizations
    int arr[size];
    for (rsize_t i = 0; i < size; i++) {
        arr[i] = i;
    }

    // Print the result
    for (rsize_t i = 0; i < size; i++) {
        printf("%ld ", arr[i]);
    }
    printf("\n");

    return 0;
}