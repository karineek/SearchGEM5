
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <math.h>
#include <float.h>
#include <profile.h>
#include <support/SupportLibraries.h>

double fma(double x, double y, double z) {
    return x * y + z;
}

double fma_type_generic(int x, int y, int z) {
    return (double)x * (double)y + (double)z;
}

double fmaf(float x, float y, float z) {
    return (double)x * (double)y + (double)z;
}

double fmal(double x, double y, double z) {
    return x * y + z;
}

int main(int argc, char **argv) {
    // Example input: 4.0 3.0 2.0
    double input = atof(argv[1]);
    double result = fma(input, atof(argv[2]), atof(argv[3]));
    printf("%f\n", result);
    return 0;
}