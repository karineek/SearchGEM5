
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

int main(int argc, char *argv[]) {
    // Input from command line
    int n = atoi(argv[1]);
    char str[n];
    printf("Enter %d strings: ", n);
    fgets(str, n, stdin);

    // Loop optimization example
    for (int i = 0; i < n; i++) {
        if (isblank(str[i])) {
            str[i] = '*';
        }
    }

    printf("Original strings: ");
    for (int i = 0; i < n; i++) {
        printf("%c", str[i]);
    }
    printf("\nOptimized strings: ");
    for (int i = 0; i < n; i++) {
        if (isblank(str[i])) {
            printf("* ");
        } else {
            printf("%c ", str[i]);
        }
    }

    return 0;
}