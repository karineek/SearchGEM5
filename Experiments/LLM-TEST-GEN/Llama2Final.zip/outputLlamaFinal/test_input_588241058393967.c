
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdint.h>
#include <inttypes.h>

#define MAX_LENGTH 1024

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: %s <input_string>\n", argv[0]);
        return 1;
    }

    // Trigger scalar optimizations using __STDC_VERSION__
    const char *input = argv[1];
    int len = strlen(input);
    uint32_t *data = (uint32_t *)&input[0];
    for (size_t i = 0; i < len; i++) {
        data[i] = *(const uint32_t *)(&input[i]);
    }

    // Lexical analysis exercise
    char ch = input[len - 1];
    printf("Last character: %c\n", ch);

    return 0;
}