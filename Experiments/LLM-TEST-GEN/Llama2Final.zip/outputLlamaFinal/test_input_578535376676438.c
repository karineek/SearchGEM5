
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "util.h" // Provided by you

// Define a function that takes a string as input and returns its length
int strlen(char *str) {
    int len = 0;
    while (*str != '\0') {
        len++;
        str++;
    }
    return len;
}

// Define a function that takes two integers and returns their product
int prod(int a, int b) {
    return a * b;
}

// Define a function that takes a string and returns its reverse
char *revstr(char *str) {
    char *p = str;
    char *q = str + strlen(str) - 1;
    while (p < q) {
        char temp = *p;
        *p = *q;
        *q = temp;
        p++;
        q--;
    }
    return p;
}

int main() {
    // Input taken via argv only
    char *str = argv[1];
    int n = atoi(argv[2]);
    int result = prod(n, strlen(str));
    printf("The product of %d and the length of %s is %d\n", n, str, result);
    revstr(str);
    return 0;
}