
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>

// Definition of the atomic_int_fast8_t type
typedef struct {
    int value;
} atomic_int_fast8_t;

// Function to promote memory to registers
void promote_memory_to_registers(void) {
    // Get the address of the first element in the array
    void *array = argv[1];

    // Loop through each element in the array and promote it to a register
    for (int i = 0; i < sizeof(argv) / sizeof(argv[0]); i++) {
        void *element = array + i;
        atomic_int_fast8_t *atomic = element;
        atomic->value = *(int *)element;
    }
}

int main(int argc, char **argv) {
    // Promote the memory to registers
    promote_memory_to_registers();

    return 0;
}