
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function specialization for error handling
void thrd_error(const char *message) {
    fprintf(stderr, "%s\n", message);
}

int main(int argc, char **argv) {
    // Test function specialization
    thrd_error("Testing function specialization");
    
    // AST example for error handling
    if (argc < 2) {
        thrd_error("Insufficient arguments");
    } else {
        printf("%s\n", argv[1]);
    }
    
    return 0;
}