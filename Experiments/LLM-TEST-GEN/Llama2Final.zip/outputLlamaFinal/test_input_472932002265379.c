
#include <stdio.h>
#include <stdint.h>
#include <llvm/llvm.h>

// Define a function that takes two integers as input and returns their sum
int32_t sum(int32_t a, int32_t b) {
  return a + b;
}

int main(void *arg) {
  // Parse command line arguments
  int argc = sizeof(argv) / sizeof(argv[0]);
  char **argv = argv;

  if (argc < 2) {
    printf("Usage: %s <a> <b>\n", argv[0]);
    return 1;
  }

  int32_t a = atoi(argv[1]);
  int32_t b = atoi(argv[2]);

  // Eliminate common subexpression
  int32_t result = a + b;

  // Print the result
  printf("The sum of %d and %d is %d\n", a, b, result);

  return 0;
}