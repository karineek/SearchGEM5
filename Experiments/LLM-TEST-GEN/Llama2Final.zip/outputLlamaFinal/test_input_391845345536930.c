
#include <iostream>
#include <vector>
#include <math.h>

int main(int argc, char** argv) {
    // Initialize the vector of doubles
    std::vector<double> v = {0};

    // Populate the vector with input from the user
    while (argc > 1) {
        double input = atof(argv[1]);
        v.push_back(input);
        argc--;
        argv++;
    }

    // Perform vectorization optimization using the sinh() function
    std::vector<double> result = v;
    for (int i = 0; i < v.size(); i++) {
        result[i] = sinh(result[i]);
    }

    // Print the result
    for (int i = 0; i < result.size(); i++) {
        std::cout << result[i] << " ";
    }
    std::cout << std::endl;

    return 0;
}