
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "llvm/profile.h"

// Function to instrument a function
void instrument_function(void *func) {
  // Get the function address
  void *func_addr = func;
  
  // Instrument the function
  llvm::ProfileGuidedInstrumentation(func_addr);
}

int main() {
  // Get the function address from the command line argument
  void *func_addr = (void *)atoi(argv[1]);
  
  // Instrument the function
  instrument_function(func_addr);
  
  return 0;
}