
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <clang-frontend/loop-fusion.h>

int main(int argc, char **argv) {
  // Example input: "ff 1 2 3"
  char *input = argv[1];
  size_t len = strlen(input);
  int fused_loops = loop_fusion(input, len);
  printf("Fused loops: %d\n", fused_loops);
  return 0;
}