
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to demonstrate vectorization
void cnd_signal(int n) {
    int i;
    for (i = 0; i < n; ++i) {
        printf("Signaling %d\n", i);
    }
}

int main(int argc, char **argv) {
    int n = atoi(argv[1]); // Vectorized input from command line
    cnd_signal(n);          // Call the vectorized function
    return 0;
}