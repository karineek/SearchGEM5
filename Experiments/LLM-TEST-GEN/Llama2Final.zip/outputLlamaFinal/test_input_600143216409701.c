
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Define a function that takes a string as input and returns its length
size_t lengthOfString(char *str) {
    return strlen(str);
}

int main(int argc, char **argv) {
    // Test the length of a string passed as an argument
    printf("Length of '%s' is %zu\n", argv[1], lengthOfString(argv[1]));
    
    // Test assignment and casting
    int x = atoi(argv[2]);
    char y = x;
    printf("x = %d, y = %c\n", x, y);
    
    // Test evaluation and constant folding
    printf("1 + 2 = %d\n", 1 + 2);
    printf("3 * 4 = %d\n", 3 * 4);
    
    // Test the order of evaluation
    printf("(3 + 4) * 5 = %d\n", (3 + 4) * 5);
    
    // Test parentheses and unary operators
    printf("!true = %d\n", !true);
    printf("!false = %d\n", !false);
    
    // Test void functions
    printf("Length of '%s' is %zu\n", "hello", lengthOfString("hello"));
    
    return 0;
}