
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

// Define a hexadecimal constant for testing purposes
#define HELLO_WORLD 0x1234567890abcdef

int main(int argc, char **argv) {
    // Check if the user provided an input string
    if (argc > 1) {
        // Convert the input string to a hexadecimal value
        int input_value = strtoul(argv[1], NULL, 16);

        // Print the converted value
        printf("Input value: %x\n", input_value);
    } else {
        // Print a default message if no input was provided
        printf("No input provided...\n");
    }

    return 0;
}