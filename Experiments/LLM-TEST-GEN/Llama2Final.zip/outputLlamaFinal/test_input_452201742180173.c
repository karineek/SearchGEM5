
#include <stdio.h>
#include <clang/clang.h>

// Function to demonstrate SCCP optimization
void foo(int x, int y) {
  if (x > 0 && y > 0) {
    bar(x + y); // trigger SCCP optimization
  } else {
    bar(x);
  }
}

// Function to demonstrate static analysis in Clang
void bar(int x) {
  if (x >= 0) {
    printf("x is positive\n");
  } else {
    printf("x is negative\n");
  }
}

int main(int argc, char** argv) {
  // Get the input from the command line
  int x = atoi(argv[1]);
  int y = atoi(argv[2]);

  // Call the function that demonstrates SCCP optimization
  foo(x, y);

  return 0;
}