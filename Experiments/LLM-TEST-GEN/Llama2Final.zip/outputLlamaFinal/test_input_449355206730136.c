
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {
    int age;
    char name[50];

    // Parse input from command line using sscanf
    if (sscanf(argv[1], "%d%s", &age, name) != 2) {
        printf("Error parsing input\n");
        return 1;
    }

    // Print the parsed values
    printf("Age: %d\nName: %s\n", age, name);

    return 0;
}