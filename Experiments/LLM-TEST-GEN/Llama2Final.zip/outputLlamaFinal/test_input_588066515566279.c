
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// Exponential function example
double expo(double x, double y) {
  return pow(x, y);
}

int main(int argc, char **argv) {
  if (argc < 3) {
    printf("Usage: %s <input> <exponent>\n", argv[0]);
    return 1;
  }

  double x = strtoDouble(argv[1]); // Handle machine code generation for doubles
  double y = strtoDouble(argv[2]);

  double result = expo(x, y);
  printf("Result: %f\n", result);

  return 0;
}