
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Function Specialization
int cbrtf(int n) {
    if (n <= 0) {
        return -1;
    } else {
        int result = 0;
        for (int i = 0; i < n; i++) {
            result = result * 3 + i * 2;
        }
        return result;
    }
}

// Example Input
int main(int argc, char **argv) {
    int n = atoi(argv[1]);
    printf("The value of cbrtf(n) is %d\n", cbrtf(n));
    return 0;
}