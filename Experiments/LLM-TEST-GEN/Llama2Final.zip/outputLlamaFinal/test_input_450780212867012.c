
#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Define a struct with member variables of type int and char
typedef struct {
    int x;
    char y[5];
} my_struct;

// Define a union with member variables of type int and char
typedef struct {
    int x;
    char y[5];
} my_union;

// Define an enum with member variants of type int and char
typedef enum {
    X = 0,
    Y = 1,
    Z = 2
} my_enum;

// Function to demonstrate memory-to-register promotion optimization
void demo(my_struct *s) {
    // Access s->x and s->y as int values
    printf("s->x = %d\n", *(int *)(&s->x));
    printf("s->y = %c\n", *(char *)(&s->y[0]));

    // Access s->x and s->y as char arrays
    printf("s->y = %s\n", s->y);
}

int main() {
    my_struct s;
    int a = 10;
    char b = 'a';

    // Set member variables of struct using argv only
    s.x = *(int *)argv[1];
    strcpy(s.y, argv[2]);

    demo(&s);

    return 0;
}