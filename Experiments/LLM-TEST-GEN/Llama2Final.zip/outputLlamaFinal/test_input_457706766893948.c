
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

// Function to print the size of an object file
size_t sizeOfObjectFile(const char* filename) {
  // Use Profile-Guided Instrumentation to measure the size of the object file
  int fd = open(filename, O_RDONLY);
  if (fd == -1) {
    perror("Error opening object file");
    return SIZE_MAX;
  }
  uint64_t size = 0;
  while ((read(fd, &size, sizeof(size)) == sizeof(size)) && size > 0);
  close(fd);
  return (size_t)size;
}

int main(int argc, char** argv) {
  if (argc < 2) {
    printf("Usage: %s <object file name>\n", argv[0]);
    return 1;
  }

  // Get the size of the object file
  const char* filename = argv[1];
  size_t size = sizeOfObjectFile(filename);

  if (size == SIZE_MAX) {
    printf("Error: unable to open %s\n", filename);
    return 2;
  }

  // Print the size of the object file
  printf("The size of %s is %ld bytes.\n", filename, (long int)size);

  return 0;
}