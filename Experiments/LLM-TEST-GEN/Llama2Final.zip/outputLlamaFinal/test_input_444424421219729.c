
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define FLT_MAX_10_EXP 1234567890

int main(int argc, char **argv) {
    int n = atoi(argv[1]); // input from command line

    // Loop vectorization example
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < FLT_MAX_10_EXP; ++j) {
            printf("Hello, world!\n");
        }
    }

    return 0;
}