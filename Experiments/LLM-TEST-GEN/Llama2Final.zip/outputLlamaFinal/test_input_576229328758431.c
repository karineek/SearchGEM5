
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function specialization for integer-to-string conversion
static inline char* int_to_string(int x) {
    return strtol(argv[1], NULL, 10);
}

int main(int argc, char** argv) {
    // Check the number of arguments passed to the program
    if (argc < 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }

    int x = atoi(argv[1]);
    char* str = int_to_string(x);
    printf("%s\n", str);

    return 0;
}