
#include <stdio.h>
#include <stdint.h>
#include <clang/entities.h>

// Function to eliminate common subexpressions
void elimCommonSubexprs(uint64_t *a, uint64_t *b) {
  // If the two expressions are equal, return them unchanged
  if (*a == *b) {
    return;
  }
  
  // Otherwise, create a new expression by adding the two
  // expressions and subtracting the smaller one from the larger
  uint64_t c = *a + *b;
  c -= std::min(*a, *b);
  
  // Store the result in both inputs
  *a = c;
  *b = c;
}

int main(int argc, char **argv) {
  uint64_t a = atoll(argv[1]);
  uint64_t b = atoll(argv[2]);
  
  elimCommonSubexprs(&a, &b);
  
  printf("After common subexpression elimination: %llu %llu\n", a, b);
  
  return 0;
}