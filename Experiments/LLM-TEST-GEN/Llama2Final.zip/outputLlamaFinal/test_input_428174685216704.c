
#include <stdio.h>
#include <stdint.h>
#include <vector>
#include <iostream>
#include <cuda_runtime.h>

__global__ void sumKernel(int *arr, int n) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) {
        arr[i] += 1;
    }
}

int main() {
    int n = atoi(argv[1]); // get the size of the array from command line argument
    int *arr = (int *)malloc(n * sizeof(int)); // allocate memory for the array
    sumKernel<<<1, 256>>>(arr, n); // launch the kernel with 1 block and 256 threads
    cudaDeviceSynchronize(); // synchronize the device
    int sum = 0;
    for (int i = 0; i < n; i++) {
        sum += arr[i];
    }
    std::cout << "The sum is: " << sum << std::endl;
    free(arr); // free the memory allocated for the array
    return 0;
}