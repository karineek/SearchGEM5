
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Function to demonstrate scalar optimization
void scalar_opt(int a, int b) {
    int result = a + b;
    if (result >= 0) {
        // Perform optimization
        result = result / 2;
    }
    printf("Result: %d\n", result);
}

// Function to demonstrate middle-end optimization
void middle_end(int a, int b, int c) {
    int result = a + b + c;
    if (result >= 0) {
        // Perform optimization
        result = result / 3;
    }
    printf("Result: %d\n", result);
}

int main(int argc, char *argv[]) {
    int a = atoi(argv[1]);
    int b = atoi(argv[2]);
    int c = atoi(argv[3]);

    // Perform optimization
    scalar_opt(a, b);
    middle_end(a, b, c);

    return 0;
}