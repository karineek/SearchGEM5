
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function specialization for matrices up to 10x10
void transposeMatrices(int **mat, int m, int n) {
    if (m <= 10 && n <= 10) {
        int i, j;
        for (i = 0; i < m; i++) {
            for (j = 0; j < n; j++) {
                int temp = mat[i][j];
                mat[i][j] = mat[j][i];
                mat[j][i] = temp;
            }
        }
    } else {
        // Fallback implementation for larger matrices
        int i, j, k;
        for (i = 0; i < m; i++) {
            for (j = 0; j < n; j++) {
                mat[i][j] = mat[j][i];
            }
        }
    }
}

int main(int argc, char **argv) {
    int m, n, size;
    int **mat;
    
    // Parse input from command line
    if (argc < 3) {
        printf("Usage: %s <matrix size> <input matrix>\n", argv[0]);
        return 1;
    }
    m = atoi(argv[1]);
    n = atoi(argv[2]);
    mat = malloc(m * sizeof(int *));
    
    // Read input matrix from command line
    size_t fread_count = fread(mat, sizeof(int), m * n, stdin);
    if (fread_count != m * n) {
        printf("Error: Could not read input matrix\n");
        return 1;
    }
    
    // Perform transpose operation
    transposeMatrices(mat, m, n);
    
    // Print output matrix
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            printf("%d ", mat[i][j]);
        }
        puts("");
    }
    
    return 0;
}