
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define MAX_INPUT_SIZE 1024

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <input> \n", argv[0]);
        return 1;
    }

    // Load input from command line argument
    char *input = argv[1];

    // Trigger Loop Fusion optimization
    int loop_fusion_result = loop_fusion(input, strlen(input));

    // Check if there was an error during serialization
    if (loop_fusion_result == -1) {
        fprintf(stderr, "Error during serialization: %s\n", strerror(errno));
        return 1;
    }

    // Print the resulting code
    printf("Loop Fusion result: %d\n", loop_fusion_result);

    return 0;
}