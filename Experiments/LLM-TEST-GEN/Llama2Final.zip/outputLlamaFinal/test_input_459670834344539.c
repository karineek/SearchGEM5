
#include <stdio.h>
#include <string.h>
#include <ast.h>

// Function to trigger scalar optimizations
void tolower(char *str) {
    // Check if the input string is empty
    if (str == NULL || *str == '\0') {
        return;
    }

    // Lowercase the input string
    char lowercaseStr[256];
    for (int i = 0; strlen(str) > 0; i++) {
        lowercaseStr[i] = tolower(str[i]);
    }

    // Copy the lowercased string back to the original buffer
    strcpy(str, lowercaseStr);
}

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: %s <input_string>\n", argv[0]);
        return 1;
    }

    // Get the input string from the command line
    char *inputStr = argv[1];

    // Call the tolower function with the input string
    tolower(inputStr);

    return 0;
}