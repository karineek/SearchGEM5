
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <llvm/llvm.h>

// Constant folding function
void constant_fold(const char *src) {
  // Load the source code into a string
  char src_buf[1024];
  strcpy(src_buf, src);

  // Perform constant folding
  for (int i = 0; i < strlen(src_buf); i++) {
    if (src_buf[i] == '(') {
      // If we find an opening paren, look for a closing paren
      int j = i + 1;
      while (j < strlen(src_buf) && src_buf[j] != ')') {
        j++;
      }

      // If we found a closing paren, fold the expression
      if (j - i > 0) {
        src_buf[i] = '\0'; // Replace the opening paren with a null terminator
        j--; // Back up to the opening paren
        src_buf[j] = '('; // Replace the closing paren with an opening paren
        i = j + 1; // Move the folded expression to the end of the string
      }
    }
  }

  // Print the modified source code
  printf("%s", src_buf);
}

int main(int argc, char **argv) {
  if (argc < 2) {
    printf("Usage: %s <source_code>\n", argv[0]);
    return 1;
  }

  const char *src = argv[1];
  constant_fold(src);

  return 0;
}