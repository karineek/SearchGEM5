
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <inttypes.h>
#include "parse.h"
#include "linked_list.h"

int main(int argc, char** argv) {
    // Parse command line arguments
    if (argc < 2) {
        printf("Usage: %s <input file>\n", argv[0]);
        return 1;
    }

    // Initialize parse context
    ParseContext pc;
    pc.input = argv[1];
    pc.output = stdout;

    // Perform instruction scheduling optimization
    InstructionScheduling is;
    is.schedule(pc);

    // Parse input file using LLVM IR
    Parse parse;
    parse.parse(pc);

    // Implement singly linked list using recursion
    SinglyLinkedList sl;
    sl.insert(pc);

    return 0;
}