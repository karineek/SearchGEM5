
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Target-Specific Optimizations
#ifdef TARGET_X86
  #define ABS(x) (((x) > 0) ? (x) : (-(x)-1)) // optimization for x86 platform
#else
  #define ABS(x) (abs(x)) // optimization for other platforms
#endif

// Frontend
#ifdef FRONTEND_GCC
  #include <gcc/config.h>
#elif defined(FRONTEND_CLANG)
  #include <clang/config.h>
#else
  #error "Unsupported frontend configuration"
#endif

// islessequal macro
#define ISLESS(a, b) (((a) == (b)) || ((a) < (b)))

int main(int argc, char **argv) {
  int x = atoi(argv[1]);
  printf("The value of x is: %d\n", ABS(x));
  if (ISLESS(x, 5)) {
    printf("x is less than 5\n");
  } else {
    printf("x is greater than or equal to 5\n");
  }
  return 0;
}