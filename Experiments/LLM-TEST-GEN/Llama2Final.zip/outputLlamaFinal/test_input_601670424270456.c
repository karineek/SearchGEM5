
#include <stdio.h>
#include <string.h>
#include <unistd.h>

// Inline function heuristics
#define INLINE_IF(fn, args) \
    if (strcmp(argv[1], #fn) == 0) { \
        fn args; \
        return 0; \
    }

// Target specific architectures
#define TARGET(arch) \
    if (strcmp(argv[2], arch) == 0) { \
        printf("Target %s\n", arch); \
        return 0; \
    }

// Type-generic macro
#define MACRO(name, types) \
    if (types) { \
        name = types; \
        return 0; \
    }

int main(int argc, char **argv) {
    INLINE_IF("printf", (int)argc);
    TARGET("x86");
    MACRO("hello", int, float);
    return 0;
}