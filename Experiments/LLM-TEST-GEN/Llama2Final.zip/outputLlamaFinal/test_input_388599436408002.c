
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <support/SupportLibraries.h>

// Function to demonstrate Memory-to-Register Promotion
void demo_m2r(int *ptr) {
    int value = *ptr;
    ptr++; // Use of address-of operator (&) to promote memory to a register
    printf("%d\n", value); // Use of the promoted value in a function call
}

// Function to demonstrate Short Circuit Evaluation
int eval(int x, int y) {
    return x < y; // Short circuit evaluation: evaluate the expression as soon as possible
}

// Function to demonstrate Operator Precedence
void demo_ops(int *ptr) {
    int value = *ptr + 10; // Evaluate expressions from left to right
    ptr++; // Use of address-of operator (&) to promote memory to a register
    printf("%d\n", value); // Use of the promoted value in a function call
}

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: %s <input>\n", argv[0]);
        return 1;
    }

    int input = atoi(argv[1]); // Convert string argument to integer
    demo_m2r(&input); // Promote memory to a register and evaluate the expression
    demo_ops(&input); // Demonstrate operator precedence

    return 0;
}