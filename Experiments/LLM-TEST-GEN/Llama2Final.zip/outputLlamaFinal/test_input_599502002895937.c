
#include <iostream>
#include <vector>
#include <cmath>
#include <supportlib.h>

int main(int argc, char** argv) {
  int numElements = atoi(argv[1]); // get the number of elements from command line argument

  std::vector<double> numbers(numElements);
  for (int i = 0; i < numElements; i++) {
    numbers[i] = static_cast<double>(i);
  }

  double sum = supportlib::sum(numbers.begin(), numbers.end()); // use the Support Libraries to calculate the sum of the vector
  std::cout << "The sum is: " << sum << std::endl;

  return 0;
}