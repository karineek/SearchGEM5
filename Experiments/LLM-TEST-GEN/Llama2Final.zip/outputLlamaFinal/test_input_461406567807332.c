
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include < loopsOptimizations.h>

int main(int argc, char *argv[]) {
    // Set input from command line arguments
    int n = atoi(argv[1]);
    int m = atoi(argv[2]);

    // Perform loop optimizations
    LoopOptimizations(n, m);

    // Print results
    printf("Result of loop optimizations: \n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            printf("%d ", *(i + j));
        }
        printf("\n");
    }

    return 0;
}