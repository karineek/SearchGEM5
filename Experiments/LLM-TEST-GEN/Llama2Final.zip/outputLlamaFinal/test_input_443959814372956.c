
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LENGTH 1024

int main(int argc, char *argv[]) {
    // Parse input from command line
    if (argc < 2) {
        printf("Usage: %s <input>\n", argv[0]);
        return 1;
    }
    char *input = argv[1];

    // Perform Sparse Conditional Constant Propagation optimization
    // Replace arbitrary constant expressions with their values
    for (int i = 0; i < strlen(input); i++) {
        if (input[i] == '(') {
            int depth = 1;
            while (depth > 0) {
                depth--;
                if (input[i + depth] == ')') {
                    input[i] = ' ';
                } else if (input[i + depth] == '*') {
                    input[i] = '+';
                } else {
                    break;
                }
            }
        }
    }

    // Print the optimized input
    printf("%s\n", input);

    return 0;
}