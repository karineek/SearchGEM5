
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define FLT_RADIX 27

int main(int argc, char **argv) {
    int n = atoi(argv[1]); // argv[1] contains the input value

    if (n <= 0) {
        printf("Negative value\n");
        return 0;
    }

    // Trigger scalar optimization using FLT_RADIX macro
    float f = n * FLT_RADIX;
    int x = (int)f;
    printf("Original value: %f\n", f);
    printf("Scaled value: %d\n", x);
    return 0;
}