
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#ifdef __x86_64__
#pragma omp parallel for schedule(static)
void loop_x86(int n) {
    for (int i = 0; i < n;++i) {
        printf("Looping on x86-64\n");
    }
}
#else
#pragma omp parallel for schedule(dynamic)
void loop_other(int n) {
    for (int i = 0; i < n;++i) {
        printf("Looping on other architecture\n");
    }
}
#endif

int main() {
    int n = atoi(argv[1]);
    loop_x86(n); // conditional inclusion based on the value of argv[1]
    return 0;
}