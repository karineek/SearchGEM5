
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Definition of FLT_TRUE_MIN constant
#define FLT_TRUE_MIN 4294967295U

int main(int argc, char **argv) {
    // Input from command line
    int n = atoi(argv[1]);

    // Calculate the result of a subexpression using FLT_TRUE_MIN
    float result = (n == 0) ? FLT_TRUE_MIN : n * 2;

    // Output the result
    printf("Result: %f\n", result);

    return 0;
}