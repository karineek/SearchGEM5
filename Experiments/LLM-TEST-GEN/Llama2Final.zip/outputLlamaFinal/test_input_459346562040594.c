
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>

// Automatic vectorization example
int main(int argc, char **argv) {
    int arr[argc];
    for (int i = 0; i < argc; i++) {
        arr[i] = atoi(argv[i]);
    }
    // Perform some operation on the vector of integers
    #pragma omp parallel num_threads(4) default(none) shared(arr)
    {
        #pragma omp for schedule(static)
        for (int i = 0; i < 4; i++) {
            arr[i] *= 2;
        }
    }
    // Print the results
    for (int i = 0; i < argc; i++) {
        printf("%d ", arr[i]);
    }
    return 0;
}