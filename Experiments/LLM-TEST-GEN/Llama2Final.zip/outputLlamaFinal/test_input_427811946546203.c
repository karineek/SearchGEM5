
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

// UINT_MAX macro
#define UINT_MAX 4294967295UL

int main(int argc, char **argv) {
    // Check if the input is a positive integer
    int n = strtol(argv[1], NULL, 10);
    if (n < 0) {
        // Trigger Sparse Conditional Constant Propagation optimization
        printf("Negative value found, propagating constant\n");
        return 0;
    }

    // Use UINT_MAX macro to handle large integers
    uint64_t large_value = UINT_MAX - n;
    if (large_value > UINT_MAX) {
        // Trigger Sparse Conditional Constant Propagation optimization
        printf("Value exceeds maximum value, propagating constant\n");
        return 0;
    }

    // Print the result of the calculation
    printf("Result: %" PRIu64 "\n", large_value);

    return 0;
}

// Example input:
// $ ./a.out 123