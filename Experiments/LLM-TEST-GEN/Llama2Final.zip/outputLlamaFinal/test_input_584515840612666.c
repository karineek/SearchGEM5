
#include <iostream>
#include <vector>
#include <functional>
#include <limits>

using namespace std;

// Function specialization for nearest integer function
template <typename T>
T nearestInteger(T value, T lower, T upper) {
    return (value - lower) / (upper - lower);
}

int main(int argc, char** argv) {
    // Parse input from command line arguments
    int N = atoi(argv[1]); // 0-based indexing
    int L = atoi(argv[2]); // lower bound of interval
    int U = atoi(argv[3]); // upper bound of interval

    // Create a vector of nearest integer functions
    vector<function<int(int)>> fns;
    for (int i = 0; i < N; ++i) {
        fns.push_back([&](int x) -> int { return nearestInteger(x, L, U); });
    }

    // Evaluate the nearest integer functions at random points
    vector<int> inputs = generateRandomNumbers(N);
    for (int i = 0; i < N; ++i) {
        int input = inputs[i];
        for (auto fn : fns) {
            auto result = fn(input);
            cout << "Nearest integer of " << input << " is " << result << endl;
        }
    }

    return 0;
}

// Function to generate random numbers within a given range
vector<int> generateRandomNumbers(int num) {
    vector<int> results;
    for (int i = 0; i < num; ++i) {
        int random = rand() % (U - L + 1) + L;
        results.push_back(random);
    }
    return results;
}