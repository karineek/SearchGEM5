
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "llvm-readir.h"

// Function specialization example
void print_char(const char *str) {
  printf("%s\n", str);
}

int main(int argc, char **argv) {
  if (argc < 2) {
    printf("Usage: %s <input>\n", argv[0]);
    return 1;
  }

  // Read LLVM IR from file
  llvm::Module module;
  llvm::FileFileReader file(argv[1], "r");
  if (!file) {
    printf("Error: Could not open input file %s\n", argv[1]);
    return 2;
  }
  module = file.getModule();

  // Display character semantics example
  for (const auto &inst : module.instructions) {
    if (inst.isString()) {
      const char *str = inst.getOperandAs<llvm::String>(0).getData();
      print_char(str);
    }
  }

  return 0;
}