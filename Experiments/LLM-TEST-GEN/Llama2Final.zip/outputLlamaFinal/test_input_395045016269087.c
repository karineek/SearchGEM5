
#include <stdio.h>
#include <string.h>
#include <llvm/llvm.h>

int main(int argc, char **argv) {
  // Check if we have enough arguments
  if (argc < 2) {
    printf("Usage: %s <IR>\n", argv[0]);
    return 1;
  }

  // Read the LLVM IR from the command line argument
  char *ir = argv[1];

  // Create an LLVM module from the IR
  llvm::ModuleMojo mojo;
  llvm::parseAssembly(ir, ir.size(), &mojo);

  // Fuse loops in the module
  llvm::LoopFusion pass;
  mojo.getPassManager().add(&pass);

  // Run the loop fusion pass
  mojo.runPasses();

  // Print the fused loops
  for (auto &loop : mojo.getRootModule()->getLoops()) {
    if (loop.getType() == llvm::Loop::Fused) {
      printf("Fused loop: %s\n", loop.toString().c_str());
    }
  }

  return 0;
}