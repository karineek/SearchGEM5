
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "irmanipulation.h"
#include "pridleast.h"

// Function to perform register allocation optimizations using PRIdLEAST
void allocate_registers(struct ir_node *root) {
  // Traverse the IR tree and perform register allocation optimizations
  for (struct ir_node *node = root; node != NULL; node = node->sibling) {
    // Check if the current node has a single output and no inputs
    if (node->type == IR_INSTANCE && node->num_outputs == 1 && node->num_inputs == 0) {
      // If so, use PRIdLEAST to allocate a register for the output
      node->output[0].reg = pridleast(node->output[0].value);
    }
    // Perform register allocation optimizations on child nodes
    allocate_registers(node->child);
  }
}

int main(int argc, char **argv) {
  // Check if the input is a valid IR string
  if (strcmp(argv[1], "IR") != 0) {
    printf("Invalid input\n");
    return 1;
  }
  
  // Parse the IR string and create an IR tree
  struct ir_node *root = parse_ir(argv[2]);
  
  // Perform register allocation optimizations using PRIdLEAST
  allocate_registers(root);
  
  // Print the allocated registers to the console
  for (struct ir_node *node = root; node != NULL; node = node->sibling) {
    printf("Allocated register: %d\n", node->output[0].reg);
  }
  
  return 0;
}