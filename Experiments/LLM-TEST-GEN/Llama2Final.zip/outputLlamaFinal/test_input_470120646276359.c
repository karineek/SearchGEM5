
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <math.h>

// Function to print a pyramid
void print_pyramid(int size) {
  // Calculate the number of rows and columns based on the size
  int rows = size / 2;
  int columns = size - rows * 2;
  
  // Print the pyramid
  for (int i = 0; i < rows; ++i) {
    for (int j = 0; j < columns; ++j) {
      printf("%d ", i * 2 + j);
    }
    printf("\n");
  }
}

// Function to print a pattern
void print_pattern(int size) {
  // Calculate the number of rows and columns based on the size
  int rows = size / 2;
  int columns = size - rows * 2;
  
  // Print the pattern
  for (int i = 0; i < rows; ++i) {
    for (int j = 0; j < columns; ++j) {
      printf("%d ", i * 2 + j);
    }
    printf("\n");
  }
}

// Program to print a pyramid and a pattern
int main(int argc, char *argv[]) {
  int size = atoi(argv[1]); // Get the size from the argument
  
  if (size < 2) {
    printf("Error: Size must be greater than or equal to 2\n");
    return 1;
  }
  
  // Print the pyramid and pattern
  print_pyramid(size);
  print_pattern(size);
  
  return 0;
}