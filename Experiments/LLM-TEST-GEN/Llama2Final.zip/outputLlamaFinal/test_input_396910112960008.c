
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Copysign function implementation
float copysignf(float x, float y) {
    if (x == 0) {
        return y;
    } else if (y == 0) {
        return x;
    } else {
        return x * y / (abs(x) * abs(y));
    }
}

int main() {
    int argc = sizeof(argv) / sizeof(argv[0]);
    char *argv[] = {"example", "-5", "-3"}; // input to the program

    if (argc > 1) { // handle non-zero input
        float result = copysignf(-5, -3);
        printf("Result: %f\n", result);
    } else {
        printf("Usage: example <number1> <number2>\n");
    }

    return 0;
}