
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {
    // Whole program analysis: calculate the maximum length of a string
    // that can be stored in memory without overflowing
    size_t max_string_len = 0;
    for (size_t i = 0; i < argc; i++) {
        max_string_len = MAX(max_string_len, strlen(argv[i]));
    }

    // Generate code to read a string from the user using fgetwc
    char *user_string = malloc(max_string_len + 1);
    for (size_t i = 0; i < max_string_len; i++) {
        int c = fgetwc(stdin);
        user_string[i] = (char)c;
    }

    // Print the read string
    printf("%s\n", user_string);

    free(user_string);
    return 0;
}