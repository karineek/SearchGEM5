
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Function to compute the floor of a number
float floor(float x) {
    int i = (int)x;
    return i - 0.5 * (i > 0.5); // Loop vectorization and IR manipulation
}

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }

    float number = strtof(argv[1], NULL); // Convert string to floating-point number
    float result = floor(number); // Compute the floor of the number
    printf("The floor of %f is %f\n", number, result); // Print the result

    return 0;
}