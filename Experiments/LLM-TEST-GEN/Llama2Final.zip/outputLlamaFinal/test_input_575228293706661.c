
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <llvm/llvm.h>

// Target-Specific Optimizations
#define TARGET_SPECIFIC_OPTIMIZATIONS \
    llvm::OptimizeFunctionOnLoad("main"); // optimize function on load

int main(int argc, char **argv) {
    // length modifier
    static const size_t LENGTH = 1024;

    // Input
    char input[] = "Hello, world!";

    // Output
    char output[LENGETH];
    TARGET_SPECIFIC_OPTIMIZATIONS;
    llvm::raw_write(output, LENGTH, argv[1]);
    printf("%s\n", output);

    return 0;
}