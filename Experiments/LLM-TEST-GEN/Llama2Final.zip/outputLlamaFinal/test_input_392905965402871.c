
#include <stdio.h>
#include <string.h>

// Function to convert binary to octal
void binary_to_octal(char *binary) {
    int i, j;
    for (i = 0; i < strlen(binary); i++) {
        j = binary[i] - '0';
        if (j > 7) { // If the character is greater than 7, it's a octal digit
            printf("%d", j);
            break; // Exit the loop
        }
    }
}

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: %s <binary_number>\n", argv[0]);
        return 1;
    }

    // Get the binary number from the command line argument
    char binary[100];
    strcpy(binary, argv[1]);

    // Inline the function to convert binary to octal
    binary_to_octal(binary);

    return 0;
}