
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <profile.h>
#include <target.h>
#include <wctob.h>

int main(int argc, char **argv) {
    // Set up profiling and target information
    profile_init();
    target_init();

    // Read input from `argv`
    char *input = argv[1];

    // Call the wctob function with the input string
    wctob(input);

    return 0;
}