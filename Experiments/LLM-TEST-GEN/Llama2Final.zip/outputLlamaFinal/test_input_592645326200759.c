
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>

// Define the recursive constant
#define MTX_RECURSIVE 1024

// Function to handle binary input
int read_binary(void *ptr, size_t size) {
    char *data = (char *)ptr;
    size_t remaining = size;
    while (remaining > 0) {
        size_t chunk = remaining;
        if (chunk > sizeof(data)) {
            chunk = sizeof(data);
        }
        memcpy(data, &data[chunk], chunk);
        remaining -= chunk;
        data += chunk;
    }
    return 0;
}

int main(int argc, char **argv) {
    // Check for enough arguments
    if (argc < 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    // Read the input file
    void *ptr = mmap(NULL, 0, 0, PROT_READ, MAP_FAILED);
    if (ptr == MAP_FAILED) {
        perror("mmap failed");
        return 1;
    }
    size_t size = read_binary(ptr, argv[1]);
    munmap((void *)ptr, 0);

    // Check for errors
    if (size < 0) {
        printf("Error reading file: %s\n", strerror(errno));
        return 1;
    }

    // Print the result
    char *data = ptr;
    for (size_t i = 0; i < size; i++) {
        printf("%x ", data[i]);
    }
    printf("\n");

    return 0;
}