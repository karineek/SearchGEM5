
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

// Function Specialization for non-digit input
void handle_non_digit(char *input) {
    if (strlen(input) > 0 && !isdigit(input[0])) {
        printf("Invalid input, please enter a digit only:\n");
    } else {
        printf("You entered: %s\n", input);
    }
}

// Function Specialization for non-digit input (alternative)
void handle_non_digit2(char *input) {
    if (strlen(input) > 0 && isdigit(input[0])) {
        printf("Invalid input, please enter a non-digit only:\n");
    } else {
        printf("You entered: %s\n", input);
    }
}

int main() {
    int argc = sizeof(argv) / sizeof(argv[0]);
    char *argv[] = { "-nondigit", "42" }; // input is taken via argv only

    // Parse the input
    handle_non_digit(argv[1]); // calls the function specialization for non-digit input

    return 0;
}