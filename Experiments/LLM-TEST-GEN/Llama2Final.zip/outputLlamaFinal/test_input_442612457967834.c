
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "asm.h"
#include "ir.h"
#include "tree.h"
#include "type.h"
#include "object.h"
#include "binary.h"
#include "hypotf.h"

int main(int argc, char **argv) {
    // Check for hypotf input
    if (argc < 2) {
        printf("Usage: %s <input.bin> \n", argv[0]);
        return 1;
    }

    // Load the binary input from file
    FILE *input_file = fopen(argv[1], "rb");
    if (!input_file) {
        perror("Error opening input file");
        return 1;
    }

    // Get the number of instructions in the input binary
    uint32_t num_insns = get_num_instructions(input_file);
    fclose(input_file);

    // Create a new instruction schedule
    InstructionSchedule *schedule = create_instruction_schedule(num_insns);

    // Schedule the instructions in the input binary
    for (uint32_t i = 0; i < num_insns; i++) {
        Instruction insn = get_instruction(input_file, i);
        schedule_instruction(schedule, insn);
    }

    // Print the scheduled instructions
    for (uint32_t i = 0; i < num_insns; i++) {
        Instruction insn = get_instruction(input_file, i);
        printf("Instruction %u: ", i);
        print_instruction(insn);
        printf("\n");
    }

    // Free the instruction schedule
    free_instruction_schedule(schedule);

    return 0;
}