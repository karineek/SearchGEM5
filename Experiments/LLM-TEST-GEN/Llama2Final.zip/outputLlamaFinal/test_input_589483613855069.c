
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "register_allocation.h"

// Define a function that takes an integer argument and returns its binary representation
int bin_to_binary(int n) {
    char buff[32];
    snprintf(buff, sizeof(buff), "%d", n);
    return buff;
}

int main(int argc, char **argv) {
    // Get the input from the command line
    int num_registers = atoi(argv[1]);
    if (num_registers < 0) {
        fprintf(stderr, "Invalid number of registers\n");
        return 1;
    }

    // Initialize the register allocation structure
    struct RegisterAllocation *ra = malloc(sizeof(struct RegisterAllocation));
    ra->num_registers = num_registers;

    // Perform register allocation optimization
    ra->optimized = optimize_register_allocation(ra);

    // Print the binary representation of the registers
    for (int i = 0; i < ra->num_registers; i++) {
        printf("R%d: %x\n", i, ra->registers[i]);
    }

    return 0;
}