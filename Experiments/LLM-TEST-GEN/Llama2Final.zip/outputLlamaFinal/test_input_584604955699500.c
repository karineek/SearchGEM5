
#include <stdio.h>
#include <stdlib.h>

// Function to demonstrate LICM optimization
void foo(int *arr, int n) {
    for (int i = 0; i < n; i++) {
        arr[i] = i * 2;
    }
}

int main() {
    // Get input from command line
    int n = atoi(argv[1]);
    int arr[n];
    for (int i = 0; i < n; i++) {
        arr[i] = atoi(argv[2 + i]);
    }
    foo(arr, n);
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    return 0;
}