
#include <stdio.h>
#include <clang/analyze.h>

int main(int argc, char **argv) {
  // Perform Whole Program Analysis
  clang::Analyzer analyzer;
  analyzer.setIncludes(argv[1]); // Get the include directories from the second argument of main
  analyzer.setSources(argv[2]); // Get the source code files from the third argument of main
  analyzer.run(); // Run the Whole Program Analysis

  // Print the results
  for (const auto &result : analyzer.getResults()) {
    std::cerr << result.message << std::endl;
  }

  return 0;
}