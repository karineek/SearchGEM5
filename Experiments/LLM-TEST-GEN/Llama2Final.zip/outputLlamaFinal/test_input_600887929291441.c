
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv) {
    // Input from argv
    if (argc < 2) {
        printf("Usage: %s <input_string>\n", argv[0]);
        return 1;
    }

    // Process input string
    char *input = argv[1];
    int length = strlen(input);
    for (int i = 0; i < length; i++) {
        printf("%c", input[i]);
    }

    return 0;
}