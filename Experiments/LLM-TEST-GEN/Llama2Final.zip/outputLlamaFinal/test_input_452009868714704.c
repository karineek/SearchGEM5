
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "scalbnf.h"

int main(int argc, char **argv) {
    // Check if the user provided an input file
    if (argc < 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    // Load the input file into a string
    char *input = argv[1];

    // Initialize the instruction scheduler
    InstructionScheduler is;

    // Perform instruction scheduling optimization
    is.schedule(input);

    // Print the optimized instructions
    for (int i = 0; i < is.get_num_instructions(); i++) {
        printf("Instruction %d: ", i + 1);
        switch (is.get_instruction(i).opcode) {
            case OPCODE_ADD:
                printf("Adding %f and %f\n", is.get_instruction(i).arg1, is.get_instruction(i).arg2);
                break;
            case OPCODE_SUB:
                printf("Subtracting %f from %f\n", is.get_instruction(i).arg1, is.get_instruction(i).arg2);
                break;
            default:
                printf("Unknown opcode %d\n", is.get_instruction(i).opcode);
                break;
        }
    }

    return 0;
}