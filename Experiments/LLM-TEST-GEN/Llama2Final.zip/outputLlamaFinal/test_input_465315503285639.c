
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Macro to demonstrate type-generic macro
#define MAX_LENGTH 1024
#define PAD(x, y) (((y) - (x)) * (sizeof(x) - 1))

int main(int argc, char **argv) {
    // Interprocedural optimization: inlining a function call
    void doubleValue(int x) {
        printf("Double value of %d is %d\n", x, x * 2);
    }

    int originalValue = atoi(argv[1]);
    doubleValue(originalValue); // Inline the function call

    return 0;
}