
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <llvm/llvm-readir.h>

int main(int argc, char **argv) {
    // Parse input from command line
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    // Read LLVM IR from file
    std::string ir = llvmReadIRFile(argv[1]);

    // Perform constant folding on the LLVM IR
    ir = ConstantFoldingPass(ir);

    // Print the modified LLVM IR
    printf("Modified LLVM IR:\n%s\n", ir.c_str());

    return 0;
}