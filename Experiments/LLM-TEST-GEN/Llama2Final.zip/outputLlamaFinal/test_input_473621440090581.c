
#include <stdio.h>
#include <time.h>

// Function specialization for mktime
int mktime(int hours, int minutes) {
    return (hours * 3600) + (minutes * 60);
}

int main(int argc, char **argv) {
    // Parse input from command line arguments
    if (argc < 2) {
        printf("Usage: %s <hours> <minutes>\n", argv[0]);
        return 1;
    }

    int hours = atoi(argv[1]);
    int minutes = atoi(argv[2]);

    // Call the specialized function mktime
    printf("The time is: %d\n", mktime(hours, minutes));

    return 0;
}