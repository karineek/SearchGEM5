
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

int main(int argc, char **argv) {
    // Input from command line
    int num_chars = atoi(argv[1]);

    // Use vswprintf to print the input number of times
    char buffer[num_chars + 1];
    vswprintf(buffer, sizeof(buffer), "%d", num_chars);

    // Print the result
    printf("%s\n", buffer);

    return 0;
}