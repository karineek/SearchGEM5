
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

#ifdef __linux__
#include <profile.h>
#endif

#define INT_LEAST64_T  ((int_least64_t)1 << 59)

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <input> <output>\n", argv[0]);
        return 1;
    }

#ifdef __linux__
    Profile profile;
    profile.init();

    // Generate some profiling data
    for (int i = 0; i < 100; i++) {
        int x = INT_LEAST64_T;
        do {
            x++;
        } while (x > 0);
    }

    profile.save("profile.dat");
#endif

    // Process the input string
    char *input = argv[1];
    char *output = malloc(strlen(input) + 1);
    for (int i = 0; input[i] != '\0'; i++) {
        output[i] = input[i];
    }
    output[strlen(input)] = '\0';

    // Print the result
    printf("%s\n", output);

    free(output);
    return 0;
}