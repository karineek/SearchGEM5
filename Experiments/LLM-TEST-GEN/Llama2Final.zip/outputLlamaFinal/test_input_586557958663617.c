
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

// Loop optimization 1: Eliminate unnecessary loops
void foo(int n) {
    int i;
    for (i = 0; i < n; ++i) {
        // Do something
    }
}

// Loop optimization 2: Minimize loop variables
void bar(int n) {
    int i = 0;
    for (; i < n; ++i) {
        // Do something
    }
}

// Collection of optimization passes:
void baz(int n) {
    int i = 0;
    for (; i < n; ++i) {
        // Do something
    }
    while (i < n) {
        // Do something else
        --i;
    }
}

// UINTMAX_MAX macro:
#define UINTMAX_MAX (((uintmax_t)0x1 << 31) - 1)

int main(int argc, char *argv[]) {
    int n = atoi(argv[1]); // Example input: 4

    foo(n);
    bar(n);
    baz(n);

    return 0;
}