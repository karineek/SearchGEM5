
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// Target-Specific Optimizations
#ifdef __x86_64__
    #define fabs(x) __builtin_fabsl(x)
#else
    #define fabs(x) abs(x)
#endif

// Handles Abstract Syntax Tree (AST)
#define AST(x) ({ \
    struct { int type; char *name; } __ast = ({ \
        int type = x; \
        char *name = #x; \
    }); \
    __ast; \
})

// uint_least16_t type
typedef int_least16_t __int16;

int main(void) {
    // Input taken via argc and argv
    int num = atoi(argv[1]);

    // Calculate the value of num using Target-Specific Optimizations and Handles Abstract Syntax Tree (AST)
    __int16 value = fabs(num);

    // Print the result
    printf("%d\n", value);

    return 0;
}