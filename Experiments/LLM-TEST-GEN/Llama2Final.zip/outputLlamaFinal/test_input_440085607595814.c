
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int main(int argc, char **argv) {
    // Check if the user provided an input file
    if (argc < 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    // Open the input file in read mode
    FILE *file = fopen(argv[1], "r");
    if (!file) {
        perror("Error opening input file");
        return 1;
    }

    // Read the input string from the file
    char line[1024];
    fgets(line, 1024, file);
    if (feof(file)) {
        printf("Error reading input file\n");
        return 1;
    }

    // Use loop vectorization optimization to count the number of occurrences of each letter in the input string
    int letter_counts[256];
    for (int i = 0; i < 256; i++) {
        letter_counts[i] = 0;
    }
    for (int i = 0; i < strlen(line); i++) {
        char c = line[i];
        letter_counts[c]++;
    }

    // Print the results
    printf("Letter counts: \n");
    for (int i = 0; i < 256; i++) {
        if (letter_counts[i]) {
            printf("%c: %d\n", i, letter_counts[i]);
        }
    }

    // Clean up
    fclose(file);

    return 0;
}