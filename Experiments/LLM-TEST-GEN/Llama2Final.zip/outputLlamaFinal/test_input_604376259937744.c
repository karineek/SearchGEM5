
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

// Function to calculate the sum of an array of integers
int arraySum(int arr[], int size) {
  int total = 0;
  for (int i = 0; i < size; i++) {
    total += arr[i];
  }
  return total;
}

// Function to print the result of arraySum()
void printResult(int result) {
  printf("The sum of the array is %d\n", result);
}

int main(int argc, char **argv) {
  int size = atoi(argv[1]); // Get the size of the array from the command line argument
  int arr[size]; // Declare an array of integers
  
  // Fill the array with some random values
  for (int i = 0; i < size; i++) {
    arr[i] = rand() % 100;
  }
  
  // Calculate the sum of the array and print the result
  int result = arraySum(arr, size);
  printResult(result);
  
  return 0;
}