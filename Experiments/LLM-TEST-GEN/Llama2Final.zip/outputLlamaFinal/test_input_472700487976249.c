
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <support/atomic.h>

// Definition of an atomic variable for the number of elements in a list
atomic_ullong_t list_size;

// Function to increment the size of a list
void inc_list_size() {
    // Use atomic_ullong_inc to increment the size of the list
    atomic_ullong_inc(&list_size);
}

// Main function
int main(int argc, char *argv[]) {
    // Check if the input is a valid file name
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <file>\n", argv[0]);
        return 1;
    }

    // Open the file for reading and allocate memory for its contents
    FILE *file = fopen(argv[1], "r");
    size_t file_size = get_file_size(file);
    char *file_contents = mmap(NULL, file_size, PROT_READ, MAP_FILE | MAP_PRIVATE, -1, 0);

    // Initialize the list of lines from the file contents
    atomic_ullong_t line_count = 0;
    for (char *p = file_contents; *p != '\0'; p++) {
        if (*p == '\n') {
            atomic_ullong_inc(&line_count);
        }
    }

    // Print the total number of lines in the file
    printf("Total number of lines: %llu\n", atomic_ullong_read(&line_count));

    // Unmap the file contents memory
    munmap(file_contents, file_size);

    return 0;
}

// Get the size of a file
size_t get_file_size(FILE *file) {
    long offset = ftell(file);
    if (offset == -1) {
        return -1; // Error: could not determine file size
    }
    size_t size = offset;
    return size;
}