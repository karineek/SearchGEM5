
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <locale.h>

// Function inlining example
void greet(const char *name) {
    printf("Hello, %s!\n", name);
}

int main(int argc, char **argv) {
    // Get the input from argv
    const char *input = argv[1];

    // Use the locale feature to format a string with a specific locale
    setlocale(LC_TIME, "en_US.UTF-8"); // US English locale
    time_t now = time(NULL);
    char buff[26];
    const size_t len = strftime(buff, sizeof(buff), "%a %d %B %Y", NULL);
    printf("Current date and time: %s\n", buff);

    // Inline the greet function to demonstrate function inlining
    greet("World!");

    return 0;
}