
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Define the function to be inlined
void inline_function(int a, int b) {
  printf("Inline function called with arguments %d and %d\n", a, b);
}

int main() {
  // Take input from command line using argv
  int a = atoi(argv[1]);
  int b = atoi(argv[2]);

  // Call the inlined function
  inline_function(a, b);

  return 0;
}