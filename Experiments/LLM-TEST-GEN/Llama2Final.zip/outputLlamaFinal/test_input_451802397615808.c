
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SIZE 100

int main(int argc, char *argv[]) {
    // Target-specific optimization: use a constant folded loop
    int n = atoi(argv[1]);
    for (int i = 0; i < n; ++i) {
        printf("Hello, world!\n");
    }

    // IR manipulation: use the fdiml function to inline a function
    float sum = fdiml(1.0, 2.0, 3.0);
    printf("%f\n", sum);

    return 0;
}