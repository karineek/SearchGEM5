
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Define a macro to enable SCCP optimization
#define ENABLE_SCCP

// Function to test SCCP optimization
int foo(int x, int y) {
    if (x > 0 && y > 0) {
        return x + y; // Triggering SCCP optimization
    } else {
        return x - y; // Disable SCCP optimization for this branch
    }
}

int main(int argc, char **argv) {
    int x = atoi(argv[1]);
    int y = atoi(argv[2]);
    printf("%d + %d = %d\n", x, y, foo(x, y)); // Output the result of the function
    return 0;
}