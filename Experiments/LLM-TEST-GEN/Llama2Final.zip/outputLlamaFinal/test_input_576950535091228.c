
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <pthread.h>
#include <semaphore.h>

// Function to demonstrate atomic pointer lock-free operation
void* atom_ptr_lock_free(void* arg) {
    // Create a semaphore to protect the atomic pointer
    sem_t* sem = sem_create(O_CREAT | O_TRUNC, 0, 0);
    if (sem == NULL) {
        perror("Error creating semaphore");
        return NULL;
    }

    // Initialize the atomic pointer with a random value
    int32_t* atomic_ptr = (int32_t*)mmap(NULL, sizeof(int32_t), PROT_READ | PROT_WRITE, MAP_ANONYMOUS, -1, 0);
    if (atomic_ptr == MAP_FAILED) {
        perror("Error mapping memory");
        sem_destroy(sem);
        return NULL;
    }
    *atomic_ptr = rand() % 100; // Set the value of the atomic pointer to a random number

    // Create a thread that tries to read the atomic pointer
    pthread_t thr;
    if (pthread_create(&thr, NULL, read_atomics, NULL) != 0) {
        perror("Error creating thread");
        sem_destroy(sem);
        return NULL;
    }

    // Wait for the thread to finish
    pthread_join(thr, NULL);

    // Check if the atomic pointer was read correctly
    if (*atomic_ptr != *(int32_t*)arg) {
        printf("Error: atomic pointer not read correctly\n");
        sem_destroy(sem);
        return NULL;
    }

    // Signal the thread to exit
    sem_post(sem);
    pthread_detach(thr);

    // Unmap the memory
    munmap((void*)atomic_ptr, sizeof(int32_t));

    return NULL;
}

// Function to demonstrate serialization
void* serialized_data(void* arg) {
    int32_t data = *(int32_t*)arg;
    char* buffer = (char*)mmap(NULL, sizeof(data), PROT_READ | PROT_WRITE, MAP_ANONYMOUS, -1, 0);
    if (buffer == MAP_FAILED) {
        perror("Error mapping memory");
        return NULL;
    }
    memcpy(buffer, &data, sizeof(data));
    *(int32_t*)arg = *(int32_t*)buffer; // Replace the original value with the serialized one
    munmap((void*)buffer, sizeof(data));
    return NULL;
}

// Program entry point
int main(int argc, char** argv) {
    if (argc < 2) {
        printf("Usage: %s <data_to_be_serialized>\n", argv[0]);
        return 1;
    }

    // Create a semaphore to protect the serialization operation
    sem_t* sem = sem_create(O_CREAT | O_TRUNC, 0, 0);
    if (sem == NULL) {
        perror("Error creating semaphore");
        return 1;
    }

    // Initialize the atomic pointer with a random value
    int32_t* atomic_ptr = (int32_t*)mmap(NULL, sizeof(int32_t), PROT_READ | PROT_WRITE, MAP_ANONYMOUS, -1, 0);
    if (atomic_ptr == MAP_FAILED) {
        perror("Error mapping memory");
        sem_destroy(sem);
        return 1;
    }
    *atomic_ptr = rand() % 100; // Set the value of the atomic pointer to a random number

    // Create a thread that tries to read the serialized data
    pthread_t thr;
    if (pthread_create(&thr, NULL, read_serialized, NULL) != 0) {
        perror("Error creating thread");
        sem_destroy(sem);
        return 1;
    }

    // Wait for the thread to finish
    pthread_join(thr, NULL);

    // Check if the serialized data was read correctly
    if (*(int32_t*)argv[1] != *atomic_ptr) {
        printf("Error: serialized data not read correctly\n");
        sem_destroy(sem);
        return 1;
    }

    // Signal the thread to exit
    sem_post(sem);
    pthread_detach(thr);

    // Unmap the memory
    munmap((void*)atomic_ptr, sizeof(int32_t));

    return 0;
}