
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Define a type-generic macro for acosh
#define ACOSH(X) (((X) > 0) ? cosh(X) : sinh(X))

int main() {
    // Take input from argc and argv
    int n = atoi(argv[1]);
    double a = strtod(argv[2], NULL);

    // Perform loop fusion optimization
    for (int i = 0; i < n; ++i) {
        double result = ACOSH(a * cosh(a));
        printf("%.4f\n", result);
    }

    return 0;
}