
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>

#define MAX_INPUT_SIZE 1024 * 1024 // 1 MB

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: %s <input_size>\n", argv[0]);
        return 1;
    }

    size_t input_size = atoi(argv[1]);
    if (input_size <= MAX_INPUT_SIZE) {
        // No memory optimizations needed
        char buffer[input_size];
        memcpy(buffer, argv[1], input_size);
        printf("%s\n", buffer);
    } else {
        // Use memory optimizations
        char *src = argv[1];
        char *dst = malloc(input_size);
        memcpy(dst, src, input_size);
        printf("%s\n", dst);
        free(src);
    }

    return 0;
}