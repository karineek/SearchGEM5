
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Function to demonstrate register allocation optimization
void demo_register_allocation(int *a, int *b, int *c) {
    // Initialize variables
    int x = 5;
    int y = 10;
    int z = 20;

    // Perform calculation using operators
    int result = a + b - c;

    // Print result
    printf("Result: %d\n", result);
}

int main(int argc, char *argv[]) {
    // Parse command line arguments
    if (argc < 3) {
        printf("Usage: %s <a> <b> <c>\n", argv[0]);
        return 1;
    }

    int a = atoi(argv[1]);
    int b = atoi(argv[2]);
    int c = atoi(argv[3]);

    // Call function to demonstrate register allocation optimization
    demo_register_allocation(&a, &b, &c);

    return 0;
}