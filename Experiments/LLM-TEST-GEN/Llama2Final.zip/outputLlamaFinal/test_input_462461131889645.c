
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

// Function Specialization using the z format modifier
void foo_z(int argc, char **argv) {
    if (argc >= 2 && strcmp(argv[1], "bar") == 0) {
        printf("Specialized foo for bar\n");
    } else {
        printf("foo for non-bar input\n");
    }
}

int main() {
    int argc = 3;
    char **argv = malloc(sizeof(char *) * argc);
    argv[0] = "main";
    argv[1] = "bar";
    argv[2] = NULL;

    foo_z(argc, argv);

    return 0;
}