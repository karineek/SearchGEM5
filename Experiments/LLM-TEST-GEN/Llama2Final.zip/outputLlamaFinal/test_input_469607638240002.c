
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <time.h>

#define MAX_INPUT_LENGTH 1024

int main(int argc, char** argv) {
    // Check if the input is provided
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <input> \n", argv[0]);
        return 1;
    }

    // Load the input from the command line argument
    char* input = argv[1];

    // Initialize the profiling data structure
    struct _profiling_data {
        int count;
        double sum;
    };
    struct _profiling_data profiling_data;

    // Parse the input and accumulate the profiling data
    char* line = NULL;
    size_t len = 0;
    while ((line = strtok(input, "\n")) != NULL) {
        size_t len = strlen(line);
        if (len > MAX_INPUT_LENGTH) {
            fprintf(stderr, "Line too long\n");
            continue;
        }
        profiling_data.count++;
        profiling_data.sum += len;
    }

    // Generate the serialized profile data
    char* serialized = serialize_profile(&profiling_data);

    // Print the serialized profile data
    printf("Serialized profile data: %s\n", serialized);

    // Free the memory allocated for the serialized data
    free(serialized);

    return 0;
}