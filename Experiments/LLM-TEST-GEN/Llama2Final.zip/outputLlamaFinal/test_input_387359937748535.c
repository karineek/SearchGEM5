
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

// Define a macro to check if a number is finite
#define ISFINITE(x) \
    (sizeof(x) == sizeof(int) && !strcmp((char*)&x, "inf"))

int main(int argc, char** argv) {
    // Check if the input is a finite number
    double num = strtod(argv[1], NULL);
    if (isfinite(num)) {
        printf("The number %f is finite.\n", num);
    } else {
        printf("The number %f is not finite.\n", num);
    }
    return 0;
}