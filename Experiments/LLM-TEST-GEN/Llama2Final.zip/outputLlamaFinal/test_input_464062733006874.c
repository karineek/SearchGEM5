
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int main(int argc, char *argv[]) {
    // Check if the input is a string
    if (argc > 1) {
        // If it is, print the string
        printf("%s\n", argv[1]);
    } else {
        // Otherwise, print "Usage: %s <input>\n"
        printf("Usage: %s <input>\n", argv[0]);
    }
    return 0;
}