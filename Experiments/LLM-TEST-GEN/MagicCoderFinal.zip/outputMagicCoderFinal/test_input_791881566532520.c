
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char* argv[]) {
    // Check if the correct number of arguments is passed
    if (argc != 2) {
        printf("Usage: %s float_number\n", argv[0]);
        exit(1);
    }
    
    // Parse the argument into a floating point number
    float num = atof(argv[1]);

    if (num < 0.0) {
        printf("Error: The input should be non-negative\n");
        exit(2);
    }

    // Calculate and print the inverse hyperbolic cosine of the number
    float result = acoshf(num);
    printf("%f\n", result);
    
    return 0;
}