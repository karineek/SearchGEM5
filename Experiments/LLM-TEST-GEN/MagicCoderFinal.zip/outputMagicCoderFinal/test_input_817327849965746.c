
#include <stdio.h>
#include <wchar.h>
#include "llvm/Support/raw_ostream.h"
#include "llvm/IR/PassManager.h"
#include "llvm/Passes/PassBuilder.h"
#include "llvm/Transforms/Instrumentation.h"

using namespace llvm;
int main(int argc, char** argv) {
  if (argc != 2) {
    fprintf(stderr, "Usage: %s <string>\n", argv[0]);
    return 1;
  }
  
  const wchar_t *input = wcspbrk(argv[1], L"abc"); // look for any of 'a', 'b' or 'c' in the input string
  
  if (input != NULL) {
    fprintf(stdout, "First occurrence of 'a', 'b', or 'c' is at position %lu.\n", wcwidth(input));
  } else {
    fprintf(stderr, "'a', 'b', or 'c' not found in the input string.\n");
  }
  
  return 0;
}