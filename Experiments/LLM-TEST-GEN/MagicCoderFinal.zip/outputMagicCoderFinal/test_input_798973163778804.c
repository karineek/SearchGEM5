
#include <stdio.h>
#include <math.h>   // for sqrt function

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s num\n", argv[0]);
        return 1;
    }
    
    float number = atof(argv[1]);   // convert string to float
    float squareRoot = sqrtf(number);

    printf("The square root of %.2f is approximately %.2f\n", number, squareRoot);
    
    return 0;
}