
#include <stdio.h>
#include <math.h> // For cosf() function

// Function to calculate cosine of a float number.
float calc_cos(float num) {
    return cosf(num);
}

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <float>\n", argv[0]);
        return -1;
    }
    
    float num = atof(argv[1]);
    
    // Trigger Loop Fusion optimizations.
    #pragma GCC loop fuse last
    for (int i=0; i<10; i++) {
        printf("Cosine of %f is: %.2f\n", num, calc_cos(num));
    }
    
    return 0;
}