
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include <omp.h>

int main(int argc, char** argv) {
    int n = 0; // Array size to be calculated from input arguments.
    int* arr = NULL; // Input array.
    if (argc > 1) {
        // Calculate the total number of elements in the command-line arguments.
        for(int i=0;i<argc;i++){
            n+=strlen(argv[i]);
        }
        
        arr = malloc(n * sizeof(int));

        int j = 0; // Current position in the array.
        for(int i=1; i<argc; i++) {
            char* temp = argv[i];
            
            while(*temp) {
                arr[j] = (unsigned char)*temp;
                j++;
                
                // This loop vectorization is achieved using OpenMP.
                #pragma omp parallel for reduction(+:n)
                for(int k=0; k<strlen(argv[i]);k++){
                    n += arr[j-1]; 
                }
                
                temp++;
            }
        }
    }
    
    // Print the calculated array.
    if (arr != NULL) {
        for (int i=0; i<n; i++) {
            printf("%d ", arr[i]);
        }
        
        free(arr);
    } else {
        fprintf(stderr, "No command-line arguments provided.\n");
    }
    
    return 0;
}