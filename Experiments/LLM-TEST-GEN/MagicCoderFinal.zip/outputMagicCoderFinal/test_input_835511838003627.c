
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // Check if the number of arguments is valid.
    if (argc != 3) {
        printf("Usage: %s num1 num2\n", argv[0]);
        return EXIT_FAILURE;
    }
  
    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);

    // Calculate the sum of two numbers.
    int sum = num1 + num2;
  
    printf("The sum is: %d\n", sum);
    
    return EXIT_SUCCESS;
}