
#include <stdio.h>

int main(int argc, char* argv[]) {
    int a = atoi(argv[1]);
    int b = atoi(argv[2]);

    // Perform and_eq operation on input integers 
    int result = a & b;

    printf("Result: %d\n", result);
    
    return 0;
}