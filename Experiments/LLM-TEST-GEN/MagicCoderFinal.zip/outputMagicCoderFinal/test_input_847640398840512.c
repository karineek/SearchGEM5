
#include <stdio.h>   // Standard Input / Output
#include <math.h>    // For sqrt() function

// Function to calculate ctanh(x)
double ctanh(double x) {
    return (1 - exp(-2 * x))/(1 + exp(-2 * x)); 
}

int main(int argc, char **argv){
    double x;

    if (argc != 2){
        printf("Usage: ./program_name <number>\n");
        return 0;
    }
    
    // Convert input string to a number
    sscanf(argv[1], "%lf", &x);
    
    // Calculate ctanh(x) and print the result
    printf("ctanh(%lf) = %lf\n", x, ctanh(x));

    return 0;
}