
#include <stdio.h>

// Recursive function to calculate power
double power(int base, int exponent) {
    if (exponent == 0) return 1;
    else if (exponent > 0) return base * power(base, exponent - 1);
    else if (exponent < 0) return 1 / power(base, -exponent);
}

int main(int argc, char *argv[]) {
    int base = atoi(argv[1]);   // get input for base from command line arguments
    int exponent = atoi(argv[2]); // get input for exponent from command line arguments

    printf("The power of %d to the power %d is: %.f\n", base, exponent, power(base, exponent));
    
    return 0;
}