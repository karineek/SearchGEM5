
#include <stdio.h>

// Function to calculate factorial
long long factorial(int n) {
    if (n == 0 || n == 1) return 1;
    else return n * factorial(n - 1);
}

// Main function
int main(int argc, char* argv[]) {
    // Check for correct number of arguments
    if (argc != 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }
    
    int num = atoi(argv[1]);
    long long fact = factorial(num); // Calculate the factorial
    printf("Factorial of %d is %lld\n", num, fact);
    return 0;
}