
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 3) { //checking the number of arguments are equal to 2
        printf("Usage:\n");
        printf("%s <num1> <num2>\n", argv[0]);
        return 1;
    }

    long int num1 = atoi(argv[1]), num2 = atoi(argv[2]);
    
    // Loop Optimizations
    for (int i=0;i<500000;i++) {
        num1 += num2; 
    }

    printf("The result is %" PRIuMAX "\n", num1);

    return 0;
}