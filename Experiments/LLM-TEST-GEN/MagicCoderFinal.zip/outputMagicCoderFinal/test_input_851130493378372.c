
#include <stdio.h>
#include <stdlib.h>
#include <immintrin.h> // Needed for vector operations

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program_name array_size array\n");
        return -1;
    }
    
    int size = atoi(argv[1]);
    uintmax_t* arr = malloc(sizeof(uintmax_t) * size);
    
    if (arr == NULL) {
        printf("Memory allocation failed\n");
        return -1;
    }
    
    for (int i = 0; i < size; ++i) {
        arr[i] = strtoumax(argv[2]+i*sizeof(uintmax_t), NULL, 10); // Convert string to uintmax_t
    }

    int sum = 0;
    
    #pragma omp target map(tofrom:sum) device(device_list:0) // Enable vectorization and atomic operations
    {
        #pragma omp parallel for reduction(+:sum) num_threads(4) // Use 4 threads in parallel
        for (int i = 0; i < size; ++i) {
            if ((arr[i] & 1) == 0) // Check if number is divisible by 2
                sum += arr[i];
        }
    }
    
    printf("Sum of numbers in the array that are divisible by 2: %lu\n", sum);
    
    free(arr);
    
    return 0;
}