
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s angle_in_radians\n", argv[0]);
        return EXIT_FAILURE;
    }

    double angle = atof(argv[1]); // convert string argument to double
    double result = ccos(angle);  // compute cosine of the angle

    printf("The cosine of %.2lf radians is: %.2lf\n", angle, result);
    return EXIT_SUCCESS;
}