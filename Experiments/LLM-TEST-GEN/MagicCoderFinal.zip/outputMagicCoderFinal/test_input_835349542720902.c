
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void printArray(int arr[], int size) {
    for (int i = 0; i < size; ++i) {
        printf("%d ", arr[i]);
    }
}

// This function takes an array of integers and a value to be inserted into the array.
void insertValue(int arr[], int *value, int size) {
    for (int i = 0; i < size; ++i) {
        if (arr[i] == -1) {
            arr[i] = *value;
            return;
        }
    }
    
    // If the array is full, print an error message and exit.
    printf("The array is full!\n");
    exit(EXIT_FAILURE);
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s [value]\n", argv[0]);
        return 1;
    }
    
    int arr[] = {-1, -1, -1, -1, -1}; // Initially filled with -1 (unspecified value in C)
    const int size = sizeof(arr) / sizeof(int);
    insertValue(arr, &atoi(argv[1]), size); // Insert the given value into array
    
    printArray(arr, size);
    
    return 0;
}