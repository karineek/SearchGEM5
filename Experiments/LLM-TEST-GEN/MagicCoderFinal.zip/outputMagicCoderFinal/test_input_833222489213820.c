
#include <stdlib.h>
#include <wchar.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <wide character string>\n", argv[0]);
        return -1;
    }

    // The wcstoll function parses a wide-character string and converts it to long int.
    // If the string does not represent a number, or if the value is out of range for a long int,
    // it returns LLONG_MIN or LLONG_MAX, which are defined in <limits.h> as -9223372036854775808 and 9223372036854775807 respectively
    long int num = wcstoll(argv[1], NULL, 10);
    
    if (num == LLONG_MIN || num == LLONG_MAX) {
        printf("The input string does not represent a valid number.\n");
        return -1;
    } else {
        printf("%ld\n", num);
        return 0;
    }
}