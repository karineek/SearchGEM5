
#include <stdio.h>  // for printf() function

int add(int x, int y) {
    return (x + y);  // Function to calculate and return the sum
}

// Driver code
int main(int argc, char *argv[]){
    if(argc != 3){
        printf("Usage: ./program <num1> <num2>\n");
        return -1;
    }

    int x = atoi(argv[1]);  // Convert the first argument into integer
    int y = atoi(argv[2]);  // Convert the second argument into integer

    printf("The sum is: %d\n", add(x, y));

    return 0;
}