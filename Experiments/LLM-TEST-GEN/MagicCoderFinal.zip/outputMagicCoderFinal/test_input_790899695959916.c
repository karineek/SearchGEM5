
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h> // include math library for fmax 

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <num1> <num2>\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    double num1 = strtod(argv[1], NULL);
    double num2 = strtod(argv[2], NULL);

    printf("The maximum number is: %.2lf\n", fmax(num1, num2)); 

    return EXIT_SUCCESS;
}