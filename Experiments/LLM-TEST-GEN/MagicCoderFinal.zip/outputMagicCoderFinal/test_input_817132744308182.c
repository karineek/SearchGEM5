
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/* Function to print array */
void printArray(int arr[], int size) {
    int i;
    for (i=0; i < size; i++)
        printf("%d ", arr[i]);
    printf("\n");
}

/* Lexical analysis function that converts string of numbers to array and sort */
void lex(char *str, int *arr) {
    char numStr[10];
    int i = 0, j;
    strtok(str, " ,.-"); // Removing unwanted characters.
    while (i < 20 && strtok(NULL, " ,.-") != NULL) {
        sscanf(strtok(NULL, " ,.-"), "%[^\n]%*c", numStr);
        arr[i++] = atoi(numStr);
    }
}

/* Function to implement selection sort */
void selectionSort(int arr[], int size) {
    int i, j;
    for (i=0; i<size-1; i++) {
        int min_idx = i;
        for (j=i+1; j<size; j++) 
            if (arr[j] < arr[min_idx]) 
                min_idx = j;
        // Swap the found minimum element with the first element        
        int temp = arr[min_idx];
        arr[min_idx] = arr[i];
        arr[i] = temp;
    }
}

/* Main function to test above functions */
int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <input>\n", argv[0]);
        exit(-1);
    }
    
    int arr[] = {-4,-10,-8,-9}; // Unsorted array to test the program.
    int size = sizeof(arr)/sizeof(int); 

    lex(argv[1], arr);

    selectionSort(arr, size);

    printf("Array after sorting: \n");
    printArray(arr, size);
    
    return 0;
}