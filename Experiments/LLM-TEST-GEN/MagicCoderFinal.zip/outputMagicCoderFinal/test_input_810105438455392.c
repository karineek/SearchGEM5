
#include <stdio.h>
#include <math.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <float_number>\n", argv[0]);
        return 1;
    }
    
    double input = strtod(argv[1], NULL);
    long double result = acosl(input);

    printf("%Lf\n", result);
    
    return 0;
}