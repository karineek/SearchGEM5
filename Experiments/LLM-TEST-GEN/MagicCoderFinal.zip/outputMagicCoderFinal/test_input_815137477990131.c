
#include <stdio.h>

int main(int argc, char *argv[]){
    if(argc != 2){ // check if exactly one argument was passed
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }
    
    int num = atoi(argv[1]); // convert command line argument to integer
    if (num != CHAR_MIN){
      printf("%d is not the minimum character value.\n", num);
    } else {
      printf("The minimum char value in C is %c\n", CHAR_MIN);
    }
    
    return 0;
}