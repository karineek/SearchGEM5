
#include <stdio.h>

int main(int argc, char *argv[]) {
    // Check if a valid number of arguments is provided
    if(argc != 2) {
        printf("Usage: %s [number]\n", argv[0]);
        return 1;
    }
    
    // Convert argument to integer and check for errors
    int n, sum = 0, i;
    char *endptr;
    
    errno = 0;
    n = strtol(argv[1], &endptr, 10);
    
    if ((errno == ERANGE && (n == LONG_MAX || n == LONG_MIN))
        || (n < 1) || (*endptr != '\0')) {
        printf("Invalid number: %s\n", argv[1]);
        return 2;
    }
    
    // Calculate sum of all odd numbers from 1 to n
    for(i = 1; i <= n; i++) {
        if (i % 2 != 0) {
            sum += i;
        }
    }
    
    printf("Sum of all odd numbers from 1 to %d: %d\n", n, sum);
    return 0;
}