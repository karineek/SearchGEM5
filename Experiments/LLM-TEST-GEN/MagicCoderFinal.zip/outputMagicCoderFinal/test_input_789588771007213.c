
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <file-name>\n", argv[0]);
        return 1;
    }

    srand((unsigned int) time(NULL));
    const char *file_name = argv[1];

    FILE* file = fopen(file_name, "w");

    if (file == NULL) {
        printf("Unable to open the file %s\n", file_name);
        return 2;
    }

    int size = 1024 * 1024; // 1MB
    char* buffer = malloc(size * sizeof(char));

    if (buffer == NULL) {
        printf("Memory allocation failed\n");
        return 3;
    }

    for (int i = 0; i < size; ++i) {
        buffer[i] = rand() % 256 + ' '; // Random ASCII characters.
    }

    fwrite(buffer, sizeof(char), size, file);

    free(buffer);
    fclose(file);

    char* tmp_name = tmpnam(NULL);

    printf("Created file: %s\n", file_name);
    printf("Temporary name: %s\n", tmp_name ? tmp_name : "Failed to get temporary name");

    return 0;
}