
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <size>\n", argv[0]);
        return -1;
    }

    int size = atoi(argv[1]);

    // Allocate memory dynamically and initialize it to zero using memset.
    char *str = (char*) malloc(sizeof(char) * size);
    if (!str) {
        printf("Failed to allocate memory\n");
        return -1;
    }

    memset(str, 0, sizeof(char) * size);

    // Free the allocated memory.
    free(str);
    
    return 0;
}