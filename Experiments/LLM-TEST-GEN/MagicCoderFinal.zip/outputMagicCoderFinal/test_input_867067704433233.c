
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <filename>\n", argv[0]);
        return -1;
    }

    FILE *file = fopen(argv[1], "rb");
    if (!file) {
        printf("Could not open file\n");
        return -1;
    }

    unsigned char buffer[3];
    size_t readBytes;

    while((readBytes = fread(buffer, 1, sizeof(buffer), file)) > 0){
        for (size_t i=0; i<readBytes; i++) {
            printf("%.2x", buffer[i]);
        }
        printf("\n");
    }

    if (ferror(file)) {
        printf("Error reading file\n");
        return -1;
    }

    fclose(file);
    
    return 0;
}