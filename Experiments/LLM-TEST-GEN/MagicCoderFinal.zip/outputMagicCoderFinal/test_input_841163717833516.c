
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Function to compare two elements in the array */
int compare (const void * a, const void * b) {
   return strcmp(*(char **)a, *(char **)b);
}

int main(int argc, char* argv[]){
    if(argc < 3){
        printf("Usage: %s <Array> <String to Search>\n", argv[0]);
        return -1;
    }

    /* Array of strings */
    char **array = (char **)malloc(sizeof(char *)*argc-1);
    for(int i=1;i<argc;i++){
        array[i-1] = argv[i];
    }

    /* Sort the array of strings */
    qsort(array, argc - 1, sizeof(char *), compare);

    /* Search for string in array */
    char *search_string = argv[1];
    void *result = bsearch(&search_string, array, (argc-1) ,sizeof(char*),compare);

    if(result != NULL){
        printf("Found: %s\n", search_string);
    }else{
        printf("Not found: %s\n", search_string);
    }

    /* Free the allocated memory */
    free(array);

    return 0;
}