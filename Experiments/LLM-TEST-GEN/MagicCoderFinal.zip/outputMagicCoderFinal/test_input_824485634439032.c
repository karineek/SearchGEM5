
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void wcscpy(wchar_t *dest, const wchar_t *src) {
    wchar_t *d = dest;
    while ((*d++ = *src++) != L'\0') // copy characters
        ;
}

// recursive function for demonstration of Interprocedural Optimization (IPA)
wchar_t *f(int n) {
    static wchar_t s[128] = L"";  // return string buffer
    if (n < 0) // base case
        return s;
    
    wcscpy(s, f(n-1));  // recursive call with parameter decremented by 1
    wcsncat(s, L"abc", sizeof(L"abc") / sizeof(wchar_t));  // append to string
    return s;
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Input is required.\n");
        exit(-1);
    }

    wchar_t *input = argv[1]; // input from command line argument
    wprintf(L"%s\n", f(atoi(input)));  // call function with parsed integer input
    
    return 0;
}