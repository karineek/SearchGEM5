
#include <stdio.h>
#include <stdlib.h>
__attribute__((target("sse4"))) // Vectorization with SSE4 instruction set
int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <num>\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    int num = atoi(argv[1]);
    __m128i result = _mm_mullo_epi32(__m128i {num, 1, num, 1}, __m128i {2, 2, 2, 2}); // Vectorized multiplication
    
    int *pResult = (int*)&result; // Convert to pointer type for print out
    printf("%d\n", pResult[0]);
    
    return EXIT_SUCCESS;
}