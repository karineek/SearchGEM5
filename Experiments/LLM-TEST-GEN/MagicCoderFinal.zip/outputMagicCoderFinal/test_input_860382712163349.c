
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int sum = 0; // initial value of sum
    for (int i = 1; i < argc; i++) {  // loop through arguments
        int num = atoi(argv[i]); // convert the argument to an integer
        if (num == 0) continue; // skip any zeros passed as arguments
        sum += num; // add this number to our running total
    }
    printf("Sum: %d\n", sum); // print out the final total
    return 0;
}