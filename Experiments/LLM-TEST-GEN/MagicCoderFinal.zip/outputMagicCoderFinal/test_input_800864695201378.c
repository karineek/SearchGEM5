
#include <stdio.h>
#include <stdlib.h>

void function1(int value);  // Declaration of function to be profiled

int main(int argc, char **argv) {
    if (argc != 2) {  // Check for correct number of arguments
        printf("Usage: ./program <integer>\n");
        return EXIT_FAILURE;
    }

    int value = atoi(argv[1]);  // Convert string argument to integer
    function1(value);  // Call the function under profiling

    return EXIT_SUCCESS;
}

void function1(int value) {
    if (value < 0) {  // Emulate a negative number
        printf("Negative number: %d\n", value);
    } else {
        int i;
        for (i=0; i<value; ++i) {  // Vertical tab simulation
            printf("\t");  
        }
        printf("%d\n", value);
    }
}