
#include <stdio.h>

// Function for characters from 'A' to 'Z'.
void print_alphabet() {
    int i;
    for (i = 65; i <= 90; ++i) // ASCII value of 'A' is 65, 'Z' is 90.
        printf("%c\n", i);
}

// Main function.
int main(int argc, char* argv[]) {
    // Checking if the number of arguments is correct (i.e., exactly one).
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <input>\n", argv[0]);
        return 1;
    }

    // Triggering Inliner Heuristics optimizations.
    __attribute__((optimize("-finline"))) print_alphabet();

    printf("%s\n", argv[1]);
    return 0;
}