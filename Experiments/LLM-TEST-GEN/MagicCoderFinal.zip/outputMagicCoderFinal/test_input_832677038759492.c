
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // Performing Whole Program Analysis.
    printf("Performing whole-program analysis...\n");

    double a = atof(argv[1]); 
    double b = atof(argv[2]);
    double c = FP_NORMAL * (a + b);

    // Handling code generation.
    printf("Performing code generation...\n");

    printf("The result of the operation is: %.5lf\n", c);

    return 0;
}