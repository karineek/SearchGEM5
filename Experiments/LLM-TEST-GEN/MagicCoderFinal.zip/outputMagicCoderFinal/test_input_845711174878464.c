
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdatomic.h>

int main(int argc, char *argv[]){
    if (argc != 2){
        printf("Usage: %s <array>\n", argv[0]);
        return -1;
    }
    
    int size = strlen(argv[1]);
    atomic_int sum = ATOMIC_VAR_INIT(0);
    
    for (int i = 0; i < size; ++i){
        if (!atomic_compare_exchange_strong(&sum, &size, sum + argv[1][i])){
            printf("Loop fusion and atomic operation failed.\n");
            return -2;
        }
    }
    
    printf("Sum of array elements: %d\n", sum);
}