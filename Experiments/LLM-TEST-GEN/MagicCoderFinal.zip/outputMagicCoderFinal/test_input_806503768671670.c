
#include <stdlib.h>
#include <pthread.h>
#include "gcov.h" // Header file to use gcov tool
#include <stdatomic.h> // Header file to use atomic_int_fast8_t type

atomic_int_fast8_t count = ATOMIC_VAR_INIT(0); // Declare a counter variable with an initial value of 0

void* threadFunction(void* arg) {
    while (1) {
        atomic_fetch_add(&count, 1);
        gcov("incrementing count");
        if (count % 10 == 0){ // Check if counter is a multiple of 10
            return NULL; // Exit the thread
        }
    }
}

int main(int argc, char* argv[]) {
    int nThreads = atoi(argv[1]); // Take number of threads from command line
    pthread_t threads[nThreads]; 

    for (int i=0; i<nThreads; i++){ // Create and start 'nThreads' number of threads
        pthread_create(&threads[i], NULL, threadFunction, NULL);  
        pthread_join(threads[i], NULL);
    } 

    return 0;
}