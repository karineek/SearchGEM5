
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <float.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s [1|0]\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    int is_subnorm_supported = atoi(argv[1]);
    
    if (is_subnorm_supported) {
        printf("The system supports subnormal floating point numbers.\n");
    } else {
        printf("The system does not support subnormal floating point numbers.\n");
    }
    
    return 0;
}