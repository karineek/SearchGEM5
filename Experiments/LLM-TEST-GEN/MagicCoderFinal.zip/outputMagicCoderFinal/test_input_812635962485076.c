
#include <stdio.h>
#include <stdlib.h>
#include <limits.h> // for INTMAX_MIN, INTMAX_MAX, PRIuMAX

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s number\n", argv[0]);
        return 1;
    }
    
    intmax_t num = atoll(argv[1]); // convert string to intmax_t

    if (num < INTMAX_MIN || num > INTMAX_MAX) {
        printf("Input number %" PRIuMAX " is out of range.\n", num);
        return 0;
    }
    
    printf("Input number: %" PRIuMAX "\n", num);
    return 0;
}