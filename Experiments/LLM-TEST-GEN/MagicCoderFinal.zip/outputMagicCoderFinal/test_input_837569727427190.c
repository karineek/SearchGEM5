
#include <stdio.h>
#include <stdlib.h>

void print_args(int argc, char **argv) {
    for (int i = 0; i < argc; ++i) {
        printf("Arg[%d] = %s\n", i, argv[i]);
    }
}

// Whole Program Optimization function (Placeholder)
void WPO(int argc, char **argv){
    // This is a placeholder. You may want to use this for further optimizations 
    printf("Executing Whole Program Optimization...\n");
    print_args(argc, argv);
}

// Provides various utility functions
void util1(){
    printf("Executing Utility Function 1...\n");
}

void util2(){
    printf("Executing Utility Function 2...\n");
}

int main(int argc, char **argv) {
    WPO(argc, argv); // Whole Program Optimization call
    
    for (int i = 1; i < argc; ++i){ 
        if(!strcmp(argv[i],"-util")){
            util1(); // Utility Function 1 call
        }else if(!strcmp(argv[i],"-util2")) {
            util2(); // Utility Function 2 call
        }
    }
    
    return 0;
}