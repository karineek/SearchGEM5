
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include <wchar.h>

int main(int argc, char *argv[]) {
    setlocale(LC_ALL, "");  // To make sure strcoll works correctly
    
    // Get input from command line arguments
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <string1> <string2>\n", argv[0]);
        return EXIT_FAILURE;
    }
    const wchar_t *s1 = wcspbrk(argv[1], L"\"'");  // Remove quotes if any
    const wchar_t *s2 = wcspbrk(argv[2], L"\"'");  // from input strings
    
    int res;
    res = strcoll((char*) s1, (char*) s2);
    
    if(res < 0) {
        printf("%ls is alphabetically before %ls\n", s1, s2);
    } else if(res > 0){
        printf("%ls is alphabetically after %ls\n", s1, s2);
    } else {
        printf("Both strings are the same!\n");
    }
    
    return EXIT_SUCCESS;
}