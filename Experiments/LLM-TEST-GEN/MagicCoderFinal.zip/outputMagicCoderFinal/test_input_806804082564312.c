
#include<stdio.h>
#include<stdlib.h>
#include<stdarg.h>
#include <inttypes.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s NUMBER\n", argv[0]);
        exit(1);
    }
    uint64_t input = strtoull(argv[1], NULL, 10);
    uint64_t output = UINT64_C(input * 2);

    printf("The doubled value is: %" PRIu64 "\n", output);

    return 0;
}