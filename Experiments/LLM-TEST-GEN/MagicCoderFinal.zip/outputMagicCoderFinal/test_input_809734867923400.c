
#include <stdio.h>
#include <stdlib.h>

int add(int a, int b) {
    return a + b;
}

int subtract(int a, int b) {
    return a - b;
}

int multiply(int a, int b) {
    return a * b;
}

double divide(int a, int b) {
    if (b == 0) {
        printf("Error: Division by zero.\n");
        exit(-1);
    } else {
        return (double)a / b;
    }
}

int main(int argc, char **argv) {
    int a = atoi(argv[1]);  // Convert the command line argument to an integer.
    int b = atoi(argv[2]);
    int choice = (argc > 3 && argv[3][0] == 'a') ? 0 : (argc > 3 && argv[3][0] == 's') ? 1 : (argc > 3 && argv[3][0] == 'm') ? 2 : 3;
    
    switch(choice) {
        case 0: printf("%d + %d = %d\n", a, b, add(a,b)); break;
        case 1: printf("%d - %d = %d\n", a, b, subtract(a,b)); break;
        case 2: printf("%d * %d = %d\n", a, b, multiply(a,b)); break;
        case 3: printf("%.1f / %.1f = %.1f\n", (double)a, b, divide(a,b)); break;
        default: printf("Error: Invalid operation.\n"); break;
    }
    
    return 0;
}