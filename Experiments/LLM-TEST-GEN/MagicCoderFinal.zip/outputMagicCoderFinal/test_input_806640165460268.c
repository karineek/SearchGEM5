
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char* argv[]) {
    // Check if there are exactly 2 arguments passed
    if (argc != 3) {
        printf("Usage: ./program_name input1 input2\n");
        return 1;
    }
    
    int result = atoi(argv[1]) + atoi(argv[2]);
    printf("The sum of %s and %s is: %d\n", argv[1], argv[2], result);

    // Return 0 to indicate a successful program execution
    return 0;
}