
#include <stdio.h> //standard input/output and error functions
#include <stdlib.h>  //used for exit() function
#include <string.h> //used for strlen() function

//union declaration
typedef union {
    int num;
    char chr[4];
} Union;

int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        printf("Usage: ./program_name <number>\n");
        exit(1);
    }

    //union initialization and printing the values
    Union unionObject;
    
    //checking for dead code.
    if ((argv[1][0] != '0') && (strlen(argv[1]) > 1))
    {
        printf("Dead Code!\n");
        return 0;
    }

    unionObject.num = atoi(argv[1]);
    printf("Union content: %d\n", unionObject.num);

    strcpy(unionObject.chr, argv[1]);
    printf("Union content as char: %s\n", unionObject.chr);
    
    return 0;
}