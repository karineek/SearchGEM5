
#include <stdio.h>
#include <stdlib.h>
#include <xmmintrin.h> // For SIMD instructions

// Structure definition
typedef struct {
    float x; 
    float y; 
} Point2D_t;

// Union definition
typedef union {
    __m128i data;   // Store data as 128-bit integer for SIMD operations.
    Point2D_t points[4];  // Array of complex data type to demonstrate structure/union usage.
} Vector_t;

// Function that calculates the average using SIMD instructions
float avg_simd(int *arr, int size) {
    __m128i sum = _mm_setzero_si128();  // Initialize a zero vector.
    for (int i=0; i<size/4; i++) {
        sum = _mm_add_epi32(sum, arr[i]);   // Add each element to the sum.
    }
    __m128i avg = _mm_srli_epi32(sum, 2);  // Right shift by 2 bits (divide by 4) to get the average.
    return *(__m128i *)&avg;  // Return as a float value.
}

int main(int argc, char **argv) {
   if (argc < 5 || argc%4 != 1){
        printf("Please provide an array of integers with a size that is a multiple of 4\n");
        return -1;
    }

    Vector_t vec = {{0, 0}, {0, 0}, {0, 0}, {0, 0}};

    // Convert input arguments to an array and calculate the average.
    for (int i=1; i<argc; i+=4) {
        vec.points[i/4].x = atoi(argv[i]);
        vec.points[i/4].y = atoi(argv[i+1]);
        // ... continue for y values
    }

   printf("Average of the array is %.2f\n", avg_simd((int *)&vec, 4));

   return 0;
}