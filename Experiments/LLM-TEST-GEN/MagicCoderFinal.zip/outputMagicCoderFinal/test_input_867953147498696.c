
#include <stdio.h>
#include <stdlib.h>

// Using alignas to define a variable with 16 byte alignment
__attribute__((aligned(16))) int x = 0;

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <value>\n", argv[0]);
        return EXIT_FAILURE;
    }

    // Using the alignas attribute to specify a variable with 16 byte alignment
    __attribute__((aligned(16))) int y = atoi(argv[1]);

    printf("Value of y: %d\n", y);

    return EXIT_SUCCESS;
}