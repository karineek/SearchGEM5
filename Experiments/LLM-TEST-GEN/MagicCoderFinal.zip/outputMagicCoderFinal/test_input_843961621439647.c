
#include <stdio.h>

// Declare a volatile variable to trigger PGO optimization
volatile int count; 

void incrementCount() {
    // Increment the 'count' variable
    count++; 
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input>\n", argv[0]);
        return -1;
    }

    int input = atoi(argv[1]);
    while(input--) {
        incrementCount(); // Trigger PGO optimization
    }
    
    printf("%d\n", count); 

    return 0;
}