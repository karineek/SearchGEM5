
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

// Function to calculate factorial of an integer
unsigned long long int factorial(int n) { 
    unsigned long long int fact = 1; 
  
    for (int i = 2; i <= n; i++) {
        fact *= i; 
    }
    return fact;
} 

// Function to print the usage of this program
void usage() { 
    printf("Usage: %s <number>\n", __argv[0]); 
    exit(1); 
}

int main(int argc, char* argv[]) { 
    // check if we have exactly one argument
    if (argc != 2) {
        usage();
    }
  
    int n;
    // try to convert the first command line argument into an integer
    if (sscanf(argv[1], "%d", &n) != 1 || n < 0) {
        fprintf(stderr, "Error: %s is not a non-negative integer.\n", argv[1]);
        usage();
    }
  
    // calculate the factorial of the number
    unsigned long long int result = factorial(n);
  
    printf("Factorial of %d is %llu\n", n, result); 
  
    return 0;
}