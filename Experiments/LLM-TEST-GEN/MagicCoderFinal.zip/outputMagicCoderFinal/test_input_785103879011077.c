
#include <stdio.h>

void multiply(int x, int y) {
    // Perform multiplication operation
    for (int i = 0; i < x; ++i){
        printf("%d",y);
    }
}

int main(int argc, char*argv[]){
   if(argc != 3){
      fprintf(stderr,"usage: %s <x> <y>\n", argv[0]);
      return 1;
   }
   int x = atoi(argv[1]), y = atoi(argv[2]);
   
   multiply(x,y); // Call the function with arguments from command line

   return 0;
}