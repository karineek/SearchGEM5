
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    // Check if any arguments were provided
    if (argc == 1) {
        printf("No command line arguments found.\n");
        return 0;
    }

    // Print each argument passed to the program
    for (int i = 0; i < argc; ++i) {
        printf("Argument %d: %s\n", i, argv[i]);
    }
    
    free(argv); // Memory Optimizations
    return 0;
}