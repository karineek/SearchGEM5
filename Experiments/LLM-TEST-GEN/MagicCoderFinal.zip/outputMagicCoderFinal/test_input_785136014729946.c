
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>  // For towlower() function

int count_chars(const char* filename);

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        exit(1);
    }
    
    int count = count_chars(argv[1]);
    printf("Character count: %d\n", count);

    return 0;
}

int count_chars(const char* filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        perror("Error opening file");
        exit(1);
    }
    
    int count = 0;
    int c;
    while ((c = fgetc(file)) != EOF) {
        // Ignore whitespace characters.
        if (isalnum((unsigned char)btowc(&c))) {
            count++;
        }
    }
    
    fclose(file);
    return count;
}