
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <string>\n", argv[0]);
        return 1;
    }
    
    char str[] = argv[1];
    int i;
    for(i=0;str[i]!='\0';i++){
        // Schedule the instructions, here it is a simple example that only skips whitespaces
        if(isspace(str[i])){
            strcspn(&str[i], " ");
        }
    }
    
    printf("Optimized string: %s\n", str);
    return 0;
}