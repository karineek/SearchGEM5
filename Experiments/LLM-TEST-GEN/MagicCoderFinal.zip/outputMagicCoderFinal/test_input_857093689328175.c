
#include <stdio.h>
#include <string.h>

// Function to calculate sum of characters 
int getSum(char* str) {
    int sum = 0;
    for (int i = 0; i < strlen(str); i++)
        sum += (int)str[i];   // Casting char to int implicitly does ASCII value conversion.
    return sum;
}

int main(int argc, char** argv){
    if(argc != 2){
       printf("Invalid arguments! Please provide a string.\n");
       return -1;
    }
    
    // Trigger Loop Fusion and Handles code generation
    int result = getSum(argv[1]);
    printf("Sum of all characters in the input string: %d\n", result);
    
    return 0;
}