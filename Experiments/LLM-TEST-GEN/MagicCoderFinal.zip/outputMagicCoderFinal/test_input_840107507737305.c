
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

// Function to divide two numbers using maximum value of type int
struct imaxdiv_result {int q; int r;} imaxdiv(int numerator, int denominator) {
    return (struct imaxdiv_result){numerator / denominator, numerator % denominator};
}

// Main function to test the above function
int main(int argc, char* argv[]) {
    if (argc != 3) {
        printf("Usage: ./program <numerator> <denominator>\n");
        return EXIT_FAILURE;
    }

    int numerator = atoi(argv[1]);
    int denominator = atoi(argv[2]);

    // Call the function to divide two numbers and print the result
    printf("The quotient is: %d\n", imaxdiv(numerator, denominator).q);
    printf("The remainder is: %d\n", imaxdiv(numerator, denominator).r);

    return EXIT_SUCCESS;
}