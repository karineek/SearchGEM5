
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // Check if there is exactly one argument passed to the program
    if (argc != 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        exit(1);
    }

    int number;
    // Convert the command-line argument to an integer
    if (sscanf(argv[1], "%d", &number) != 1) {
        printf("Invalid input\n");
        exit(1);
    }

    // Check if the number is negative or positive and print the result
    if (number < 0)
        printf("%d is a negative number.\n", number);
    else
        printf("%d is a positive number.\n", number);

    return 0;
}