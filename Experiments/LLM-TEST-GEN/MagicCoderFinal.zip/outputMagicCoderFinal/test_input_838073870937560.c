
#include <stdio.h>

int main(int argc, char* argv[]) {
    if (argc != 3) {
        printf("Usage: %s num1 num2\n", argv[0]);
        return 1;
    }

    signed char a = atoi(argv[1]);
    signed char b = atoi(argv[2]);

    int sum = a + b, diff = a - b, prod = a * b, quot = (int)a / b;

    printf("Sum: %d\n", sum);
    printf("Difference: %d\n", diff);
    printf("Product: %d\n", prod);
    printf("Quotient: %d\n", quot);

    return 0;
}