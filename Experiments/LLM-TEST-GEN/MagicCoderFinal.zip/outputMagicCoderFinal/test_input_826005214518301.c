
#include <stdio.h>
#include <expf.h> // Note: this is not a standard library. You will need to include the correct header file depending on your system/compiler.
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <argument>\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    double argument = atof(argv[1]); // Convert the string to a floating point number.
    double result = cexpf(argument); // Use the cexpf function to calculate the exponential of 'argument'.
    
    printf("The result is: %f\n", result); 
    return EXIT_SUCCESS; 
}