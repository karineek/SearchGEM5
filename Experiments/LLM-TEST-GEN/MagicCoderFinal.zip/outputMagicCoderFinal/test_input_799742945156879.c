
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2 || argv[1] == NULL) {
        printf("Usage: %s [argument]\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    // Your code here.
    printf("You entered: %s\n", argv[1]);

    return 0;
}