
#include <stdio.h>
#include <stdlib.h>

int is_prime(int num) {
    int i;

    if (num <= 1) return 0;

    for (i = 2; i * i <= num; i++) {
        if (num % i == 0)
            return 0;
    }

    return 1;
}

int main(int argc, char* argv[]) {
    int start, end, i;

    // Check for correct number of arguments
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <start> <end>\n", argv[0]);
        exit(1);
    }

    // Convert the command-line arguments to integers
    start = strtol(argv[1], NULL, 10);
    end   = strtol(argv[2], NULL, 10);

    printf("Prime numbers between %d and %d are: ", start, end);

    // Find and print all prime numbers in the range
    for (i = start; i <= end; i++) {
        if (is_prime(i)) {
            printf("%d ", i);
        }
    }

    printf("\n");

    return 0;
}