
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // Check if an argument is provided
    if (argc != 2) {
        printf("Usage: %s number\n", argv[0]);
        return EXIT_FAILURE;
    }

    int number = atoi(argv[1]);
    
    // Print the address of the number using PRIdPTR format specifier
    printf("The address of the input number is: %" PRIdPTR ".\n", (PRIdPTR)&number);

    return EXIT_SUCCESS;
}