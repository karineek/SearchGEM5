
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    if (argc > 1 && atoi(argv[1]) > 5) {
        printf("The input number is greater than 5\n");
    } else {
        printf("The input number is not provided or it's not greater than 5\n");
    }
    
    return EXIT_SUCCESS;
}