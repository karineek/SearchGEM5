
#include <stdio.h>
#include <limits.h> // for DBL_MAX_EXP and INT_MAX

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: ./%s NUM\n", argv[0]);
        return -1;
    }
    
    int num = atoi(argv[1]);
    double d = pow(2.0, num);
    
    // Finding the maximum exponent of a number using DBL_MAX_EXP macro
    int exp_max = DBL_MAX_EXP; 
    while (1) {
        if ((exp_max + 1) < INT_MAX) {
            double d_temp = pow(2.0, exp_max + 1);
            if (d_temp <= d) {
                printf("Max exponent of number %d is: %d\n", num, exp_max);
                return 0;
            }
        } else {
            printf("Cannot find the maximum exponent of number %d.\n", num);
            return -1;
        }
        exp_max++;
    }
}