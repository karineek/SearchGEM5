
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // Check if the user passed any arguments
    if (argc != 2) {
        printf("Usage: %s <string_to_convert>\n", argv[0]);
        return 1;
    }

    // Try to convert string to long integer
    char *endptr;
    errno = 0;
    long num = strtol(argv[1], &endptr, 10);

    if (errno != 0 || argv[1] == endptr) {
        printf("Error: '%s' is not a valid number\n", argv[1]);
        return 1;
    } else {
        printf("%ld\n", num);
        return 0;
    }
}