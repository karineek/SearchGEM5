
#include <stdio.h>
#include <complex.h>
#include <math.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: ./main <complex number>\n");
        return -1;
    }
    
    double real_part = atof(argv[1]);
    double imaginary_part = cimag(real_part);

    printf("The imaginary part of the complex number is: %f\n", imaginary_part);

    return 0;
}