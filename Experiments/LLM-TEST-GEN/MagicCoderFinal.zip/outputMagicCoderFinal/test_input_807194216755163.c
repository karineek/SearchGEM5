
#include <stdio.h>
#include <stdlib.h>

// Macro for common subexpression elimination (CSE)
#define FACT(n) ((n == 0 || n == 1) ? 1 : (n * FACT((n)-1)))

int main(int argc, char* argv[]) {
    if(argc < 2) {
        printf("Please provide an argument.\n");
        return EXIT_FAILURE;
    }
    
    int n = atoi(argv[1]); // convert command line argument to integer
    
    if (n < 0) {
        printf("Factorial of a negative number is not defined.\n");
        return EXIT_FAILURE;
    }
    
    long long fact = FACT(n);
    
    printf("The factorial of %d is: %lld\n", n, fact);
    
    return 0;
}