
#include <stdio.h>

// Declaring our macro to calculate factorial 
#define FACT(n) n == 0 ? 1 : (long long int)(n * FACT(n - 1))

int main(int argc, char **argv) {
    // Checking if the input is valid
    if(argc != 2){
        printf("Usage: ./program <number>\n");
        return -1;
    }
    
    // Type conversion to long long int for factorial calculation
    long long int number = atoll(argv[1]);
    
    // Using type-generic macro to calculate the factorial.
    printf("The factorial of %lld is: %lld\n",number, FACT(number));

    return 0;
}