
#include <stdio.h>

int main(int argc, char *argv[]) {
    int a = atoi(argv[1]); // get first argument
    int b = atoi(argv[2]); // get second argument
    int i;

    for (i=0; i<a; ++i) 
        for (int j=0; j<b; ++j) {
            printf("%d ", a*b); // The output will be the product of 'a' and 'b'
        }
    
    return 0;
}