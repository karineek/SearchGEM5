
#include <stdio.h>
#include <stdlib.h>

// Declare the macro
#define PRINT_AND_SUM(Type, value) \
do { \
    printf("The sum of all elements: %d\n", (value).sum); \
} while(0)

// Define a struct for input data
typedef struct {
    int sum;
} InputData;

int main(int argc, char* argv[]) {
   if(argc < 2){
        printf("No arguments provided. Exiting...\n");
        return -1;
   }

   // Declare the input data
   int sum = atoi(argv[1]);
   
   InputData input_data = {sum};

   PRINT_AND_SUM(input_data);

   return 0;
}