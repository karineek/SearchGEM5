
#include <stdio.h>

#define IS_NON_NEG(x) ((x) >= 0)

int main(int argc, char* argv[]) {
    if(argc != 3){
        printf("Usage: %s num1 num2\n", argv[0]);
        return -1;
    }
    
    int a = atoi(argv[1]);
    int b = atoi(argv[2]);

    if(!IS_NON_NEG(a) || !IS_NON_NEG(b)){
        printf("Both inputs must be non-negative integers.\n");
        return -1;
    }
    
    int sum = a + b;
    printf("The sum of %d and %d is: %d\n", a, b, sum);
    return 0;
}