
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char **argv) {
    // Check if an argument is provided
    if (argc != 2) {
        printf("Usage: ./program <command>\n");
        return 1;
    }

    // Execute the command using system function
    int result = system(argv[1]);

    // Check the exit status of the command
    if (result == 0) {
        printf("Command executed successfully.\n");
    } else {
        printf("Command execution failed with error code: %d\n", result);
    }

    return 0;
}