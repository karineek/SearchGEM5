
#include <stdio.h>

long long crealf(int n){
    if(n == 0) return 1;
    else return n * crealf(n-1);
}

int main(int argc, char* argv[]){
    // Check if there are at least two command line arguments
    if (argc < 2){
        printf("Please provide an input number.\n");
        return -1;
    }
    
    int n = atoi(argv[1]);
    
    long long result = crealf(n);
    printf("The factorial of %d is: %lld\n", n, result);
    
    // Loop-Invariant Code Motion example: print the sum of all numbers from 0 to n
    int sum = 0;
    for(int i=0; i<n+1; i++){
        sum += i;
    }
    printf("The sum from 0 to %d is: %d\n", n, sum);
    
    return 0;
}