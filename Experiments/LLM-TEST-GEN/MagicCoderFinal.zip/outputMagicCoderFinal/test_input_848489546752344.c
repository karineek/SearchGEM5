
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>  // Include errno to use strerror function

// Function to display error message along with the strerror() function
void ErrorHandler(const char* functionName) {
    printf("Error in %s: %s\n", functionName, strerror(errno));
}

int main(int argc, char *argv[]){
    if (argc != 2){   // If the number of arguments is not equal to 2
        fprintf(stderr, "Usage: %s <input_file>\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    FILE *fp;   // Declare file pointer for input file
    char buffer[100];  // Declare buffer to read line by line

    fp = fopen(argv[1], "r");   // Open the input file in read mode
    if (fp == NULL){
        ErrorHandler("fopen");
        exit(EXIT_FAILURE);
    }
    
    while(fgets(buffer, sizeof buffer, fp) != NULL){  // Read line by line until end of file is reached
        printf("%s", buffer);   // Print the content of the buffer (current line from input file)
    }

    fclose(fp);  // Close the file after reading all its contents

    return 0;
}