
#include <stdio.h>
#include <ctype.h>

int main(int argc, char *argv[]) {
    // check if there are exactly two arguments
    if (argc != 2) {
        printf("Usage: %s <char>\n", argv[0]);
        return -1;
    }
    
    int result = isgraph(argv[1][0]);
    
    // print the result of checking if the character is alphanumeric
    printf("%c is graphical: %s\n", argv[1][0], (result == 0) ? "No" : "Yes");
    
    return 0;
}