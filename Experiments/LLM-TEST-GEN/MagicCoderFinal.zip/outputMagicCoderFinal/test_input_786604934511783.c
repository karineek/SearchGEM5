
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // Checking if there's any argument
    if (argc != 2) {
        printf("Usage: %s num\n", argv[0]);
        exit(1);
    }

    int n = atoi(argv[1]);
    for (int i=0;i<n;++i){
        //This line of code will trigger loop vectorization. 
        //It's also a example of a release fence 
        printf("%d",i);
    }
    
    return 0;
}