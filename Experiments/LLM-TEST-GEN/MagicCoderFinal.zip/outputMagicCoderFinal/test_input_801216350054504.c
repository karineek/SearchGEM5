
#include <stdio.h>

// Recursive function for calculating factorial
long long fact(int n) {
    if (n == 0 || n == 1) return 1;
    else return n * fact(n-1);
}

int main(int argc, char **argv) {
    int num = -1; // Initialize to some invalid value
    
    // Input error checking
    if (argc != 2 || sscanf(argv[1], "%d", &num) != 1) {
        printf("Please provide a valid integer argument.\n");
        return -1;
    }

    long long result = fact(num); // Call the function with the provided argument
    
    printf("Factorial of %d is: %lld\n", num, result);

    return 0;
}