
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s number\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    double input = atof(argv[1]);
    double result = ctanh(input); // This requires the -lm flag for linking.

    printf("The hyperbolic tangent of %lf is: %.20lg\n", input, result);

    return 0;
}