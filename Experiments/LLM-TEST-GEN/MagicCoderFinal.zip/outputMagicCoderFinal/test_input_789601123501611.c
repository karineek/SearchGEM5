
#include <stdio.h>

int main(int argc, char *argv[]) {
    // IPO: Interprocedural optimization
    // %U conversion specifier is used to print the pointer value as a hexadecimal number
    
    if (argc != 2) {
        printf("Usage: ./program <string>\n");
        return -1;
    }
    
    char* str = argv[1];
    printf("The input string is \"%U\"\n", str);
    printf("%p\n", str); // print the address of 'str' in hexadecimal format
    
    return 0;
}