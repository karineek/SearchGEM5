
#include <stdio.h>
#include "llvm/Transforms/Utils/FunctionPass.h" // Includes Profile-Guided Instrumentation
#include "llvm/Passes.h" // Includes General LLVM analysis passes

ldiv_t div(int dividend, int divisor) {
    ldiv_t result = ldiv(dividend, divisor);
    return result; 
}

int main(int argc, char *argv[]){
    if(argc != 3){
        printf("Usage: ./program <dividend> <divisor>\n");
        return -1; // Error exit code
    }

    int dividend = atoi(argv[1]);
    int divisor = atoi(argv[2]);

    ldiv_t divResult = div(dividend, divisor);
    printf("Quotient: %d\n", divResult.quot);
    printf("Remainder: %d\n", divResult.rem);
    
    return 0; // Normal exit code
}