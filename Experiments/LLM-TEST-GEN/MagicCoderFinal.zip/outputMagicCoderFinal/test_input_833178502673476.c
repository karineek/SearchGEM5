
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>  // for toupper()

// PGI related header files, these may vary depending on the compiler's implementation and version
#ifdef __PGI
#include "pgi.h"
#endif

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <input string>\n", argv[0]);
        exit(1);
    }
    
    // PGI_BEGIN_PROFILE macro should start a new profile session. This might not be needed on some compilers.
#ifdef __PGI
    PGI_BEGIN_PROFILE;
#endif
    
    char *input = argv[1];  // the string to process will be the first command line argument
    size_t length = strlen(input);
    
    for (size_t i = 0; i < length; ++i) {
        input[i] = toupper((unsigned char)input[i]);  // use toupper to convert the character to uppercase
    }

    printf("Converted string: %s\n", input);
    
    // PGI_END_PROFILE macro should end a profile session. This might not be needed on some compilers.
#ifdef __PGI
    PGI_END_PROFILE;
#endif

    return 0;
}