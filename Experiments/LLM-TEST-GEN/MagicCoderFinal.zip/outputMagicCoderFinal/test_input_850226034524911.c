
#include <stdio.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Please provide a single integer input.\n");
        return 1;
    }

    long int num = strtol(argv[1], NULL, 10);

    // Check that the argument is indeed an integer. If it's not, there will be an error in the above line and num will remain its initial value of 0.
    if (num == 0) {
        printf("Please provide a positive integer input.\n");
        return 1;
    }

    long int result = 1;
    for(int i = 2; i <= num; ++i) {
        // Unrolling optimization: GCC will automatically optimize this loop to calculate the factorial in constant time.
        result *= i;
    }
    
    printf("The factorial of %ld is %ld.\n", num, result);

    return 0;
}