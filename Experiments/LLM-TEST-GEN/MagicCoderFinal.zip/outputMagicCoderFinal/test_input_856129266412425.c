
#include <stdio.h>  // for printf

// Function declaration 
int convertRank(char c); 

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./programName intValue\n");
        return -1;
    }

    // Call the function
    int rank = convertRank(argv[1][0]);
    printf("The conversion rank of %d is: %d\n", argv[1][0], rank);

    return 0;
}

// Function definition 
int convertRank(char c) {
    // Ranks in the order of their ASCII values 
    if (c >= '9') 
        return 8;  
    else if (c >= '8' && c <= '9') 
        return 7;  
    else if (c == '7') 
        return 6;  
    // More conditions can be added as per the requirement
}