
#include <stdio.h>
#include <stdlib.h> // for abs() function

int main(int argc, char *argv[]) {
    if(argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return EXIT_FAILURE;
    }

    int num = atoi(argv[1]); // convert string to integer
    int absNum = abs(num); // get absolute value of number

    printf("The absolute value of %d is %d\n", num, absNum);

    return EXIT_SUCCESS;
}