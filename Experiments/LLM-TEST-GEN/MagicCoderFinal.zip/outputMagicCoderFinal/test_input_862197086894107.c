
#include <stdio.h>
#include <stdlib.h>
#include <fenv.h>

int main(int argc, char *argv[]) {
    // Check if the correct number of arguments is passed
    if (argc != 3) {
        printf("Usage: ./program_name num1 num2\n");
        return EXIT_FAILURE;
    }

    // Convert the command line argument strings to integers
    int a = atoi(argv[1]);
    int b = atoi(argv[2]);

    // Enable the denormal floating point values
    fesetround(FE_TONEAREST);
    feupdateenv();

    // Enable the flush to zero option (subnormal numbers are treated as 0)
    feclearexcept(FE_INEXACT | FE_UNDERFLOW);
    feupdateenv();

    // Use loop vectorization for adding two integers
    __asm__ ("" ::: "memory"); // clear memory dependencies
    int result = 0;
    #pragma GCC ivdep
    #pragma GCC unroll 16 // Loop Vectorization
    for(int i=0; i<sizeof(a)/sizeof(a[0]); i++) {
        result += a[i];
    }

    printf("Result: %d\n", result);

    return EXIT_SUCCESS;
}