
#include <stdio.h>

// Define a function with __inline__ attribute 
__inline__ int add(int x, int y) {
    return (x + y);
}

int main(int argc, char *argv[]){
   // Print the sum of first two command line arguments
   printf("The sum is: %d\n", add(atoi(argv[1]), atoi(argv[2])));
   
   return 0;
}