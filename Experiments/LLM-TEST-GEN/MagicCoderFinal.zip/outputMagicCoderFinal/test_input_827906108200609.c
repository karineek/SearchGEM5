
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s number\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    int num = atoi(argv[1]);

    printf("The square of the input number is : %d\n", Square(num));
    return 0;
}