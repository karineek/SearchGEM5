
#include <stdio.h>
#include <stdlib.h>

// A simple function for illustration purposes
double sum(int n) { 
    double total = 0;
    for (int i = 1; i <= n; ++i){
        total += i * i;
    }
    return total;
}

int main(int argc, char** argv) {
    if (argc != 2 || sscanf(argv[1], "%d", &n) != 1){
        printf("Usage: %s <integer>\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    printf("Sum of squares from 1 to %d is %.2lf\n", n, sum(n));
    
    return EXIT_SUCCESS;
}