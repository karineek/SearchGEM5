
#include <stdio.h>
#include <stdlib.h>

// Function template for finding primes
template<int n> 
void is_prime(int num) {
    if (num % n == 0 && n != num) {
        printf("%d is not a prime number.\n", num);
    } else if (n == num){
        printf("Prime: %d\n", num);
    }
}

// Function specialization for 2, the smallest prime number.
void is_prime<2>(int num) {
   if(num > 1 && num % 2 != 0){
       printf("%d is a prime number.\n", num);
   } else{
      printf("%d is not a prime number.\n", num);
   }
}

// Main function
int main(int argc, char *argv[]) {
    // Check if an argument was passed
    if (argc < 2) {
        fprintf(stderr, "Please provide the upper limit of numbers to check for prime.\n");
        exit(1);
    }
    
    int max = atoi(argv[1]);

    // Check if argument is positive integer.
    if (max < 2) {
        fprintf(stderr, "Argument must be a positive integer greater than or equal to 2.\n");
        exit(1);
    }
    
    for(int num = 2; num <= max; ++num){
      // Function Specialization triggering.
      is_prime<num%2==0 ? 2 : num>(num);
    }
  
    return 0;
}