
#include <stdio.h>

int main(int argc, char* argv[]) {
    double number = atof(argv[1]);
    printf("Number is: %D\n", number);
    return 0;
}