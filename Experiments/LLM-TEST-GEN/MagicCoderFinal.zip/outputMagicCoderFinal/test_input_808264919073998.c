
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {
    // Check if user provided an argument
    if (argc != 2) {
        printf("Usage: %s number\n", argv[0]);
        return 1;
    }
    
    double number = atof(argv[1]);
    
    // Check if the input is a non-negative real number
    if (number < 0 || isnan(number)) {
        printf("Invalid input\n");
        return 1;
    }
    
    // Calculate gamma
    double result = tgamma(number);
    
    printf("Gamma of %f is %.20lf\n", number, result);
    
    return 0;
}