
#include <stdio.h>  // For printf()
#include <stdlib.h> // For exit()

// Function to swap two integers
void swap(int *xp, int *yp) {
    int temp = *xp;
    *xp = *yp;
    *yp = temp;
}

// Function to implement bubble sort
void bubbleSortOptimized(int arr[], int n) {
    if (n <= 1) {
        return;
    }
  
    // Create a temporary array and copy the address of elements
    int tempArray[n];
    for (int i = 0; i < n; ++i) {
        tempArray[i] = arr[i];
    }

    // Traverse through all array elements
    for (int i = 0; i < n-1; ++i) {
        bool swapped = false;
  
        // Last i elements are already in place
        for (int j = 0; j < n - i - 1; ++j) {
            if (tempArray[j] > tempArray[j+1]) {
                swap(&tempArray[j], &tempArray[j+1]);
                
                // Marking swapped as true so that we don't
                // traverse this again.
                swapped = true;
            }
        }
  
        // If no two elements were swapped by inner loop, then break
        if (swapped == false) {
          break;
        }
    }

    // Copy the sorted array back to arr[], so that 
    // pass by value arguments remain valid
    for(int i = 0; i < n; ++i){
       arr[i] = tempArray[i];
    }
}

// Function to perform Static analysis in Clang
void analyzeStatic(const char *filename) {
    // Call clang's static analyzer on the file
    int systemCallStatus = system((std::string("clang-analyze ") + filename).c_str());
    
    // Check for errors and return an exit status if so
    if(systemCallStatus != 0) {
        printf("Error running static analysis: %d\n", systemCallStatus);
        exit(EXIT_FAILURE);
    }
}

// Main function
int main(int argc, char *argv[]) {
    // Check if the program was run with an argument
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    // Read file into a vector for sorting
    FILE *file = fopen(argv[1], "r");
    if (file == NULL) {
        printf("Error opening the file: %s\n", argv[1]);
        return EXIT_FAILURE;
    }
    
    int numbers[10]; // Assuming each line in file has 10 integers
    for (int i = 0; i < 10; ++i) {
        fscanf(file, "%d", &numbers[i]);
    }
    fclose(file);
    
    // Sort the numbers using bubble sort and print them out
    analyzeStatic(argv[1]);
    for (int i = 0; i < 10; ++i) {
        printf("%d ", numbers[i]);
    }

    return EXIT_SUCCESS;
}