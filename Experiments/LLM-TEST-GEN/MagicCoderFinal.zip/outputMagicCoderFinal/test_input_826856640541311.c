
#include <stdio.h>  // Standard Input / Output
#include <stdlib.h>  // Required for exit() and atoi()
#include <string.h>   // Used to manipulate C-style strings (like strtok())

int main(int argc, char *argv[]){
    int i;
    if(argc <= 1){
        printf("No command line arguments were given.");
        exit(0);
    }
    
    for (i = 1; i < argc; i++){   // Start from second element because first is program name.
        
        // Memory Optimization: Use atoi() instead of strtol() to convert string to integer to save memory.
        int val = atoi(argv[i]); 
        
        printf("Value %d\n", val);   // Print the value on command line.
    }
    
    return 0; 
}