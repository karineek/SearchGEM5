
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    int num = atoi(argv[1]);
    double doubleNum = (double)num;

    if (doubleNum > 5) {
        printf("Number is greater than 5\n");
    } else if (doubleNum < 5) {
        printf("Number is less than 5\n");
    } else {
        printf("Number is exactly 5\n");
    }
    
    return EXIT_SUCCESS;
}