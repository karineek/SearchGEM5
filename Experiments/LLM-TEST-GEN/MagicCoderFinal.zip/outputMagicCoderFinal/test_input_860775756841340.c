
#include <stdio.h>

int main(int argc, char *argv[]) {
    // Your code here...
    
    printf("argc = %d\n", argc); 
    if (argc > 1) {
        printf("Your argument: %s\n", argv[1]);
    } else {
        printf("No arguments provided.\n");
    }
    return 0;
}