
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {
    // Check if user provided an input
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }
    
    double x = atof(argv[1]);
    double sum = x;
    int n;
    
    for (n = 2; n <= 10; n += 2) {
        sum = sum * x / n + x;
    }
    
    printf("sinh(%f) = %f\n", x, sum);
    
    return 0;
}