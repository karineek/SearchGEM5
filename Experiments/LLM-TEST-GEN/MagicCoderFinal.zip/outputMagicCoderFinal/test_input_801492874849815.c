
#include <stdio.h>  // Standard input/output
#include <string.h> // String handling
#include <stdlib.h> // For exit() function
#include <signal.h> // For sig_atomic_t

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: ./%s <input>\n", argv[0]);
        return -1;
    }
    
    int input = atoi(argv[1]); // Convert string to integer
    
    for(int i=0; i<10; ++i) {
        printf("%d ", (sig_atomic_t)(input*i)); 
    }
    return 0;
}