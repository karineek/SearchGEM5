
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) { // check that we receive exactly one argument
        fprintf(stderr, "Usage: %s string\n", argv[0]);
        return 1;
    }
    
    char* input = argv[1];
    printf("Input: %s\n", input);

    // For this example we will reverse the given string.
    int len = strlen(input);
    for (int i = 0; i < len/2; ++i) {
        char temp = input[i];
        input[i] = input[len-1-i];
        input[len-1-i] = temp;
    }
    
    printf("Output: %s\n", input);
    return 0;
}