
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {
    // Check if there's an argument provided
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return -1;
    }
    
    float number = atof(argv[1]);   // Convert string to float
    float result = expm1f(number);  // Calculate natural logarithmic of 1 minus the number
    
    printf("Result: %f\n", result);
    
    return 0;
}