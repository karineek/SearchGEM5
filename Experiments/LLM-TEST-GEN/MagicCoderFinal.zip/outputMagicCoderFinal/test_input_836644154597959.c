
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    // Check if the correct number of arguments is passed.
    if (argc != 2) {
        printf("Usage: %s seconds\n", argv[0]);
        return -1;
    }

    int sleep_time = atoi(argv[1]);

    // Sleep for the number of seconds passed as argument.
    sleep(sleep_time);

    printf("Program started at %ld\n", (long) time(NULL));
    printf("Program has been running for %d second(s)\n", sleep_time);

    return 0;
}