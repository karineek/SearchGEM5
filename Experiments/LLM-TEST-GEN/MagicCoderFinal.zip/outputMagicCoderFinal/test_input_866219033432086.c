
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function Inlining Optimization
inline void print_arg(int argc, char *argv[]) {
    for (int i = 0; i < argc; ++i) {
        printf("Arg %d: %s\n", i+1, argv[i]);
    }
}

// Dealing with Object File Manipulation and Line buffered stream
void manipulate_obj(char *filename) {
    FILE *file = fopen(filename, "r");
    
    // Check if file exists 
    if (file == NULL) {
        printf("Could not open file\n");
        exit(-1);
    }

    char line[256];
    while (fgets(line, sizeof(line), file)) {
        printf("%s", line);
    }

    fclose(file);
}

int main(int argc, char *argv[]) {
    print_arg(argc, argv);
    
    // Manipulate object file (for example "manipulate.txt")
    manipulate_obj("manipulate.txt");

    return 0;
}