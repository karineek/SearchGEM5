
#include <stdio.h>

int main(int argc, char* argv[]) {
    if (argc != 3) {
        printf("Usage: ./program_name num1 num2\n");
        return -1;
    }
    
    // Here we are performing the common subexpression elimination.
    int sum = 0, x = atoi(argv[1]), y = atoi(argv[2]);

    // Common Subexpression Elimination: We can move this operation into a function or macro
    printf("Sum is: %d\n", (x + y));

    return 0;
}