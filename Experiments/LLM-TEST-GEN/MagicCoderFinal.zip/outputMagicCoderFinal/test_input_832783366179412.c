
#include <stdio.h>
#include <stdatomic.h>

int main(int argc, char* argv[]) {
    if (argc != 3) {
        printf("Usage: %s <number> <compare_to>\n", argv[0]);
        return -1;
    }

    atomic_uint_least64_t number = atoull(argv[1]); // convert argument to atomic uint
    atomic_uint_least64_t compareTo = atoull(argv[2]); // convert argument to atomic uint
    
    atomic_uint_least64_t oldNumber; 
    bool success = atomic_compare_exchange_weak_explicit(&number, &oldNumber, compareTo, memory_order_seq_cst, memory_order_relaxed);

    if (success) {
        printf("Atomic Compare-Exchange succeeded. Old value: %llu\n", oldNumber);
    } else {
        printf("Atomic Compare-Exchange failed.\n");
    }
    
    return 0;
}