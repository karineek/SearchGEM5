
#include <stdio.h>

// Function Inlining
__attribute__((always_inline)) int compare(int x, int y) {
    if (x > y) return 1;
    else if (x == y) return 0;
    else return -1;
}

// Abstract Syntax Tree Manipulation
#define isless(x, y) (((x) < (y)) ? (x) : ((x) != (y)))

int main(int argc, char** argv) {
    int x, y;
    
    if(argc != 3) {
        printf("Usage: ./program_name x y\n");
        return -1;
    }
  
    // Check if input values are integers
    sscanf(argv[1], "%d", &x);
    sscanf(argv[2], "%d", &y);
    
    int result = compare(x, y);

    printf("Is %d less than %d? %s\n", x, y, (isless(result, 0)) ? "Yes" : "No");
    return 0;
}