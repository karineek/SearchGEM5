
#include <stdio.h>
#include <math.h> // for log2l()

// Assume the implementation of log2l function in your environment.
long double log2l(long double x);

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return -1;
    }
    
    long double num = atol(argv[1]); // Convert the input string to a long int.
    
    // Checking if the number is 0 (since log2(0) is undefined), and if so, skip calculation of logarithm.
    if (num != 0) {
        printf("Log base 2: %Lf\n", log2l(num));
    } else {
        printf("Cannot calculate Log base 2 for 0.\n");
    }
    
    return 0;
}