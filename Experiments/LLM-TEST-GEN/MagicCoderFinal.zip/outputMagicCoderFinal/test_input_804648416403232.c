
#include <stdio.h>
#include <string.h>

void concat_strings(char *dest, const char *src) {
    strcat(dest, src);
}

int main(int argc, char **argv) {
    // Check if the right number of arguments is provided
    if (argc != 3) {
        printf("Usage: %s <string1> <string2>\n", argv[0]);
        return -1;
    }

    const int BUFFER_SIZE = 1024; // Maximum size of the output string
    char dest[BUFFER_SIZE]; // Output string
    memset(dest, '\0', BUFFER_SIZE); // Clear the destination string

    concat_strings(dest, argv[1]); // Concatenate string 1 to the destination
    concat_strings(dest, argv[2]); // Concatenate string 2 to the destination

    printf("Concatenated strings: %s\n", dest);

    return 0;
}