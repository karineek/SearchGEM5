
#include <stdio.h>
#include <stdlib.h>

int factorial(int n);

int main(int argc, char *argv[]) {
    if (argc != 2) { // Check if the user has inputted exactly one argument
        printf("Usage: ./%s number\n", argv[0]);
        exit(1);
    }
    
    int n = atoi(argv[1]); // Convert the user's input from a string to an integer
    if (n < 0) {
        printf("Sorry, factorial does not exist for negative numbers.\n");
        exit(2);
    }

    printf("%d!\n", n);
    
    // Call the interprocedural optimization function
    int fact = factorial(n);
    printf("%d! = %d\n", n, fact);
    
    return 0;
}

int factorial(int n) {
    if (n == 0 || n == 1)
        return 1;
    else
        return n * factorial(n - 1); // Rescanning and replacement is happening here.
}