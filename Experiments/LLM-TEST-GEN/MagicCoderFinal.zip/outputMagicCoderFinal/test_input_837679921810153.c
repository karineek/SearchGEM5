
#include <stdio.h>
int main(int argc, char **argv) {
    // Check if a file was provided via command line arguments.
    if (argc != 2 || strlen(argv[1]) <= 4 || strcmp(argv[1] + strlen(argv[1]) - 3, ".c")) {
        printf("Usage: %s <file>\n", argv[0]);
        return 1;
    }
    
    // Open the file for reading.
    FILE *f = fopen(argv[1], "r");
    
    // Check if we were able to open the file.
    if (!f) {
        printf("Unable to open %s\n", argv[1]);
        return 1;
    }
    
    // Declare a buffer for reading in the file.
    char buf[4096];
    int flag = 1;

    while (fgets(buf, sizeof buf, f)) {
       if(flag == 1){
            printf("The first line of input is: %s", buf);
            flag=2; //we only print the first line once
        }
    }
    
    // Close the file.
    fclose(f);
    
    return 0;
}