
#include "llvm/IR/Module.h"
#include "llvm/IRReader/IRReader.h"
#include "llvm/Support/SourceMgr.h"
#include "llvm/Transforms/Scalar.h"
#include "llvm/PassManager.h"
#include "llvm/ExecutionEngine/ExecutionEngine.h"
#include "llvm/ADT/StringRef.h"
#include <iostream>

using namespace llvm;

int main(int argc, char **argv) {
    if (argc != 2) {
        std::cout << "Usage: sccp_demo <input file>" << std::endl;
        return 1;
    }

    // Parse the input LLVM IR.
    SourceMgr srcmgr;
    std::unique_ptr<Module> M = parseIRFile(srcmgr, argv[1], std::make_shared<LLVMLoopAnalysisManager>());

    if (!M) {
        std::cout << "Error parsing module." << std::endl;
        return 1;
    }
    
    // Create a pass manager.
    PassManager PM;

    // Add SCCP optimization.
    FunctionPass* sccp = createSCCPPass();
    if (sccp) {
      PM.add(sccp);
    } else {
      std::cout << "Unable to create SCCP pass." << std::endl;
      return 1;
    }

    // Run the optimization passes on the module.
    if (PM.run(*M)) {
        std::cout << "Error running pass manager." << std::endl;
        return 1;
    }

    // Write out the optimized LLVM IR.
    writeIRToFile(*M, argv[1]);
    
    return 0;
}