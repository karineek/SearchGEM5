
#include <stdio.h>

// Declare a function to be optimized away
int common_factor(int x, int y) {
    if (x == 0 || y == 0) return 0; // GCC recognizes this as dead code and optimizes it out
    for (int i = 1; i <= x && i <= y; ++i) {
        if ((x % i == 0) && (y % i == 0)) {
            return i;
        }
    }
    // If the function doesn't terminate, it will also be optimized out.
    return -1;
}

int main(int argc, char *argv[]) {
    int num = atoi(argv[1]);
    printf("The factor of 60 and %d is: %d\n", num, common_factor(60, num));
    return 0;
}