
#include <stdio.h>
#include <stdlib.h>

// Function for addition operation
double add(int x, int y) {
    return (double)(x + y);
}

// Function for subtraction operation
double subtract(int x, int y) {
    return (double)(x - y);
}

// Driver code
int main(int argc, char **argv) {
    
    // Check if exactly 2 arguments are provided
    if (argc != 3) {
        printf("Please provide two numbers.\n");
        return 1;
    }

    // Perform the operations
    int x = atoi(argv[1]);
    int y = atoi(argv[2]);
    
    double result_add = add(x,y);
    double result_subtract = subtract(x,y);

    printf("Result of addition: %.0lf\n", result_add);
    printf("Result of subtraction: %.0lf\n", result_subtract);
    
    return 0;
}