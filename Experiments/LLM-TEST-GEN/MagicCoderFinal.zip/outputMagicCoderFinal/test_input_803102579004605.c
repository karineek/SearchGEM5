
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv){
    if(argc != 2 || sscanf(argv[1], "%f", &argv[1]) != 1) {
        printf("Usage: %s <float>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    float num = atof(argv[1]);
    double squaredNum;
    
    // Optimize by unrolling loop (compiler will do this automatically for large loops)
    for(int i=0;i<2;i++) {
        squaredNum = num * num; 
    }

    printf("Square of %.1f is: %.1f\n", num, squaredNum);
    
    return EXIT_SUCCESS;
}