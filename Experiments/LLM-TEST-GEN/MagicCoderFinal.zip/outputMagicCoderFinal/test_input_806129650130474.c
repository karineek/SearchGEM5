
#include <stdio.h>

int main(int argc, char** argv) {
    // Check if exactly two arguments were passed in.
    if (argc != 3) {
        printf("Usage: %s num1 num2\n", argv[0]);
        return 1;
    }
    
    // Declare variables with smallest possible data types to conserve memory.
    const char* str1 = argv[1];
    const char* str2 = argv[2];
    unsigned int num1, num2;

    // Check that the passed in arguments can be converted to integers.
    if (sscanf(str1, "%u", &num1) != 1 || sscanf(str2, "%u", &num2) != 1) {
        printf("Error: Arguments must be integers\n");
        return 1;
    }
    
    // Calculate and print the sum of the two numbers.
    unsigned int result = num1 + num2;
    printf("Sum: %u\n", result);

    return 0;
}