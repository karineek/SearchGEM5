
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./programname \"string_to_convert\"\n");
        return -1;
    }
    
    double result = wcstod(argv[1], NULL);

    if(result == 0.0){
        printf("Conversion failed!\n");
    }else{
        printf("The converted double: %.2lf\n", result);
    }

    return 0;
}