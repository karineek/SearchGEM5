
#include <stdio.h>

int add(int x, int y) {
    return x + y;
}

int main(int argc, char* argv[]) {
    if(argc != 3){
        printf("Usage: ./program x y\n");
        return -1;
    }
    
    int x = atoi(argv[1]);
    int y = atoi(argv[2]);
    
    int sum = add(x,y);

    printf("%d + %d = %d\n", x, y, sum);
    return 0;
}