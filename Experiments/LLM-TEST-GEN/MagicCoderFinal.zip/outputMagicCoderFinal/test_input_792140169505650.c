
#include <stdio.h>  // for printf and vfwscanf_s
#include <stdlib.h> // for exit

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <filename>\n", argv[0]);
        exit(1);
    }
    
    FILE *file = fopen(argv[1], "r");
    if (!file) {
        printf("Unable to open file\n");
        exit(1);
    }

    char buffer[128];
    while (fscanf_s(file, "%s", buffer, 128) != EOF) {
        // perform constant folding during compile-time with vfwscanf_s function
        printf("Constant Folding: %s\n", argv[0]);
    }
    
    fclose(file);
    return 0;
}