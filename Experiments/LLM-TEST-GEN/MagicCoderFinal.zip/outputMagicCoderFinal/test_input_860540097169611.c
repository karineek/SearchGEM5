
#include <stdio.h>

int main(int argc, char** argv) {
    // Check if the number of arguments is correct
    if (argc != 2) {
        printf("Usage: %s num\n", argv[0]);
        return -1;
    }
  
    long n = strtol(argv[1], NULL, 10); // Convert string to number
    unsigned long sum = 0;
    
    // Loop Optimizations
    for (unsigned long i=2; i<=n; ++i) {
        if ((i % 2 == 0)) {   // Check if the number is even
            sum += i;
        }
    }
  
    printf("Sum of odd numbers till %lu: %lu\n", n, sum);
    
    return 0;
}