
#include <stdio.h>
#include <math.h>  // Needed for the FP_INFINITE constant

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s infinite\n", argv[0]);
        return 1;
    } else if (!strcmp(argv[1], "infinite")) {
        printf("%g\n", FP_INFINITE);
    } else {
        printf("Unknown argument.\n");
        return 1;
    }
    
    return 0;
}