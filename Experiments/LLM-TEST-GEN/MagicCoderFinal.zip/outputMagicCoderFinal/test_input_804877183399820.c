
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 4) {
        printf("Usage: %s a b c\n", argv[0]);
        return EXIT_FAILURE;
    }

    float a = strtof(argv[1], NULL);
    float b = strtof(argv[2], NULL);
    float c = strtof(argv[3], NULL);

    printf("Result: %.2f\n", fmaf(a, b, c));

    return EXIT_SUCCESS;
}