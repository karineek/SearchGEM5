
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input_string>\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    int len = strlen(argv[1]);
    for (int i=len-1; i>=0; --i) {
        printf("%c", argv[1][i]);
    }
    printf("\n");
    
    return EXIT_SUCCESS;
}