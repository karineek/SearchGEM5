
#include <stdio.h>
#include <locale.h>
#include <wchar.h>

int main(int argc, char *argv[]) {
   if (argc != 2){
       fprintf(stderr, "Usage: %s string\n", argv[0]);
       return EXIT_FAILURE;
   }
   
   // Setting locale to use UTF-8 strings.
   setlocale(LC_ALL, "");

   const wchar_t* wcstr = (wchar_t*)argv[1];

   int result = wcserror(wcstr);

   switch (result) {
       case WCSERR_OK: printf("The string is valid.\n"); break;
       default: printf("Error: %d\n", result);
   }
   
   return 0;
}