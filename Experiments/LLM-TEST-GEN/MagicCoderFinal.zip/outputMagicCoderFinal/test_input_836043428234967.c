
#include <stdio.h>  // for printf
#include <locale.h> // for setlocale, wcstombs
#include <wchar.h>  // for mbstowcs, wcstombs

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <wide-character string>\n", argv[0]);
        return -1;
    }

    // set locale to utf-8 for wcstombs to work correctly
    if (setlocale(LC_ALL, "en_US.UTF-8") == NULL) {
        printf("Failed to set locale\n");
        return -1;
    }

    const wchar_t *wcs = argv[1]; // wide character string
    char mbs[MB_CUR_MAX] = "";   // multibyte character string
    
    size_t len = wcstombs(mbs, wcs, MB_CUR_MAX); // convert wchar to mbchar

    if (len == (size_t)-1) {  // if conversion failed
        printf("Conversion failed\n");
        return -1;
    }
    
    printf("%s\n", mbs); // print converted string

    return 0;
}