
#include <stdio.h>
#include <math.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s number\n", argv[0]);
        return 1;
    }
    double number = atof(argv[1]);
    
    // Constant folding optimization: calculate square before main() execution
    const double square = pow(number, 2.0);
    
    printf("Square of %f is: %.2lf\n", number, square);
    
    return 0;
}