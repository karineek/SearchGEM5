
#include <stdio.h>

int main(int argc, char** argv){
    // Check if correct number of arguments are passed
    if(argc != 2) {
        printf("Usage: %s <input_number>\n", argv[0]);
        return -1;
    }
    
    // Read input from command line
    int num = atoi(argv[1]);
    
    // Display the number back
    printf("Input number is: %d\n",num);
    
    return 0;
}