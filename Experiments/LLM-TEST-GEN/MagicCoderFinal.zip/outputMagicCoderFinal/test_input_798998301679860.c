
#include <stdio.h>
#include <stdlib.h>
#include <__clang_analyzer__/dead_code.h>  // Clang-specific header

int main(int argc, char** argv) {
    int x = atoi(argv[1]);

    #if DEAD_CODE
    printf("Dead code is eliminated!\n");
    #endif
    
    return 0;
}