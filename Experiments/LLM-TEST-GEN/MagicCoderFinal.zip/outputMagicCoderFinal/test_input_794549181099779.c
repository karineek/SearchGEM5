
#include <stdio.h>
#include <math.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s number\n", argv[0]);
        return -1;
    }

    double num = atof(argv[1]); // Convert argument to double
    double absolute_num = fabs(num); // Get the absolute value of the number

    printf("The absolute value of %lf is: %lf\n", num, absolute_num);

    return 0;
}