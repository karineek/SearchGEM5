
#include <stdio.h>

int main(int argc, char **argv) {
    if (argc != 3) {
        printf("Usage: %s <input1> <input2>\n", argv[0]);
        return 1;
    }

    int result = atoi(argv[1]) + atoi(argv[2]); // Comma punctuator

    printf("Result of the operation is: %d\n", result);

    return 0;
}