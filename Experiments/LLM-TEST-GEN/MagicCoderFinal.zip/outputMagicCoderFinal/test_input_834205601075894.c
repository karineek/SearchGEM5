
#include <stdio.h>
#include <ctype.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./prog \"char\"\n");
        return 1;
    }

    // Check the character with iscntrl() function
    if (iscntrl((unsigned char)*argv[1])) {
        printf("%s is a control character.\n", argv[1]);
    } else {
        printf("%s is not a control character.\n", argv[1]);
    }
    
    return 0;
}