
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program input_file output_file\n");
        exit(-1);
    }
    
    FILE* inputFile = fopen(argv[1], "r");
    if (!inputFile) {
        printf("Unable to open file %s\n", argv[1]);
        exit(-1);
    }

    float number;
    fscanf(inputFile, "%f", &number);
    
    fclose(inputFile);
    
    double result = log10(number);
    
    FILE* outputFile = fopen(argv[2], "w");
    if (!outputFile) {
        printf("Unable to open file %s\n", argv[2]);
        exit(-1);
    }
    
    fprintf(outputFile, "%f\n", result);
    fclose(outputFile);
    
    return 0;
}