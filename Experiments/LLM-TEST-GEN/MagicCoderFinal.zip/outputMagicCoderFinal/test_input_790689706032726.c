
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <immintrin.h> //for Intel SSE instructions

void *thrd_nomem(void *arg) {
    char *str = (char*) arg;
    __m128i vals = _mm_loadu_si128((__m128i *) str); 
    
    // Vectorized operations can be done here

    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <thread_num> <string>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    int thread_num = atoi(argv[1]);
    
    char str[16];  // assuming that the string is no longer than 128 bytes
    memset(str, 0, sizeof(str));
    strncpy(str, argv[2], 15); // strncpy to avoid buffer overflow

    pthread_t threads[thread_num];
    for (int i = 0; i < thread_num; ++i) {
        if (pthread_create(&threads[i], NULL, thrd_nomem, str)) {
            fprintf(stderr, "Error creating thread\n");
            exit(EXIT_FAILURE);
        }
    }
    
    for (int i = 0; i < thread_num; ++i) {
        if (pthread_join(threads[i], NULL)) {
            fprintf(stderr, "Error joining thread\n");
            exit(EXIT_FAILURE);
        }
    }
    
    return 0;
}