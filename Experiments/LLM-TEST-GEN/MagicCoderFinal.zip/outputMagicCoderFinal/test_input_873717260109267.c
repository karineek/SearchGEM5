
#include <stdio.h>
#include <stdlib.h>
#include <limits.h> // To use FLT_MANT_DIG

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s decimal_places\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    int decimal_places = atoi(argv[1]); // Convert argument to integer
    float value = powf(10.0, decimal_places);

    printf("The number of digits that can be represented by the floating point type: %d\n", FLT_MANT_DIG);
    
    // Common subexpression elimination (same expression repeated)
    float result = value * 2;
    result += value;
    result -= value;
    
    printf("The number you entered is equal to: %.%df\n", decimal_places, decimal_places);
    return 0;
}