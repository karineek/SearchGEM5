
#include <stdio.h>

// Function to check if number is positive
inline int isPositive(int num) {
    return (num > 0);
}

int main(int argc, char* argv[]) {
    // Checking if the correct argument was provided
    if(argc != 2){
        printf("Usage: %s <number>\n", argv[0]);
        return -1;
    }

    int num = atoi(argv[1]);

    // Inline function call
    if (isPositive(num)) {
        printf("%d is a positive number.\n", num);
    } else {
        printf("%d is not a positive number.\n", num);
    }
    
    return 0;
}