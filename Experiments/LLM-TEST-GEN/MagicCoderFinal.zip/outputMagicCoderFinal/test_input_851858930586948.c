
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {
    for (int i = 1; i < argc; ++i) {
        double number = atof(argv[i]); // Convert string to double
        printf("log gamma(%f) = %f\n", number, lgamma(number));
    }

    return 0;
}