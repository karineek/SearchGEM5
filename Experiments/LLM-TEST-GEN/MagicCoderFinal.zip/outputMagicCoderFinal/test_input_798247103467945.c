
#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <lconv.h>

int main(int argc, char *argv[]) {
    // Check if the correct number of arguments is provided
    if (argc != 2) {
        printf("Usage: ./%s LOCALE\n", argv[0]);
        return EXIT_FAILURE;
    }

    // Set new locale, and check for errors
    if(setlocale(LC_ALL, argv[1]) == NULL) {
        printf("Error setting locale to '%s'\n", argv[1]);
        return EXIT_FAILURE;
    }

    // Print out the current locale settings
    lconv *lc = localeconv();
    if (lc != NULL) {
        printf("Decimal point: %s\n", lc->decimal_point);
        printf("Thousands separator: %s\n", lc->thousands_sep);
        printf("Currency symbol: %s\n", lc->currency_symbol);
    } else {
        printf("Error calling localeconv()\n");
    }
    
    return EXIT_SUCCESS;
}