
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc <= 1) {
        printf("Please provide at least one integer argument.\n");
        return EXIT_FAILURE;
    }
    
    int sum = 0;
    for (int i=1; i<argc; ++i) {
       if(sscanf(argv[i],"%d",&sum+i)!=1){
           printf("Please provide integer arguments only.\n");
           return EXIT_FAILURE;
       }else{
            sum = sum + atoi(argv[i]);
        }
    } 
    
    printf("The sum is: %d\n", sum);

    return EXIT_SUCCESS;
}