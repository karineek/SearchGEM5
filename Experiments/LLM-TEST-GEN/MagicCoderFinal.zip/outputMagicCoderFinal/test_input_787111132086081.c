
#include <stdio.h>  // for printf()
#include <wctype.h>  // for towupper()
#include <string.h>   // for strlen(), memset()

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input>\n", argv[0]);
        return -1;
    }

    wchar_t wc;
    size_t length = strlen(argv[1]);
    
    for (size_t i = 0; i < length; i++) {
        // Convert the char to a wide character.
        wc = argv[1][i];
        
        // If the char is a lowercase letter, convert it to an uppercase letter.
        if(iswlower(wc)) 
            wc = towupper(wc);
            
        printf("%lc", wc);
    }
    
    return 0;
}