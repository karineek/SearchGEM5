
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <numaif.h>

// Function to test vectorization and object file manipulation
void testVectorAndObjectFile() {
    // Define an array for the computation
    int arr[1024];

    #pragma omp simd
    for(int i = 0; i < 1024; i++) {
        arr[i] = i * 2;
    }
}

// Function to test numactl, which demonstrates NUMA utilization
void testNuma() {
    // Create a large object file that will be moved around by numactl.
    FILE* fp = fopen("large_file", "wb");
    if (!fp) {
        printf("Could not open large file\n");
        exit(1);
    }

    int n = 2048 * 1024; // size of the file in bytes.
    char* buf = malloc(n * sizeof(char));
    if (!buf) {
        printf("Could not allocate memory\n");
        exit(1);
    }

    fwrite(buf, n, 1, fp);
    fclose(fp);
}

int main(int argc, char** argv) {
    if (argc != 2 || strcmp(argv[1], "--vector") == 0) {
        printf("Running vectorization test\n");
        testVectorAndObjectFile();
    } else if (strcmp(argv[1], "--numa") == 0) {
        printf("Running NUMA utilization test\n");
        testNuma();
    } else {
        printf("Invalid argument. Please provide '--vector' or '--numa'.\n");
        return -1;
    }
    
    return 0;
}