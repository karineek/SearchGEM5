
#include <stdio.h>
#include <stdbool.h>

// Function to check whether a character is an alphabet or not 
bool is_alpha(char c){
    return ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) ? true : false;
}

// Function specialization: Inlining function, for better performance.
__attribute__((always_inline)) bool is_alpha_inline(char c){
    return ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) ? true : false;
}

int main(int argc, char *argv[]){
    if(argc != 2) {
        printf("Please provide a character as an argument.\n");
        return 1;
    }
    
    // Check whether the input is an alphabet or not.
    bool result = is_alpha((char)argv[1][0]);
    printf("Is %c an alphabet? %s\n", argv[1][0], (result ? "Yes" : "No"));

    // Function specialization: Check the same input using inlined function.
    result = is_alpha_inline((char)argv[1][0]);
    printf("Is %c an alphabet? %s\n", argv[1][0], (result ? "Yes" : "No"));

    return 0;
}