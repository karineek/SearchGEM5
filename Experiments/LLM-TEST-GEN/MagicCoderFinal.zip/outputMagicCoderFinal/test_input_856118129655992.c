
#include <stdio.h>
#include <stdlib.h>

// function that is called when the function is profiled
void func(int a) {
    int i;
    for (i = 0; i <= a; i++)
        printf("%d ", i);
}

// main function which takes command line arguments
int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s num\n", argv[0]);
        return EXIT_FAILURE;
    }

    int num = atoi(argv[1]); // convert the command line argument to integer
    
    func(num); // call the function with the given number

    return EXIT_SUCCESS;
}