
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <input>\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    int number = atoi(argv[1]);
    printf("%d\n", number * 2); // Example of a loop-invariant operation

    return EXIT_SUCCESS;
}