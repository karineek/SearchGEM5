
#include <stdio.h>
#include <stdlib.h>
#include <math.h> // For abs function

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Incorrect number of arguments\n");
        return 1;
    }

    int num = atoi(argv[2]);
    int absNum = abs(num); // Calculate absolute value of num
    
    printf("Allocating registers for operations\n");
    printf("Operation: x = %d + y (Register Allocation)\n", absNum);

    return 0;
}