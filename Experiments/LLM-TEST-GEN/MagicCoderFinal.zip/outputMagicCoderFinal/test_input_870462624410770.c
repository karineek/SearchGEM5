
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input>\n", argv[0]);
        exit(1);
    }
    
    // Accessing the command line argument
    char* input = argv[1];

    printf("Input: %s\n", input);
    return 0;
}