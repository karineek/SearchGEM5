
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <filename>\n", argv[0]);
        return 1;
    }
    
    FILE* file = fopen(argv[1], "r");
    if (!file) {
        perror("fopen");
        return 2;
    }

    char buffer[4096];
    while (fgets(buffer, sizeof buffer, file)) {
        printf("%s", buffer);
    }
    
    // Clear error state of stream. If there was an error in the stream, it can be checked via feof() function
    clearerr(file); 
  
    fclose(file);
    
    return 0;
}