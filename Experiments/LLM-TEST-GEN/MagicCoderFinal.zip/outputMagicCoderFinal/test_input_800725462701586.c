
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        exit(-1);
    }
    
    FILE* file = fopen(argv[1], "r");
    if (!file) {
        perror("Error opening the file.");
        exit(-1);
    }
    
    char buffer[256];
    while (fgets(buffer, sizeof(buffer), file)) {
        // Vectorization: Perform operations on the whole array at once.
        int sum = 0;
        for (int i=0; i<strlen(buffer); ++i) {
            sum += buffer[i];
        }
        
        printf("Sum of ASCII values in %s is: %d\n", buffer, sum);
    }
    
    fclose(file);
    
    return 0;
}