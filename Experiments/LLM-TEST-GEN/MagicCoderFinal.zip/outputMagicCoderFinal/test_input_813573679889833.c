
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]) {
    double x;  // Variable to be tested
    
    if (argc != 2) {
        fprintf(stderr, "Usage: ./progname number\n");
        exit(EXIT_FAILURE);
    }
    
    x = atof(argv[1]);
    
    // Test the ilogb function
    int logbase = ilogb(x);  // Store result in a variable
    
    printf("The integer part of %f is %d\n", x, logbase);
    return EXIT_SUCCESS;
}