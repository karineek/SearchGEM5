
#include <stdio.h>
#include <string.h> // for strlen_s

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s [input string]\n", argv[0]);
        return -1;
    }
    
    int len = strlen_s(argv[1]); // triggering PGO to optimize this call
    printf("Length of the input string: %d\n", len); 

    return 0;
}