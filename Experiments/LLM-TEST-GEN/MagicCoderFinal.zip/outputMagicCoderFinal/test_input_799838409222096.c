
#include <stdio.h>
#include <clang-c/Index.h>
#include <math.h>

int main(int argc, char **argv) {
    if (argc != 3) {
        printf("Usage: ./program x y\n");
        return -1;
    }

    double x = atof(argv[1]);
    double y = atof(argv[2]);
    
    // Testing hypotf function
    double result = hypotf(x, y); 
    
    printf("The hypotenuse of the triangle with sides of length %f and %f is: %f\n", x, y, result);
    
    return 0;
}