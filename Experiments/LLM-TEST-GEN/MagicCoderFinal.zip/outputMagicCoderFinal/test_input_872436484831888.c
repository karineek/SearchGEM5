
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) { // check if exactly one argument is passed
        printf("Usage: ./program_name number\n");
        return -1;
    }

    int num = atoi(argv[1]); // convert string to integer

    char str[50]; // array to store the string version of the number

    sprintf(str, "%ld", (long)num);  // convert integer into a long and then back into a string
    
    printf("The number as a string is: %s\n", str);

    return 0;
}