
#include <stdio.h>

int function_to_inline(int num) {
    return num * 2;
}

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s number\n", argv[0]);
        return -1;
    }
    
    int result = function_to_inline(atoi(argv[1]));
    
    printf("%d * 2 = %d\n", atoi(argv[1]), result);
    
    // This is where LLVM Bitcode handling could be implemented.
    
    return 0;
}