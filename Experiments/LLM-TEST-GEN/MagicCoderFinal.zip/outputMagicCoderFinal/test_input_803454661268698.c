
#include <stdio.h>  // Needed for printf function.
#include <wctype.h> // Needed for iswspace function.

int main(int argc, char *argv[]) {
    if (argc != 2) { // Check that there's exactly one argument passed in.
        printf("Usage: %s <character>\n", argv[0]);
        return 1;
    }

    int result = iswspace((wint_t)argv[1][0]); // Call the function to check if it's a space character.
    
    // Use an if statement to print whether or not the argument is a whitespace character.
    printf("%s %s a whitespace character.\n", (result ? "Yes" : "No"), argv[1]); 

    return 0; // Return 0 upon successful execution of the program.
}