
#include <stdio.h>
#include <string.h>

// Function to convert a string to lowercase
void towlower(char *str) {
    while (*str != '\0') {
        if ('A' <= *str && *str <= 'Z') {
            *str = *str + 32; // ASCII value of 'a' - 'A' = 32
        }
        str++;
    }
}

// Inline function to check if a string is empty or not.
inline int isEmpty(char* str) {
   return (*str == '\0');
}

int main(int argc, char** argv) {
    if (argc != 2) {
        printf("Invalid number of arguments.\n");
        return -1;
    }

    towlower(argv[1]);

    // Checking whether string is empty or not.
    if (isEmpty(argv[1])) {
       printf("%s is an empty string\n", argv[1]);
    } else {
        printf("%s is a non-empty string\n", argv[1]);
    }
    
    return 0;
}