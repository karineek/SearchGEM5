
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main(int argc, char **argv) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <numerator> <denominator>\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    imaxdiv_t result = imaxdiv(atoi(argv[1]), atoi(argv[2]));

    printf("Quotient: %d\n", result.quot);
    printf("Remainder: %d\n", result.rem);

    return 0;
}