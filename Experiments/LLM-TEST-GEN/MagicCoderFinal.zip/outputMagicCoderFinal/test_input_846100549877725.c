
#include <stdio.h>

int main(int argc, char *argv[]) {
    if(argc != 2){
        printf("Usage: %s <n>\n", argv[0]);
        return -1;
    }
    int n = atoi(argv[1]); // Get input from command line argument

    for (int i = 1; i <= n; ++i) { // Loop Optimization: unrolling the loop for better performance
        __asm__("nop" ::: "memory"); // Targets specific architecture: inline assembler code
        printf("%D\n", i*i);
    }
    return 0;
}