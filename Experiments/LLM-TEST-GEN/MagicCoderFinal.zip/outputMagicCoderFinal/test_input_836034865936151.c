
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {
    // Check if correct number of arguments are provided
    if (argc != 3) {
        printf("Error! Please provide two numbers as input.\n");
        return -1;
    }

    double x = atof(argv[1]);   // convert string to double
    double y = atof(argv[2]);

    double result1 = sinh(x);  // use function from math.h for optimization
    printf("sinh(%f) = %f\n", x, result1);

    double result2 = (exp(x) - 1) / exp(x);   // calculate y without optimization
    printf("%f = %f\n", y, result2);

    return 0;
}