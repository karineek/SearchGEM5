
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <string>\n", argv[0]);
        exit(1);
    }
    
    const char *input = argv[1];
    int len = strlen(input);
  
    printf("Received input string: '%s'\n", input);
    printf("Length of the string is %d\n", len);

    return 0;
}