
#include <stdio.h>
#include <string.h>
#include <ctype.h>  // for toupper function

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input string>\n", argv[0]);
        return 1;
    }
    
    char input_string[100]; // assuming the maximum length of the string is 100.
    strncpy(input_string, argv[1], sizeof(input_string)-1);
    input_string[sizeof(input_string) - 1] = '\0'; // Ensure null-termination
    
    char output_string[100];
    for (int i=0; input_string[i]; i++) {
        output_string[i] = toupper((unsigned char)input_string[i]);
    }
    output_string[sizeof(output_string) - 1] = '\0'; // Ensure null-termination
    
    printf("Output: %s\n", output_string);
    
    return 0;
}