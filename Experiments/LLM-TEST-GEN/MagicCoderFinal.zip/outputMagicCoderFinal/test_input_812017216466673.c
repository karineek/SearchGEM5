
#include <stdio.h>
#include <stdint.h> // To use uint_least8_t 
#include <assert.h>

// A function to print the assembly code of a given function
void printAssembly(char* func) {
    // Calling gcc -S -o outfile filename.c
    FILE *fp;
    fp = popen("gcc -S -o - tmp.c", "r");  // Replace 'tmp.c' with your source file
    assert(fp);
    
    char buffer[1024];
    while (fgets(buffer, sizeof(buffer), fp) != NULL) {
        printf("%s", buffer);
    }
    pclose(fp);
}

// A function to generate bitcode from assembly 
void genBitCode() {
    // Calling llvm-as and redirecting output to tmp.bc
    FILE *fp;
    fp = popen("llvm-as < - > tmp.bc", "r");
    assert(fp);
    
    pclose(fp);
}

int main(int argc, char** argv) {
    // Check if we have at least one argument
    if (argc<2){
        printf("Please provide a function name\n");
        return 1;
    }
    FILE *f = fopen("tmp.c", "w");
    assert(f);
    
    // Write the C code for the provided function and input to tmp.c
    // Replace 'func' with your desired function
    fprintf(f, "void func() {\n"); 
    int i;
    for (i = 1; i < argc; ++i) {
        fprintf(f,"   uint_least8_t %s;\n", argv[i]);
    }
    fprintf(f, "}\n");
    
    // Close the file
    fclose(f);
    
    printAssembly("func");
    genBitCode();  // This line is just a placeholder; replace it with your code to generate bitcode.
    
    return 0;
}