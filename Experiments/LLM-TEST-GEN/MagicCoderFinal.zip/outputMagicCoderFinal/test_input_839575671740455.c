
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include "llvm-c/Core.h"
#include <stdatomic.h>

int main(int argc, char *argv[]) {
    // Check if there is at least one argument
    if (argc < 2) {
        printf("Please provide at least one integer value.\n");
        return -1;
    }
    
    atomic_int_fast8_t sum = 0;

    pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;

    // Reading and adding the input arguments
    for (int i=1; i<argc; i++) {
        int val = atoi(argv[i]);
        atomic_fetch_add(&sum, val); 

        if(val % 2 != 0)
            printf("Odd number detected: %d\n", val);
    }
    
    // Lock the mutex while printing to avoid race conditions
    pthread_mutex_lock(&mtx);
    printf("Sum of all numbers is: %ld\n", atomic_load(&sum));
    pthread_mutex_unlock(&mtx);

    return 0;
}