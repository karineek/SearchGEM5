
#include <stdio.h>
#include <stdint.h> // For int_fast8_t

// Function to multiply two vectors (arrays) element-wise
void multiplyVectors(int_fast8_t *a, int_fast8_t *b, int size){
    for (int i = 0; i < size; i++) {
        a[i] = a[i]*b[i]; // Multiply elements of a by corresponding element in b
    }
}

// Function to add two vectors (arrays) element-wise
void addVectors(int_fast8_t *a, int_fast8_t *b, int size){
    for (int i = 0; i < size; i++) {
        a[i] += b[i]; // Add corresponding elements of a and b
    }
}

// Main function
int main(int argc, char* argv[]){
   if (argc != 3) {
      printf("Usage: ./program <vector size> <input>\n");
      return -1;
   }

   int size = atoi(argv[1]); // Read vector size from command line
   int_fast8_t *a = malloc(size * sizeof(int_fast8_t));  // Vector a
   int_fast8_t *b = malloc(size * sizeof(int_fast8_t));  // Vector b
   
   // Convert string input to array of integers
   for (int i=0;i<size;i++) {
      sscanf(&argv[2][i*sizeof(int_fast8_t)],"%hhd",&b[i]);
   }

   multiplyVectors(a, b, size); // Vector multiplication
   
   addVectors(a, b, size); // Vector addition

   for (int i = 0; i < size; i++) {
      printf("%d ", a[i]);
   }

   free(a);
   free(b);
   return 0;
}