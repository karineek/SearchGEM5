
#include <stdio.h>
#include <locale.h>
#include <wchar.h>
#include <errno.h> 

// Function to convert UTF-8 string to wide character string
int convertUTF8toWideChar(const char *str, wchar_t* buffer) {
    mbstate_t state;
    memset(&state, 0, sizeof(mbstate_t));
    size_t converted = mbrtowc(buffer, str, MB_CUR_MAX, &state);

    // If an illegal sequence is encountered, return the error indicator.
    if (converted == (size_t)-1) {
        perror("mbrtowc");
        return -1; 
    }
    // If no characters were converted or we reached the end of the string, just return 0.
    else if ((converted == 0) || (str[converted] == '\0')) {
        *buffer = L'\0';
        return 0;
    }
    // Otherwise, there's more to convert...
    else {
        buffer[0] = L'\0';  // Null terminate the string.
        return wcrtomb(buffer, str + converted, MB_CUR_MAX, &state);
    }
}

int main(int argc, char* argv[]) {
    setlocale(LC_ALL, "");
    
    if (argc != 2) {
        printf("Usage: %s <UTF-8 string>\n", argv[0]);
        return -1;
    }
    
    wchar_t buffer[MB_CUR_MAX];
    convertUTF8toWideChar(argv[1], buffer);
    wprintf(L"%ls\n", buffer);  // Output wide char string.

    return 0;
}