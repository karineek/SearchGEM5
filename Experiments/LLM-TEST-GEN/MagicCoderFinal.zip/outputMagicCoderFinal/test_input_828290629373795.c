
#include <stdio.h>
#include <stdlib.h>
#include <stdatomic.h> // for atomic operations

// An atomic pointer
atomic_int a;

void increment() { 
    int old = atomic_load(&a);
    while (atomic_compare_exchange_weak(&a, &old, old + 1) != old) {}
}

int main(int argc, char* argv[]) {
    a = 0; // initialize to zero

    int n; // number of increments

    if (argc < 2) { 
        printf("Usage: %s <n>\n", argv[0]);
        return 1; 
    }
    
    sscanf(argv[1], "%d", &n);

    // Increment 'a' n times using atomic operations
    for (int i = 0; i < n; i++) {
        increment();
    }

    printf("Final value of a: %d\n", atomic_load(&a));
    return 0; 
}