
#include <stdio.h>
#include <stdlib.h>

int add(int x, int y) {
    return x + y;  // This is an example of a function that can be vectorized
}

int subtract(int x, int y) {
    return x - y;  // This is another example of a function that can be vectorized
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program <number> <number>\n");
        exit(1);
    }
    
    int x = atoi(argv[1]);
    int y = atoi(argv[2]);

    // Demonstration of using rvalue in C. Here we use the result of function call as a return value for another function call.
    printf("Result of addition: %d\n", add(x, y)); 
    printf("Result of subtraction: %d\n", subtract(x, y));
    
    // To enable vectorization, we would need to use compiler flags which are beyond the scope of this question.
    return 0;
}