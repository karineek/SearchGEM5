
#include <stdio.h>
#include <stdlib.h>

void process_data(FILE* file) {
    char buffer[1024];  // Assuming this function will not read more than 1K data at a time.
    while (fgets(buffer, sizeof(buffer), file)) {
        printf("%s", buffer);
    }
}
int main(int argc, char *argv[]) {
    FILE* file;
    if(argc != 2) { // Checking if user has passed a filename as argument.
        fprintf(stderr, "Please pass exactly one argument: the name of the file to read.\n");
        exit(EXIT_FAILURE);
    }
    file = fopen(argv[1], "r"); // Opening the file in reading mode.
    
    if (file == NULL) {
        fprintf(stderr, "Error opening the file: %s\n", strerror(errno));
        exit(EXIT_FAILURE);
    }

    setbuf(file, NULL); // Using setbuf function to disable buffering.
    process_data(file);
    
    fclose(file);  // Closing the file after reading.
    return EXIT_SUCCESS;
}