
#include <stdio.h>
#include <stdlib.h>
#include <complex.h>

double asinh(double x) {
    return log(x + sqrt(x * x + 1));
}

int main(int argc, char **argv) {
    
    if (argc != 3){
        printf("Usage: ./program input_file output_file\n");
        return EXIT_FAILURE;
    }

    FILE *in = fopen(argv[1], "rb"), *out = fopen(argv[2], "wb");
    
    if (in == NULL || out == NULL) {
        printf("Error opening file\n");
        return EXIT_FAILURE;
    }

    double x, y;

    while (fread(&x, sizeof(double), 1, in) && fread(&y, sizeof(double), 1, in)) {
        complex z = cexp(asinh(x + I*y));
        fwrite(&creal(z), sizeof(double), 1, out);
        fwrite(&cimag(z), sizeof(double), 1, out);
    }
    
    fclose(in);
    fclose(out);
    
    return EXIT_SUCCESS;
}