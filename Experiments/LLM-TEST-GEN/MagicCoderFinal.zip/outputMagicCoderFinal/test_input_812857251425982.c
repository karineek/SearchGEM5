
#include <stdio.h>
#include <stdlib.h>
#include <floating.h>

int main(int argc, char *argv[]) {
    int cnt = 0; // counter for exception raised
    feclearexcept(FE_ALL_EXCEPT); 
    feholdexcept(0); // disable all floating-point exceptions
    while (1) {
        double d = atof(argv[1]);
        printf("The entered number is: %lf\n",d);
         if (feraiseexcept(FE_ALL_EXCEPT)) 
             ++cnt; // increment counter on exception raise
    }
    return 0;
}