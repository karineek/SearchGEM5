
#include <stdio.h>  // For printf()
#include <stdlib.h> // For exit(), atof() and lround()
#include <math.h>   // For lround()

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <double>\n", argv[0]);
        exit(1);
    }
    
    double input = atof(argv[1]);
    int roundedValue = lround(input);
    
    printf("%.f\n",roundedValue);
    
    return 0;
}