
#include <stdio.h>
#include <stdlib.h>
#pragma GCC diagnostic ignored "-Wconversion"

// Function to convert number to binary format string
void itobin(int num, char* bin_str) {
    for (int i = 31; i >= 0; --i) {
        bin_str[32 - 1 - i] = '0' + ((num >> i) & 1);
    }
}

// Function to write binary string to a file in binary format
void writebin(const char* filename, const char* str) {
    FILE *f = fopen(filename, "wb");
    if (f == NULL) {
        printf("Cannot open %s for writing.\n", filename);
        exit(EXIT_FAILURE);
    }
    size_t len = strlen(str);
    if (fwrite(str, 1, len, f) != len) {
        printf("Failed to write all data to %s\n", filename);
        exit(EXIT_FAILURE);
    }
    fclose(f);
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Please provide an integer argument.\n");
        return -1;
    }
    
    int num = atoi(argv[1]); // convert the input string to an integer

    char bin_str[33]; // a buffer for the binary string
    itobin(num, bin_str); // Convert the number to binary
    
    writebin("output.bin", bin_str); // Write out the binary string as a file

    return 0;
}