
#include <stdio.h>

extern int fib(int n); // Declaration of a function that calculates Fibonacci numbers

int main(int argc, char **argv) {
    if (argc != 2 || sscanf(argv[1], "%d", &n) == 0) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }

    int result = fib(n);
    printf("The Fibonacci number of %d is %d\n", n, result);
    return 0;
}