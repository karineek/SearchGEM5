
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./program_name <number>\n");
        return EXIT_FAILURE;
    }
    
    int n = atoi(argv[1]); // convert string to integer
    double sum, product;
    #pragma clang loop vectorize(enable)
    for (int i=0; i < 4; ++i){
        if (n >= i) {
            sum += n * i;
        }
    }
    
    printf("Sum = %lf\n", sum);

    return EXIT_SUCCESS;
}