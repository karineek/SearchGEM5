
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int main(int argc, char** argv) {
    if (argc != 3) {
        printf("Usage: %s num1 num2\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    int num1 = atoi(argv[1]), num2 = atoi(argv[2]);
    if (num2 == 0) {
        printf("Error: Division by zero.\n");
        return EXIT_FAILURE;
    }

    double result = fmod(num1, num2);
    printf("The remainder of %d divided by %d is %.2lf\n", num1, num2, result);
    
    return 0;
}