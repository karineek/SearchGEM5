
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 3) { // Checks if exactly two arguments are passed
        printf("Please provide exactly two numbers as command-line arguments.\n");
        return EXIT_FAILURE;
    }

    int a = atoi(argv[1]); // Converts the first argument to integer and stores it in 'a'
    int b = atoi(argv[2]); // Converts the second argument to integer and stores it in 'b'

    int sum;
    if (a == 0) {
        printf("Warning: Division by zero is not allowed.\n");
        return EXIT_FAILURE;
    } else {
        sum = b / a; // If 'a' is not equal to 0, this line is executed.
    }

    printf("The sum of %d and %d is %d\n", a, b, sum);

    return EXIT_SUCCESS;
}