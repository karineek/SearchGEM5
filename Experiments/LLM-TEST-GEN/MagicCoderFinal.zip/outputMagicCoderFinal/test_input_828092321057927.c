
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program_name num1 num2\n");
        return EXIT_FAILURE;
    }

    int x = atoi(argv[1]);
    int y = atoi(argv[2]);
    
    // Multiplication function with PGO optimization
    int result = cpowl(x,y); 

    printf("Result: %d\n", result);

    return EXIT_SUCCESS;
}