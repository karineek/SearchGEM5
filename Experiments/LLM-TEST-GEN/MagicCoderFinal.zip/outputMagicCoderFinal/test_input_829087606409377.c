
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h> // Required for using char32_t

int main(int argc, char **argv) {
    if (argc != 2){
        printf("Usage: %s [input string]\n", argv[0]);
        return -1;
    }

    // Declare a variable of type char32_t
    char32_t inputChar = u'\u265E'; // A heart with exclamation mark.

    printf("Input String: %ls\n", argv[1]); // Convert the string to wide character and print it.

    return 0;
}