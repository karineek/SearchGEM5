
#include <stdatomic.h> // Include for atomic operations 

// Declaration and definition of your function here...
void increment(atomic_int_fast64_t *counter) {
    atomic_fetch_add(counter, 1);
}

// The main function can be as follows:
int main(int argc, char *argv[]){
   if (argc != 2){
       printf("Usage: %s <number>\n", argv[0]);
       return -1;
    }
    
    atomic_int_fast64_t counter = 0; // Initial value for your counter

    int num = atoi(argv[1]);
    while (num--){
        increment(&counter); // Calling function to increment the counter
    }

    printf("Final count: %lu\n", atomic_load(&counter)); 
    return 0;
}