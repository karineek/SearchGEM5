
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <locale.h>

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input>\n", argv[0]);
        return 1;
    }
    
    // Simple loop optimization example with string length comparison.
    for(int i = 0; strlen(argv[1]) > i; i++) {
        if (argv[1][i] == ' ') {
            printf("Detected space at position: %d\n", i);
        }
    }
    
    // Multibyte and wide string example.
    char* mbs = argv[1];
    wchar_t* wcs = L"Hello, 世界!";
    printf("Multibyte string length: %zu\n", strlen(mbs));
    printf("Wide string length: %zu\n", wcslen(wcs));
    
    // Using setlocale to make sure that multibyte characters are displayed correctly.
    if (setlocale(LC_ALL, "") == NULL) {
        fprintf(stderr, "Could not set locale, aborting.\n");
        exit(1);
    }
    
    printf("Multibyte string: %s\n", mbs);
    printf("Wide string: %ls\n", wcs);
    
    return 0;
}