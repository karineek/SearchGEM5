
#include <stdio.h>

int main(int argc, char *argv[]) {
    // Check if the program received at least one argument
    if (argc != 2) {
        printf("Please provide an input string.\n");
        return -1;
    }
    
    int i = 0;
    // Loop Optimization: Here we loop over a predefined array.
    while (argv[1][i]) {
        printf("%c", argv[1][i++]);
        
        // Form-feed character (`\f`)
        if (argv[1][i] == '\f') {
            printf("Form-Feed Character detected!\n");
        } 
    }
    
    return 0;
}