
#include <stdio.h>
#include <string.h>
#include "tss.h"  //Assume that the tss header is included

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s [string]\n", argv[0]);
        return 1;
    }
    
    //tss_set can be used to set a string as an argument
    tss_set(argv[1], strlen(argv[1]));

    printf("Your argument is: %s\n", argv[1]);
    
    return 0;
}