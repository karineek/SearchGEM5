
#include <stdio.h>
#include <stdlib.h>

// Function Specialization
int add_int(int x, int y) { return x + y; }
float add_float(float x, float y) { return x + y; }

// _Generic 
int main(int argc, char **argv)
{
    if (argc != 3) {
        printf("Usage: ./program <type> <x> <y>\n");
        return -1;
    }

    char type[10];
    strcpy(type, argv[1]);

    switch(type[0])
    {
        case 'i': 
            printf("%d\n", add_int(atoi(argv[2]), atoi(argv[3]))); 
            break;
        
        case 'f': 
            printf("%.1f\n", add_float(atof(argv[2]), atof(argv[3]))); 
            break;

        default: 
            printf("Invalid type, must be either 'i' for int or 'f' for float.\n");
    }

    return 0;
}