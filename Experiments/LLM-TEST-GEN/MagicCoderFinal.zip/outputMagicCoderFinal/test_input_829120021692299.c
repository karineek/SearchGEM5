
#include <stdio.h>
#include <stdlib.h>

// Declare a function that will be inlined
static inline void print_integer(int n) {
    printf("Value is %" PRId "\n", n);  // Use PRId to get the correct integer format specifier
}

int main(int argc, char *argv[]) {
    int num;

    // Check if a command line argument was provided
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <integer>\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    // Try to convert the input string into an integer
    num = atoi(argv[1]);
    if (num == 0 && errno == EINVAL) {
        fprintf(stderr, "Invalid input\n");
        return EXIT_FAILURE;
    }
    
    // Call the inlined function with the number as argument
    print_integer(num);

    return 0;
}