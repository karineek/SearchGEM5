
#include <stdio.h> 
#include <stdlib.h> 

int main(int argc, char *argv[]) { 
    if (argc != 2) {
        printf("Usage: ./%s <binary>\n", argv[0]);
        return 1; 
    }
    
    long binary = strtol(argv[1], NULL, 2); 
    printf("%ld\n", binary); 
  
    return 0; 
}