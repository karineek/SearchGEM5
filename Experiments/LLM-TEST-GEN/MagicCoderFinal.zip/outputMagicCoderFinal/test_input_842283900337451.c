
#include <stdio.h> 
#include <stdlib.h>

typedef struct {
    int real;
    int imag;
} ComplexNumber;

// Function to check whether a complex number is even or odd
int checkEvenOrOdd(ComplexNumber num) {
    if (num.imag == 0) {
        return (num.real % 2) ? 1 : 0; // Odd number
    } else {
        int realPart = num.real + num.imag*1j; // Imaginary part
        return (int)(realPart.real); // Even number if the real part is even
    }
}

// Main Function
int main(int argc, char *argv[]) {
    if(argc < 2) {
        printf("Usage: %s <complexNumber>\n", argv[0]);
        return 1;
    }
    
    ComplexNumber num = { .real = atoi(argv[1]), .imag = 0}; // For real part only

    int result = checkEvenOrOdd(num);
    printf("The number %d is ", num.real);
    (result == 0)? printf("odd\n"): printf("even\n");
    
    return 0;
}