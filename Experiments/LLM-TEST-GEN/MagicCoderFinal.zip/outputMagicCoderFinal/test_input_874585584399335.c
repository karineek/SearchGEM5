
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <numerator> <denominator>\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    int numerator = atoi(argv[1]);
    int denominator = atoi(argv[2]);

    if (denominator == 0) {
        printf("Error: Division by zero is undefined.\n");
        exit(EXIT_FAILURE);
    }

    // dividing numerator and denominator to get quotient and remainder
    struct tms ts;
    
    int result = div(numerator, denominator);
    printf("The quotient is: %d\n", result.quot);
    printf("The remainder is: %d\n", result.rem);

    return 0;
}