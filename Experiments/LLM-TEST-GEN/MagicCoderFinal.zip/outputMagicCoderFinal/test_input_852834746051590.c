
#include <stdio.h>
#include <math.h>

int main(int argc, char* argv[]) {
    double x;
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return -1;
    }

    sscanf(argv[1], "%lf", &x);
    
    // Calculate tangent with automatic vectorization and Sema
    double tan_value = sin(2*x) / (cos(2*x) + cos(2*x)); 

    printf("The tangent value of %f is: %.9lf\n", x, tan_value);

    return 0;
}