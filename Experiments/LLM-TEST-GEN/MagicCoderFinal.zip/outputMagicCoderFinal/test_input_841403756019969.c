
#include <stdio.h>
#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/BasicBlock.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/IntrinsicInst.h"
#include "llvm/IRReader/IRReader.h"
#include "llvm/Support/SourceMgr.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/Bitcode/ReaderWriter.h"

using namespace llvm;

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input.bc>\n", argv[0]);
        return 1;
    }
    
    LLVMContext &C = getGlobalContext();
    SMDiagnostic &Diag = getModuleIntrinsicErrors();
    Module *M = parseIRFile(argv[1], Diag, C);

    if (M) {
        // Print the module
        M->dump();
        
        // Now delete the module so it doesn't leak.
        delete M;
    } else {
        printf("Unable to load '%s'\n", argv[1]);
        return 1;
    }
    
    return 0;
}