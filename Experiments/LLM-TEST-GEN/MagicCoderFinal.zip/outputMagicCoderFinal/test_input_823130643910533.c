
#include <stdio.h>
#include <clang-c/Index.h>

// Function to calculate the scalar projection of two vectors
double cproj(double x, double y) {
    if (y != 0.0) {
        return x * y / fabs(y);
    } else {
        return HUGE_VAL;
    }
}

int main(int argc, char **argv){
    // Check that there are exactly two arguments
    if (argc != 3) {
        printf("Usage: %s <x> <y>\n", argv[0]);
        return -1;
    }

    double x = atof(argv[1]);
    double y = atof(argv[2]);

    // Calculate scalar projection
    double proj = cproj(x, y);

    printf("The scalar projection of %f and %f is: %f\n", x, y, proj);

    return 0;
}