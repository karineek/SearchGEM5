
#include <stdio.h>
#include <stdlib.h> // for exit()
#include <math.h>   // for round, pow

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        exit(1);
    }

    double num = atof(argv[1]);

    // Interprocedural Optimizations: IPO
    printf("Interprocedural Optimizations:\n");
    printf("Input number is %.2lf\n", num);

    // Serialization: This part of the compiler takes care of converting data types into a byte stream for transmission or storage.
    FILE *file;
    file = fopen ("result.bin","wb");
    if (file == NULL) {
      printf("Error opening file!");
      exit (1);
    }
    fwrite(&num, sizeof(double), 1, file); // serialize data to a binary file
    fclose(file);

    // Rounding Mode and Floating Point Operations: Certain functions in the math library can be used for rounding modes.
    int mode = FE_TONEAREST; // Example of rounding mode
    double result = pow(num, 2); // Example of a floating-point operation

    printf("Rounding Mode and Floating Point Operations:\n");
    printf("The input number raised to power of 2 is %.2lf\n",result);

    return 0;
}