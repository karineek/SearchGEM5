
#include <stdio.h> 
int main(int argc, char *argv[]) {
    if (argc != 2) { // check if there is exactly one command line argument
        printf("Usage: ./program_name num\n");
        return -1;
    }
    
    int num = atoi(argv[1]); // convert the command line argument to an integer
    long long result = 1;
    for (int i=2; i<=num; ++i) {
        result *= i;
    }
    printf("The factorial of %d is %lld\n", num, result);
    
    return 0;
}