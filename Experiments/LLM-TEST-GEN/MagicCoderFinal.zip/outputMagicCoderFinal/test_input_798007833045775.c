
#include <stdio.h>

// Function to calculate and print multiplication table for two numbers
void generateMultiplicationTable(int num1, int num2) {
    for (int i = 1; i <= 10; ++i) {
        printf("%d * %d = %d\n", num1, i, num1*i);
    }
}

// Function to handle command line arguments and trigger the inlining optimization
void main(int argc, char** argv) {
    if (argc != 3) { // Check for correct number of arguments
        printf("Usage: %s <number1> <number2>\n", argv[0]);
        return;
    }
    
    int num1 = atoi(argv[1]), num2 = atoi(argv[2]);
    if (num1 <= 0 || num2 <= 0) { // Check that both numbers are positive
        printf("Both numbers must be positive.\n");
        return;
    }
    
    generateMultiplicationTable(num1, num2);
}