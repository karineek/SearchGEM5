
#include <stdio.h>
#include <stdlib.h>
#include <stdatomic.h>
#include <string.h>

void atomic_signal_fence(int order) {
    atomic_thread_fence(order);
}

__attribute__((always_inline)) void inlineFunc() {
    atomic_signal_fence(memory_order_acquire);
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        exit(1);
    }
    
    int num = atoi(argv[1]);
    
    inlineFunc(); // Function inlining test

    atomic_signal_fence(memory_order_release);

    printf("The number is: %d\n", num);

    return 0;
}