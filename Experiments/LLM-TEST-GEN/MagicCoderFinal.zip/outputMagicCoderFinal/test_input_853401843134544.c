
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if(argc != 2){
        printf("Usage: %s N\n", argv[0]);
        return -1;
    }
    
    long sum = 0;
    int n = atol(argv[1]);
    for (int i=1; i<=n; ++i) {
       // loop invariant: i will not change within this loop iteration.
       sum += i;
    }
    printf("Sum of numbers from 1 to %d is: %ld\n", n, sum);
    
    return 0;
}