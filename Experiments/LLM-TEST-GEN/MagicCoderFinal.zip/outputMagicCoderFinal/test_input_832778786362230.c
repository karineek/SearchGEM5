
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

long convert_string_to_long(char *str) {
    char *endptr;
    long val = strtol(str, &endptr, 10);
    
    // Check for errors (like non-numeric strings or invalid characters after the number)
    if ((errno == ERANGE && (val == LONG_MAX || val == LONG_MIN)) ||
        (errno != 0 && errno != ERANGE)) {
        perror("strtol");
        exit(EXIT_FAILURE);
    }
    
    if (endptr == str) {
        fprintf(stderr, "No digits were found\n");
        exit(EXIT_FAILURE);
    }
    
    return val;
}

int main(int argc, char *argv[]){
   if(argc!=2){
       printf("Please provide exactly one argument!");
       return 1;
   }
   long num = convert_string_to_long(argv[1]);
   
   printf("%ld",num); // prints the converted number
   return 0;
}