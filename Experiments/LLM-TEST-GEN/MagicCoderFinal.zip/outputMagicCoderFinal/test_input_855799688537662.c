
#include <stdio.h>  // for printf
#include <stdlib.h> // for exit()
#include <time.h>   // for difftime(), time_t, time()

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s timestamp1 timestamp2\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    time_t t1 = atoi(argv[1]);
    time_t t2 = atoi(argv[2]);
    
    double difference = difftime(t2, t1);
    printf("The difference between %s and %s is %.0f seconds.\n", argv[1], argv[2], difference);
    
    return 0;
}