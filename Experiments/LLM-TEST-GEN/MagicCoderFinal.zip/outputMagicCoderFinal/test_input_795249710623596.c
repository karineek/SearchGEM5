
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int main(int argc, char **argv) {
    clock_t start, end;
    double cpu_time_used;
    int i, j, n = 1000000;
    
    if (argc != 2){
        printf("Usage: %s <n>\n", argv[0]);
        return -1;
    }
    sscanf(argv[1], "%d", &n);

    int *a = malloc(sizeof(int) * n); // allocate memory in a loop

    start = clock();
    for (i=0 ; i<n ; i++) {
        a[i] = 2*i+3;
    }
    
    end = clock();
    cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC; // measure the time taken by the loop

    printf("Execution Time: %f sec\n", cpu_time_used);

    free(a); // de-allocate memory 
    
    return 0;
}