
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int num1, num2;
    float result;

    if (argc != 3) {
        printf("Usage: ./programName num1 num2\n");
        return 1;
    }
    
    // Converting string inputs to integers and floats respectively.
    num1 = atoi(argv[1]);
    num2 = atoi(argv[2]);

    // Basic loop operation
    for (int i=0; i<num1; ++i) {
        printf("Loop iteration: %d\n", i);
    }
    
    result = 1.5 * num2 + 3.4;   // Type conversion from integer to float in this line.

    printf("The sum is: %.2f\n", result);

    return 0;
}