
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

// Function to calculate factorial
unsigned long long int factorial(int n) {
    unsigned long long int result = 1;
    
    for (int i=2; i<=n; i++)
        result *= i;
        
    return result;
}

int main(int argc, char **argv) {
    if(argc != 2){
        printf("Error: Please enter exactly one argument.\n");
        exit(1);
    }
    
    int num = atoi(argv[1]);
    unsigned long long int result;
    
    // check if the entered number is within the range of ULONG_MAX
    if (num > 38) {
      printf("Error: Input number is larger than ULONG_MAX.\n");
      exit(1);
    } else if (num < 0){
        printf("Error: Input number cannot be negative.\n");
        exit(1);
    } else {
        result = factorial(num);
        printf("The factorial of %d is %llu\n", num, result);
    }
    
    return 0;
}