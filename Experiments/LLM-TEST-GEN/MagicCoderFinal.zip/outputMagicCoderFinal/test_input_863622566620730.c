
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s seconds_ahead\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    time_t t = time(NULL);
    struct tm *timeinfo = localtime(&t);
    
    int ahead = atoi(argv[1]);
    timeinfo->tm_sec += ahead; // add given seconds to the current time
    
    mktime(timeinfo); 
    
    printf("Current time in %d seconds: %s\n", ahead, asctime(timeinfo));
    
    return EXIT_SUCCESS;
}