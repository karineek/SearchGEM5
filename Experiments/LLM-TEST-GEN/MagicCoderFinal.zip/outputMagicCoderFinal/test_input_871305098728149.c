
#include <stdio.h>

int main(int argc, char **argv) {
    int num;
    
    // Use fscanf_s to read input from command line argument (BASH example: "2")
    if (argc != 2 || sscanf_s(argv[1], "%d", &num) != 1) {
        printf("Usage: %s <integer>\n", argv[0]);
        return -1;
    }
    
    // Print the input value multiple times using Automatic Vectorization and Handles Abstract Syntax Tree (AST).
#pragma loop(hint_parallel(0))
    for (int i = 0; i < 10; i++) {
        printf("%d\n", num);
    }
    
    return 0;
}