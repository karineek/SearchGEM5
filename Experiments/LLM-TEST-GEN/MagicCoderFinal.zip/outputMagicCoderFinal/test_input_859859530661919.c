
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 3 || strcmp(argv[1], "--") == 0) {
        printf("Usage: ./prog -- [options]\n");
        return 1;
    }
    printf("Options: %s\n", argv[2]);
    // You can use options for Scalar Optimizations or the Frontend here. For example, you could enable optimization with -O2 by doing:
    // if(strcmp(argv[1], "-O2") == 0) {printf("Optimization level set to O2\n");}
    return 0;
}