
#include <stdio.h>
#include <stdlib.h>

double sqrt(double x) {
    // Initialize the guess with a sensible value 
    double guess = (x + 1.0) / 2.0; 
    for (int i = 0; i < 15; ++i) { 
        guess = (guess + x/guess) / 2.0; 
    }
    return guess;
}

int main(int argc, char** argv) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        exit(1);
    }
    
    double number = atof(argv[1]);
    if (isnormal(number)) { // Check that the input is a normal number, i.e., not infinity or NaN
        printf("The square root of %f is approximately %.8lf\n", number, sqrt(number)); 
    } else {
        printf("%s is not a normal number.\n", argv[1]);
    }
    
    return 0;
}