
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

// Taylor series approximation for cosine
double cacoshf(float x) {
    double sum = 1; //initialize the sum to 1
    int i;
    
    if (x <= -2 || x >= 2) {
        printf("Invalid input, function does not exist in this interval.\n");
        exit(EXIT_FAILURE);
    }

    for(i = 0; i < 15; ++i) { //iterate up to the 15th term
        sum += ((double)(-1 * pow(-x, (2 * i))))/((double)(factorial(2*i)));
    }
    
    return sum;
}

// Factorial function
long long factorial(int n) {
    if (n == 0 || n == 1) return 1; // base case of factorial
    else return n * factorial(n-1); // recursive call for larger numbers
}

// Function to trigger Interprocedural Optimizations
void optimizationTest() {
    float x = cacoshf(0.5f);
    printf("cacoshf(%f) = %f\n", 0.5f, x);
}

int main(int argc, char *argv[]) {
    if (argc != 2) { // check the number of arguments
        fprintf(stderr, "usage: %s <float>\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    float x = atof(argv[1]);
    optimizationTest();

    // Print Assembly and Bitcode (these lines are not valid in C)
    printf("Assembly: %s\n", __FUNCTION__);
    printf("Bitcode: %d\n", __LINE__);
    
    return EXIT_SUCCESS;
}