
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void read_word(char **dest, FILE *f) {
    size_t len = 0;
    char *line = NULL;
    if (getline(&line, &len, f) != -1) {
        // Inlining the getline function
        *dest = strdup(line);
    } else {
        printf("Error reading file\n");
        exit(EXIT_FAILURE);
    }
}

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <filename>\n", argv[0]);
        return EXIT_FAILURE;
    }

    FILE *f = fopen(argv[1], "r");
    if (!f) {
        perror("Could not open file");
        return EXIT_FAILURE;
    }

    char *word = NULL;
    read_word(&word, f);

    printf("Read word: %s\n", word);
    
    // Free the memory allocated by strdup()
    free(word);
    
    fclose(f);
    return EXIT_SUCCESS;
}