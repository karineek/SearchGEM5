
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// Function for the nearbyintl function 
double nearbyint_example(double x) {
    return nearbyint(x);
}

void loop_optimizations_exercise() {
    int i; // Declare a variable to use in loop
    printf("Loop Optimization Exercise:\n");
    
    for (i = 0; i < 10; ++i) {
        printf("%d ", i); // Print the numbers from 0 through 9, inclusive
    }
}

int main(int argc, char *argv[]) {
    if(argc != 2){
        fprintf(stderr,"Usage: %s <double>\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    // Implement clang frontend
    double x = strtod(argv[1], NULL);
    printf("Input Number: %.2lf\n", x);
    printf("Nearbyint Output: %.2lf\n", nearbyint_example(x));
    
    loop_optimizations_exercise(); // Trigger Loop Optimizations Exercise
    
    return 0;
}