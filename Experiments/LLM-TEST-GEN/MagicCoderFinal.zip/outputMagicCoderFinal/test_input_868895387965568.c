
#include <stdio.h>

int main(int argc, char *argv[]) {
    if (argc != 2) { // Ensure exactly one argument is provided
        printf("Usage: %s YEAR\n", argv[0]);
        return 1;
    }

    int year = atoi(argv[1]); // Convert the command line argument to an integer

    if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) { // Check if the year is a leap year
        printf("%d is a leap year.\n", year);
    } else {
        printf("%d is not a leap year.\n", year);
    }

    return 0;
}