
#include <stdio.h>
#include <stdlib.h> // Required for malloc()

// Function declaration
void f(void);

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./%s string\n", argv[0]);
        exit(1);
    }
    
    // Memory Optimizations
    char* str = malloc(strlen(argv[1])+1);
    if (!str) {
        perror("Memory allocation failed");
        return 1;
    }
    strcpy(str, argv[1]);
  
    printf("Input string: %s\n", str);
    
    // Call the function f()
    f();
    
    free(str); // Free the allocated memory
  
    return 0;
}

// Function definition
void f() {
    printf("This is an external function\n");
}