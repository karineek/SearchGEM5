
#include <stdio.h>
#include <math.h>
#include "llvm-c/Core.h"
#include "ProfileGuidedOpt.h"

// Manipulate the Core LLVM Intermediate Representation (IR) by hooking into ilogbf function
int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <input>\n", argv[0]);
        return 1;
    }

    const char *file = argv[1];
    LLVMOpaquePassManager passManager = NULL;
    LLVMOpaqueFunctionPassManager functionManager = NULL;

    // Create a pass manager
    LLVMInitializeNativeTarget();
    LLVMInitializeNativeAsmParser();
    LLVMInitializeNativeDisassembler();
    LLVMInitializeProfileGuidedOptPass(*getGlobalContext());

    LLVMOrcModAnalysisManager amgr = LLVMAsmAnalysisManagerBuilder().create();
    
    LLVMTargetData td = getTheTargetMachine().createTargetData();

    LLVMInitializeNativeTarget();
    LLVMInitializeNativeTargetAsmParser();
    LLVMInitializeNativeTargetDisassembler();

    LLVMOpaquePassManager passManager = LLVMFunctionPassManagerCreate();
    LLVMInitializeProfileGuidedOptPass(*getGlobalContext());
    LLVMAddAnalysisPass(&passManager, amgr);
    
    // Load the IR into the context
    LLVMModuleRef mod = LLVMGetModuleFromName(file);
    if (!mod) {
        printf("Unable to load module %s\n", file);
        return 1;
    }

    // Run the passes on the function
    LLVMOpaquePassManager passManager = LLVMFunctionPassManagerCreate();
    LLVMAddProfileGuidedOptPass(&passManager, NULL);
    
    if (LLVMPassManagerRun(passManager, mod)) {
        printf("Optimization failed\n");
        return 1;
    }

    // Write the modified IR back to file
    FILE *file = fopen(file, "wb");
    LLVMWriteBitcodeToFile(mod, file);
    fclose(file);
    
    printf("Optimization done!\n");
    return 0;
}