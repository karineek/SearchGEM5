
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s number\n", argv[0]);
        return 1;
    }
    
    double number = atof(argv[1]);
    if (number == 0) {
        printf("atanh(0) is undefined. Please provide a non-zero input.\n");
        return 1;
    }
    
    double result = atanh(number);
    printf("The inverse hyperbolic tangent of %lf is: %lf\n", number, result);
    
    return 0;
}