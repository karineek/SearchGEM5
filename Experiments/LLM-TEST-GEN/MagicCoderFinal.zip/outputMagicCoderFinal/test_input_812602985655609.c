
#include <stdio.h>

int main(int argc, char *argv[]) {
    // Check if enough arguments are provided
    if (argc != 3) {
        printf("Usage: ./pgo_example num1 num2\n");
        return -1;
    }
    
    int sum = atoi(argv[1]) + atoi(argv[2]);
    
    FILE *file;
    file = fopen("output.txt", "w");
    
    if (file == NULL) {
        printf("Error opening the file!\n");
        return -1;
    }
    
    fprintf(file, "%d\n", sum);
    fclose(file);

    return 0;
}