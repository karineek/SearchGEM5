
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>  // Includes for Sema and LC_CTYPE

int main(int argc, char *argv[]) {
    setlocale(LC_ALL, "");  // Sets locale to handle international characters
    if (argc != 2) {
        printf("Usage: ./programName number\n");
        return EXIT_FAILURE;
    }
    int input = atoi(argv[1]);
    
    if (input % 2 == 0)
        printf("%d is even.\n", input);
    else
        printf("%d is odd.\n", input);
        
    return EXIT_SUCCESS;
}