
#include <stdio.h>
#include <stdlib.h>

int factorial(int n){ 
    int fact = 1; 
  
    while (n > 0) { 
        fact *= n; 
        n--; 
    } 
      
    return fact; 
}
  
// Main function.
int main(int argc, char* argv[]){ 
    
    // Check if a command line argument is provided.
    if (argc != 2){
        printf("Please provide an integer as a command line argument.\n");
        return -1;
    }
      
    int n = atoi(argv[1]);
    printf("Factorial of %d = %d\n", n, factorial(n)); 
      
    return 0;
}