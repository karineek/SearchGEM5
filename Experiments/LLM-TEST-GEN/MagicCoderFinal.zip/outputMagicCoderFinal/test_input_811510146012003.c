
#include <stdio.h>
#include <stdlib.h>

#define EXP_TYPE(type, x) (x ## _ ## type)

#define LOOP_FUSION(type, var) \
    type temp = 0; \
    for(int i = 0; i < sizeof(var)/sizeof(var[0]); ++i){ \
        temp += EXP_TYPE(type, var)[i]; \
    }

int main(int argc, char **argv) {
     if (argc != 3) {
          fprintf(stderr, "Usage: %s num1 num2\n", argv[0]);
          exit(EXIT_FAILURE);
     }

     int num1 = atoi(argv[1]), num2 = atoi(argv[2]);

     LOOP_FUSION(int, {num1, num2}) ;  // Using macro for loop fusion
     
     printf("The sum is: %d\n", temp);

     return EXIT_SUCCESS;
}