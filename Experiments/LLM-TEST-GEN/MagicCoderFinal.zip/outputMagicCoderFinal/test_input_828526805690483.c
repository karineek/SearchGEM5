
#include <stdio.h>
#include <string.h>
#include <locale.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <amount>\n", argv[0]);
        return 1;
    }
    
    setlocale(LC_MONETARY, ""); // This line sets the locale for currency conversions.

    char *currency = strdup(money_string);
    
    double amount = atof(argv[1]);
    printf("Original amount: %s\n", argv[1]);
    printf("Amount in default locale: %.2f\n", amount);

    return 0;
}