
#include <stdio.h>
#include <stdlib.h>
#include "llvm/IR/LLVMContext.h"
#include "llvm/IRReader/MemoryBufferRef.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/Bitcode/ReaderWriter.h"
#include "llvm/IR/Module.h"

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./program <input file>\n");
        return 1;
    }

    // Load the input file into a LLVM memory buffer.
    llvm::SMDiagnostic Err;
    std::unique_ptr<llvm::Module> M = llvm::parseIRFile(argv[1], Err, llvm::LLVMLoader);

    if (!M) {
        Err.print("Could not parse input", argv[0]);
        return 1;
    }

    // Perform transformations on the module here (for example, remove all instructions).
    M->deleteAllInstructions();

    // Write out the transformed IR to stdout or a file.
    llvm::raw_ostream OS(llvm::errs());  // Defaults to stderr.
    if (!llvm::writeIR(*M, OS)) {
        return 1;
    }

    return 0;
}