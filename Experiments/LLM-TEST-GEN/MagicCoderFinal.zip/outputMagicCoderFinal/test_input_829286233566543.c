
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./program_name <input>\n");
        return EXIT_FAILURE;
    }

    const char* input = argv[1];
    int count[256] = {0};
    
    for (const char *p = input; *p != '\0'; p++) 
        count[(unsigned char)*p]++;

    printf("Character Counts:\n");
    for (int i = 0; i < 256; ++i) {
        if (count[i])
            printf("%c: %d\n", (char)i, count[i]);
    }
    
    return EXIT_SUCCESS;
}