
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <integer1> <integer2>\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);

    printf("Sum of %d and %d is: %d\n", num1, num2, num1 + num2);

    return EXIT_SUCCESS;
}