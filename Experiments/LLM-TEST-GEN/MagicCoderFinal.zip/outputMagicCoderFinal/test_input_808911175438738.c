
#include <stdio.h>  // for printf and scanf
#include <stdlib.h> // for exit() and atoi()

int cacosl(int a, int b);

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s num1 num2\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    int a = atoi(argv[1]), b = atoi(argv[2]);
    
    printf("Result: %d\n", cacosl(a, b));
    return 0;
}

int cacosl(int a, int b) {
    // This function just returns the sum of two numbers for now. It could be modified to do more complex calculations.
    return a + b;
}