
#include <stdio.h>  // For printf function
#include <stdlib.h> // For exit function
#include <string.h> // For memset function
#include <limits.h> // For INT_MIN and INT_MAX
#include <time.h>   // For time function
#include <unistd.h> // For sleep function

typedef struct {
    long count[256]; // 256 possible characters + NULL character
} char_count;

void add(char_count *c, char x) {
    c->count[(unsigned char)x]++;
}

int main(int argc, char **argv) {
    if (argc != 2 || !strcmp(argv[1], "--help")) {
        printf("Usage: ./program input.txt\n");
        exit(0);
    }

    FILE *f = fopen(argv[1], "r");
    char_count c;
    
    // Initialize the character count
    memset(&c, 0, sizeof(c));

    int ch;
    while ((ch = getc(f)) != EOF) {
        add(&c, (char)ch);
    }

    for (int i = 0; i < 256; ++i) {
        if (c.count[i] > 0) {
            printf("%c: %ld\n", i, c.count[i]);
        }
    }

    // Wait before exiting to ensure the profile is updated
    sleep(1);
    
    return 0;
}