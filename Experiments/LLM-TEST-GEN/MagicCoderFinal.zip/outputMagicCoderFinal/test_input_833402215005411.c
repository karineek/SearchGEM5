
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    // Check if there are exactly 1 argument (for demonstration purpose)
    if (argc != 2) {
        printf("Usage: ./program_name <input>\n");
        return EXIT_FAILURE;
    }

    // Open the file passed as an argument and check for errors
    FILE *file = fopen(argv[1], "r");
    if (file == NULL) {
        printf("Could not open file\n");
        return EXIT_FAILURE;
    }

    char c;  // Define a character variable

    while ((c = getc(file)) != EOF) {   // Read from the opened file until reaching end of file
        putchar(c);                     // Write to standard output (screen)
    }

    fclose(file);      // Close the file after reading all its contents

    clearerr(stdin);   // Clear error indicator on standard input

    return EXIT_SUCCESS;  // Return success exit status code
}