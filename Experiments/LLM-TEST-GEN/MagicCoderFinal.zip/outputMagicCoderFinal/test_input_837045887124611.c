
#include <stdio.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Please provide exactly one argument.\n");
        return -1;
    }

    printf("Your input is: %s\n", argv[1]);

    return 0;
}