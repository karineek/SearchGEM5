
#include <stdio.h>  // include standard input-output library
#include <stdlib.h> // include standard library for dynamic memory management

// function to calculate factorial of a number
long long factorial(int n) {
    if (n <= 1) return 1;
    else return n * factorial(n - 1);
}

// main function to get user input and call factorial function
int main(int argc, char **argv) {
    // check if exactly one argument is provided
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return -1;
    }
    
    int n = atoi(argv[1]);  // convert user input to integer
    long long result = factorial(n);  // call function to calculate factorial
    
    printf("Factorial of %d is: %lld\n", n, result);
    
    return 0;  // successful termination
}