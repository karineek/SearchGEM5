
#include <stdio.h>
#include <fenv.h>

int main(int argc, char **argv) {
    // Check if an argument was provided on the command line
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return -1;
    }
    
    fenv_t old, new;
    
    // Save the current floating-point environment in 'old'
    feholdex(&old);

    // Disable underflow and overflow exceptions (they might occur during multiplication)
    feupdateenv(&new);
    feenableexcept(FE_OVERFLOW | FE_UNDERFLOW);
    
    int result;
    result = atoi(argv[1]) * atoi(argv[1]);
    
    // Restore the old environment
    fesetenv(&old);

    printf("The square of %s is %d\n", argv[1], result);
    return 0;
}