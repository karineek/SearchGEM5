
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s num\n", argv[0]);
        return -1;
    }

    double x = atof(argv[1]);
    double square = pow(x, 2);
    
    printf("%.5f squared is %.5f.\n", x, nearbyintl(square));

    return 0;
}