
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: ./program_name number1 number2\n");
        exit(0);
    }

    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);

    // Performing bitwise OR operation 
    num1 |= num2;

    printf("Result of Bitwise OR: %d\n", num1);
    
    return 0;
}