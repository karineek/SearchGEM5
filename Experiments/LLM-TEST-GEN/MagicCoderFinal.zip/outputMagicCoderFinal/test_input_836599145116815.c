
gcc -fprofile-generate -O3 main.c -o main