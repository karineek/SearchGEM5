
#include <stdio.h>
#include <float.h>

// Function to print next floating point number which is closer to x than y.
double nextClosestFp(double x, double y) {
    return nextafter(x, y);
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <number1> <number2>\n", argv[0]);
        return -1;
    }

    double number1 = atof(argv[1]);
    double number2 = atof(argv[2]);

    if (isnan(number1) || isnan(number2)) {
        printf("Error: invalid input.\n");
        return -1;
    }

    // Print next floating point number which is closer to number1 than number2.
    double result = nextClosestFp(number1, number2);
    if (isnan(result)) {
        printf("There's no number closer to %f than %f.\n", number1, number2);
    } else {
        printf("%f is the next floating point number which is closer to %f than %f.\n", result, number1, number2);
    }

    return 0;
}