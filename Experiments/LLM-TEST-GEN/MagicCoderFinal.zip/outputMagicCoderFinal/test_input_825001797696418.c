
#include <stdio.h>

//Function declaration for Operator
int add(int a, int b);
int subtract(int a, int b);
int multiply(int a, int b);
double divide(double a, double b);

//Main function to receive inputs and call respective functions based on operator
int main(int argc, char *argv[]){
    if (argc != 4) {
        printf("Usage: ./calc <operand> <operator> <constant>\n");
        return 1;
    }
  
    int operand = atoi(argv[1]);
    char operator_char = argv[2][0]; // get the first character of operator string
    
    switch (operator_char) {
        case '+':
            printf("Result: %d\n", add(operand, atoi(argv[3])));
            break;
        case '-':
            printf("Result: %d\n", subtract(operand, atoi(argv[3])));
            break;
        case '*':
            printf("Result: %d\n", multiply(operand, atoi(argv[3])));
            break;
        case '/':
            printf("Result: %.2lf\n", divide(operand, atof(argv[3])));
            break;
        default:
            printf("Invalid operator. Only +,-,*,/ are supported.\n");
    }
  
    return 0;
}

//Function specialization for '+' operator
int add(int a, int b) {
    return a + b;
}

//Function specialization for '-' operator
int subtract(int a, int b) {
    return a - b;
}

//Function specialization for '*' operator
int multiply(int a, int b) {
    return a * b;
}

//Function specialization for '/' operator
double divide(double a, double b){
    if (b == 0) {
        printf("Error! Division by zero\n");
        return -1.0; // or any value to indicate error
    } else {
        return a / b;
    }
}