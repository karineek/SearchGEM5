
#include <stdio.h>
#include <string.h>

void print_rank(int num) {
    printf("Rank of number %d is: ", num);
    
    if (num == 10 || num == 20 || num == 30 || num == 40 || num == 50)
        printf("High\n");
    else if(num == 2 || num == 4 || num == 6 || num == 8 || num == 12)
        printf("Medium\n");
    else if(num == 1 || num == 3 || num == 5 || num == 7 || num == 9)
        printf("Low\n");
    else
        printf("Invalid number\n");
}

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <number>\n", argv[0]);
        return 1;
    }
    
    int num = atoi(argv[1]); // convert string to integer
    print_rank(num);         // call the function to test rank of number
    
    return 0;
}