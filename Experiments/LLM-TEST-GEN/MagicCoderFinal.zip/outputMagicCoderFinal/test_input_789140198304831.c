
#include <stdio.h>
#include <stdlib.h>
#include <cmath>

int main(int argc, char* argv[]) {
    // Check if correct number of arguments is provided
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    double num = atof(argv[1]);

    // Calculate the complex hyperbolic tangent of the input number
    double result = std::catanh(num);

    printf("The value of coth(%f) is: %f\n", num, result);
    
    return EXIT_SUCCESS;
}