
#include <stdio.h>
#include <stdlib.h>
#include <tgmath.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if(argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    double number = atof(argv[1]);
    printf("cosh(%lf) = %.2lf\n", number, cosh(number));
    
    return 0;
}