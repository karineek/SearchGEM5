
#include <stdio.h> 
#include <math.h> 
  
int main(int argc, char *argv[]) { 
    double x = atof(argv[1]); // Convert input to a double 
    double result;
    
    if (argc != 2) {
        printf("Usage: ./program_name number\n");
        return 1;
    }
      
    result = cosh(x);  // Use the cosh library function to calculate hyperbolic cosine 
  
    printf("%f", result);  // Print the result 
    
    return 0; 
} 