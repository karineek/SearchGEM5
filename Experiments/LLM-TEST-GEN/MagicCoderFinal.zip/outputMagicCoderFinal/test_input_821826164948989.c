
#include <stdio.h>

// Declare a function to multiply two numbers
double multiply(int num1, int num2) {
    return (double)(num1 * num2);
}

int main(int argc, char** argv) {
    // Inputs should be of type integer
    if (argc != 3) {
        printf("Usage: %s <int> <int>\n", argv[0]);
        return -1;
    }
    
    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);

    // Call the multiply function and print the result
    printf("Result: %.2f\n", multiply(num1, num2));

    return 0;
}