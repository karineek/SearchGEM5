
#include <stdio.h> 
#include <math.h> 

int main(int argc, char**argv){ 
    if(argc!=2){ 
        printf("Usage: %s <angle in degrees>", argv[0]); 
        return -1; 
    } 

    double angle = atof(argv[1]); // convert string to number 
    double radian_angle = (M_PI/180) * angle; //convert from degree to radian 

    printf("Sine of %.2lf degree is: %.4lf\n", angle, copysign(1.0, sin(radian_angle)));
    
    return 0; 
} 