
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <input_file>\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    FILE *fp = fopen(argv[1], "r");
    
    if (fp == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    int size, i;
    // Get the number of elements in the array.
    fscanf(fp, "%d", &size);
    
    int *array = (int*) malloc(sizeof(int) * size);

    for (i=0; i < size; i++) {
        fscanf(fp, "%d", &array[i]);
    }

    // Vectorized multiplication by 2 using '*=' operator.
    for(i = 0; i < size; ++i)
        array[i] *= 2;
    
    printf("The new array is: \n");
    for (i=0; i < size; i++) {
        fprintf(stdout, "%d ", array[i]);
    }
    
    free(array);
    fclose(fp);

    return 0;
}