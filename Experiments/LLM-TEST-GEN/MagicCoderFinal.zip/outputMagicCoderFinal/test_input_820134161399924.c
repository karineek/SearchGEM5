
#include <stdio.h>
#include <stdlib.h> // For exit() function 

int multiply(int n) {
    if(n <= 0){
        return -1;
    } else{
       int result = 0;
       for(int i=1; i<=n; ++i){
           result += i; // Equivalent to n*n 
       }
       return result;
   }
}

int main(int argc, char *argv[]) {
    if (argc != 2) { // Check that exactly one argument is provided
        printf("Usage: %s <integer>\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    int n;
    sscanf(argv[1], "%d", &n); // Convert command line argument to an integer
    
    int result = multiply(n); 
        
    if (result == -1){
        printf("Error: Argument must be a positive number\n");
        exit(EXIT_FAILURE);
    } else {
        printf("Result of multiplication is %d.\n", result);
        return 0; // All operations were successful, so return 0
    }
}