
#include <clang-c/Index.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    // Check if exactly one argument is provided (the C code file).
    if(argc != 2){
        printf("Usage: %s <file>\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    const char* filename = argv[1];
    FILE *inputFile = fopen(filename, "r");
    
    // Check if the file exists.
    if(!inputFile){
        printf("Error opening file: %s\n", filename);
        return EXIT_FAILURE;
    }
    
    // Create a translation unit from the source code.
    CXIndex index = clang_createIndex(1, 0);
    CXTranslationUnit tu = clang_parseTranslationUnit(index, filename, NULL, 0, NULL, 0, CXTranslationUnit_None);
    
    // Generate LLVM IR for the translation unit.
    const char* args[] = {"-S", "-emit-llvm"};
    clang_saveTranslationUnit(tu, filename, NULL, NULL, 0);
    
    // Perform some simple scalar optimizations on the generated LLVM IR.
    FILE *outputFile;
    outputFile = fopen("optimized.ll", "r");
    if(!outputFile) {
        printf("Error opening file: optimized.ll\n");
        return EXIT_FAILURE;
    }
    
    // Compare sizes of input and output files to demonstrate line buffering.
    int inputSize = 0, outputSize = 0;
    char *line = NULL;
    while ((line = fgets(line, sizeof line, inputFile)) != NULL) {
        inputSize += strlen(line);
    }
    
    while ((line = fgets(line, sizeof line, outputFile)) != NULL) {
        outputSize += strlen(line);
    }
    
    printf("Size of original file: %d\n", inputSize);
    printf("Size of optimized LLVM IR: %d\n", outputSize);
    
    // Close and clean up.
    clang_disposeTranslationUnit(tu);
    clang_destroyIndex(index);
    fclose(inputFile);
    fclose(outputFile);
    return EXIT_SUCCESS;
}