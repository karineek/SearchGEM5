
#include <stdio.h>
#include <stdlib.h>
#define FACT(x) ((x == 0)? 1 : (x * FACT(x-1)))

int main(int argc, char **argv){
    if(argc != 2 || atoi(argv[1]) < 0 ){ //ensure input is a positive integer
        printf("Usage: %s [positive_integer]\n", argv[0]);
        return 1;
    }
    
    int number = atoi(argv[1]);
    long result = FACT(number);
    printf("The factorial of %d is %ld\n", number, result);
    return 0;
}