
#include <stdio.h>
#include <math.h>  // include math library for sqrt function

int main(int argc, char* argv[]) {
    double num;

    if (argc != 2) {
        printf("Please enter one argument.\n");
        return -1;
    }

    num = atof(argv[1]); // convert string to double
    
    printf("The square root of %.0lf is %lf\n", num, sqrtl(num)); 

    return 0;
}