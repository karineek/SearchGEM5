
#include <stdio.h>

int main(int argc, char **argv) {
    int i;
    for (i = 0; i < argc; ++i) { // Loop Optimizations
        printf("You entered: %s\n", argv[i]); // Frontend
        goto nextarg; // Triggers loop optimization
nextarg:;
    }
    return 0;
}