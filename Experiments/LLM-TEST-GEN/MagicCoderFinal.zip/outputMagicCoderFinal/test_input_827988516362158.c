
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    int start, end;

    // Check if the correct number of arguments is passed
    if (argc != 3) {
        printf("Please provide two numbers.\n");
        return -1;
    }
    
    // Convert input strings to integers
    sscanf(argv[1], "%d", &start);
    sscanf(argv[2], "%d", &end);

    // Check if the second number is smaller than the first one, and swap them if necessary.
    if (start > end) {
        int temp = start;
        start = end;
        end = temp;
    }

    // Loop through all odd numbers within the range
    for(int i = start; i <= end; i += 2) {
        printf("%d ", i);
    }
    printf("\n");
    
    return 0;
}