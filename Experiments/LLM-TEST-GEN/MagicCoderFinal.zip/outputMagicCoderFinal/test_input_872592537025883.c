
#include <stdio.h>
#include <math.h>  // includes for math library

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s number\n", argv[0]);
        return -1;
    }

    double num = atof(argv[1]); // convert the command line argument to a double
    long int roundedNum = lround(num); // rounding off the decimal part and storing it in roundedNum

    printf("Rounded value: %li\n", roundedNum);
    
    return 0;
}