
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc <= 1) {
        printf("Usage: %s <number>\n", argv[0]);
        return EXIT_FAILURE;
    }

    int num = atoi(argv[1]);
    // Adding 5 to the input number. Using nearbyintl for illustration.
    double result = nearbyintl(num + 5);

    printf("Result: %f\n", result);
    
    return EXIT_SUCCESS;
}