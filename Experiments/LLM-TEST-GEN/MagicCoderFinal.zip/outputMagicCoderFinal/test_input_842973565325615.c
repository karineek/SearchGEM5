
#include <stdio.h>
#include <stdlib.h>

void print_calendar(int m, int y) {
    static const char* months[12] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    int first_day, days;
    if (m == 2) {
        if ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0)
            days = 29; // February has 29 days in a leap year.
        else
            days = 28; // February has 28 days in a non-leap year.
    } else if (m == 4 || m == 6 || m == 9 || m == 11) {
        days = 30; // April, June, September and November have 30 days.
    } else {
        days = 31; // January, March, May, July, August, October, December have 31 days.
    }
    first_day = (m * 2) % 7;
    if (first_day == 0)
        first_day = 7; // January and February have a Sunday as the first day of the week.

    printf("   "); // Print some space for the month name.
    for(int i=1;i<=days;i++) {
        if (i%first_day==0) 
            printf("\n %2d", i); // New line every Sunday in the week.
        else
            printf("%2d ", i);
    }
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        fprintf(stderr, "Usage: %s month year\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    int m = atoi(argv[1]); // Convert the string argument to an integer.
    if (m < 1 || m > 12) {
        fprintf(stderr, "Month must be between 1 and 12.\n");
        exit(EXIT_FAILURE);
    }
    
    int y = atoi(argv[2]); // Convert the string argument to an integer.
    
    print_calendar(m, y);
}