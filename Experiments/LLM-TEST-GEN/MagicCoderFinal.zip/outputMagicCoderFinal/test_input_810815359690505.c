
#include <stdio.h>
#include <stdlib.h>

// Function to convert decimal number to binary
inline int decToBinary(int n) {
    return (n == 0 ? 0 : ((n % 2) + 10 * decToBinary(n / 2)));
}

int main(int argc, char* argv[]) {
    if (argc != 2 || sscanf(argv[1], "%d", &n) != 1) {
        fprintf(stderr, "Usage: %s <decimal>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    printf("Binary representation of decimal number '%d' is: %d\n", n, decToBinary(n));
    
    return EXIT_SUCCESS;
}