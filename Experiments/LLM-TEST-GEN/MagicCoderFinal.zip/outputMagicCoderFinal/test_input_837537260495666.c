
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s file\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    printf("FLT_MAX_EXP = %d\n", FLT_MAX_EXP); // Exercise FLT_MAX_EXP

    /* Trigger Profile-Guided Instrumentation */
    char buf[1024];
    FILE *fp;
    if ((fp=fopen(argv[1], "r")) == NULL) {
        fprintf(stderr, "Cannot open input file %s\n", argv[1]);
        exit(EXIT_FAILURE);
    }
    
    /* Parse assembly files */
    while (fgets(buf, sizeof buf, fp) != NULL) {
       printf("%s", buf);  // print each line of the file
    }
    
    fclose(fp);
    return EXIT_SUCCESS;
}