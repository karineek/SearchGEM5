
#include <stdio.h>

int main(int argc, char *argv[]) {
  if (argc != 2) {
    printf("Usage: ./program <number>\n");
    return -1;
  }
  
  int num = atoi(argv[1]);
  int result = ~num & 0xFFFFFFFF; // ensure the number is 32 bits
  
  printf("The bitwise complement of %d is: %d\n", num, result);
  
  return 0;
}