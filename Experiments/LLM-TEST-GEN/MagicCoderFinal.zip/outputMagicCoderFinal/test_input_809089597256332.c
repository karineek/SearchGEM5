
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double hypot(double x, double y) {
    return sqrt(x*x + y*y);
}

int main(int argc, char **argv) {
    if (argc != 3) {
        printf("Usage: %s <side1> <side2>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    double side1 = atof(argv[1]);
    double side2 = atof(argv[2]);

    printf("The hypotenuse of the triangle with sides %f and %f is: %.2f\n", 
           side1, side2, hypot(side1, side2));

    return EXIT_SUCCESS;
}