
gcc -O3 main.c -l llvm -o main