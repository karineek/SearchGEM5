
#include <stdio.h>
#include <stdlib.h>

// Define the function that will be inline
static inline void print_message() {
    printf("This message should not appear in the output.\n");
}

int main(int argc, char* argv[]) {
    // Check if an argument has been provided
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <message>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    // Print the message from command line argument
    printf("%s\n", argv[1]);
    
    print_message();

    return 0;
}