
#include <iostream>
#include <string>
#include <stdlib.h>
#include <ctype.h>
#include <cstdio>
#include <cerrno>
#include <cstring>

// Interprocedural Optimizations (IPO) is performed by the compiler automatically, it is not necessary to implement this manually. 
// Handles code generation is typically handled by the compiler, although some languages offer explicit support for this.
// Exercise of perror function: we'll use it when attempting to open a file that does not exist or is otherwise inaccessible.

int main(int argc, char* argv[]) {
    if (argc != 2) { // Checks if there's exactly one argument
        std::cerr << "Usage: ./program <file>" << std::endl;
        return EXIT_FAILURE;
    }
    
    FILE *fp = fopen(argv[1], "r"); 
    if (fp == NULL) { // File is not accessible
        perror("fopen"); // Prints the error message associated with errno (usually 'No such file or directory')
        return EXIT_FAILURE;
    }
    
    char ch;
    while ((ch = fgetc(fp)) != EOF) { // Reads characters from file until end of file is reached
        std::cout << ch; 
    }
    if (ferror(fp)) { // Check for read errors
        perror("fgetc"); // Prints the error message associated with errno (usually 'Input/output error')
        return EXIT_FAILURE;
    }
    
    fclose(fp); // Close file after reading is done.
    return EXIT_SUCCESS; 
}