
#include <stdio.h>

int main(int argc, char *argv[]) {
    // Check if a command-line argument is provided
    if (argc > 1) {
        printf("Your input: %s\n", argv[1]);
    } else {
        printf("No input provided. Please provide an input.\n");
    }
    
    return 0;
}