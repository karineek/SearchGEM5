
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int main(int argc, char *argv[]) {
    // Check if an argument is given 
    if (argc != 2) {
        printf("Usage: %s [number]\n", argv[0]);
        return -1;
    }
    
    float x = atof(argv[1]);
    float y = ccoshf(x);

    // Print the result
    printf("%.2f\n", y);

    return 0;
}