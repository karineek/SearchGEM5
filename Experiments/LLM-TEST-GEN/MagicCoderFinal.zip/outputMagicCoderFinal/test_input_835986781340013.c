
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

// Define a utility function to check if a number is positive
int is_positive(double n){
    return (n > 0) ? 1 : 0;
}

// Implement csqrt function with Inliner Heuristics optimizations
double csqrt(double n){
    // Check if the input is a non-negative number
    if(!is_positive(n)){
        printf("Error: Input must be a non-negative number\n");
        exit(1);
    }
    return sqrt(n);
}

int main(int argc, char* argv[]){
    // Check if an argument is provided
    if(argc != 2){
        printf("Usage: %s <number>\n", argv[0]);
        exit(1);
    }
    
    double num = atof(argv[1]); // Convert input to a double

    printf("Square root of %.2f is: %.2f\n", num, csqrt(num));

    return 0;
}