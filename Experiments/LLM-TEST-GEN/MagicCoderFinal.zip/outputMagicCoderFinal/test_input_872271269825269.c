
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // Check if we have exactly one argument
    if (argc != 2) {
        printf("Usage: %s <environment_variable>\n", argv[0]);
        return -1;
    }

    // Get the value of the specified environment variable
    const char *value = getenv(argv[1]);
    
    if (value == NULL) {
        printf("Environment variable %s is not set\n", argv[1]);
    } else {
        printf("Value of environment variable %s: %s\n", argv[1], value);
    }

    return 0;
}