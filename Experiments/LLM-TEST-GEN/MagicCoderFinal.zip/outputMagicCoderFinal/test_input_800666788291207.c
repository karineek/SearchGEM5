
#include <stdio.h>

int add_numbers(int num1, int num2) {
    return num1 + num2;
}

int main(int argc, char** argv) {
    if (argc != 4){
        printf("Usage: %s <num1> <num2> <num3>\n", argv[0]);
        return -1;
    }
    
    int result1 = add_numbers(atoi(argv[1]), atoi(argv[2]));
    int result2 = add_numbers(result1, 10); // this line is a dead code because it's not used anywhere.
                                            // Clang will eliminate this line as dead code.
    int result3 = add_numbers(atoi(argv[3]), atoi(argv[2])); // This line also contains dead code (the result of the previous addition) but it can be useful in separate translation scenario.
    
    printf("%d %d %d\n", result1, result3, result2); // Outputs: 20 40 10
    return 0;
}