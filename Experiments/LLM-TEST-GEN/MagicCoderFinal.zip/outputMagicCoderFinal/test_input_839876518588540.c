
#include <stdio.h>
#include <stdlib.h>

// Declare function for automatic vectorization
__attribute__((optimize("Ofast"))) double dot_product(int n, double *a, double *b) {
    int i;
    double sum = 0.0;

    // Vectorized loop (automatic vectorization by GCC)
    for (i=0; i<n; i++) {
        sum += a[i] * b[i];
    }
    
    return sum;
}

int main(int argc, char **argv) {
    // Check if user has provided arguments
    if(argc < 3) {
        printf("Please provide two vectors as arguments.\n");
        exit(EXIT_FAILURE);
    }

    int n = atoi(argv[1]);
    
    // Declare vectors
    double *a, *b;

    // Allocate memory for vectors
    a = malloc(sizeof(double) * n);
    b = malloc(sizeof(double) * n);

    if (a == NULL || b == NULL) {
        printf("Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }

    // Fill vectors with input arguments
    for (int i=0; i<n; i++) {
        a[i] = atof(argv[2+i*2]);
        b[i] = atof(argv[2+(i*2)+1]);
    }

    // Calculate dot product and print result
    printf("Dot product: %.3lf\n", dot_product(n, a, b));
    
    // Free memory for vectors
    free(a);
    free(b);

    return 0;
}