
#include <stdio.h>
#include <stdlib.h>

// Function to add two numbers (ANSIE 754)
double addNumbers(double num1, double num2) {
    return num1 + num2;
}

int main(int argc, char *argv[]) {
    // Inputs via command-line arguments
    double num1 = atof(argv[1]);  // Convert input string to double
    double num2 = atof(argv[2]);  // Convert input string to double
    
    printf("The sum of %.2lf and %.2lf is: %.2lf\n", num1, num2, addNumbers(num1, num2));

    return 0;
}