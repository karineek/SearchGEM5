
#include <stdio.h>
#include <math.h> // For using DBL_EPSILON macro

int main(int argc, char**argv){
    if (argc != 3) {
        printf("Usage: ./programName <number1> <number2>\n");
        return -1;
    }
    
    double num1 = atof(argv[1]); // Convert the input to a double.
    double num2 = atof(argv[2]); 
  
    printf("The numbers are: %f and %f\n", num1, num2);
      
    if (DBL_EPSILON > abs((num2-num1)/num2)) { // Instruction Scheduling
        printf("The second number is approximately equal to the first.\n");
    } else {
        printf("The second number is not approximately equal to the first.\n");
    }
  
    return 0;
}