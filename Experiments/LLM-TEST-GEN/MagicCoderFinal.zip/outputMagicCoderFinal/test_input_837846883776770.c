
#include <stdio.h>
#include <stdlib.h>
#include <stdatomic.h>
#include <pthread.h>

atomic_int count;  // shared variable between threads
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;  // for synchronization

void* threadFunction(void *arg) {
    int local_count = atomic_load(&count);  // read the current count
    
    while (1) {
        if (atomic_compare_exchange_weak(&count, &local_count, local_count + 1)) {
            printf("Thread %ld incremented the counter to: %d\n", pthread_self(), local_count + 1);
            
            // simulate some work for a moment
            sleep(1);
        } else {
            printf("Thread %ld could not increment. Another thread might have modified the counter!\n", pthread_self());
        }
    }
    
    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number of threads>\n", argv[0]);
        exit(1);
    }
    
    int num_threads = atoi(argv[1]);
    
    pthread_t thread[num_threads];
    for (int i=0; i<num_threads; ++i) {
        if(pthread_create(&thread[i], NULL, &threadFunction, NULL)) {
            printf("Failed to create thread %d\n", i+1);
            exit(2);
        }
    }
    
    for (int i=0; i<num_threads; ++i) {
        if(pthread_join(thread[i], NULL)) {
            printf("Failed to join thread %d\n", i+1);
            exit(3);
        }
    }
    
    return 0;
}