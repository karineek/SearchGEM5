
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
  if (argc != 4) {
    printf("Usage: ./prog <register_allocation_method> <serialization_method> <expression>\n");
    return -1;
  }
  
  // Register Allocation optimization logic here.
  // For the sake of this example, we just print the arguments.
  printf("Register Allocation Method: %s\n", argv[1]);
  
  // Serialization logic here.
  // For the sake of this example, we just print the arguments.
  printf("Serialization Method: %s\n", argv[2]);
  
  // Expression logic here.
  // For the sake of this example, we just print the expression.
  printf("Expression: %s\n", argv[3]);
  
  return 0;
}