
#include <stdio.h>
#include <stdlib.h>

// AST node structure
struct Node {
    char* str;
};

double scalarOptimization(Node* node) {
    return atof(node->str); // Convert string to double using atof function
}

int main(int argc, char *argv[]){
    if (argc != 2){
        printf("Usage: ./program_name <number>\n");
        return 1;
    }
    
    Node node;
    node.str = argv[1]; // Getting input from command line argument

    printf("Input value: %s\n",node.str);
    double result = scalarOptimization(&node); // Calling the function to perform scalar optimizations
    printf("Result: %.2f\n",result);
    return 0;
}