
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return EXIT_FAILURE;
    }

    // Convert number to string using itoa function
    char buffer[10];
    int num = atoi(argv[1]);
    if (num > 9) {
        printf("Number must be an integer between 0 and 9\n");
        return EXIT_FAILURE;
    }
    
    itoa(num, buffer, 10);
    printf("The string representation of %d is: %s\n", num, buffer);

    // Parsing assembly files. This part requires a specific assembly file as input
    FILE *fp;
    char path[256];
    sprintf(path, "./%s", argv[1]); 
    fp = fopen(path, "r");
    if (fp == NULL) {
        printf("Error opening file\n");
        return EXIT_FAILURE;
    }
    
    // Sparse Conditional Constant Propagation. This part requires a specific input as well
    int val = 0;
    for (int i = 0; i < num; ++i) {
        val += i % 2 ? -1 : 1;
    }
    
    printf("The value of the loop is: %d\n", val);
    return EXIT_SUCCESS;
}