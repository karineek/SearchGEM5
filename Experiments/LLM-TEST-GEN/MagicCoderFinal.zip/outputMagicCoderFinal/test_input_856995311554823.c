
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char* argv[]) {
   if (argc != 2) {
      fprintf(stderr, "Usage: %s <input>\n", argv[0]);
      exit(EXIT_FAILURE);
   }
   
   // Instruction Scheduling optimizations can be exercised here.
   printf("Scheduled instructions:\n");
   
   char* input = argv[1];
   
   // A simple example of acquiring a fence in C:
   __sync_synchronize(); 

   return EXIT_SUCCESS;
}