
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <number1> <shift>\n", argv[0]);
        exit(1);
    }
    
    int num = atoi(argv[1]); // convert string to integer
    int shift_amount = atoi(argv[2]); 

    int vectorized_num;
    
    asm("vmovdqa %1, %%ymm0\n\t"
        "vpsllw %2, %%ymm0, %%ymm1\n\t" // shift left (num << shift_amount)
        "vpmovdw %%ymm1, %0\n\t"  // store result in vectorized_num
        :"=r"(vectorized_num) : "g"(num), "r"(shift_amount) : "%ymm0", "%ymm1");
    
    printf("Result of shift left: %d\n", vectorized_num);

    asm("vmovdqa %1, %%ymm0\n\t"
        "vpsrlw %2, %%ymm0, %%ymm1\n\t" // shift right (num >> shift_amount)
        "vpmovdw %%ymm1, %0\n\t"  // store result in vectorized_num
        :"=r"(vectorized_num) : "g"(num), "r"(shift_amount) : "%ymm0", "%ymm1");
    
    printf("Result of shift right: %d\n", vectorized_num);
    
    return 0;
}