
#include <stdio.h>
#include <math.h>

// Inline Function Declaration
inline float mySqrt(float num);

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s number\n", argv[0]);
        return 1;
    }
    
    float num = atof(argv[1]);
    
    // Call the inline function to calculate square root of a number
    float sqrt_num = mySqrt(num);

    printf("The square root of %f is %f\n", num, sqrt_num);

    return 0;
}

// Inline Function Definition
inline float mySqrt(float num) {
    return sqrt(num);
}