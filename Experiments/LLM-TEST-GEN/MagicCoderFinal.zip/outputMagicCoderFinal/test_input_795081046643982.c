
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    if (argc != 2) { // Checking if user has provided exactly one argument
        printf("Usage: %s array\n", argv[0]);
        exit(1);
    }
    
    int* arr = malloc(sizeof(int) * atoi(argv[1])); // Converting the string to integer 
    if (arr == NULL) {
        printf("Memory allocation failed.\n");
        exit(2);
    }

    for (int i = 0; i < atoi(argv[1]); i++) {
        scanf("%d", &arr[i]); // Taking input from command line
    }

    int sum = 0;
    for (int i = 0; i < atoi(argv[1]); i++) {
        sum += arr[i]; // Computing the sum of all elements in array
    }
    
    printf("Sum: %d\n", sum); // Printing the sum
    free(arr); // Deallocating memory
    return 0;
}