
#include <stdio.h>
#include <math.h> // Include math.h for lgamma function

// Function to calculate the natural logarithm of Gamma function
double my_lgamma(int n){ 
    return lgamma(n);
}

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return -1;
    }
    
    int n = atoi(argv[1]); // Convert the command line argument to integer
    double result = my_lgamma(n); // Call our custom lgamma function

    printf("The natural logarithm of Gamma of %d is %f\n", n, result);
    
    return 0;
}