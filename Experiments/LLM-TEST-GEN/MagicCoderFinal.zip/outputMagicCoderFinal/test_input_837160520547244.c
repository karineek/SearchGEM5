
#include <stdio.h>  // For printf and scanf functions
#include <math.h>   // For llrint function

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: ./%s <double>\n", argv[0]);
        return 1;
    }
    
    double d = atof(argv[1]);
    long lrint_result = llrint(d);
    
    printf("Rounded integer of %f is: %ld\n", d, lrint_result);
    
    return 0;
}