
#include <stdio.h>
#include <stdlib.h>

// Check if __alignas is defined
#ifdef __alignas
  #define HAS_ALIGNAS
#endif

int main(int argc, char *argv[]) {
    // Check for proper command-line arguments
    if (argc != 2) {
        printf("Usage: ./program <array size>\n");
        return 1;
    }

    int size = atoi(argv[1]);

    // Allocate memory and initialize an array with random numbers
    int *arr = malloc(size * sizeof(int));
    for (int i = 0; i < size; ++i) {
        arr[i] = rand();
    }

    printf("Sum without vectorization: %d\n", calculateSumWithoutVectorization(arr, size));
    
#ifdef HAS_ALIGNAS
    printf("Sum with vectorization and __alignas_is_defined macro defined: %d\n", calculateSumWithVectorizationAndAlignas(arr, size));
#else
    printf("__alignas is not defined. Sum with vectorization is not possible.\n");
#endif
    
    // Free allocated memory
    free(arr);
    
    return 0;
}