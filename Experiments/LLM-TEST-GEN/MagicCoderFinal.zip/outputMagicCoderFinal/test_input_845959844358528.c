
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./program_name number\n");
        return EXIT_FAILURE;
    }
    
    double number = atof(argv[1]);
    double squareRoot = sqrt(number);

    printf("The square root of %f is %f.\n", number, squareRoot);
    return 0;
}