
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {
    // Check if a valid number of arguments is provided
    if (argc != 2) {
        printf("Error: Exactly one argument should be provided.\n");
        return -1;
    }
    
    wchar_t dest[50];   // Destination string
    memset(dest, '\0', sizeof(dest)); // Ensure the array is initialized with null characters 

    errno_t e = wcsncpy_s(dest, argv[1], L'\0');  
    
    if (e != 0) {
        printf("Error copying string: %d\n", e);
        return -1;
    }

    // Output the copied string
    wprintf(L"Copied string: %s\n", dest);

    return 0;
}