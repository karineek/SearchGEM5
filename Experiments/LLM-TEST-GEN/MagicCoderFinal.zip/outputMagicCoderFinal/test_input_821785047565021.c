
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Instruction Scheduling algorithm */
void scheduleInstructions(int n, int *instructions){
    // Placeholder function for the scheduling algorithm.
    printf("Scheduled instructions:\n");
    
    // Print the scheduled instructions
    for (int i = 0; i < n; i++){
        printf("%d ", instructions[i]);
    }
}

/* Main Function */
int main(int argc, char *argv[]) {
    if (argc != 3) { // Check if input is correct
        printf("Usage: %s <number of instructions> <comma-separated instructions>\n", argv[0]);
        return -1;
    }
    
    int n = atoi(argv[1]); // Convert the first command line argument to integer
    if (n <= 0) {
        printf("Number of instructions must be positive\n");
        return -1;
    }
    
    /* Create an array of integers for scheduled instructions */
    int *instructions = malloc(n*sizeof(int)); // Memory allocation
    if (instructions == NULL) { // Check if memory is allocated successfully
        printf("Memory allocation failed\n");
        return -1;
    }
    
    /* Convert the comma-separated arguments to an integer array */
    int *ptr = instructions;
    char *token = strtok(argv[2], ","); // Tokenize the second command line argument
    while (token != NULL) {
        *ptr++ = atoi(token); 
        token = strtok(NULL, ",");
    }
    
    if ((n != ptr - instructions)) {
        printf("Wrong number of arguments\n");
        return -1;
    }
    
    /* Schedule the instructions */
    scheduleInstructions(n, instructions);

    free(instructions); // Free allocated memory
    return 0;
}