
#include <stdio.h>
#include <math.h>

int main(int argc, char** argv) {
    if (argc != 2) {
        printf("Usage: %s number\n", argv[0]);
        return -1;
    }

    double input = atof(argv[1]);
    if (input <= 0) {
        printf("Invalid input. Please provide a positive number.\n");
        return -1;
    }

    double log_base2 = logbl(input);
    
    printf("The base 2 logarithm of %f is %f\n", input, log_base2);
    
    return 0;
}