
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // Check if we received exactly one argument
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <number>\n", argv[0]);
        return EXIT_FAILURE;
    }

    int number = atoi(argv[1]);

    // Check the parity of the number using SCNoPTR (Sparse Conditional Constant Propagation)
    printf("%d\n", number % 2 == 0 ? 1 : 0);

    return EXIT_SUCCESS;
}