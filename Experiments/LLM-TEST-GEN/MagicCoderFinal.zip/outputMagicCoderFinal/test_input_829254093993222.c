
#include <stdio.h>
#include <math.h>  // for "creal" function

void printSquare(int number) {
    printf("The square of %d is: %d\n", number, number * number);
}

double computeLogarithm(double num) {
    return log10(num);  
}

// This is a specialization for int type.
void printSquareSpecializedForInt(int number) {
    printf("The square of %d is: %d\n", number, pow(number, 2));
}

int main(int argc, char* argv[]) {
    if (argc != 2){
        printf("Usage: ./programName <input>\n");
        return -1;
    }

    int number = atoi(argv[1]);
    
    // Calling function specialization for int.
    printSquareSpecializedForInt(number);

    printf("The logarithm of %d is: %.2f\n", number, computeLogarithm((double)number));

    return 0;
}