
#include<stdio.h>

// Function to calculate sum
double add(int a, int b) {
    return (double)(a + b);  // casting to double
}

// Main function with Interprocedural Optimizations
int main(int argc, char **argv) {
    if(argc != 3){
        printf("Usage: ./prog <num1> <num2>\n");
        return -1;
    }
    
    int num1 = atoi(argv[1]); // convert argument to integer
    int num2 = atoi(argv[2]); // convert argument to integer
  
    double result = add(num1, num2);  // intermediate variable
    
    printf("The sum of %d and %d is: %.2lf\n", num1, num2, result);  // print the result with two decimal places
    
    return 0;
}