
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s num\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    int num = atoi(argv[1]);
    
    for (int i=0; i<num; i++) {
        // This loop is vectorized by the compiler. 
        printf("Hello, world!\n");
    }
    
    return EXIT_SUCCESS;
}