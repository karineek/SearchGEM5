
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {
  if (argc != 2) {
    printf("Usage: %s float_number\n", argv[0]);
    return -1;
  }

  double x = atof(argv[1]); // convert string to floating point number
  
  // use frexp() function, it separates the value into two parts: the mantissa and the exponent.
  int exp;
  double mant = frexp(x, &exp);

  printf("The original number is %f\n", x);
  printf("Mantissa part is %.15e\n", mant); // Print the mantissa in scientific notation.
  printf("Exponent part: %d\n", exp); 

  return 0;
}