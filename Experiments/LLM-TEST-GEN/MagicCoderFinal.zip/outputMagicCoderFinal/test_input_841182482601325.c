
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// Function to calculate cube
double cpowf(float x) {
    return x * x * x;
}

int main(int argc, char *argv[]) {
    // Check if the correct number of arguments is provided
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    float num = atof(argv[1]); // Convert the input to a floating point number

    // Calculate cube and print result
    double cubedNum = cpowf(num); 
    printf("The cube of %.2f is: %.2f\n", num, cubedNum);
    
    return EXIT_SUCCESS;
}