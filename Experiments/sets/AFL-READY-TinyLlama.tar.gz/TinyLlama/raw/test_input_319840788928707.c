
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc > 1 && strcmp(argv[1], "BASH") == 0) {
        printf("Hello, BASH!\n");
        return 0;
    } else {
        fprintf(stderr, "Usage: %s [-h] [--help]\n", argv[0]);
        exit(EXIT_FAILURE);
    }
}