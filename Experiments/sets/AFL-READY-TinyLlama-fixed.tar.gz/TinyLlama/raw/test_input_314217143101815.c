
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    int exitcode;

    // Read user input
    if (argc <= 1 || !isatty(fileno(stdin))) {
        printf("Usage: %s <input file>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    char buffer[256];
    read(STDIN_FILENO, buffer, 256);
    if (write(1, buffer, strlen(buffer)) != strlen(buffer)) {
        perror("Error writing input file");
        exit(EXIT_FAILURE);
    }

    // Call BASH shell interpreter with the input file name as argument
    printf("%s\n", argv[1]);
    exitcode = system(argv[1]);

    return 0;
}