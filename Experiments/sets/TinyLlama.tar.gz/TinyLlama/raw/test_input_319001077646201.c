
#include <stdio.h>
#include <stdlib.h>

typedef int atomic_int_leaest32_t;

int main() {
    char* argv[] = {"myfile"};
    
    if (argv[0] == NULL || strcmp(argv[0], "-") != 0) {
        fprintf(stderr, "Usage: %s [-] file [file ...]\n", argv[0]);
        exit(1);
    }

    atomic_int_leaest32_t* addr = (atomic_int_leaest32_t*) malloc(sizeof(atomic_int_leaest32_t));
    if (addr == NULL) {
        fprintf(stderr, "Failed to allocate memory for file contents\n");
        exit(1);
    }
    
    FILE* file = fopen(argv[1], "r");
    if (file == NULL) {
        fprintf(stderr, "Failed to open %s for reading\n", argv[1]);
        exit(1);
    }

    fseek(file, 0, SEEK_END);
    long fileSize = ftell(file);
    if (fileSize == -1) {
        fprintf(stderr, "Failed to get file size\n");
        exit(1);
    }
    
    char buffer[fileSize + 1];
    if (fread(buffer, sizeof(char), fileSize, file) != fileSize) {
        fprintf(stderr, "Failed to read file contents\n");
        exit(1);
    }
    
    strncpy(addr, buffer, fileSize);
    addr[fileSize] = '\0';

    printf("%s", addr);

    fclose(file);

    return 0;
}