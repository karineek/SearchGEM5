
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

void profile(int (*func)(int), int argc, char **argv) {
    unsigned long long start_time, end_time;
    float cpu_percent;
    struct rusage ru;

    if (getrusage(RUSAGE_SELF, &ru) == 0) {
        gettimeofday(&start_time, NULL);
        func(argc, argv);
        gettimeofday(&end_time, NULL);
        cpu_percent = (float)((end_time.tv_sec - start_time.tv_sec) * 100 + (end_time.tv_usec - start_time.tv_usec) / 1000000.0) / 60;
        printf("CPU usage: %.2f%%\n", cpu_percent);
    } else {
        puts("Error: getrusage() failed.");
    }
}

int main(int argc, char **argv) {
    int i = 0;
    
    while (i < argc) {
        profile(&printf, argc - 1, argv + 1);
        printf("Args: %s\n", argv[i]);
        
        if (i == argc - 2) {
            puts("Process finished.");
            return 0;
        } else {
            i++;
        }
    }
    
    puts("Process terminated unexpectedly.");
    return 1;
}