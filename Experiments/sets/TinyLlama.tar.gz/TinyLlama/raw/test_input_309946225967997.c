
#include <stdio.h>

int main() {
    int argc;
    char *argv[2];
    
    argv[0] = "hello";
    argv[1] = "world";
    
    argc = 2;
    
    printf("Inputs: %d\n", argc);
    
    for (int I = 0; I < argc; i++) {
        printf("%s ", argv[i]);
    }
    printf("\n");
    
    return 0;
}