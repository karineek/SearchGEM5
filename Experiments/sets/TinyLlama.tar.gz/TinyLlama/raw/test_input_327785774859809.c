
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

int main(int argc, char **argv) {
    int sig = signal(SIGINT, sig_handler);
    
    if (argc > 1 && !strcmp(argv[1], "-h") || !strcmp(argv[1], "--help")) {
        printf("Usage: scalaro [-h] [args...]\n");
        printf("\n");
        return EXIT_SUCCESS;
    } else if (argc > 1 && !strcmp(argv[1], "-v") || !strcmp(argv[1], "--version")) {
        printf("ScalaR Optimization v1.0\n");
        exit(EXIT_SUCCESS);
    } else {
        FILE *file = fopen(argv[1], "r");
        
        if (file == NULL) {
            perror("Failed to open input file for reading.\n");
            return EXIT_FAILURE;
        }
        
        // read input from BASH input and handle errors
        char buffer[BUFSIZ] = {'\0'};
        size_t bytes_read = 0, bytes_left = BUFSIZ;
        
        while ((bytes_read = fread(buffer, 1, BUFSIZ, file)) != 0) {
            if (fwrite(buffer, 1, bytes_read, stdout) == bytes_read) {
                putc('\n', stdout);
            } else {
                perror("Failed to write to output stream.\n");
                return EXIT_FAILURE;
            }
        }
        
        fclose(file);
    }
    
    signal(SIGINT, sig); // restore default handler after program exits
    return EXIT_SUCCESS;
}