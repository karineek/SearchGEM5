
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    printf("The command line arguments are:\n");
    for (int I = 0; I < argc; i++) {
        printf("%s\t", argv[i]);
    }
    printf("\n");
    
    return 0;
}