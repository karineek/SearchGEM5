
#include <stdio.h> /* Required for printf() */

int main(void) {
    int n, sum = 0; /* Initial value of sum */
    
    /* Read an integer from the command line via argv[1] */
    char str[25];
    while (getline(&str[0], sizeof(str), stdin) > 0) {
        int num = atoi(str); /* Convert string to integer */
        
        /* Calculate sum of all numbers <= n using recursion */
        if (num < n) {
            for (int I = num; I < n; i++) {
                sum += 10 * sum + i; /* Add 10 and sum up rest of number */
            }
            
            printf("Sum of all numbers <= %d is %d\n", n, sum); /* Print result */
        }
    }
    
    return 0;
}