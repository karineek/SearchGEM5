
#include <stdio.h> /* Standard input/output library */
#include <stdlib.h> /* Standard library */
#include <string.h> /* String manipulation functions */

/* Define a function to process user input */
int main(int argc, char **argv) {
    int i;
    
    for (i = 1; i < argc; i++) {
        printf("Enter word: ");
        fgets(argv[i], sizeof(argv[i]), stdin); /* Get user input */
        
        if (argc > i) { /* Check if we have enough arguments */
            printf("\nError: not enough arguments\n");
            return 1; /* Exit the program with error code */
        } else if (!argv[i][0]) { /* Check if argument is empty */
            printf("Error: argument cannot be empty\n");
            return 1; /* Exit the program with error code */
        }
    }
    
    /* Perform memory-to-register promotion optimizations using negation operator (!) */
    for (i = 0; i < argc - 1; i++) {
        if (!strcmp(argv[i], "!")) {
            printf("%s", strtok(argv[++i], " ")); /* Promote negated word to its original state */
        } else {
            printf("Adding %s... ", argv[i]); /* Add the user input to the memory */
            fgets(buffer, sizeof(buffer), stdin); /* Read input line and clear buffer */
            
            for (j = 0; j < strlen(argv[i]) && !strcmp(argv[i], " "); j++) { /* Loop through each character of user input */
                buffer[j] += argv[++i][j]; /* Add characters to memory */
            }
            
            printf("done\n"); /* Display progress */
        }
    }
    
    return 0; /* Exit the program without errors */
}