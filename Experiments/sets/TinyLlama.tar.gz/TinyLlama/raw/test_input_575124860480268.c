
#include <stdio.h> /* for fprintf() */
#include "compiler-state-analysis.h" /* for CSA_optimize(), CSA_run_to_const_and_exit() */

int main(void) {
    /* Input: argv[1] = "hello world!" */
    if (argc != 2 || strcmp(argv[1], "-") == 0) { /* optional -h, --help option */
        fprintf(stderr, "Usage: %s [options] [filename]\n", argv[0]);
        return 1; /* exit with error code */
    }

    char const *filename = argv[1]; /* filename from argv[1] */

    CSA_initialize(RSIZE_MAX); /* initialize state analyzer */

    if (CSA_run_to_const_and_exit(filename) == 0) { /* execute and exit with success */
        fprintf(stdout, "OK: %s\n", filename);
    } else { /* execute and exit with failure */
        fprintf(stderr, "FAIL: %s\n", filename);
        return 1; /* exit with error code */
    }

    CSA_cleanup();

    return 0; /* exit without errors */
}