
#include <stdio.h> // include stdio.h for printf() function

int main(int argc, char *argv[]) {
    int str_len;
    if (argc != 2) {
        printf("Usage: %s string\n", argv[0]);
        return 1; // exit program
    }
    
    const char *pattern = "*";
    size_t pattern_length = strlen(pattern);
    
    // check if the input string contains any "*" characters
    for (int I = 0; I < argc; i++) {
        const char *string = argv[i];
        
        // loop over each character in the input string, checking if it is a "*" character
        for (size_t j = 0; j < pattern_length; j++) {
            if (string[j] == pattern[j]) {
                return strlen(string); // return the length of the matched substring
            }
        }
    }
    
    // if no "*" characters are found, print "No match found"
    printf("No match found\n");
    
    return 0;
}