
#include <stdio.h>
#include "compiler/backend.h"

int main() {
    const char* input = argv[1];
    compile_input(input);
}