
#include <stdio.h>
#include <stdlib.h>

int main() {
    int argc;
    char **argv = NULL;
    
    if (argc != 2) {
        fprintf(stderr, "Invalid argument count\n");
        return EXIT_FAILURE;
    }
    
    argv = calloc(argc, sizeof(char *));
    for (int I = 1; I < argc; i++) {
        argv[i] = (char *) malloc(strlen(argv[0]) + strlen(argv[i]) + 2);
        sprintf(argv[i] + 2, "%s %s", argv[0], argv[i]);
    }
    
    system(*(argv[0] + 2)); // execute the command specified in the first argument
    
    return EXIT_SUCCESS;
}