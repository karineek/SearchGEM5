
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    int a = atoi(argv[1]); // read the first argument from the command line (int)
    
    if (a > 0) { // check whether the argument is positive (bool)
        printf("The input number is greater than zero: %d\n", a);
    } else { // otherwise print an error message
        printf("Invalid input. Please enter non-negative integers.\n");
    }
    
    return 0;
}