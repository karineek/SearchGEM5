
#include <stdio.h> // for printf() and fprintf()
#include <string.h> // for strlen()

// Function to print the input line in bold font
void boldPrint(char *str) {
  int i;
  for (i = 0; i < (int)strlen(str); i++) {
    printf("%c", str[i]);
    if (i % 2 == 1) { // print the odd numbered characters in bold font
      printf("*\n");
    }
  }
}

// Function to print input in uppercase and add a '!' after each line
void upperPrint(char *str) {
  int i;
  for (i = 0; I < (int)strlen(str); i++) {
    if (i % 2 == 1) { // print the odd numbered characters in bold font
      printf("%c", str[i]);
      printf("! "); // add a '!' after each line
    } else {
      printf("%c", str[i]); // do not add a '!' for even numbered characters
    }
  }
}

// Function to provide various utility functions
void utils(void) {
  // print the input line in bold font
  boldPrint(argv[0]);
  
  // print input in uppercase and add a '!' after each line
  upperPrint(strtok(argv[1], "\n"));
}

int main() {
  int I, argc;
  char *line = NULL;
  char *upperStr = NULL;
  
  // get input from user and process it
  printf("Enter a BASH line (no quotes): ");
  if ((argc = getenv_s(&line, &upperStr)) != 1) {
    fprintf(stderr, "Failed to get input.\n");
    return 1;
  }
  
  // call functions to provide various utility functions and print the output
  utils();
  
  return 0;
}