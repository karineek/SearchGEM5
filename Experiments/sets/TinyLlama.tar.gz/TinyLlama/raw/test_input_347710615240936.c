
#include <stdio.h>
#include <stdlib.h>

#define MAX_ARGS 3 // maximum number of arguments allowed

int main(int argc, char *argv[]) {
    if (argc > MAX_ARGS) {
        printf("Error: Too many arguments\n");
        return 1;
    }

    int n = atoi(argv[1]); // parse integer argument
    char buf[MAX_ARGS + 1]; // buffer to hold binary string

    // check if binary format is valid
    switch (argc) {
        case 2:
            snprintf(buf, sizeof(buf), "%d", n); // convert integer to binary string
            break;
        default:
            printf("Error: Invalid input\n");
            return 1;
    }

    int i = 0;
    char *output = (char *) malloc(sizeof(char) * MAX_ARGS + 2); // allocate space for binary string and separator

    while (i < argc - 1 && n > 0) {
        snprintf(buf + strlen(buf), sizeof(buf) - strlen(buf), "%d", n); // convert integer to binary string
        memcpy(&output[strlen(buf)], buf, sizeof(char) * MAX_ARGS + 2); // copy binary string and separator into output buffer
        snprintf(buf, sizeof(buf), " | "); // add separator between two binary strings
        n /= 2; // update integer argument for next iteration
        i++;
    }

    if (i == argc - 1) {
        snprintf(&output[strlen(output)], sizeof(char) * MAX_ARGS + 2, "%d", n); // convert integer to binary string and add separator at end
        printf("%s\n", output); // print binary string with separator
    } else {
        snprintf(buf, sizeof(buf), " %d", n); // add remaining bits of integer to binary string
        memcpy(&output[strlen(output)], buf, sizeof(char) * MAX_ARGS + 2); // copy binary string and separator into output buffer
    }

    return 0;
}