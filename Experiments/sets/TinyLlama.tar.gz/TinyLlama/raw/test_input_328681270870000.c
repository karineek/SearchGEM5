
$ ./a.out 5
The cube of 5 is 25