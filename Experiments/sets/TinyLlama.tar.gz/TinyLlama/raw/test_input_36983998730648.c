
#include <stdio.h>
#include <stdlib.h>

#define MAX_ARG 10

void specialized(int* arg) {
    printf("Specialization called with argument %d\n", *arg);
}

void base_function(int arg) {
    printf("Base function called with argument %d\n", arg);
}

int main() {
    int argc;
    char* argv[MAX_ARG];
    
    // Get arguments from command line
    argc = sizeof(argv)/sizeof(argv[0]);
    for (int I=0; I<argc; i++) {
        argv[i] = (char*)calloc(MAX_ARG+1, sizeof(char));
        
        // Get input from user
        printf("Enter argument %d:", i+1);
        fgets(argv[i], MAX_ARG+1, stdin);
        argv[i][0] = '\0'; // Remove newline character
    }
    
    // Call base function for first argument
    specialized(&argc);
    
    // Call specialized function with remaining arguments
    for (int I=1; I<argc; i++) {
        base_function(argv[i]);
    }
    
    return 0;
}