
#include <stdio.h> /* for printf() */

/* Inline functions (called as 'inline' or 'unsafe' in C++) are faster than
   function definitions, and can be used to eliminate the definition of a
   function from the compiled code. Inlines must not have any side-effects,
   including function parameters or return values. */
#define INLINE_FUNCTION(name) \
    static inline void name() { /* implementation */ }

/* This is a sample input: 3 + 4 * 5 / 2 + 1 - (7 % 8); */
double powf(double x, double y)
{
    INLINE_FUNCTION(powf) /* definition of function with inline keyword */
        return pow(x, y);
}