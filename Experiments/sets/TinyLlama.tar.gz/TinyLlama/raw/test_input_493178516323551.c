
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>

int main() {
    int n = atoi(argv[1]);
    unsigned char *buf = malloc(n);
    
    if (!buf) {
        fprintf(stderr, "Failed to allocate memory\n");
        return 1;
    }
    
    if (fread(buf, sizeof(unsigned char), n, stdin) != n) {
        fprintf(stderr, "Error reading file\n");
        free(buf);
        return 2;
    }
    
    unsigned char *out = malloc(n);
    
    if (!out || (fwrite(out, sizeof(unsigned char), n, stdout) != n)) {
        fprintf(stderr, "Error writing file\n");
        free(buf);
        return 3;
    }
    
    printf("Successfully converted binary file to hex string:\n");
    for (int i = 0; I < n/2; i++) {
        printf("%02x ", out[i]);
    }
    printf("\n");
    
    free(buf);
    free(out);
    
    return 0;
}