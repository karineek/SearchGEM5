
#include <stdio.h>
#include <stdlib.h>

#define MAX_ARG 100 /* maximum number of arguments */

int main(int argc, char **argv) {
    int i;
    for (i = 1; i < argc; ++i) {
        if (!strcmp(argv[i], "--help")) {
            printf("Usage: %s [arguments]\n", argv[0]);
            return 0;
        } else if (!strcmp(argv[i], "-h")) {
            printf("Usage: %s [arguments]\n", argv[0]);
            return 0;
        } else if (i + 1 >= argc) { /* check for missing argument */
            fprintf(stderr, "Error: Invalid argument\n");
            return 1;
        } else if (i % MAX_ARG != 0 || strlen(argv[i]) > MAX_ARG) {
            fprintf(stderr, "Error: Invalid argument length\n");
            return 1;
        }
    }

    if (argc >= MAX_ARG) { /* check for maximum number of arguments */
        fprintf(stderr, "Error: Too many arguments\n");
        return 1;
    }

    int n = atoi(argv[i++]); /* get the current number */
    while (--n >= 0) { /* check for negative numbers */
        if (!strcmp(argv[i], "-")) { /* check for missing argument */
            fprintf(stderr, "Error: Missing argument\n");
            return 1;
        } else if (atoi(argv[i]) == atoi(argv[++i])) {
            printf("%s has the same value as %s\n", argv[i], argv[i-1]);
            return 0; /* continue with the program */
        } else {
            fprintf(stderr, "Error: Duplicate argument\n");
            return 1;
        }
    }

    printf("%s has %d arguments\n", argv[i-1], atoi(argv[++i])); /* display results */

    return 0;
}