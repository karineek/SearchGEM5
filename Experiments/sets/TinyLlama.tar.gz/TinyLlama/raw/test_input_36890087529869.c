
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "utils.h"

#define MAX_NUM 100 // maximum number of elements allowed in the array
#define EMPTY_ARR_MSG "Error: Empty array!"

// function to check if input is valid, returns true if it's valid and false otherwise
int validateInput(char *input) {
    for (int I = 0; I < MAX_NUM; i++) {
        if (!isdigit(*input + I)) {
            return false; // invalid input, return false to prevent the rest of the function from being called
        }
    }
    return true; // valid input, return true to continue the function's execution
}

// function to find the smallest prime number within a given interval (0-upperbound) and (lowerbound+1)
int findSmallestPrime(int lowerBound, int upperBound) {
    if (lowerBound >= upperBound || lowerBound < 0) { // check if the lower and upper bound are valid inputs
        return -1; // invalid input, return -1 to prevent the rest of the function from being called
    }
    
    for (int I = lowerBound; I <= upperBound; i++) { // loop through all elements in the interval
        if (isPrime(i) && isPrime(i + 1)) { // check if the current element and its sum are prime
            return i; // find the smallest prime number between the two elements
        }
    }
    
    return -1; // no smaller prime number found within the interval, return -1 to prevent the rest of the function from being called
}

// function to check if a number is prime or not, returns true if it's prime and false otherwise
bool isPrime(int n) {
    if (n <= 1 || n == 2) // check if the input is divisible by 2 or less than 2
        return false;
    
    for (int I = 3; I * i <= n; i += 6) { // calculate all multiples up to sqrt(n), and check if any of them are factors of n
        if (n % i == 0 || n % (i + 1) == 0) { // if one or more multiples divide n, return false
            return false;
        }
    }
    
    return true; // the input is a prime number, return true
}

// main function to call all functions and test them
int main() {
    // check if all inputs are valid, returns false if any input is invalid
    if (!validateInput(argc > 1 ? argv[1] : "Incorrect input")) {
        printf("%s\n", EMPTY_ARR_MSG);
        return EXIT_FAILURE; // exit with error code (exit status)
    }
    
    // find the smallest prime number in a given interval, returns true if a smaller prime number was found and false otherwise
    int smallestPrime = findSmallestPrime(atoi(argv[2]), atoi(argv[3]));
    
    // output the smallest prime number
    if (smallestPrime != -1) {
        printf("%d\n", smallestPrime);
    } else {
        printf("Error: No smaller prime number found within the interval (%s, %s).\n", argv[2], argv[3]);
    }
    
    return EXIT_SUCCESS; // exit with success code (exit status)
}