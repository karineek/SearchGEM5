
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s [-d | -s] FILE\n", argv[0]);
        exit(1);
    }
    
    const char *filename = argv[1];
    FILE *file;
    
    if (strcmp(argv[2], "-d") == 0) {
        file = fopen(filename, "r");
        if (!file) {
            perror("fopen() failed\n");
            return 1;
        }
        
        int ret = 0;
        while ((ret = getline(&file_buf[0], sizeof(file_buf), file)) > 0) {
            char *ptr = strtok(&file_buf[0], "\n");
            printf("%s", ptr);
        }
        
        fclose(file);
    } else if (strcmp(argv[2], "-s") == 0) {
        file = fopen(filename, "r");
        if (!file) {
            perror("fopen() failed\n");
            return 1;
        }
        
        char line[100];
        while ((line[0] = getline(&file_buf[0], sizeof(file_buf), file)) > 0) {
            printf("%s", line);
        }
        
        fclose(file);
    } else {
        perror("Invalid argument\n");
        return 1;
    }
    
    return 0;
}