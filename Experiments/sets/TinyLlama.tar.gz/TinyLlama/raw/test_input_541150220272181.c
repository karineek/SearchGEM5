
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s [options] <file>\n", argv[0]);
        return 1;
    }
    
    /* Read file */
    FILE *file = fopen(argv[1], "r");
    if (file == NULL) {
        perror("Failed to open file\n");
        exit(1);
    }
    
    /* Loop over files */
    size_t size = ftell(file);
    char *buffer = malloc(size + 1); // Allocate memory for buffer
    if (buffer == NULL) {
        perror("Failed to allocate memory\n");
        exit(1);
    }
    
    /* Read file into buffer */
    size_t read_size = fread(&buffer[0], 1, size, file);
    if (read_size != size) {
        perror("Failed to read file\n");
        exit(1);
    }
    
    /* Loop over files */
    for (int I = 0; I < size / sizeof(char); i++) {
        char *line = buffer + i * sizeof(char);
        printf("%s\n", line);
    }
    
    /* Close file */
    fclose(file);
    
    return 0;
}