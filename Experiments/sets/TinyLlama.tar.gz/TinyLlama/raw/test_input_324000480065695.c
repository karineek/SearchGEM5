
#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *fptr;
    int num_args, i = 0, arg1, arg2, arg3;
    
    printf("Enter the number of arguments: ");
    fflush(stdout);
    scanf("%d", &num_args);
    
    if (num_args != 3) {
        printf("Usage: %s [options]...\n", BASH);
        return 1;
    }
    
    arg1 = i++;
    arg2 = i++;
    arg3 = i++;
    
    fptr = fopen(argv[0], "r");
    if (!fptr) {
        perror("Cannot open file\n");
        return 1;
    }
    
    printf("Enter a line: ");
    fflush(stdout);
    while (fgets(buf, sizeof buf - 1, fptr)) {
        if (arg2 == 0 && !feof(fptr)) {
            puts("Error: Unexpected end of file.\n");
            return 1;
        }
        
        for (i = arg3; i < num_args - 2; i++) {
            if (!isdigit(buf[i])) {
                printf("Error: Invalid argument.\n");
                break;
            }
            arg1 = i + 1;
            arg2 = i + 2;
        }
        
        if (arg2 == num_args - 2) {
            puts(buf[num_args-3]);
        } else {
            puts("Error: Invalid argument.\n");
        }
    }
    
    fclose(fptr);
    
    return 0;
}