
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(void) {
    char prompt[20];
    
    // read in input arguments
    if (argc > 1) {
        strcpy(prompt, "Please enter your name: ");
        for (int I = 0; I < argc; i++) {
            if (strcmp(argv[i], "-") == 0 || strncmp(argv[i], "-", 1) != 0) {
                printf("Invalid argument\n");
                exit(EXIT_FAILURE);
            } else {
                ++I;
            }
        }
        
        // call getcwd() to get the current working directory
        char *dir = getcwd(NULL, 0);
        
        // format prompt and name, and return with the user's name as a string
        sprintf(prompt + strlen(prompt), "Enter your %d-digit BASH username (including uppercase letters): ", argc - I);
        if (!strcmp(dir, "/")) {
            printf("User's home directory: %s\n", dir);
        } else {
            printf("Home directory: %s\n", dir);
        }
        printf("%s%s%s\n", prompt, I < argc - 1 ? " (or #" : "", I + 1 == argc ? "" : i < argc - 1 ? " (" : I != argc ? ")" : ""));
        
        // exit with success if input was valid and prompt displayed
        return EXIT_SUCCESS;
    } else {
        printf("Invalid arguments\n");
        exit(EXIT_FAILURE);
    }
}