
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2 || argv[1][0] != '/') {
        printf("Usage: %s file\n", argv[0]);
        return 1;
    }
    
    FILE *file = fopen(argv[1], "r");
    
    if (!file) {
        perror("Failed to open input file");
        return 2;
    }
    
    char buffer[1024];
    int read_size = 0;
    while (fread(buffer, sizeof(char), 1, file) > 0 && (read_size += fread(buffer, sizeof(char), 1, file))) {
        printf("%c\n", buffer[0]);
        
        // Inlining optimizations for thrd_current function
        if ((strcmp(argv[0], "thrd_current") == 0) && (read_size >= 5)) {
            char *p = buffer + sizeof(char);
            
            while (*p != '\n') {
                p++;
            }
            
            printf("%s\n", buffer);
        }
    }
    
    fclose(file);
    return 0;
}