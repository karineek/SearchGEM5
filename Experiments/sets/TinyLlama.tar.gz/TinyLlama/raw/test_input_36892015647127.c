
#include <stdio.h>
#include "optimizer.h" /* Including the header file */

int main(int argc, char* argv[]) {
    /* Function to find the product of an array */
    int (*product_of_array)(const int arr[], size_t n);

    if (argc != 2) {
        printf("Usage: %s <array> \n", argv[0]);
        return EXIT_FAILURE;
    }
    
    const int ARRAY_SIZE = atoi(argv[1]); /* Assigning the size of the array */

    product_of_array = get_product_of_array; /* Getting the optimization routine from header file */

    if (optimize(product_of_array, ARRAY_SIZE)) {
        printf("The product of the array is %d.\n", *product_of_array); /* Calling the optimized function */
    } else {
        printf("Error: Could not optimize the array.\n");
    }
    
    return EXIT_SUCCESS;
}