
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s [input_file]\n", argv[0]);
        exit(1);
    }
    
    FILE *input_file = fopen(argv[1], "r");
    if (!input_file) {
        perror("Error opening input file");
        return 1;
    }
    
    char buffer[8192];
    size_t readed_size = 0;
    while (fread(buffer, sizeof(char), sizeof(buffer), input_file) == sizeof(buffer)) {
        printf("%s", buffer);
        readed_size += fread(buffer, sizeof(char), sizeof(buffer), input_file);
    }
    
    fclose(input_file);
    
    return 0;
}