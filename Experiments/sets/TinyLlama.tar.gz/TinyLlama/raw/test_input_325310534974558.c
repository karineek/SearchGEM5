
#include <stdio.h>
#include <stdlib.h>

#define NB_SAVED_PARAMS 3

void save_params(int nb_params, int *params) {
    printf("Saving %d parameters to memory...\n", NB_SAVED_PARAMS);

    for (int I = 0; I < nb_params; i++) {
        printf("%d: %d\n", I, params[i]);
    }
}

int main() {
    int nb_params;
    int *params = NULL;
    
    // Read number of parameters from command line (or system input)
    char **argv = (char **)malloc(NB_SAVED_PARAMS*sizeof(char*));
    for (int I = 0; I < NB_SAVED_PARAMS; i++) {
        argv[i] = strdup(argv[i]); // Copy to command line buffer
    }
    
    if (!getenv("SIGFPENAME") || !getenv("SIGPADDR")) {
        printf("No SIGFPED or SIGPADDR environment variable provided!\n");
        free(argv);
        exit(1);
    } else {
        // Initialize variables (can be done elsewhere)
        params = malloc(NB_SAVED_PARAMS * sizeof(int));

        // Read and save parameters to memory from command line buffer
        for (int I = 0; I < NB_SAVED_PARAMS; i++) {
            char **saveme = argv[i] + strlen(argv[i]) - 1;
            *saveme = '\0'; // Remove newline character from end of buffer
        }
        
        // Save parameters to command line buffer (for debugging)
        for (int I = 0; I < NB_SAVED_PARAMS; i++) {
            sprintf(argv[i], "%d: %d", I, params[i]);
        }
    }
    
    // Call SIGFPENAME macro to invoke Loop-Invartant Code Motion (LICM) optimization on input buffer
    save_params(NB_SAVED_PARAMS, params);
    
    // Check if LICM optimization was successful and print output (or error messages depending on success)
    printf("LICM optimized parameters: ");
    for (int I = 0; I < NB_SAVED_PARAMS; i++) {
        printf("%d: %d\n", I, params[i]);
    }
    
    return 0;
}