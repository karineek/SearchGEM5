
#include <stdio.h>

void print_usage(const char* name) {
    fprintf(stderr, "Usage: %s [options] FILE\n", name);
}

int main(int argc, char** argv) {
    if (argc != 3) {
        print_usage("C compiler");
        return 1;
    }
    
    const char* optimization = "opt";
    if (!strcmp(argv[1], "-O")) {
        optimization = "";
    } else if (!strcmp(argv[1], "-O2")) {
        optimization = "--optimize=2";
    } else if (!strcmp(argv[1], "-O3")) {
        optimization = "--optimize-speed";
    } else {
        print_usage("Invalid option: -O");
        return 1;
    }
    
    const char* file_name = argv[2];
    
    // Load the input into a buffer from disk (using FILE* interface)
    int fd = open(file_name, O_RDONLY);
    if (fd < 0) {
        perror("Could not open file");
        return 1;
    }
    
    // Close the input stream
    close(fd);
    
    printf("Loading %s...\n", file_name);
    
    // Generate an error if the program failed to load the input
    char* buffer = read(0, &buffer_size, 1);
    if (buffer == NULL) {
        perror("Failed to read file");
        return 1;
    }
    
    void (*function)(void*) = dlsym(RTLD_NEXT, "main");
    function();
    
    printf("Done loading %s.\n", file_name);
}