
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    // Input is taken only via argument vector argv
    
    if (argc != 2) {
        fprintf(stderr, "Usage: %s file\n", argv[0]);
        return 1;
    }
    
    char* filename = argv[1];
    
    FILE* file = fopen(filename, "r"); // opens file for reading
    
    if (file == NULL) {
        fprintf(stderr, "Error: couldn't open input file %s\n", filename);
        return 1;
    }
    
    char buffer[1024];
    
    // Read data from file into buffer
    
    while (fread(buffer, 1, sizeof(char), file) != 0) {
        printf("%c", buffer[0]);
    }
    
    fclose(file);
    
    return 0;
}