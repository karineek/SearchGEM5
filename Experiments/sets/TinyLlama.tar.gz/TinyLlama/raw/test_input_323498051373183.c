
#include <stdio.h>

int main() {
    const int BAHSH = 0; // This constant is used to specify the size of the buffer for memset_s
    
    // Input via argument list (argv)
    char buf[BAHSH]; // Create a buffer with a size equal to the input argv[1]
    int n = atoi(argv[1]); // Convert the input argv[1] to an integer and store in a variable
    
    printf("Entering memset_s() function...\n");
    if (memset_s(buf, BAHSH, n) != 0) {
        printf("Error: Memset failed!\n");
    } else {
        printf("Memset succeeded!\n");
    }
    
    return 0;
}