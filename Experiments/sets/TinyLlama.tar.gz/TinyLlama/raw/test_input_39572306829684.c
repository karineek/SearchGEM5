
#include <stdio.h> /* for printf() and fputs() */
#include <stdlib.h> /* for exit() */

int main(int argc, char *argv[]) {
    int x = atoi(argv[1]);  /* gets the input as a integer */
    int y = atoi(argv[2]);  /* gets the second input as a integer */

    if (x < 0 || y < 0) {
        printf("Invalid input. Please enter non-negative integers.\n");
        exit(1);
    } else {
        /* perform some operation on x and y using atomic_store_explici() */
        int z = atomic_store_excl(&x, &y, 1); /* atomic_store_excl() stores the second variable to its exclusive-lock memory location */
        printf("Result: %d (%d + %d) = %d\n", x, x, y, z);
    }

    return 0;
}