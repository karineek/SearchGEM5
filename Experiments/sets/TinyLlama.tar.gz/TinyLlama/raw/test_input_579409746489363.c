
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAXLINE 1024

void print_error(const char* msg, ...){
    va_list args;
    va_start(args, msg);
    vfprintf(stderr, msg, args);
    va_end(args);
    exit(EXIT_FAILURE);
}

void* memory_optimizer(void** ptr, size_t* size, int argc, char *argv[]){
    if(argc == 2){
        const char* filename = argv[1];
        FILE* file = fopen(filename, "r");
        if(!file){
            print_error("Cannot open file: %s", filename);
            return ptr;
        }
        int line_count = 0;
        size_t buffer_size = MAXLINE + sizeof("//") - 1; // add space for comment and newline
        char buffer[buffer_size];
        buffer[buffer_size-1] = '\n'; // add newline at the end of buffer
        int i, j, k;
        char* line_ptr = buffer;
        for(i=0; fgets(*ptr, *size, file); i++){
            if(line_count == 0){
                strcpy(line_ptr, "//"); // add comment at the beginning of line
                line_ptr += sizeof("//") - 1; // add newline to end of comment
            }else{
                k = strcspn(line_ptr, "\r\n");
                if(k > 0){
                    strcpy(line_ptr + k, " ");
                }
                line_ptr += strlen(line_ptr); // add space to end of line
            }
            line_count++;
        }
        *size = (int)(sizeof(buffer[0])*line_count+2) / 3; // round up size to 3 bytes
        fclose(file);
        return ptr;
    }else{
        print_error("Invalid usage: %s", argv[0]);
        return ptr;
    }
}

int main(int argc, char *argv[]){
    if(argc == 2){
        FILE* file = fopen(argv[1], "r");
        if(!file){
            print_error("Cannot open file: %s", argv[1]);
            return 1;
        }
        const char* filename = argv[1];
        char buffer[MAXLINE+sizeof("//")] = {0};
        int line_count = 0;
        size_t buffer_size = MAXLINE + sizeof("//") - 1; // add space for comment and newline
        if(fgets(buffer, buffer_size, file) == NULL){
            print_error("Cannot read file: %s", argv[1]);
            return 2;
        }
        fprintf(stderr, "File '%s':\n%.*s\n", filename, MAXLINE+1, buffer);
        char* line = buffer + sizeof("//") - 1; // remove newline at the end of comment
        for(int I=0; I<MAXLINE; i++){
            if(*line == '\n'){
                *line_ptr = 0; // replace newline with empty string, which is not a newline character
                line_ptr += sizeof("//") - 1; // remove newline from comment
            }else{
                line_ptr[i] = '\0'; // replace newline with null character, which is a newline character
            }
            line++;
        }
        line_count++;
        fclose(file);
    }else{
        print_error("Invalid usage: %s", argv[0]);
    }
}