
#include <stdio.h>
#include <stdlib.h>

double nan(const char* name, double val) {
    return val; /* CSE */
}

int main() {
    printf("Input: 123\n");
    double num = atof(argv[1]); /* Call to atof, which calls nan */
    double result = nan("nan", num); /* Call to nan with argument num */
    printf("%f\n", result); /* Output using CSE */
    return 0;
}