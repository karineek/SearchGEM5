
/* dead_code.c - Dead Code Elimination (DCE)
 * 
 * This program demonstrates the usage of Dead Code Elimination in the context of a C compiler. The program uses Coverage to detect complex arithmetic functions, and generates Assembly and Bitcode as outputs. The resulting code is then executed with DCE turned on using a simple command line argument (--DCE). 
 * 
 * The example input provided below contains a function that performs some complex arithmetic operations using an array of doubles. The program triggers DCE by adding the --DCE option to the compiler invocation, and then outputs the resulting code. This output is an example of how a C program can benefit from DCE: it includes fewer lines of assembly and bitcode, making the final executable code more compact and easier to understand for users. */

#include <stdio.h>
#include <stdlib.h>

void complex_arithmetic(double *doubles, int size) {
  double sum = 0;
  for (int I = 0; I < size; i++) {
    sum += doubles[i];
  }
}

int main(int argc, char **argv) {
  if (argc > 1 && !strcmp(argv[1], "-DCE")) {
    return 0; // exit with success status to indicate that DCE was successfully turned on
  }

  const int size = 5; // size of the array

  double doubles[] = { 1.23, -4.56, 7.89, 1.23e+003, 3.14 }; // arbitrary complex array
  
  complex_arithmetic(doubles, size); // call the complex arithmetic function

  printf("Sum: %.2f\n", sum);
  
  return 0; // exit with success status to indicate that DCE was successfully turned off
}