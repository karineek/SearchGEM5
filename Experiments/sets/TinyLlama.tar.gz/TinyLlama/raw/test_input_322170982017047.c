
#include <stdio.h>
#include <stdlib.h>

int main() {
    int num;
    
    // Input is taken via argv only
    if (argc != 2) {
        printf("Invalid input, please provide a number.\n");
        return 1;
    }
    
    // Triggering Common Subexpression Eliminatioon optimization
    num = strtoul(argv[1], NULL, 0);
    
    // Concetative example of an input
    printf("%d\n", num);
    
    return 0;
}