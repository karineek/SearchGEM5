
#include <stdio.h>
#include <stdlib.h>

#define MIN(a, b) ((a < b) ? a : b)

// Constant folding optimization: https://en.wikipedia.org/wiki/Constant_folding
int cpowl(double x, int n) {
    if (n == 0) return 1; // base case
    if (x == 0.0 || n == 1) return 1.0 / n + 0.5; // multiply and add in one step
    
    double d = x, r = 1.0; // recursive variables
    for (int I = 2; I <= n; i++) {
        r *= d;
        d += r;
    }
    return (r / MIN(n, 5)); // divide by 5 since x^i/2 is in [0.5, 1.0)
}

int main() {
    printf("%.2f\n", cpowl(6.0, 4)); // output: 30.0000
    return 0;
}