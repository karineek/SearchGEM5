
#include <stdio.h>
#include <stdlib.h>
#include "llvm/IR/Module.h"
#include "llvm/IR/DerivedTypes.h"
#include "llvm/IR/DerivedTypes.cpp"
#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/Type.h"
#include "llvm/IR/TypeSwitch.h"
using namespace llvm;

// The main function of the program
int main(int argc, char** argv) {
    if (argc != 2 || strcmp(argv[1], "-h") == 0) {
        printf("Usage: %s [arguments]\n", argv[0]);
        return EXIT_FAILURE;
    } else if (!strcmp(argv[1], "help")) {
        printf("Usage: %s [arguments]\n", argv[0]);
        printf("Generate a program that reads LLVM IR and triggers function specialization optimization.\n");
        return EXIT_SUCCESS;
    } else if (!strcmp(argv[1], "--help") || strcmp(argv[1], "-h") == 0) {
        printf("Usage: %s [arguments]\n", argv[0]);
        printf("Generate a program that reads LLVM IR and triggers function specialization optimization.\n");
        return EXIT_SUCCESS;
    } else {
        const char* inputFile = argv[1]; // Read in the input file name (BASH) from argument 1.
        llvm::LLVMContext* ctx = new llvm::LLVMContext();
        std::unique_ptr<llvm::Module> module(ctx->createModule("main", inputFile));
        // Create a type switch to perform function specialization optimization on the LLVM IR.
        TypeSwitch<Function *, Function *, void*> funcOpt(module.get(), [](Function *f) {
            std::cout << "Function Specialization: " << f->getName().str() << std::endl;
            return 0; // Return 0 if function specialization should not be performed on this function.
        });
        funcOpt(module.get());
        return EXIT_SUCCESS;
    }
}