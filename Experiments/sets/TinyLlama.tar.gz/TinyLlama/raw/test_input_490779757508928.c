
#include <stdio.h>
#include <stdint.h> // include uintptr_t for vectorization optimization and middle-end implementation

void foo(uint32_t a) { printf("A = %d\n", a); } // Input value will be taken from argument 1 (argv[1])

int main() {
    int32_t arg = (int32_t) getarg(1, ""); // get argv value as int32_t and pass it to foo function
    foo(arg);
    
    return 0;
}