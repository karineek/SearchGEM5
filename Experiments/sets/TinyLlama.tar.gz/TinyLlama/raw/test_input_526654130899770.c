
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h> /* for tempnam() */

#define VECTORIZE 1

int main(int argc, char *argv[]) {
    int i;
    char filename[50];

    srand(time(NULL));   // seed randomness generator
    
    if (argc < 2) {       // if no input filename provided, exit
        fprintf(stderr, "Usage: %s [filename] [-V]\n", argv[0]);
        return EXIT_FAILURE;
    }

    filename[0] = '\0';   // initialize filename to empty string
    
    if (VECTORIZE) {      // if vectorization is on, call tmpnam_s with a random suffix
        sprintf(filename, "%s.%d", argv[1], rand() % 26 + 'a');
    } else {              // otherwise, call tmpnam_s without a random suffix
        snprintf(filename, sizeof(filename), "%s", argv[1]);
    }
    
    FILE *tmp = tempnam(NULL, NULL); // open temporary file in backend
    
    if (!tmp) {            // check for error opening temporary file
        fprintf(stderr, "Failed to create temporary file\n");
        return EXIT_FAILURE;
    } else {                // otherwise, handle success of creating temporary file
        int rc = 0;         // initialize temp file status counter to 0
        
        while (1) {          // loop until tmpfile is closed or an error occurs
            if (rc > 0 && rc < 256) {   // handle errors by incrementing counter
                sprintf(filename + rc, "%s%d", argv[1], rand() % 26 + 'a');
                rc = 0;                    // reset temp file status counter to zero
            } else if (rc == 254) {     // handle end-of-file by closing temporary file
                fclose(tmp);           // close temporary file in backend
                return EXIT_SUCCESS;   // exit successfully
            } else {                    // handle other errors as needed
                perror("Failed to create temporary file");
                return EXIT_FAILURE;
            }
        }
    }
    
    return EXIT_SUCCESS; // exit successfully
}