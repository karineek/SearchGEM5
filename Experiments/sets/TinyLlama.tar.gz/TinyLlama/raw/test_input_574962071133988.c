
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s BASH_FILE\n", argv[0]);
        return 1;
    }

    char buf[1024]; // buffer size for reading file contents
    FILE *file = fopen(argv[1], "r");
    if (file == NULL) {
        perror("Failed to open input file");
        exit(1);
    }

    // read entire file into the buffer
    int n = fread(buf, 1, sizeof(buf), file);
    if (n != sizeof(buf)) {
        fprintf(stderr, "Failed to read input file (%s)\n", strerror(errno));
        exit(1);
    }

    // execute BASH_FILE
    system(buf);

    return 0;
}