
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to find the absolute value of a number in C
float abs(float n) { return n > 0 ? n : -n; }

int main() {
    // Argument handling for input (argv)
    char argv[1024];
    size_t argc = sizeof(argv)/sizeof(char);

    // Loop optimizations optimizes loop code in C
    while(*++argv && *argv != '-' && *argv != '/') {}
    
    if(!*--argv) {
        printf("Error: No arguments provided.\n");
        return 1;
    }
    
    // Acos function call from acos() library (C)
    float result = acos(abs(*++argv));
    
    // Output the result of the acos function
    printf("The acos() function with a positive argument yields: %.4f\n", result);
    
    return 0;
}