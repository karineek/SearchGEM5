
#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int ret;
    
    if (argc != 2) {
        fprintf(stderr, "Usage: %s [executable file]\n", argv[0]);
        exit(1);
    }
    
    const char *filename = argv[1];
    
    // Initialize timer
    struct timespec ts;
    ts.tv_sec = 0;
    ts.tv_nsec = 1000000; // 1 millisecond resolution
    if (settimeofday(&ts, NULL)) {
        fprintf(stderr, "Error setting timer: %s\n", strerror(errno));
        return 1;
    }
    
    // Open executable file for reading and writing
    FILE *file = fopen(filename, "r+b");
    if (file == NULL) {
        fprintf(stderr, "Error opening file: %s\n", filename);
        return 1;
    }
    
    // Start profiling timer and initialize profile counters
    if (pcoptimize_init(file)) {
        fprintf(stderr, "Error initializing PCOP: %s\n", strerror(errno));
        return 1;
    }
    
    // Call optimization pass and gather profiling data
    int ret = pcoptimize_run(file);
    if (ret) {
        fprintf(stderr, "Error optimizing %s: %s\n", filename, strerror(errno));
        return 1;
    }
    
    // Cleanup and close profiling data
    pcoptimize_cleanup();
    if (pcoptimize_close()) {
        fprintf(stderr, "Error closing PCOP: %s\n", strerror(errno));
        return 1;
    }
    
    // Show profiling data
    printf("Optimization time %.3f seconds\n", (double)pcoptimize_get_time() / 1000.0);
    
    // Cleanup timer and close file if not previously opened
    pcoptimize_cleanup();
    if (file) fclose(file);
    
    return 0;
}