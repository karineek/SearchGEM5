
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(void) {
    char argv[1024];  // maximum number of arguments allowed by BASH
    int argc = 0;      // initial value for argument count
    
    while (1) {         // infinite loop to handle user input
        sprintf(argv + 1, "%s", getenv("BASH_VERSION"));  // append version info
        if (argc > 0 && argv[0][0] == '/') {               // check for '/' in first argument
            argc = 1;
            printf("%s %s\n", "Usage: ", argv[0]);        // print usage message
            continue;                                    // exit loop and wait for user input
        } else if (argc > 0) {                           // check for argument(s)
            int c, i = 0;
            while (1) {
                sprintf(argv[i], "%c", getchar());
                if (!isprint(c = argv[i][0])) break;      // handle non-printable characters
                if (argc == 0 && c == '/')                     // handle first argument as 'command'
                    printf("%s\n", argv[i]);
                else if (!isalnum(c)) {                      // check for valid input
                    printf("Invalid input: %s", argv[i]);
                    continue;
                } else break;
            }
        } else {                                          // handle empty argument
            printf("%s\n", argv[0]);
        }
        if (argc != 1 || !getenv("BASH_VERSION")) break;   // check for correct number and version of BASH
    }
    return 0;
}