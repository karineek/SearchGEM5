
#include <stdio.h>
#include <stdlib.h>

int main() {
    double a, b, c;
    int i = 0;
    
    // get input values from argv
    while((i + 1) < (argc - 1)) {
        if(i % 2 == 0) {
            sscanf(argv[i], "%lf %*s", &a);
            sscanf(argv[i+1], "%lf %*s", &b);
            
            c = a / b;
            printf("The DivideAssignOptimized (%lf/%lf) = %.2f\n", a, b, c);
        } else {
            printf("Invalid input.\n");
            return 0;
        }
        
        i++;
    }
    
    // check if input is valid
    if(i == (argc - 1)) {
        printf("Input: %s\n", argv[0]);
        printf("DivideAssignOptimized (%lf/%lf) = %.2f\n", a, b, c);
    } else {
        printf("Invalid input.\n");
        return 0;
    }
    
    return 0;
}