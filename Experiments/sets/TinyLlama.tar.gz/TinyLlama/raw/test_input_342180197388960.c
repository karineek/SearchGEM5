
#include <stdio.h>

int main() {
    int num = 0;
    unsigned long long int i;
    
    // input from argv only
    for(i=1; i<argc; i++) {
        char ch = tolower(argv[i][0]);
        
        // SCCP optimizations:
        // 1. Replace non-digit characters with 0 (binary)
        if(!isdigit(ch)) {
            num *= 2;
            num += ch - '0';
            num %= 10;
        }
    }
    
    printf("%d\n", num);
    
    return 0;
}