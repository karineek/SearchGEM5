
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char** argv) {
    if (argc != 2 || !strcmp(argv[1], "BASH")) {
        printf("Usage: %s BASH\n", argv[0]);
        return 0;
    }
    
    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen");
        exit(EXIT_FAILURE);
    }
    
    char buf[32] = {0};
    while (fgets(buf, sizeof(buf), fp)) {
        printf("%s", buf);
    }
    fclose(fp);
    
    return 0;
}