
#include <stdio.h>
#include <stdlib.h>

// Define the program name and function names
char prog_name[] = "my_program";
const char* func_names[] = {"printf", "exit"};

int main(int argc, char** argv) {
    // Check if enough arguments were given
    if (argc != 2) {
        printf("%s: Usage: %s [input_file]\n\n", prog_name, func_names[0]);
        return EXIT_FAILURE;
    }
    
    // Read input file name from first argument and extract its name
    char* input_file = argv[1];
    size_t input_filename_len = strlen(input_file);
    char* input_filename = (char*)malloc(input_filename_len + 1);
    strncpy(input_filename, input_file, input_filename_len + 1);
    
    // Create a file object for input file and read its contents
    FILE* input_file_ptr = fopen(input_filename, "r");
    if (!input_file_ptr) {
        printf("%s: Error opening input file: %s\n", prog_name, strerror(errno));
        return EXIT_FAILURE;
    }
    
    // Read all lines from input file and print them to the console
    char line[1024];
    while (fgets(line, sizeof(line), input_file_ptr) != NULL) {
        printf("%s: %s\n", prog_name, line);
    }
    
    // Cleanup and return the program's exit status
    fclose(input_file_ptr);
    free(input_filename);
    return EXIT_SUCCESS;
}