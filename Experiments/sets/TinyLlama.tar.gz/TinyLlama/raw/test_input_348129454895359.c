
#include <stdio.h>
#include <stdlib.h>

// Main program
int main(int argc, char **argv) {
    int n = atoi(argv[1]); // take input from command line arguments
    if (n <= 0 || n >= 3) {
        printf("Invalid input: Must be between 2 and 4\n");
        return 1;
    }

    int **arr = calloc(n, sizeof *arr); // allocate memory for array
    if (!arr) {
        perror("calloc failed");
        exit(EXIT_FAILURE);
    }
    
    printf("Initializing array: \n");
    for (int I = 0; I < n; i++) {
        arr[i] = calloc(n, sizeof *arr[0]);
        if (!arr[i]) {
            perror("calloc failed for element %d\n", i);
            exit(EXIT_FAILURE);
        }
        
        printf("\t%d: ", I + 1);
        for (int j = 0; j < n; j++) {
            if (!arr[i][j] || arr[i][j] == INFINITY) {
                perror("Infinity in element %d, element %d\n", i + 1, j + 1);
                exit(EXIT_FAILURE);
            }
            printf("%.2f ", arr[i][j]);
        }
        
        putchar('\n');
    }
    
    printf("Done.\n");
    
    // Main program: Call function, pass in array and output result
    int (*func)(int*, int*) = (int(*)())malloc(sizeof *func);
    func = (int(*)())calloc(4, sizeof *func);
    if (!func) {
        perror("calloc failed for func");
        exit(EXIT_FAILURE);
    }
    
    printf("Function is: %p\n", func); // print pointer to function
    
    printf("Entering main()\n");
    int num = 1;
    while (num <= n) {
        for (int I = 0; I < n - num + 1; i++) {
            if (!statical_analyz(arr[i], n - num + 1, func, &num)) {
                perror("Infinite loop in function");
                exit(EXIT_FAILURE);
            }
        }
        
        printf("\n"); // output function result for each element of input array
        int res = (*func)(arr[0], n - num + 1);
        if (res != INFINITY) {
            printf("Function %d(%.2f, %d): %.2f\n", num, arr[0][num - 1], n, res);
            printf("Done.\n");
        } else {
            perror("Infinite loop in function");
            exit(EXIT_FAILURE);
        }
        
        num++; // advance to next input element
    }
    
    return 0;
}