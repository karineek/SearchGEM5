
#include <stdio.h>

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s file\n", argv[0]);
        return -1;
    } else {
        FILE *f = fopen(argv[1], "r");
        if (!f) {
            perror("failed to open file for reading\n");
            exit(1);
        }
        char buf[1024];
        int size;
        while ((size = fread(buf, 1, sizeof(buf)-1, f)) != 0) {
            printf("%.*s", (int)size, buf);
        }
        fclose(f);
        return 0;
    }
}