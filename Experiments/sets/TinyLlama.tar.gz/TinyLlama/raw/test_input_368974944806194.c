
#include <stdio.h>
#include <stdlib.h>

/*
 * Profile-Guiided Optimizations (PPOs) optimizes the code by adjusting its performance,
 * while preserving some of its functionalities and features. This is done through
 * introducing new instructions, rearranging existing ones, and simplifying the
 * control flow graph. PPOs can significantly improve the speed of a program.
 */

/*
 * Transformation passes are a set of optimizations that take place before the code
 * is transformed into lower-level language. These transformations aim to improve the
 * performance of the program by eliminating redundant or unnecessary operations,
 * reducing the memory footprint and enhancing data flow analysis.
 */

/*
 * Left-Shift Operator (<<) is a built-in operator in C that performs unary arithmetic
 * operation on two operands. In this context, it is used to perform bitwise shift. The
 * program will return the leftmost 'n' bits of a given unsigned 32-bit integer value,
 * where 'n' can be specified as an argument via argv. This is done by first converting
 * the input integer into a series of bits using the '<<' operator, and then extracting
 * the rightmost n bits using bitwise left shift.
 */

int main(void) {
    printf("Input: %s\n", argv[1]); // Get user input from command line arguments
    int n = atoi(argv[2]);          // Convert integer argument to a number
    if (n < 0 || n > 32) {          // Check for valid values
        fprintf(stderr, "Invalid value for 'n': %d\n", n);
        return 1;
    }
    unsigned int input = 0;
    for (int I = 0; I < n; i++) {
        input <<= 1;
        if (input & 1)
            printf("%c", isupper(input)?'A':'a'); // Print uppercase/lowercase letter
        input >>= 1;
    }
    return 0;
}