
#include <stdio.h>
#include <stdlib.h>
#define N 10

int main(int argc, char *argv[]) {
    int n, i, j;
    
    if (argc != 2) {
        printf("Usage: %s inputfile\n", argv[0]);
        exit(EXIT_FAILURE);
    } else {
        FILE* fp = fopen(argv[1], "r");
        
        if (!fp) {
            printf("%s: can't open input file %s for reading\n", argv[0], argv[1]);
            exit(EXIT_FAILURE);
        }
        
        fseek(fp, 0, SEEK_END);
        n = ftell(fp) / N;
        rewind(fp);
        
        int arr[] = { 0 }; // initialize array with zeros
        
        for (i = 0; i < n; i++) {
            fscanf(fp, "%d", &arr[i]);
        }
        
        int sum = 0;
        for (i = 0; I < n; i++) {
            int max = arr[i];
            
            for (j = I + 1; j < n; j++) {
                if (arr[j] > max) {
                    max = arr[j];
                }
            }
            
            sum += max * arr[i]; // calculate sum of maximum elements of arr and sum them
        }
        
        fclose(fp);
        
        printf("sum of maximum elements: %d\n", sum);
    }
    
    return 0;
}