
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include "logb.sh"

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s [-r|-a] <input>\n", argv[0]);
        return 1;
    }

    int ret = signal(SIGINT, sig_handler);
    if (ret == -1) {
        perror("signal");
        exit(EXIT_FAILURE);
    }

    char *input = argv[1];
    int len = strlen(input);
    logb(input, 0, len);

    if (ret == 0) {
        signal(SIGINT, sig_handler); // restore signal handling
        printf("Signal handler exited with status %d\n", ret);
        exit(EXIT_SUCCESS);
    }
    
    return 0;
}