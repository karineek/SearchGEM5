
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv) {
    int ret = 0;
    char *input = NULL;
    size_t input_len = 0;
    
    if (argc != 2 || !strcmp(argv[1], "-h")) {
        fprintf(stderr, "Usage: %s [-h] input\n", argv[0]);
        return EXIT_FAILURE;
    } else if (!strcmp(argv[1], "--help")) {
        fprintf(stdout, "%s\n", help);
        return EXIT_SUCCESS;
    }
    
    input_len = strtol(argv[1], NULL, 0);
    if (input_len == -1 || input_len > MAX_INPUT_LEN) {
        fprintf(stderr, "Invalid input length: %zu\n", input_len);
        return EXIT_FAILURE;
    } else if (!input) {
        fprintf(stderr, "Input cannot be nullptr\n");
        return EXIT_FAILURE;
    } else {
        input = (char *)malloc(sizeof(char) * input_len);
        if (!input) {
            fprintf(stderr, "Failed to allocate memory for input\n");
            return EXIT_FAILURE;
        }
        
        memset(input, 'x', sizeof(char) * input_len); // zero out unused memory
        
        if (read(STDIN_FILENO, input, input_len) != input_len) {
            fprintf(stderr, "Failed to read input from standard input\n");
            return EXIT_FAILURE;
        }
    }
    
    if (!strcmp(argv[2], "-")) {
        // execute the program without arguments or with only -h
        int status = system(input);
        
        if (status < 0) {
            perror("Failed to execute program\n");
            return EXIT_FAILURE;
        }
    } else {
        // read input from standard input and execute the program with arguments
        int status = system(input);
        
        if (status < 0) {
            perror("Failed to execute program\n");
            return EXIT_FAILURE;
        }
    }
    
    free(input);
    input = NULL;
    
    return status;
}