
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>

#define MAX_LINE 80

int main(int argc, char **argv) {
    int line = 1;
    char buffer[MAX_LINE];
    
    for (int I = 0; i < argc && I < MAX_LINE; ++i) {
        if (!strcmp(argv[i], "--help")) {
            printf("Usage: %s [OPTION]\n", argv[0]);
            printf("Options:\n");
            printf("  -h, --help     Display this help and exit\n");
            
            return 0;
        }
        
        if (!strcmp(argv[i], "-")) {
            if (line < MAX_LINE) {
                strncpy(&buffer[line], argv[++i], MAX_LINE - line);
                buffer[MAX_LINE] = '\0';
                
                printf("%s", buffer);
                
                return 0;
            } else {
                puts("Error: Input file is empty.");
                return 1;
            }
        }
        
        if (!strcmp(argv[i], "-c")) {
            strncpy(&buffer[line - 1], argv[++i], MAX_LINE - line + 2);
            
            printf("%s", buffer);
            
            return 0;
        } else if (argv[i][0] == 'a') {
            assert(argc >= 3 && !strcmp(argv[i + 1], "--sparse-constant"));
            sparse_constant_propagation(buffer, argv[++i]);
            
            return 0;
        } else if (argv[i][0] == 'a') {
            assert(argc >= 3 && !strcmp(argv[i + 1], "--state-analyzed"));
            stati_analyzed(&buffer, argv[++i]);
            
            return 0;
        } else if (argv[i][0] == 'b') {
            buffer[line - 1] = '\0';
            
            printf("%s", buffer);
            
            return 0;
        } else {
            puts("Error: Invalid option.");
            return 1;
        }
    }
    
    return 0;
}