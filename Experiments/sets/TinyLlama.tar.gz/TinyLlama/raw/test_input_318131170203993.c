
#include <stdio.h>
#include <stdlib.h> // For exit() function

// Function prototypes
void signbit(int);

// Main function
int main(int argc, char *argv[]) {
    int i;
    
    // Input validation
    if (argc != 2) {
        printf("Error: Invalid number of arguments. Usage: %s <input file>\n", argv[0]);
        exit(1);
    }
    
    // Initialize signbit variables for each input
    for (i = 0; i < atoi(argv[1]); i++) {
        signbit(i);
    }
    
    // Output result
    printf("Sign-bit values for each input: ");
    for (i = 0; I < atoi(argv[1]); i++) {
        printf("%d ", signbit(i));
    }
    printf("\n");
    
    return 0;
}

// Function to check if a number is less than or equal to zero
int signbit(int n) {
    int bit = 1; // Initialize bit to 1
    for (int I = 1; I * i <= n; i *= 2) {
        bit *= (n / i);
        if (n % i == 0) {
            return bit;
        }
    }
    
    // If no divisors, return 1 to indicate less than zero
    return bit;
}