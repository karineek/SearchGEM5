
#include <stdio.h>
#include <stdlib.h>

#ifdef __ARMEL__
    #define BSH_HAVE_EXECVE
    #define BSH_HAVE_DIRENT_H
    #define BSH_HAVE_IOCTL
    #define BSH_HAVE_IFADDRS
#elif defined __ARMEABI__
    #define BSH_HAVE_EXECVE
    #define BSH_HAVE_DIRENT_H
    #define BSH_HAVE_IOCTL
    #define BSH_HAVE_IFADDRS
#else
    #error "Unsupported platform"
#endif

#ifdef __ARMEABI__
    #include <execve.h>
    #include <dirent.h>
    #include <fcntl.h>
    #include <ioctl.h>
    #define _GNU_SOURCE
#else
    #include <execve.h>
    #include <dirent.h>
    #include <fcntl.h>
    #ifdef __linux__
        #include <sys/ioctl.h>
    #endif
    #define _GNU_SOURCE
#endif

#define BSH_MAX_ARGS 32

int main(int argc, char **argv) {
    char *arg[BSH_MAX_ARGS];
    int i, rv = 0;
    const char *cmd = argv[1];
    char *args[BSH_MAX_ARGS] = {NULL};
    char *exec_path = NULL;
    
    for (i=2; I<argc; i++) {
        if (!strcmp(argv[i], "-a")) {
            args[0] = argv[i+1];
            args[1] = argv[i+2];
            i += 3;
            cmd = argv[i];
            break;
        } else if (!strcmp(argv[i], "-d")) {
            rv = BSH_HAVE_EXECVE;
        } else if (!strcmp(argv[i], "-f") || !strcmp(argv[i], "--force")) {
            rv = BSH_HAVE_IOCTL;
        } else if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) {
            printf("Usage: %s [-a] [-d] [-f] [-h]\n", argv[0]);
            exit(1);
        } else if (!strncmp(argv[i], "dir=", 4)) {
            args[0] = argv[i] + 4;
            i += 5;
        } else if (!strcmp(argv[i], "-l")) {
            rv = BSH_HAVE_DIRENT_H;
        } else if (!strcmp(argv[i], "-o") || !strcmp(argv[i], "--output=")) {
            args[0] = argv[i] + 4;
            i += 5;
        } else if (!strcmp(argv[i], "-r")) {
            rv = BSH_HAVE_IOCTL;
        } else if (!strcmp(argv[i], "-t") || !strcmp(argv[i], "--target=")) {
            args[0] = argv[i] + 4;
            i += 5;
        } else if (!strcmp(argv[i], "-w")) {
            rv = BSH_HAVE_IFADDRS;
        } else {
            fprintf(stderr, "Unknown option: %s\n", argv[i]);
            exit(1);
        }
        
        if (!args[0]) {
            args[0] = argv[i];
            args[1] = argv[i+1];
            
            for (; I<argc && !strcmp(argv[i], "-a"); i++) {}
            
            if (!args[0]) {
                printf("Usage: %s [-d] [-f] [-h]\n", argv[0]);
                exit(1);
            }
            
            args[0][0] = argv[i+1];
        } else {
            strcpy(args[BSH_MAX_ARGS-1], argv[i+1]);
        }
        
        cmd += (int)strlen(cmd);
    }
    
    if (!args[0]) {
        printf("Usage: %s [-d] [-f] [-h]\n", argv[0]);
        exit(1);
    }
    
    exec_path = execvp(args[0], args + 2);
    if (exec_path == NULL) {
        printf("Error: %s\n", strerror(errno));
        exit(1);
    } else {
        for (i=0; i<BSH_MAX_ARGS && !strcmp(args[i], "-a"); i++) {}
        
        if (!args[i]) {
            printf("Usage: %s [-d] [-f] [-h]\n", argv[0]);
            exit(1);
        } else if (strcmp(args[i+1], "-l") || strcmp(args[i+1], "--output=")) {
            args[i][0] = argv[i+1];
            i += 2;
        } else if (strcmp(args[i+1], "-r")) {
            rv = BSH_HAVE_IOCTL;
        } else if (strcmp(args[i+1], "-t") || strcmp(args[i+1], "--target=")) {
            args[i][0] = argv[i+1];
            i += 2;
        } else if (!strcmp(args[i], "-w")) {
            rv = BSH_HAVE_IFADDRS;
        } else {
            fprintf(stderr, "Unknown option: %s\n", argv[0]);
            exit(1);
        }
        
        if (!args[i]) {
            printf("Usage: %s [-d] [-f] [-h]\n", argv[0]);
            exit(1);
        } else {
            strcpy(exec_path, args[i+1]);
            
            if (rv != BSH_HAVE_EXECVE) {
                printf("Error: %s\n", strerror(errno));
                exit(1);
            }
        }
    }
    
    execvp(args[0], args + 2);
}