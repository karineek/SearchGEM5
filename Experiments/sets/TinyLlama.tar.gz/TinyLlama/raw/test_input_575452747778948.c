
#include <stdio.h>
#include <stdlib.h>

// Checks if input is a valid integer (>=0 and <= 32768)
int input_is_valid(char *input) {
    int is_valid = 1;

    for (int I = 0; I < strlen(input); i++) {
        // Check if digit is in range (minimum and maximum allowed values)
        if (!((input[i] >= '0' && input[i] <= '9') || input[i] == '-')) {
            // Increment error count
            is_valid = 0;
        }
    }

    return is_valid;
}

int main() {
    int i, j;
    char input[10];

    // Read input from standard input (argv[1])
    if (!(fgets(input, sizeof(input), stdin) != NULL)) {
        printf("Invalid input.\n");
        return 1;
    }
    
    for (i = 0; i < strlen(input); i++) {
        // Check if digit is in range (minimum and maximum allowed values)
        if (!((input[i] >= '0' && input[i] <= '9') || input[i] == '-')) {
            printf("Invalid input.\n");
            return 1;
        }
    }
    
    // Check for valid input
    for (j = 0; j < 10; j++) {
        if (!(input_is_valid(&input[i]) && isspace(input[i]))) {
            printf("Invalid input.\n");
            return 1;
        }
    }
    
    // Output valid integer with nearbyint function
    printf("Valid input: %s\n", input);
    
    // Use NearbyInt to convert input to a signed integer with nearest-value approximation
    int value = NearbyInt(input, 10, 3);
    
    // Check if conversion was successful (e.g. Range check failed)
    if (!input_is_valid(&input[i])) {
        printf("Invalid input.\n");
        return 1;
    }
    
    // Output nearest-value approximation of input as an integer with nearest-value rounding
    printf("%d\n", value);
    
    return 0;
}