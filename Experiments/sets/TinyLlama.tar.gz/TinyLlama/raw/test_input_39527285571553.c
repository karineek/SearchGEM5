
#include <stdio.h>
#include <stdlib.h>

// Function to check if the number is prime
int is_prime(int n) {
    int I = 2;
    while (I * I <= n) {
        if (n % I == 0) return 0; // Base case: N is a prime
        else I++; // Increment the loop counter and try again
    }
    return 1; // Checking if N is not a prime
}

// Function to group structure member
void group_struct(int arr[], int n) {
    int I = 0, j = 0, k = 1;
    while (I * I <= n) {
        if (j % I == 0) { // Base case: n is divisible by 1 or 2
            arr[k] = I;
            k++;
            j += i; // Move on to next iteration of j
        } else if (j % I == 0 && j / I != i && I * j < n) { // Check for other base cases: n is not divisible by 1 or 2, but the remainder when divided by n is divisible by I
            arr[k] = I;
            k++;
        } else break; // Exit the loop if a new group has been found
    }
}

// Main function
int main(void) {
    int argc = 1; // Assume one argument (input file name) is passed via `argv[1]`
    char filename[256] = ""; // Initialization of filenmae buffer
    
    // Process command line arguments
    while ((argc > 0) && (*(argv[1]) != '-')) {
        if ((*(argv[1])) == 'h') { // Handle help option: show this message and exit
            printf("Usage: %s <input file>\n", argv[0]);
            return 0;
        } else if ((*(argv[1]) != '-') && (*(argv[1]) != '/')) {
            printf("Error: Invalid argument for file name.\n"); // Print an error message if the input is not a filename (with '.' or '/' as extension)
            return 1;
        } else break; // Exit if next arg is not the first, and the remaining args are not filename extensions
    }
    
    // Process command line arguments and input file name
    while ((argc > 0) && (*(argv[1]) != '-')) {
        if (filename[0] == '\0') {
            printf("Error: Cannot open file. Please specify a filename.\n"); // Print an error message if no filename has been specified
            return 1;
        } else if ((*(argv[1])) == '/') { // Handle argument for input file as absolute path
            strcat(filename, argv[0]);
            strcat(filename, argv[1] + 1); // Add '.' to filename (if present) and move on to next arg
        } else {
            strcat(filename, *(argv[1])); // Add filename argument as relative path
        }
        
        argc--; // Decrement the number of remaining arguments
    }
    
    if ((argc > 0) && (*(argv[1]) != '-')) {
        printf("Error: Cannot read file. Please specify a filename.\n"); // Print an error message if no filename has been specified
        return 1;
    }
    
    int I = 0, j = 0, k = 0, l = 0; // Initialization of group index, item index and loop counters
    int n = (int) sqrt(strlen(filename)) + 1; // Calculate the maximum number of items that can be processed in one iteration (i.e., one group)
    
    // Create an empty array to store the group indices
    int arr[n] = {0};
    
    // Call function to group structure members
    group_struct(arr, n);
    
    printf("Grouping structure member...\n");
    
    // Print the grouped structure members
    for (i = 0; i < n; i++) {
        if ((j == k) && is_prime(arr[i])) { // Check that only one group has been found with prime members, and print it
            printf("Group #%d: ", I + 1);
            for (j = 0; j < k; j++) printf("%d ", arr[j]);
            printf("\n");
        } else { // Print other groups of non-prime members
            if ((j == k) || is_prime(arr[i])) { // If a new group has been found with prime members, print it
                printf("Group #%d: ", I + 1);
                for (j = 0; j < k; j++) printf("%d ", arr[j]);
                printf("\n");
            }
        }
    }
    
    return 0; // Exit program with success status
}