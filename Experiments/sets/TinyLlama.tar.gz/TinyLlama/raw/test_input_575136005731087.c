
#include <stdio.h>
#include <stdlib.h>

int main() {
    int argc;
    char **argv;

    argc = 2;
    argv = (char **)malloc(sizeof(char *) * argc);
    
    argv[0] = strdup("input.txt"); // input file
    argv[1] = strdup("-h"); // help message

    if (argc == 1 || !(argv[0][strlen(argv[0]) - 1] != '/' && argv[0][strlen(argv[0]) - 1] != '\\')) { // no file or invalid file extension
        printf("Error: Invalid input filename.\n"); exit(EXIT_FAILURE);
    }
    
    if (argc == 2) { // help message only, no file
        printf("%s", argv[1]);
    } else { // read file contents and display them
        FILE *input = fopen(argv[0], "r");
        
        if (!input) { // error opening file
            printf("Error: Failed to open input file.\n"); exit(EXIT_FAILURE);
        }
        
        char buffer[1024];
        int read;
        
        while ((read = fread(buffer, 1, sizeof(buffer), input)) > 0) { // read data from file until EOF is reached
            printf("%s", buffer); // display data
        }
        
        fclose(input);
    }
    
    return EXIT_SUCCESS;
}