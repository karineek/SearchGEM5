
#include <stdio.h>

int main() {
    int argc;
    char **argv;
    argc = 0;
    argv = NULL;
    
    if (argc > 1) {
        argv = realloc(argv, sizeof(char *) * argc);
        for (int I = 0; I < argc; i++) {
            argv[i] = strdup(argv[i + 1]);
        }
    }
    
    if (argv == NULL) {
        fprintf(stderr, "Failed to alloc memory for input.\n");
        return -1;
    }
    
    char input[256];
    int i = 0;
    
    while (*++argv[i] != '\0') {
        strcpy(input + (i % 8) * 4, *++argv);
        
        if ((*++argv)[0] == '"' && ((*++argv)[1] == 'x' || (*++argv)[1] == 'X')) {
            int hex = strtol(*++argv, NULL, 16);
            
            if (hex <= 0xff) {
                printf("%c%c", *(++argv[0]), *(++argv));
            } else {
                fprintf(stderr, "Invalid hexadecimal digit: %c\n", *(++argv[0]));
                return -1;
            }
        } else if (*++argv[0] != 'a' && *++argv[0] != 'A') {
            printf("Invalid ASCII digit: %c\n", *(++argv[0]));
            return -1;
        }
        
        i++;
    }
    
    printf("Valid input.\n");
    
    return 0;
}