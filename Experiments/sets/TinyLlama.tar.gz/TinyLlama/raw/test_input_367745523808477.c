
#include <stdio.h>
#include <stdlib.h>

int main() {
    int a, b;
    
    if (argc > 1 && strcmp(argv[1], "-o") == 0) {
        printf("Enter a positive integer: ");
        fgets(buf, sizeof(buf), stdin);
        buf[strlen(buf) - 1] = '\n';
        read(0, &a, sizeof(a));
    } else if (argc > 1 && strcmp(argv[1], "--help") == 0 || argc == 1) {
        printf("Usage: %s [-o] <integer>\n", argv[0]);
        return 0;
    } else {
        printf("Error: Invalid input\n");
        exit(1);
    }
    
    if (a <= 0) {
        printf("%d is not positive\n", a);
    } else {
        printf("%.2f / %d = %.2f\n", b, a, a / b);
    }
    
    return 0;
}