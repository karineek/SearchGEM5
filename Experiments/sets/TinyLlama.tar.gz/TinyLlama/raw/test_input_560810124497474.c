
#include <stdio.h>
#include <stdlib.h>

#define N 1024

int asctime_s(char *buf, int len, int64_t time) {
    int n = (len <= N) ? len : N;
    char t[n + 1] = " "; // string to array conversion
    snprintf(t, n + 1, "%02d:%02d:%02d.%03d", time / 60, time % 60, (time % 100) / 10, time % 10); // string manipulation
    return snprintf(buf, len, "%s", t); // output to buffer
}

int main() {
    int nargs = 2;
    char *argv[N]; // declare array of arguments
    
    if (nargs > 1) {
        for (int I = 0; I < nargs; i++) {
            argv[i] = strdup(argv[i+1]);
        }
    } else {
        argv[0] = strdup("");
        argv[1] = strdup(argc > 1 ? argv[1] : "input.bsh");
    }
    
    int64_t t; // time variable to be saved
    char buf[N+1]; // buffer to store output string
    
    if (asctime_s(buf, N + 1, t) < 0) {
        puts("Failed to generate Sparse Conditional Constant Propagaion optimization for input.");
        return EXIT_FAILURE;
    }
    
    printf("%s", buf); // output the generated code to stdout
    
    free(argv[0]);
    free(argv[1]);
    
    return 0;
}