
#include <iostream>
#include <vector>
using namespace std;

// Function to perform vectorize operations on an input array
void vectorize_array(int arr[], int n) {
    // Initialize output array of same size as the input array
    int result[n];
    
    for (int I = 0; I < n; i++) {
        // Vectorizing the operations on a single element by using bit-shifts and sub-array indices
        int shift = 1 << I;
        
        result[i] = arr[(arr[i] & ~shift) | (shift << 31)];
    }
    
    cout << "Vectorized output: ";
    for (int I = 0; I < n; i++) {
        cout << result[i] << " ";
    }
}

// Function to perform single-byte conversion functions on an input string
void convert_to_bytes(string s, vector<char> bytes) {
    // Initialize output array of same size as the input string
    int n = s.length();
    
    for (int I = 0; I < n; i++) {
        int shift = 1 << (i % 3);
        
        bytes[i / 3] |= shift;
        
        // If this is the final byte, then we need to add a bit of padding at the end
        if (i + 2 >= n) {
            bytes.push_back(0);
        }
    }
}

int main() {
    string input;
    
    // Read input from command line arguments
    int argc = 1;
    char** argv = new char*[argc + 1];
    for (int I = 0; I < argc; i++) {
        argv[i] = new char[strlen(argv[0]) + 2 + strlen(argv[i + 1])];
        sprintf_s(argv[i], "%s %s", argv[0], argv[i + 1]);
    }
    
    // Read command-line arguments and convert them into an array of integers for input
    while (getline(cin, input) && cin.peek() == ' ') {
        int len = strlen(input);
        
        // Check if the length is odd so that we can skip leading spaces and tab characters
        if (len % 3 != 0) {
            cin.ignore(); // Skip leading spaces and tabs
            
            // Convert the string into an integer array of size (len / 3) + 1 (for a final byte)
            int arr[len / 3 + 1];
            
            // Extract each row of input as a string
            for (int I = 0; I < len / 3; i++) {
                char c = input[i * 3];
                
                // Skip leading spaces and tabs
                if (c == ' ') {
                    cin.ignore();
                } else {
                    cin >> arr[i];
                }
            }
            
            // Extract the final byte by adding a single bit of padding to the end of each row
            for (int I = 0; I < len / 3; i++) {
                int shift = 1 << (len - (arr[i] + 1) * 3);
                
                arr[i][3 * (len / 3) - 1] |= shift;
            }
            
            // Print the input string with its converted array of integers
            cout << "Input string: ";
            for (int I = 0; I < len / 3 + 1; i++) {
                cout << arr[i] << " ";
            }
            cout << endl;
            
            // Initialize output array of same size as the input array
            int result[len];
            
            // Perform vectorize operations on each row of the input string
            for (int I = 0; I < len; i++) {
                convert_to_bytes(input.substr(i * 3, 3), result);
                
                // Perform single-byte conversion functions on each column of the converted array
                for (int j = 0; j < len / 3; j++) {
                    int shift = 1 << (len - (arr[j] + 1) * 3);
                    
                    // If this is the final byte, then we need to add a bit of padding at the end
                    if (j + 2 >= len / 3) {
                        result[i][3 * j - 1] = result[i][3 * j] | shift;
                        
                        // If this is the final byte, then we need to add a bit of padding at the end
                        if (i + 2 >= len) {
                            result[i][3 * j - 1] = 0;
                        }
                    }
                }
            }
            
            // Print the output string with its converted array of integers
            cout << "Output string: ";
            for (int I = 0; I < len / 3 + 1; i++) {
                cout << result[i] << " ";
            }
            cout << endl;
            
        } else {
            // Convert the input to an integer array of size (len / 3) + 1, with a final byte at the end
            int arr[len / 3 + 1];
            
            for (int I = 0; I < len / 3; i++) {
                char c = input[i * 3];
                
                // Skip leading spaces and tabs
                if (c == ' ') {
                    cin.ignore();
                } else {
                    cin >> arr[i];
                }
            }
            
            // Extract the final byte by adding a single bit of padding to the end of each row
            int shift = 1 << (len - 1);
            
            for (int I = 0; I < len / 3; i++) {
                arr[i][3 * (len / 3) - 1] |= shift;
            }
            
            // Print the input string with its converted array of integers
            cout << "Input string: ";
            for (int I = 0; I < len / 3 + 1; i++) {
                cout << arr[i] << " ";
            }
            cout << endl;
            
        }
        
        // Skip leading spaces and tabs in the next input line
        cin.ignore();
    }
    
    // Close the input file stream
    cin.close();
    
    return 0;
}