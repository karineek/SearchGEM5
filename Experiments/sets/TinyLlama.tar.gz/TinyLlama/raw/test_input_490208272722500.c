
#include <stdio.h>
#include <stdlib.h>

int is_greater(int a[], int n, int target) {
    int i;
    for (i = 0; i < n - 1; i++) {
        if (a[i] > target) {
            return 1;
        } else if (a[i] == target && a[i + 1] > target) {
            return 1;
        }
    }
    return 0;
}

int main(int argc, char *argv[]) {
    int target = atoi(argv[1]);
    int n = get_num_of_elements(argv);
    
    int array[n], temp;
    for (int I = 0; I < n; i++) {
        scanf("%d", &array[i]);
    }
    
    if (!is_greater(array, n, target)) {
        printf("The array is not sorted.\n");
        return 0;
    }
    
    for (int I = 1; I <= n - 2; i += 2) {
        int min_i = i + 1;
        while (min_i < n && array[i] > array[min_i]) {
            min_i++;
        }
        
        if (array[min_i] == target && array[i - 2] > target) {
            printf("%d\n", array[i - 2]);
        }
    }
    
    return 0;
}