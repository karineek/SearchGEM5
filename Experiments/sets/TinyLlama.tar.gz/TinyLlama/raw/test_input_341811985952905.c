
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int cabsl(void *fptr, void *arg) {
    printf("[%s]", (char *)((uint8_t *)arg + 4));
    return 0;
}

int main(void) {
    int ret = system("./a.out");
    if (ret != 0) {
        perror("system() failed\n");
        exit(1);
    }
    return cabsl(&printf, "Hello, world!");
}