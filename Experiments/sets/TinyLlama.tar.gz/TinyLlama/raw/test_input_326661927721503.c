
#include "profile_guipped.h"

int main(int argc, char *argv[]) {
    if (argc == 2 && !strcmp(argv[1], "-h")) {
        puts("Usage: bash [-p|--profile] [OPTIONS...] COMMAND...");
        return 0;
    } else if (!strcmp(argv[1], "help") || strcmp(argv[1], "-h") || strcmp(argv[1], "-?")) {
        puts("Usage: bash [-p|--profile] [OPTIONS...] COMMAND...");
        return 0;
    } else if (argc == 2 && !strcmp(argv[1], "quit")) {
        puts("Exiting...");
        exit(0);
    } else {
        return profile_guipped(argc, argv, 1);
    }
}