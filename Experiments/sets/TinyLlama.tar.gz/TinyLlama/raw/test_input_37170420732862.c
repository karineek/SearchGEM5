
#include <stdio.h>

int main() {
    int argc;
    char **argv = NULL;
    
    if((argc = getopt(1, &argv, "hi:")) != 2) {
        fprintf(stderr, "Usage: %s [-i|-h] [<file.bsh>]\n", argv[0]);
        return 1;
    }
    
    if(argc == 2 && (strcmp(argv[1], "-i") == 0)) {
        printf("Running with -i\n");
        return 0;
    } else if(argc == 2 && (strcmp(argv[1], "-h") == 0)) {
        printf("Running without -i\n");
        return 0;
    } else if(argc != 1) {
        fprintf(stderr, "Invalid arguments: %s", argv[0]);
        return 1;
    }
    
    puts("Target-Specific Optimizations and Frontend and colon punctuator (:)");
    
    return 0;
}