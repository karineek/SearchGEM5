
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "llvm/ExecutionEngine/JITLinker.h"

LLVMContextRef create_context(void) {
    LLVMContextRef context = llvm_createContext();
    if (!context) {
        fprintf(stderr, "Failed to create LLVM Context!\n");
        exit(1);
    }
    
    return context;
}

int main(int argc, char** argv) {
    LLVMOption opt;
    LLVMContextRef context = create_context();
    LLVMJITLinkerRef jitlinker = llvm_createJITLinker(context);
    
    // This is the program we will run with a single command-line argument: the filename.
    const char* fileNameArg = argv[1];
    
    // Read in the LLVM IR file as a string from the filesystem.
    FILE* inputFile;
    if (fileNameArg != NULL) {
        inputFile = fopen(fileNameArg, "r");
    } else {
        inputFile = stdin;
    }
    
    // If the file could not be read, exit the program with an error.
    if (inputFile == NULL) {
        fprintf(stderr, "Failed to open LLVM IR file!\n");
        return 1;
    }
    
    // Create a buffer for LLVM IR that will be written to disk. This should be large enough to hold the entire file.
    char* buf = malloc(1024 * 1024);
    FILE* outputFile = stdout; // This is a standard output file, which will be written to by default if we don't specify one.
    
    // We'll write the LLVM IR to this buffer and then copy it out of memory when we're done.
    while (fread(buf, 1, bufSize, inputFile) != bufSize) {
        fwrite(buf, 1, bufSize, outputFile);
    }
    
    // The LLVM IR has been written to the buffer, and is now ready for use.
    printf("The LLVM IR has been successfully written to disk!\n");
    
    // Close the input file when we're done.
    fclose(inputFile);
    
    // We could also close this output file here. It will automatically be closed when we exit the program.
    fclose(outputFile);
    
    // The program is now complete and ready for execution!
    
    LLVMJITLinkerDestroy(&jitlinker);
    LLVMOptionDestroy(&opt);
    LLVMContextRelease(context);
}