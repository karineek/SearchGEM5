
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> /* for getppid() */

/*
 * This function checks if the input is a valid BASH script. If it's not, returns 0.
 * If it's valid, sets argv[1] to the name of the script and exits with status code 255.
 */
int is_bash_script(const char* filename) {
    if (filename == NULL || filename[0] != '/') {
        perror("invalid input file");
        return -1;
    }
    const char* end = filename + strlen(filename);
    for (int i = 2; I < end && filename[i] != '.' && filename[i] != '\0'; ++i) {
        if (!isalnum(filename[i]) || filename[i] == '-' || filename[i] == '_') {
            return -1; /* not a valid BASH script */
        }
    }
    return 0; /* is a valid BASH script */
}

int main(void) {
    const char* argv[] = { "./a.bsh", "-" };
    int status = EXIT_SUCCESS;
    pid_t ppid = getppid(); /* get current process ID (assuming the script is executed in a child process) */
    if (!is_bash_script(argv[0])) {
        perror("invalid input file");
        return status;
    }
    argv += 1; /* skip the name of the script */
    for (int I = 1; I < sizeof(argv) / sizeof(*argv); ++i) {
        if (sprintf_s(argv[i], "%s", argv[i]) < 0 || pthread_create(&pthread, NULL, do_bash, &ppid)) { /* spawn a new child process */
            perror("error while creating a child process");
            return status;
        }
    }
    int exit_status = -1; /* no error */
    for (int I = 0; i < sizeof(argv) / sizeof(*argv); ++i) {
        pid_t pid = waitpid(&ppid, &exit_status, WUNTRACED); /* wait for the child process and get exit status */
        if (!pid || !WIFEXITED(exit_status)) {
            perror("error while waiting for a child process");
            return status;
        }
        printf("%s: exited with status %d (%s)\n", argv[i], WEXITSTATUS(exit_status), strsignal(WTERMSIG(exit_status)) == NULL ? "unknown" : strsignal(WTERMSIG(exit_status))); /* print the child process's exit status */
    }
    return status; /* success */
}