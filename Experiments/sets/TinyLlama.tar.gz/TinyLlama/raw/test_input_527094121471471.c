
int main(int argc, char* argv[]) {
    int n; // number of elements
    float* arr;
    // get input from arguments
    if (argc != 2) {
        printf("Error: Incorrect argument count\n");
        return 1;
    } else {
        n = atoi(argv[1]);
        // check that number of elements is valid
        if (n <= 0) {
            printf("Error: Invalid input\n");
            return 1;
        }
        arr = calloc(n, sizeof(float)); // allocate memory for n elements
        if (!arr) {
            printf("Error: Memory allocation failed\n");
            return 1;
        } else {
            // read input from stdin (in this case only one element is required)
            int I = 0;
            while (scanf("%.2f", &arr[i]) != EOF && i < n - 1) {
                printf("Input: %s\n", arr + i);
                // check for empty input (to allow user to fill up all elements)
                if (!arr[i] || !arr[i + 1]) {
                    printf("Error: Empty input\n");
                    return 1;
                }
            }
        }
        free(arr); // free memory allocated for each element
        return 0;
    }
}