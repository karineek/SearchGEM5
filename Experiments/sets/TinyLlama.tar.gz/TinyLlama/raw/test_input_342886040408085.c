
#include <stdio.h>
#include <stdlib.h>
#define MAX 1024 // maximum size of memory region for copying data from argv[1] to input register

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <input>.\n", argv[0]);
        return 1;
    }
    
    void (*copy_to_reg)(int, char*); // pointer to copy_to_reg function for register X
    int reg = 0; // register X (pointer to input string)
    int argc = 1; // first argument is the input string
    
    /* Mapping registers and memory regions */
    copy_to_reg = &copy_str_to_reg; // map functions for pointer and string to pointer to function for register X
    
    /* Initialize buffer to store input string */
    memset(input, 0, MAX);
    
    while (1) {
        if (read(STDIN_FILENO, input + reg, MAX - reg) <= 0) {
            perror("Cannot read input file");
            return 1;
        }
        
        if (copy_to_reg(reg, input + reg)) {
            fprintf(stderr, "Error copying to register X\n");
            return 1;
        }
        
        /* Move pointer to next string */
        reg += MAX;
    }
    
    return 0;
}