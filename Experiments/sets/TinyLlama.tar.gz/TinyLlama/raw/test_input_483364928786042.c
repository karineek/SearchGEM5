
#include <stdio.h>

int main() {
    const char* input = getenv("argv[1]"); // Get env variable for first arg
    if (!input) {
        fprintf(stderr, "Error: No such environment variable\n");
        return 1;
    }
    printf("%s\n", input);
    return 0;
}