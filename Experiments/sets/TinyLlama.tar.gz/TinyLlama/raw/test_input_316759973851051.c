
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s file\n", argv[0]);
        return 1;
    } else {
        char buffer[1024];
        FILE *file = fopen(argv[1], "r");
        if (file == NULL) {
            perror("Failed to open file: ");
            return 2;
        } else {
            int counter = 0, count = 0;
            printf("%s", buffer);
            while (!feof(file)) {
                fscanf(file, "%s", buffer + strlen(buffer));
                count++;
                if (count > 5) {
                    printf("\n");
                    printf("Line %d\n", counter);
                    for (int I = 0; I < count; i++) {
                        printf("%c ", buffer[i]);
                    }
                    printf("\n");
                }
            }
            fclose(file);
            return 0;
        }
    }
}