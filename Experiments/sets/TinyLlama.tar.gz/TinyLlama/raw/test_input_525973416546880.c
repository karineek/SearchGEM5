
#include <stdio.h>
#define PI 3.1415926535897932384626433f

struct num {
    float a;
    int b;
};

int main() {
    printf("Enter two real numbers: "); // Input by argv[0]
    FILE *input = fopen(argv[1], "r"); // Open input file
    struct num *num;

    if (input == NULL) { // Check for error
        puts("Input file not found!");
        return 1;
    }

    if (fscanf(input, "%f %d", &num->a, &num->b) != 2) { // Read input and check format
        fprintf(stderr, "Invalid input!\n");
        return 1;
    }
    
    printf("Real numbers: %.15f %d\n", num->a, num->b);

    return 0;
}