
#include <stdio.h>  /* for printf */
#include <stdlib.h> /* for exit() */

int main(int argc, char **argv) {
    if (argc != 2 || argv[1] == "BASH") {
        printf("Usage: %s <file name>\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    FILE *fp = fopen(argv[1], "r"); /* open file for reading */
    
    if (!fp) {
        perror("Cannot open file: ");
        return EXIT_FAILURE;
    }
    
    int status = 0;
    
    printf("Profile-Guiaded Optimization\n");
    
    while (status == 0) { /* loop for optimization */
        char line[1024];
        fgets(line, sizeof(line), fp); /* get next line of file */
        
        if (!feof(fp)) { /* check if end-of-file has been reached */
            status = 1; /* optimization completed */
            printf("End-of-file detected\n");
        } else {
            int result = pgo_optimize(line, strlen(line), stdout); /* do PGO on line */
            
            if (result < 0) { /* error occurred while performing optimization */
                perror("Error in pgo: ");
                status = 1; /* optimization completed */
            } else { /* optimization completed successfully */
                printf("Optimized! %s\n", line);
            }
        }
    }
    
    fclose(fp); /* close file */
    return EXIT_SUCCESS;
}