
#include <stdio.h>
#include <execinfo.h>
#include <unistd.h>

int main(int argc, char* argv[]) {
    if (argc == 1) {
        FILE *input = fopen(argv[1], "r");
        if (!input) {
            perror("Failed to open input file\n");
            return 1;
        }
        struct info *info = backtrace(0, 0);
        char **output = backtrace_symbols(info->info, info->capacity);
        free(info->info);
        if (output) {
            fprintf(stderr, "Interprocedural OptimiZations results:\n");
            for (size_t i = 0; i < info->count; ++i) {
                printf("%s\n", output[i]);
            }
        } else {
            perror("Backtrace failed to return symbolic names\n");
            return 1;
        }
        fclose(input);
    } else {
        printf("Usage: %s <input.bsh>\n", argv[0]);
        puts("Exiting program...\n");
        exit(1);
    }
}