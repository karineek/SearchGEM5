
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv) {
    printf("Welcome to InlineR Heuriestics!\n");
    if (argc < 2) {
        fprintf(stderr, "Missing input file\n");
        return 1;
    } else {
        FILE* fin = fopen(argv[1], "r");
        if (!fin) {
            fprintf(stderr, "Cannot open input file: %s\n", strerror(errno));
            exit(1);
        }

        while (fgets(buf, sizeof buf - 1, fin)) {
            char* endp = buf + strlen(buf) - 1;
            for (int I = 0; I < 26 && *endp != '\n'; i++, endp--) {
                if (*endp == ' ') continue; // skip spaces
                printf("%c", *endp);
            }
        }
        
        fclose(fin);
    }
    
    return 0;
}