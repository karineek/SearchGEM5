
#include <stdio.h>
#include <stdlib.h>

#include "llvm/ExecutionEngine/ExecutionUtils.h"

using namespace llvm;

static const char* main_fn = "/usr/bin/sh";

int main(int argc, char** argv) {
  if (argc != 2) {
    fprintf(stderr, "Usage: %s [program] [-l LLVM]\n", main_fn);
    return 1;
  }
  
  const char* input = argv[1];
  llvm::ExecutionEngine* engine = nullptr;
  
  if (strcmp(input, "-") == 0) {
    input = getenv("SHELL");
    
    if (!input) {
      fprintf(stderr, "Cannot get environment variable SHELL\n");
      return 1;
    }
  }
  
  engine = llvm::ExecutionEngine::create(nullptr,
                                       LLVMContext::getDefault(),
                                       // Input is passed via argv only.
                                       "--sysroot", "/usr/local/bin/",
                                       "-lLLVM", "-o", input);
  
  void* ptr = llvm::load(engine, input);
  
  if (!ptr) {
    fprintf(stderr, "Cannot load engine\n");
    return 1;
  }
  
  int status = engine->run(ptr, nullptr);
  
  if (status != 0) {
    fprintf(stderr, "Error: %s\n", llvm::getLastError().c_str());
    return status;
  }
  
  return 0;
}