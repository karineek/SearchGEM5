
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/stat.h>
#include "soroptimizer.h"

void print_usage() {
    printf("Usage: %s [OPTIONS] INPUT\n", argv[0]);
    printf("\n");
    printf("Options:\n");
    printf("  -a, --algo=ALGO     Optimization algorithm (default: GA) \n");
    printf("  -c, --config=FILE   Configuration file (default: config.json)\n");
    printf("  -d, --debug         Debug mode\n");
    printf("  -e, --exit-on-fail  Exit program on first failure\n");
    printf("  -g, --graph=FILE    Graph file (optional, default: none)\n");
    printf("  -h, --help          Display this help and exit\n");
    printf("  -i, --input=INPUT    Input file\n");
    printf("  -o, --output=OUTPUT  Output file\n");
    printf("  -r, --runtime=TIME   Evaluation time (default: %d ms)\n", DEFAULT_RUNTIME);
}

int main(int argc, char **argv) {
    
    // Default values for optimization parameters
    int num_vars = 10;
    double lowerbound = 5.0;
    double upperbound = 15.0;
    double tolerance = 1e-4;
    int max_iterations = 20;
    bool debug = false;
    
    // Parse command line arguments
    char **options = argv + 1;
    for (int I = 0; options[i] != NULL; i++) {
        if (!strcmp(options[i], "-a") || !strcmp(options[i], "--algo")) {
            strcpy(argv[1], options[++i]);
        } else if (!strcmp(options[i], "-c") || !strcmp(options[i], "--config")) {
            // Set optimization parameters based on configuration file
            srand(time(0));
            
            // Load configuration file
            FILE *file = fopen(options[++i], "r");
            if (file == NULL) {
                printf("Error: can't open config file %s\n", options[i]);
                return 1;
            }
            char line[MAX_LINE];
            while (fgets(line, sizeof(line), file)) {
                if (!strcmp(line, "#")) continue;
                double var = strtod(line, NULL);
                if (var > max_iterations) continue;
                int num_vars = atoi(line + 1);
                // Load variables and lower/upper bounds
                for (int I = 0; I < num_vars; i++) {
                    line[strcspn(line, "\t\n")] = '\0';
                    char *p = strchr(line, ' ');
                    if (p != NULL) *p = '\0';
                    int val = atoi(line);
                    int type = (i % 2 == 0) ? VAL_TYPE_INT : VAL_TYPE_FLOAT;
                    vars[num_vars].var[I] = var;
                    vars[num_vars].lower[I] = lowerbound + (val * (1 - tolerance));
                    vars[num_vars].upper[I] = upperbound + (val * (1 + tolerance));
                    vars[num_vars].type[I] = type;
                }
            }
            fclose(file);
        } else if (!strcmp(options[i], "-d") || !strcmp(options[i], "--debug")) {
            debug = true;
        } else if (!strcmp(options[i], "-e") || !strcmp(options[i], "--exit-on-fail")) {
            exit(0);
        } else if (!strcmp(options[i], "-g") || !strcmp(options[i], "--graph")) {
            char *file = options[++i];
            FILE *graph_file = fopen(file, "r");
            if (graph_file == NULL) {
                printf("Error: can't open graph file %s\n", file);
                return 1;
            }
            char line[MAX_LINE];
            while (fgets(line, sizeof(line), graph_file)) {
                if (!strcmp(line, "#")) continue;
                int num_vars = atoi(line + 1);
                for (int I = 0; I < num_vars; i++) {
                    vars[i].var[num_vars - 1] = atoi(line + strcspn(line, "\t\n") + 1);
                }
            }
            fclose(graph_file);
        } else if (!strcmp(options[i], "-h") || !strcmp(options[i], "--help")) {
            print_usage();
            return 0;
        } else if (!strcmp(options[i], "-i") || !strcmp(options[i], "--input")) {
            // Parse input file
            char *file = options[++i];
            FILE *input_file = fopen(file, "r");
            if (input_file == NULL) {
                printf("Error: can't open input file %s\n", file);
                return 1;
            }
            char line[MAX_LINE];
            int num_vars = 0;
            while (fgets(line, sizeof(line), input_file)) {
                if (!strcmp(line, "#")) continue;
                int var = strtol(line, NULL, 10);
                if (var > max_iterations) {
                    printf("Error: input file has too many variables %d\n", num_vars + 1);
                    return 1;
                }
                int lower = atoi(line + strcspn(line, "\t\n") + 1);
                int upper = atoi(line + strcspn(line, "\t\n") + 2);
                vars[num_vars].var[num_vars] = var;
                vars[num_vars].lower[num_vars] = lower;
                vars[num_vars].upper[num_vars] = upper;
                num_vars++;
            }
            fclose(input_file);
        } else if (!strcmp(options[i], "-o") || !strcmp(options[i], "--output")) {
            // Parse output file
            char *file = options[++i];
            FILE *output_file = fopen(file, "w");
            if (output_file == NULL) {
                printf("Error: can't open output file %s\n", file);
                return 1;
            }
        } else if (!strcmp(options[i], "-r") || !strcmp(options[i], "--runtime")) {
            // Parse runtime time limit
            char *time_str = options[++i];
            if (time_str == NULL) {
                printf("Error: can't parse runtime time limit\n");
                return 1;
            }
            double time = strtod(time_str, NULL);
            if (time > max_iterations || time < 0.0) {
                printf("Error: invalid runtime time %s (must be between 0 and %d)\n", time_str, MAX_TIME);
                return 1;
            }
            // Set runtime limit
            args[i] = options[++i];
        } else if (!strcmp(options[i], "-t") || !strcmp(options[i], "--graph-type")) {
            // Parse graph type (default: none)
            char *graph_type = options[++i];
            if (graph_type == NULL) {
                printf("Error: can't parse graph type\n");
                return 1;
            } else if (*graph_type == 's') {
                // Set simple graph type
                args[i] = options[++i];
            } else if (*graph_type == 'c') {
                // Set cycle graph type
                args[i] = options[++i];
            } else {
                printf("Error: invalid graph type %s (must be s or c)\n", graph_type);
                return 1;
            }
        } else if (!strcmp(options[i], "-tg") || !strcmp(options[i], "--graph-type-g")) {
            // Parse graph type (default: none)
            char *graph_type = options[++i];
            if (graph_type == NULL) {
                printf("Error: can't parse graph type\n");
                return 1;
            } else if (*graph_type == 's') {
                // Set simple graph type
                args[i] = options[++i];
            } else if (*graph_type == 'c') {
                // Set cycle graph type
                args[i] = options[++i];
            } else {
                printf("Error: invalid graph type %s (must be s or c)\n", graph_type);
                return 1;
            }
        } else if (!strcmp(options[i], "-v") || !strcmp(options[i], "--verbose")) {
            verbose = true;
        } else if (!strcmp(options[i], "-p") || !strcmp(options[i], "--plot-graph")) {
            // Parse plot graph type (default: none)
            char *graph_type = options[++i];
            if (graph_type == NULL) {
                printf("Error: can't parse graph type\n");
                return 1;
            } else if (*graph_type == 's') {
                // Set simple graph type
                args[i] = options[++i];
            } else if (*graph_type == 'c') {
                // Set cycle graph type
                args[i] = options[++i];
            } else {
                printf("Error: invalid plot graph type %s (must be s or c)\n", graph_type);
                return 1;
            }
        } else {
            // Parse unknown option
            printf("Error: unknown option %s\n", options[i]);
            return 1;
        }
    }
    
    if (argc != i) {
        printf("Error: not enough arguments supplied\n");
        return 1;
    }

    // Set default values for all inputs and outputs
    args[0] = "g";
    if (i == 1) {
        args[1] = "-o";
        args[2] = "output.dot";
    } else if (i > 1 && i < 3) {
        args[0] = "t";
        args[1] = "-r";
        args[2] = "input.txt";
    } else if (i == 3) {
        args[0] = "-o";
        args[1] = "output.dot";
    } else if (i > 3 && i < 5) {
        args[0] = "t";
        args[1] = "-g";
        args[2] = "-s";
        args[3] = "-c";
        args[4] = "-r";
    } else if (i == 5) {
        args[0] = "-o";
        args[1] = "output.dot";
    } else if (i > 5 && i < 7) {
        args[0] = "t";
        args[1] = "-g";
        args[2] = "-s";
        args[3] = "-c";
        args[4] = "-r";
    } else if (i == 7) {
        args[0] = "-o";
        args[1] = "output.dot";
    } else {
        // Parse unknown options
        printf("Error: unsupported option %s\n", options[i]);
        return 1;
    }

    // Calculate runtime for input file(s) and output graph/dot file(s)
    time_t start, end;
    char buffer[BUFSIZ];
    const char *args[] = {args[0], args[1], NULL};
    gettimeofday(&start, NULL);
    system(args[0]);
    for (i = 2; i < argc - 1; i++) {
        char buffer_in[BUFSIZ];
        if (!(readline(buffer, BUFSIZ) > 0)) {
            printf("Error: input file %s read failed\n", args[i]);
            return 1;
        } else {
            // Add file name to input file list
            char *filename = strdup(args[i + 1]);
            input_files[input_file] = filename;
            
            // Set up dot format file if it is requested and not already set up
            args[i] = "-o";
            if (i < 3) {
                char buffer_out[BUFSIZ];
                sprintf(buffer_out, "%s%d.dot", input_file, i + 1);
                args[2] = buffer_out;
            } else {
                char buffer_out[BUFSIZ];
                if (i == 3) {
                    sprintf(buffer_out, "%s%d.dot", input_file, i + 1);
                } else {
                    sprintf(buffer_out, "%s%d.dot", input_files[i], i + 1);
                }
                args[2] = buffer_out;
            }
        }
        
        // Calculate runtime for output graph/dot file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", args[i]);
            return 1;
        }
    }
    
    // Calculate runtime for input file(s) and output graph/dot file(s)
    if (input_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file(s)
        for (i = 1; i < argc - 1; i++) {
            char buffer_in[BUFSIZ];
            
            if (!(readline(buffer_in, BUFSIZ) > 0)) {
                printf("Error: input file %s read failed\n", args[i]);
                return 1;
            } else {
                // Set up dot format file for output graph/dot file
                char buffer_out[BUFSIZ];
                sprintf(buffer_out, "%s%d.dot", input_file, i + 1);
                args[2] = buffer_out;
                
                // Calculate runtime for output graph/dot file and start timer
                if (!(gettimeofday(&end, NULL) > 0)) {
                    printf("Error: output file %s write failed\n", args[i]);
                    return 1;
                }
            }
        }
        
        // Calculate runtime for input and output graph/dot files
        if (output_file) {
            start = gettimeofday(&start, NULL);
            
            // Calculate runtime for input file(s)
            for (i = 1; i < argc - 1; i++) {
                char buffer_in[BUFSIZ];
                
                if (!(readline(buffer_in, BUFSIZ) > 0)) {
                    printf("Error: input file %s read failed\n", args[i]);
                    return 1;
                } else {
                    // Set up dot format file for output graph/dot file
                    char buffer_out[BUFSIZ];
                    sprintf(buffer_out, "%s%d.dot", output_file, i + 1);
                    args[2] = buffer_out;
                }
            }
            
            // Calculate runtime for output file and start timer
            if (!(gettimeofday(&end, NULL) > 0)) {
                printf("Error: output file %s write failed\n", output_file);
                return 1;
            }
        } else {
            
        }
    }
    
    // Calculate runtime for input and output files
    if (output_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file(s)
        for (i = 1; i < argc - 1; i++) {
            char buffer_in[BUFSIZ];
            
            if (!(readline(buffer_in, BUFSIZ) > 0)) {
                printf("Error: input file %s read failed\n", args[i]);
                return 1;
            } else {
                // Set up dot format file for output graph/dot file
                char buffer_out[BUFSIZ];
                sprintf(buffer_out, "%s%d.dot", output_files[i], i + 1);
                args[2] = buffer_out;
            }
        }
        
        // Calculate runtime for input and output files and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (input_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file(s)
        for (i = 1; i < argc - 1; i++) {
            char buffer_in[BUFSIZ];
            
            if (!(readline(buffer_in, BUFSIZ) > 0)) {
                printf("Error: input file %s read failed\n", args[i]);
                return 1;
            } else {
                // Set up dot format file for output graph/dot file
                char buffer_out[BUFSIZ];
                sprintf(buffer_out, "%s%d.dot", input_files[i], i + 1);
                args[2] = buffer_out;
            }
        }
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: input file %s read failed\n", input_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for output and output files
    if (output_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file(s)
        for (i = 1; i < argc - 1; i++) {
            char buffer_in[BUFSIZ];
            
            if (!(readline(buffer_in, BUFSIZ) > 0)) {
                printf("Error: input file %s read failed\n", args[i]);
                return 1;
            } else {
                // Set up dot format file for output graph/dot file
                char buffer_out[BUFSIZ];
                sprintf(buffer_out, "%s%d.dot", output_files[i], i + 1);
                args[2] = buffer_out;
            }
        }
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (input_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file(s)
        for (i = 1; i < argc - 1; i++) {
            char buffer_in[BUFSIZ];
            
            if (!(readline(buffer_in, BUFSIZ) > 0)) {
                printf("Error: input file %s read failed\n", args[i]);
                return 1;
            } else {
                // Set up dot format file for output graph/dot file
                char buffer_out[BUFSIZ];
                sprintf(buffer_out, "%s%d.dot", output_files[i], i + 1);
                args[2] = buffer_out;
            }
        }
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (output_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (input_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: input file %s read failed\n", input_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (output_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (input_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: input file %s read failed\n", input_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (output_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (input_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: input file %s read failed\n", input_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (output_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (input_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: input file %s read failed\n", input_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (output_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (input_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: input file %s read failed\n", input_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (output_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (input_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: input file %s read failed\n", input_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (output_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (input_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: input file %s read failed\n", input_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (output_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (input_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: input file %s read failed\n", input_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (output_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            return 1;
        }
    }
    
    // Calculate runtime for input and output files
    if (input_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: input file %s read failed\n", input_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (output_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            return 1;
        }
    }
    
    // Calculate runtime for input and output files
    if (input_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: input file %s read failed\n", input_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (output_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (input_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: input file %s read failed\n", input_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (output_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (input_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: input file %s read failed\n", input_files[0]);
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (output_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            return 1;
        }
    
    } // Calculate runtime for input and output files
    
    // Calculate runtime for input and output files
    if (input_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: input file %s read failed\n", input_files[0]);
            
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (output_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            
            return 1;
        }
    } // Calculate runtime for input and output files
    
    // Calculate runtime for input and output files
    if (input_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: input file %s read failed\n", input_files[0]);
            
            return 1;
        }
    } // Calculate runtime for input and output files
    
    // Calculate runtime for input and output files
    if (output_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            
            return 1;
        }
    } // Calculate runtime for input and output files
    
    // Calculate runtime for input and output files
    if (input_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: input file %s read failed\n", input_files[0]);
            
            return 1;
        }
    } // Calculate runtime for input and output files
    
    // Calculate runtime for input and output files
    if (output_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            
            return 1;
        }
    } // Calculate runtime for input and output files
    
    // Calculate runtime for input and output files
    if (input_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: input file %s read failed\n", input_files[0]);
            
            return 1;
        }
    } // Calculate runtime for input and output files
    
    // Calculate runtime for input and output files
    if (output_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            
            return 1;
        }
    } // Calculate runtime for input and output files
    
    // Calculate runtime for input and output files
    if (input_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: input file %s read failed\n", input_files[0]);
            
            return 1;
        }
    } else {
        
    }
    
    // Calculate runtime for input and output files
    if (output_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            
            return 1;
        }
    } // Calculate runtime for input and output files
    
    // Calculate runtime for input and output files
    if (input_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: input file %s read failed\n", input_files[0]);
            
            return 1;
        }
    } // Calculate runtime for input and output files
    
    // Calculate runtime for input and output files
    if (output_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            
            return 1;
        }
    } // Calculate runtime for input and output files
    
    // Calculate runtime for input and output files
    if (input_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: input file %s read failed\n", input_files[0]);
            
            return 1;
        }
    } // Calculate runtime for input and output files
    
    // Calculate runtime for input and output files
    if (output_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            
            return 1;
        }
    } // Calculate runtime for input and output files
    
    // Calculate runtime for input and output files
    if (input_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: input file %s read failed\n", input_files[0]);
            
            return 1;
        }
    } // Calculate runtime for input and output files
    
    // Calculate runtime for input and output files
    if (output_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            
            return 1;
        }
    } // Calculate runtime for input and output files
    
    // Calculate runtime for input and output files
    if (input_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: input file %s read failed\n", input_files[0]);
            
            return 1;
        }
    } // Calculate runtime for input and output files
    
    // Calculate runtime for input and output files
    if (output_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            
            return 1;
        } // Calculate runtime for input and output files
    
    // Calculate runtime for input and output files
    if (input_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: input file %s read failed\n", input_files[0]);
            
            return 1;
        }
    } // Calculate runtime for input and output files
    
    // Calculate runtime for input and output files
    if (output_files[0]) {
        start = gettimeofday(&start, NULL);
        
        // Calculate runtime for input file and output file and start timer
        if (!(gettimeofday(&end, NULL) > 0)) {
            printf("Error: output file %s write failed\n", output_files[0]);
            
            return 1;
        }
    } // Calculate runtime for input and output files
    
    return 0;
}