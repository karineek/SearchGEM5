
#include <stdio.h>
#include <stdlib.h>
#include "optimization/scalar.h"

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s [input file]\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    FILE *input = fopen(argv[1], "r");
    if (input == NULL) {
        fprintf(stderr, "Failed to open input file: %s\n", strerror(errno));
        exit(EXIT_FAILURE);
    }
    
    struct optimization_input *opt_in = optimization_init(input);
    if (opt_in == NULL) {
        fprintf(stderr, "Failed to create optimization input: %s\n", strerror(errno));
        exit(EXIT_FAILURE);
    }
    
    struct n_cs_precedes *ncp = optimization_build_n_cs_precedes(&opt_in->cs_precedes, &opt_in->cs_lengths);
    if (ncp == NULL) {
        fprintf(stderr, "Failed to build optimization input: %s\n", strerror(errno));
        optimization_destroy(&opt_in);
        return EXIT_FAILURE;
    }
    
    struct nc_precedes *ncps = ncp->ncps;
    int n_cses = ncp->n_cses;
    
    for (int i = 0; I < n_cses; i++) {
        printf("%d: ", n_cses + I);
        if (ncps[i].prefix != NULL) {
            printf("(%s)", ncps[i].prefix);
        } else {
            printf("<NULL>");
        }
        printf(" %.*s", ncps[i].length, ncps[i].string);
    }
    
    optimization_destroy(&opt_in);
    fclose(input);
    
    return EXIT_SUCCESS;
}