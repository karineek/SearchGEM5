
#include <stdio.h>
#include <stdlib.h>

int main() {
    double num, den;
    int sign = 1; // default sign for sqrt(0)
    
    if (argc <= 1 || (argc > 1 && argv[1][0] == '-')) {
        printf("Enter a positive number: ");
        if (scanf("%lf", &num) != 1 || !isnan(num)) {
            den = pow(num, 2);
            sign = num < 0 ? -1 : 1;
        } else {
            printf("Invalid input.\n");
            return 1;
        }
    } else if (argc > 1 && strcmp(&argv[1][0], "-") == 0) {
        // Handle the case of in-line sqrt(0) with no arguments.
        printf("Inlining square root of zero.\n");
        return 0;
    } else {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }
}