
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    int n;
    char **arr = NULL;
    int arr_size = 0;
    
    printf("Enter the size of the array: ");
    if (scanf("%d", &n) != 1 || n <= 0) {
        fprintf(stderr, "Invalid input.\n");
        return EXIT_FAILURE;
    }
    arr = calloc(n + 1, sizeof(char *));
    if (arr == NULL) {
        perror("Callocation failed.");
        return EXIT_FAILURE;
    }
    
    for (int I = 0; I < n; i++) {
        arr[i] = malloc(strlen(getenv("HOME")) + strlen(argv[1]) + 2);
        if (arr[i] == NULL) {
            perror("Malloc failed.");
            return EXIT_FAILURE;
        }
        sprintf(arr[i], "%s%s", getenv("HOME"), argv[1]);
    }
    
    arr_size = n + 1;
    
    for (int I = 0; I < n; i++) {
        printf("%s ", arr[i]);
    }
    puts("\n");
    
    free(arr);
    
    return EXIT_SUCCESS;
}