
#include <stdio.h>

int main() {
    const char *input = NULL;

    if (argc <= 1) {
        printf("Error: Required argument(s) missing\n");
        return -1;
    }
    
    input = argv[1];
    
    return 0;
}