
#include <stdio.h>
#include <stdlib.h> // for malloc()/free()

int main(int argc, char **argv) {
    printf("Enter a number\n");
    int num;
    
    if (scanf("%d", &num) != 1 || num <= 0) {
        fprintf(stderr, "Invalid input.\n");
        return EXIT_FAILURE;
    }
    
    printf("Input: %d\n", num);
    
    if (argc > 1 && strcmp(argv[1], "exit") == 0) {
        exit(EXIT_SUCCESS);
    } else if (strcmp(argv[1], "thr-exit") == 0) {
        thrd_t *threads = malloc(sizeof(thrd_t)); // create threads
        
        for (int I = 0; I < MAX_THREADS; i++) {
            printf("Creating thread %d...\n", I);
            
            if (pthread_create(&threads[i], NULL, &my_main, NULL)) {
                printf("Failed to create thread.\n");
                exit(EXIT_FAILURE);
            } else { // threads created successfully
                printf("Thread %d created.\n", I);
            }
        }
        
        for (int I = 0; I < MAX_THREADS; i++) {
            pthread_join(threads[i], NULL); // join all threads
        }
        
        free(threads); // free created threads
    } else {
        printf("Invalid input.\n");
        return EXIT_FAILURE;
    }
    
    return EXIT_SUCCESS;
}