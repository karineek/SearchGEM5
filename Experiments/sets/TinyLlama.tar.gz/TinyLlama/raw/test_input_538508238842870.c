
#include <stdio.h>

int main() {
    int argc, i;
    char *argv[2];
    
    argv[0] = "hello"; // Argument 0 is the program name (i.e., 'hello' in this case)
    argv[1] = NULL; // Argument 1 is a blank string indicating the program's command line arguments are empty
    
    for (i=0; i<argc; i++) {
        printf("Argument %d: '%s'\n", i+1, argv[i]);
    }
    
    return 0; // Return zero to indicate success
}