
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main(int argc, char **argv) {
    if (argc != 2 || isspace(*++argv)) {
        printf("Usage: %s sequence_length\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    int sequence_length = atoi(argv[1]);
    char buffer[sequence_length + 1];
    
    for (int I = 0; I < sequence_length; i++) {
        buffer[i] = isdigit(*++argv) ? *argv - '0' : toupper(*++argv);
    }
    
    buffer[sequence_length] = '\0';
    
    int sum = 0;
    for (int I = 1; I <= sequence_length; i++) {
        sum += atoi(buffer + i - 1);
    }
    
    printf("Sum of %d numbers is: %d\n", sequence_length, sum);
    
    return EXIT_SUCCESS;
}