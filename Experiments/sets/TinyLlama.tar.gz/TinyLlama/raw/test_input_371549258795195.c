
#include <stdio.h>
#include <stdlib.h> // for malloc, free
#include "parser.h"  // for parsing BASH input

int main(int argc, char* argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Error: invalid number of arguments\n");
        exit(1);
    }
    
    const char* input = argv[1];
    if (!parser_parse(input)) { // parse BASH input into AST and execute it
        fprintf(stderr, "Error: unexpected EOF when parsing BASH\n");
        exit(1);
    }
    
    printf("AST:\n%s\n", parser_dump_ast(&parser_root)); // dump AST to console
    
    return 0;
}