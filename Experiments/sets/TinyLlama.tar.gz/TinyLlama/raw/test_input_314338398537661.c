
#include <stdio.h>
#include <stdlib.h>

int main() {
    int num = 0;
    
    // Get input from command line arguments
    char argv[1024];
    size_t argc = sizeof(argv) / sizeof(arg);
    for (int I = 0; I < argc; i++) {
        if (!strcmp(argv[i], "-n")) {
            sscanf(argv[++i], "%d", &num);
            if (num <= 0) {
                printf("Error: Invalid input (must be a positive integer).\n");
                return 1;
            }
        } else if (!strcmp(argv[i], "-m") && argc >= 2) {
            sscanf(argv[++i], "%d", &num);
            if (num <= 0) {
                printf("Error: Invalid input (must be a positive integer).\n");
                return 1;
            }
        } else {
            printf("Usage: %s [options]\n", argv[i]);
            exit(EXIT_SUCCESS);
        }
    }
    
    // Loop-Invariant Code Motion optimizacija (optimization)
    if (num <= 0) {
        printf("Error: Invalid input (must be a positive integer).\n");
        return 1;
    }
    num = abs(num);
    
    // Frontend and ATOMIC_
    int result = atomic_add(&num, 1);
    if (result == -1) {
        printf("Error: Input not supported.\n");
        return 1;
    } else if (result != num + 1) {
        printf("Error: Input is invalid.\n");
        return 1;
    }
    
    // Examples of input (BASH)
    puts("Example 1:");
    puts("1 -n -m");
    puts("123 -n");
    puts("456 -m -m");
    puts("789 -n -n");
    
    return 0;
}