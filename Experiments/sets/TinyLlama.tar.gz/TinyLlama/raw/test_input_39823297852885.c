
gcc -I/path/to/libcxxfilt.a main.cpp -o my_program
./my_program < argv[1]