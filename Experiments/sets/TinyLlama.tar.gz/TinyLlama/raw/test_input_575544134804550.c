
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    int I = 0;
    
    while (I < argc) {
        printf("Enter input line %d:\n", I);
        if (argc == 1) {
            // No input to handle.
            break;
        } else {
            // Handle input.
            char input[32];
            strcpy(input, argv[i]);
            printf("%s\n", input);
        }
        I++;
    }
    
    return 0;
}