
#include <stdio.h>
#include <stdlib.h>
#define BASH_SCNXMAX 10000
#define BASH_MAX_ARGS 50

void usage(void) {
    printf("Usage: bash [options] [args]\n");
    printf("\t-s, --script\n");
    printf("\t-e, --echo\n");
    printf("\t-h, --help\n");
    printf("\t-q, --quiet\n");
    printf("\t[options] [args]\n");
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        usage();
        return -1;
    }
    int i = 0;
    for (i = 1; i < argc; i++) {
        if (*(argv[i] + 1) == '-') {
            switch (*(argv[i] + 2)) {
                case 's':
                    printf("%.*s\n", argv[i] - 2, argv[i]);
                    return 0;
                case 'e':
                    printf("arg %d: %s\n", i, argv[i + 1]);
                    return 0;
                case 'h':
                    usage();
                    return -1;
                case 'q':
                    printf("quiet mode is on.\n");
                    return 0;
                default:
                    printf("invalid option -%c\n", *(argv[i] + 1));
                    usage();
                    return -1;
            }
        } else if (strcmp(argv[i], "--script") == 0) {
            puts(script());
        } else if (strcmp(argv[i], "--echo") == 0) {
            puts(echo ? "true" : "false");
        } else {
            printf("unrecognized option - %c\n", *(argv[i] + 1));
            usage();
            return -1;
        }
    }
    return 0;
}