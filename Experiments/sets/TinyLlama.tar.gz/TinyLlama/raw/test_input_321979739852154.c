
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    int line_num = 0;
    char* buffer[1024];
    FILE* file = NULL;

    if (argc != 2) {
        printf("Usage: %s <input> \n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    while ((line_num = getline(&buffer[0], sizeof(buffer), stdin)) > 0) {
        line_num = sscanf(buffer, "%s", buffer);
        if (line_num != 1 || strcmp(buffer, "") == 0) {
            printf("Invalid input. Please enter a valid BASH expression.\n");
            continue;
        }
        
        file = fopen(argv[1], "w+");
        if (!file) {
            perror("Failed to open file for writing.");
            exit(EXIT_FAILURE);
        }
        
        write(STDOUT_FILENO, buffer, line_num + 1);
        
        fclose(file);
    }
    
    return 0;
}