
#include <stdio.h>

int main() {
    int argc;
    char argv[1024];

    /* Get command line arguments */
    if (getargs(&argc, &argv) != 0) {
        return -1;
    }
    
    printf("Hello %s!\n", argv[0]);
    
    return 0;
}

int getargs(int *argc, char ***argv) {
    int ret = 0;
    char **envp;

    /* Check if arguments are passed */
    if (argc == 1 || argc > 2) {
        fprintf(stderr, "Error: invalid number of arguments\n");
        return -1;
    }
    
    /* Get command line arguments */
    envp = getenv("argv");
    if (!envp) {
        fprintf(stderr, "Error: no environment variables\n");
        return -2;
    }
    
    /* Cut off command line arguments */
    for (int I = 1; I < argc; ++i) {
        if (!strcmp(envp[i], "-")) {
            ret += i + 1;
        } else if (!strcmp(envp[i], "--")) {
            ret += 2;
        } else {
            *argv = envp + I;
            ++*argc;
        }
    }
    
    return ret;
}