
#include <stdio.h> // for printf()
#include <math.h> // for hypot()

int main(int argc, char *argv[]) {
    float x1, x2;
    
    if (argc == 3) {
        x1 = atof(argv[1]);
        x2 = atof(argv[2]);
        
        printf("Hypot of %.2f and %.2f is: %.2f\n", x1, x2, hypot(x1, x2));
    } else {
        puts("Enter two numbers separated by comma:");
        scanf("%f,%f", &x1, &x2);
        
        printf("Hypot of %.2f and %.2f is: %.2f\n", x1, x2, hypot(x1, x2));
    }
    
    return 0;
}