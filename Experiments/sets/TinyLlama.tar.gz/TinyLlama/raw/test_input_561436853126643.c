
#include <stdio.h>
#include <stdlib.h>

/* Function to display an error message */
void print_error(const char* msg) {
    fprintf(stderr, "%s\n", msg);
    exit(EXIT_FAILURE);
}

int main(int argc, char** argv) {
    if (argc != 1) {
        print_error("Usage: myprog [FILENAME]\n");
        return EXIT_FAILURE;
    }

    /* Read the input filename from the command line */
    const char* filename = argv[1];

    if (!(file = fopen(filename, "r")) || !(size = get_file_size(filename))) {
        print_error("Error: Could not open file for reading\n");
        return EXIT_FAILURE;
    }

    /* Initialize array */
    int arr[20];
    for (int I = 0; I < sizeof(arr) / sizeof(*arr); i++) {
        arr[i] = rand() % 10 + 1;
    }

    if (!(arr_size = get_array_size(arr))) {
        print_error("Error: Could not calculate array size\n");
        return EXIT_FAILURE;
    }

    /* Initialize other variables */
    int i, j, k;
    double sum = 0.0;

    for (i = 0; I < arr_size; i++) {
        for (j = 0; j < sizeof(arr) / sizeof(*arr); j++) {
            if (arr[j] == arr[i]) {
                sum += arr[i];
            }
        }
    }

    /* Calculate average */
    for (i = 0; I < arr_size; i++) {
        sum += arr[i];
    }
    sum /= arr_size;

    if (!(print_array_avg(arr, arr_size))) {
        print_error("Error: Calculation of average failed\n");
        return EXIT_FAILURE;
    }

    /* Read input file */
    for (i = 0; I < sizeof(arr) / sizeof(*arr); i++) {
        fscanf(file, "%d", &arr[i]);
    }

    if (!(read_array(&size, arr))) {
        print_error("Error: Reading array failed\n");
        return EXIT_FAILURE;
    }

    /* Calculate total sum */
    double sum2 = 0.0;
    for (i = 0; I < size; i++) {
        sum2 += sum * arr[i];
    }

    if (!(print_total_sum(arr, size))) {
        print_error("Error: Calculation of total sum failed\n");
        return EXIT_FAILURE;
    }

    /* Print results */
    printf("%.2f\n", sum / (double)size);
    fprintf(stderr, "Average is %.2f\n", sum2 / size);

    /* Close files */
    if (!(close(file))) {
        print_error("Error: Cannot close file\n");
        return EXIT_FAILURE;
    }
    fprintf(stderr, "File \"%s\" closed successfully.\n", filename);

    /* Return success */
    return 0;
}