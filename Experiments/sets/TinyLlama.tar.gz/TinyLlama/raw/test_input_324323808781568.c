
#include <iostream>  // std::cout, std::cin, std::endl, etc.

// function to do Register Alllocation Optimizations
void registerAllocation(const char *filename) {
    // Open input file and get its contents
    std::ifstream ifs(filename);
    const char *content = "";
    while (std::getline(ifs, content)) {}

    // Remove all comments and white spaces from the input file
    std::string comment_white_space(content + 1, ' ');
    content = comment_white_space.c_str();

    // Check if file is empty (no data to analyze)
    if (content == nullptr || content[0] == '\0') {
        std::cout << "Input file is empty or contains no data." << std::endl;
        return;
    }

    // Find and analyze all global variable definitions in the input file
    for (int I = 0; I < content.length(); i++) {
        if (content[i] == 'A' && content[i + 1] == 'L' && content[i + 2] == 'O' && content[i + 3] == 'T') {
            // Find and analyze all global variable definitions in the input file
            std::cout << "Global Variable Definition: " << content.substr(i, i + 9) << std::endl;
        } else if (content[i] == 'R' && content[i + 1] == 'E' && content[i + 2] == 'G' && content[i + 3] == 'N') {
            // Find and analyze all register assignments in the input file
            std::cout << "Register Assignment: " << content.substr(i, i + 11) << std::endl;
        } else if (content[i] == 'C' && content[i + 1] == 'O' && content[i + 2] == 'D') {
            // Find and analyze all conditionals in the input file
            std::cout << "Condition: " << content.substr(i, i + 6) << std::endl;
        } else if (content[i] == 'E' && content[i + 1] == 'D' && content[i + 2] == 'S' && content[i + 3] == 'E') {
            // Find and analyze all statements in the input file
            std::cout << "Statement: " << content.substr(i, i + 7) << std::endl;
        } else if (content[i] == ';') {
            // Skip comment lines
            while (std::getline(ifs, content)) {}
        }
    }

    // Close input file and get its error code
    const int error_code = std::ifstream::failure(ifs);

    // Check if file was opened successfully or not
    if (error_code != 0) {
        std::cout << "Error opening input file: " << error_code << std::endl;
    } else {
        std::cout << "Input file analysis completed." << std::endl;
    }
}

int main(int argc, char *argv[]) {
    // Get input filename from user
    const char *filename = argv[1];
    
    try {
        registerAllocation(filename);
    } catch (const std::exception &e) {
        std::cout << "Error: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}