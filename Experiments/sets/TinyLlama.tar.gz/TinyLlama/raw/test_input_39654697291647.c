
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if(argc != 2){
        printf("Invalid arguments\n");
        return -1;
    }
    
    int len = atoi(argv[1]);
    
    // VLA (variable length array)
    float *arr = (float*) malloc(len * sizeof(float));
    
    for(int I = 0; I < len; i++){
        arr[i] = (float)rand() / RAND_MAX;
    }
    
    printf("Original array:\n");
    for(int I = 0; I < len; i++) {
        printf("%.2f ", arr[i]);
    }
    printf("\n");
    
    // Loop-invariant code motion optimization (LCOM)
    for(int I = 0; I < len; i++){
        float min_val = arr[i];
        
        for(int j = I+1; j < len; j++){
            if(arr[j] < min_val){
                min_val = arr[j];
            }
        }
        
        arr[i] = min_val;
    }
    
    printf("Optimized array:\n");
    for(int I = 0; I < len; i++) {
        printf("%.2f ", arr[i]);
    }
    printf("\n");
    
    free(arr);
    
    return 0;
}