
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s file\n", argv[0]);
        return 1;
    } else {
        int I = atoi(argv[1]);
        int j = 1;
        
        FILE *file = fopen(argv[1], "r");
        if (file == NULL) {
            printf("Error: Could not open file %s\n", argv[1]);
            return 1;
        }
        
        while ((fscanf(file, "%c", &(char)I)) != EOF && I > j) {
            char name[30];
            sprintf(name, "%d.%c", I, I < 26 ? 'a' + I : 'A' + I);
            printf("%s ", argv[1]);
            
            fscanf(file, "%s", &name[j]);
            j++;
        }
        
        fclose(file);
        return 0;
    }
}