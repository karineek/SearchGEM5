
#include <stdio.h> /* printf, puts */
#include <stdlib.h> /* exit */
#include <unistd.h> /* execve(2) */

/* Define SIGILL to catch signals that may trigger the error */
#define SIGILL 100 /* same value as in sigsetjmp() definition */

int main(int argc, char *argv[]) {
    pid_t pid;
    
    if (argc < 2) {
        printf("Usage: %s [program] [arguments]\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    pid = fork();
    if (pid == 0) { /* Child process */
        execve("/bin/sh", argv + 1, argv[1]);
        exit(EXIT_FAILURE);
    }
    
    pid = wait(&status); /* Wait for the child process to finish */
    
    if (pid < 0) { /* Check for error */
        perror("Failed to execute child");
        exit(EXIT_FAILURE);
    } else if (WIFSIGNALED(status)) {
        printf("Child exited with signal %d\n", WTERMSIG(status));
    } else if (WIFEXITED(status) || WIFSIGNALED(status)) {
        printf("Child finished with status %d (%s)\n", WEXITSTATUS(status), strsignal(WEXITSTATUS(status)));
    } else {
        printf("Error: unexpected error during child execution\n");
        exit(EXIT_FAILURE);
    }
    
    return 0; /* Signal handler exits program */
}