
#include <stdio.h>
#include <stdlib.h>
#include "sparse.h"

int main(int argc, char **argv) {
    int n;
    double *A;
    
    if (argc != 2 || !strcmp(argv[1], "-?")) {
        printf("Usage: %s [-v] A\n", argv[0]);
        return 0;
    }
    
    n = atoi(argv[1]);
    
    if (argc != 3 || !strcmp(argv[2], "-v")) {
        printf("Creating sparse matrix of size %d\n", n);
    } else {
        A = create_sparse(n, false);
        printf("%d nonzeros in row #%d:\n", n-1, 1);
        for (int I = 1; I <= n-1; i++) {
            for (int j = 1; j <= n-i+1; j++) {
                if (A[i][j] > 0) {
                    printf("%d ", A[i][j]);
                } else {
                    printf("0 ");
                }
            }
            printf("\n");
        }
        
        // Saving sparse matrix to file
        if (argc != 3 || !strcmp(argv[2], "save")) {
            FILE *f = fopen(argv[3], "wb");
            save_sparse(A, f);
            fclose(f);
        }
    }
    
    return 0;
}