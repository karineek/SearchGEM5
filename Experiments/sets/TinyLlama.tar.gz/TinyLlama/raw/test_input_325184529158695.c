
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "opt.h"

/* A recursive function that generates a permutation of a given array based on an element at a random index */
int* permute(int arr[], int n, int target) {
    // Generate a random index for each array element
    srand((unsigned int)time(NULL));
    
    int i = 0;
    while (arr[i] != target) {
        // Generate a random index for this element
        int j = rand() % (n - 1);
        
        // Swap the elements at `i` and `j` positions
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = target;
    }
    
    return arr;
}

/* Function to execute the ScalaR Optimizations optimizer algorithm on a given input */
int main(int argc, char** argv) {
    int n, i, j, k, target;
    
    // Get input from user (input array and target element)
    if (argc > 2) {
        fprintf(stderr, "Usage: %s INPUT_ARRAY TARGET_ELEMENT\n", argv[0]);
        exit(1);
    }
    
    // Get input array length from user or default to 32 elements (32 is the maximum number of elements that can be processed in an Scalar-optimized execution)
    sscanf(argv[1], "%d", &n);
    
    if (n <= 0 || n > 32) {
        fprintf(stderr, "Invalid input array length. Must be between 1 and 32\n");
        exit(1);
    }
    
    // Get target element from user or default to the first element
    sscanf(argv[2], "%d", &target);
    
    if (target < 0 || target > n - 1) {
        fprintf(stderr, "Invalid input target element. Must be between 0 and %d\n", n - 1);
        exit(1);
    }
    
    // Get random seed from user or default to a fixed value for better reproducibility
    sscanf(argv[3], "%ld", &k);
    
    if (k <= 0) {
        k = 1;
    }
    
    int permutedInput[n][3]; // Array to store the permutation of the input array based on the target element
    int index = 0;          // Index of the current element in the original input array (used for generating random indices)
    
    while (index < n - 1) { // Generate a random permutation using a recursive function based on the current element and a given seed
        permutedInput[index][0] = index;
        permutedInput[index][1] = target;
        
        if (++index % k == 0 || index == n - 1) { // If we've generated all permutations, check if any of them is equal to the target element and report it
            for (i = 0; i < n; i++) {
                if (permutedInput[i][0] == target && permutedInput[i][1] == target) {
                    printf("%d %d\n", permutedInput[i][0], permutedInput[i][1]);
                    return 0; // Exit the program and print the generated output array
                }
            }
        }
        
        index = rand() % n - index + n; // Generate a random index for the current element (between original input array elements) and a given seed
    }
    
    printf("Error: No permutation found that matches the target element\n");
    return 0;
}