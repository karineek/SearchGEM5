
#include <stdio.h>  /* for printf() */
#include <stdlib.h>  /* for exit() */
#include <string.h>   /* for strlen() */

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s filename\n", argv[0]);
        exit(-1);
    }
    FILE *fp = fopen(argv[1], "r"); /* open file for reading */
    if (!fp) {
        fprintf(stderr, "Error: Cannot open file '%s'\n", argv[1]);
        exit(-1);
    }
    char line[50];
    int n = 0;
    while (fgets(line, sizeof(line), fp) != NULL) {
        if (strlen(line) > 0) {
            n++;
        }
    }
    fclose(fp);
    
    printf("Number of lines: %d\n", n);
    return 0;
}