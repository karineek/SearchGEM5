
#include <stdio.h>

int main(int argc, char *argv[]) {
    // The -i parameter indicates to accept one input file
    // Get input from stdin using getchar() and scanf("%s", argv[1])
    
    // Read in input text
    FILE *input = fopen(argv[1], "r");
    if (!input) {
        perror("error: unable to open file");
        return 1;
    }
    
    // Call bssearch() with the read input, and print the result
    char *str = NULL;
    int n = bssearch(input, str);
    if (n < 0) {
        perror("error: no matches found");
        fclose(input);
        return 1;
    }
    
    // Print the first match
    printf("%s\n", str);
    
    // Close input file and free memory allocated for str
    fclose(input);
    free(str);
    
    // Return zero to indicate success
    return 0;
}