
#include <stdio.h>
#include <time.h> /* For time_t */

/* Function to get current time in seconds */
static int gettime(struct timeval *tv) {
    struct timezone tz;
    int ret = 0;
    
    if (gettimeofday(&tv->tv_sec, &tv->tv_usec) != 0) {
        perror("Failed to get system time\n");
        ret = -1;
    }
    
    return ret;
}

/* Main function */
int main(int argc, char *argv[]) {
    struct timespec ts[2]; /* 2 seconds */
    int ret = 0;
    const long max_wait = 1800000000L; /* 30 minutes */
    
    if (argc > 1 && strcmp(argv[1], "-h") == 0) {
        printf("Usage: %s [-h]<seconds>\n", argv[0]);
        return 0;
    }
    
    while (1) {
        /* Set the current time */
        if (gettime(ts) == -1) {
            perror("Failed to get system time\n");
            ret = -1;
            break;
        } else {
            /* Calculate the difference between current and desired times */
            if ((ts[0].tv_sec + ts[1].tv_sec * 1000L) > max_wait) {
                printf("The specified time is too far in the future (%ld seconds)\n", max_wait - ts[1].tv_sec);
                break;
            } else if ((ts[0].tv_sec + ts[1].tv_sec * 1000L) < ts[0].tv_sec) {
                printf("The specified time is in the future (%ld seconds)\n", ts[1].tv_sec - ts[0].tv_sec);
                break;
            } else {
                /* Calculate difference between desired and current times */
                int sec = ts[1].tv_sec;
                int min = ts[1].tv_usec / 1000L % 60;
                int hour = (ts[1].tv_usec / 1000L % 3600) / 60;
                
                printf("%ld.%02d:%02d\n", sec, min, hour);
            }
        }
        
        /* Wait for user to press enter */
        if (waitpid(0, NULL, 0) != waitpid(-1, NULL, 0)) {
            perror("Failed to wait for child process\n");
            return -1;
        }
    }
    
    return 0;
}