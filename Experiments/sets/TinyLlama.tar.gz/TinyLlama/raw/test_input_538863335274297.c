
/* SCCP - Sparse Conditional Constant Propagaion */
#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int a, b;
    int sum = 0;

    /* Input: get input from argv only */
    if (argc < 2) {
        fprintf(stderr, "Error: Invalid number of arguments\n");
        return 1;
    } else if (argv[1][0] != '-') {
        fprintf(stderr, "Error: Invalid first argument\n");
        return 1;
    }
    
    /* Input is a bitcode */
    FILE *file = fopen(argv[1], "r");
    if (!file) {
        fprintf(stderr, "Error: Cannot open file %s\n", argv[1]);
        return 1;
    }
    
    /* Handle LLVM bitcode */
    while ((a = getc(file)) != EOF) {
        if (isdigit(a)) {
            sum += a - '0';
        } else {
            printf("Error: Invalid input\n");
            fclose(file);
            return 1;
        }
    }
    
    /* Handle log10 type-generic macro */
    if (a != EOF) {
        while ((a = getc(file)) != EOF) {
            sum += log10((double) a - '0');
        }
    }
    
    /* Output result */
    printf("Sum: %d\n", sum);

    fclose(file);
    return 0;
}