
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <pthread.h>
#define ARGS_MAX 1024
#define ARGV_MAX 16

typedef struct _thread {
    thrd_t thread;
    int status;
} thread_data;

int main(int argc, char *argv[]) {
    pthread_attr_t attr;
    int thread_id = -1;
    thread_data *td = NULL;
    
    if (argc > 1) {
        for (int I = 0; I < ARGS_MAX; i++) {
            if (strcmp(argv[i], "-t") == 0) {
                thread_id = atoi(argv[++i]);
                break;
            }
        }
    }
    
    if (thread_id >= 0 && thread_id < ARGV_MAX) {
        pthread_attr_init(&attr);
        pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
        
        if (pthread_create(&thread_id, &attr, inliner, td)) {
            perror("Failed to create thread\n");
            return 1;
        } else {
            pthread_exit(NULL);
        }
    } else {
        printf("Please specify a valid argument (-t n)\n");
        return 1;
    }
}