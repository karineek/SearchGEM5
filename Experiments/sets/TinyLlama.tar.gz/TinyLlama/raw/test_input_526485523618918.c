
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

#define MAX_ARGS 10

void sigint_handler(int sig) {
    printf("SIGINT caught!\n");
}

int main() {
    pid_t pid = fork();
    
    if (pid == 0) { // child process
        int i;
        
        for (i = 1; i < MAX_ARGS; i++) {
            printf("%s ", argv[i]);
        }
        putchar('\n');
        
        exit(0);
    } else if (pid > 0) { // parent process
        int rc;
        
        rc = execvp("whole_program_analysis", NULL);
        
        perror("execvp failed");
        exit(EXIT_FAILURE);
    } else { // error handling
        printf("Invalid arguments.\n");
        return 1;
    }
}