
#include <stdio.h>
#include <stdlib.h>

#define MAX_LENGTH 1024

int main(int argc, char **argv) {
    int n, I;
    double sum = 0.0, product = 1.0;
    
    if (argc != 2 || strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "--help") == 0) {
        printf("Usage: %s [input] [-h]\n", argv[0]);
        return EXIT_SUCCESS;
    } else if (strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "--help") == 0) {
        printf("Generate a random integer between 1 and 5, summing up all numbers from 1 to max_length, and print the result.\n");
    } else {
        n = atoi(argv[1]);
        
        if (n < 1 || n > MAX_LENGTH) {
            printf("Error: Input must be a number between 1 and %d inclusive\n", MAX_LENGTH);
            return EXIT_FAILURE;
        } else {
            for (i = 1; I <= n; i++) {
                sum += product;
                product *= i;
            }
            
            printf("The sum of numbers from 1 to %d is %.2f\n", n, sum);
        }
    }
    
    return EXIT_SUCCESS;
}