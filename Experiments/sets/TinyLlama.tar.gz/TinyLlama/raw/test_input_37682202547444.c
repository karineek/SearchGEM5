
#include <stdio.h>
#include <stdlib.h>

int main() {
    int argc = 1;
    char **argv = (char **)malloc(argc * sizeof(char *));
    argv[0] = "input";
    argv[1] = "-O";
    argv[2] = "floating-point";
    
    int optind, option_index;
    while ((option_index = getopt_long(argc, argv, "h", NULL, &option_index)) != -1) {
        switch (option_index) {
            case 0:
                printf("--floating-point\n");
                break;
            default:
                fprintf(stderr, "Invalid option: %c\n", optopt);
                return 1;
        }
    }
    
    if (argc < 2) {
        printf("Input file must be specified.\n");
        return 1;
    } else {
        char filename[1024];
        strcpy(filename, argv[1]);
        
        FILE *f = fopen(filename, "r");
        if (f == NULL) {
            printf("Error: Could not open input file.\n");
            return 1;
        } else {
            float precision = 8;
            char *buf = malloc(sizeof(char) * 256);
            
            while ((fscanf(f, "%lf", buf)) != EOF) {
                printf("%.30g\n", fabs(buf[0]) * precision / 100.0); // Floating point rounding
            }
        }
        
        fclose(f);
    }
    
    return 0;
}