
#include <stdio.h> // for printf()
#include <stdlib.h> // for exit()
#include <math.h>  // for sincos()

// Function to compute the sine and cosine of an angle in degrees (angle is in radians)
float sin_cos(float angle) {
    return sincos(angle * M_PI / 180);
}

int main() {
    float pi = 3.1415926535897; // PI constant

    // Get user input in argv only
    char filename[100];
    if (argc > 1) {
        sprintf(filename, "%s", argv[1]);
    } else {
        printf("Usage: %s [file.txt]\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    // Open file for reading and write
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        printf("Error: Cannot open file '%s'\n", filename);
        exit(EXIT_FAILURE);
    }
    fclose(fp);

    // Read data from file and calculate sine and cosine of angle in radians
    float angles[10];
    int n = 0;
    while (fscanf(fp, "%f", &angles[n]) == 1 && n < 10) {
        angles[n] *= pi; // Convert degrees to radians
        sincos(angles[n], &angles[n]);
        printf("%d %.2f\n", ++n, angles[n]);
    }

    // Print out results and exit
    fprintf("Angle(deg): ");
    for (int I = 0; I < n; i++) {
        printf("%.2f ", angles[i]);
    }
    printf("\n");
    fflush(stdout);

    // Close file and exit if successful
    if (fclose(fp) == EOF) {
        printf("Error: Cannot close file '%s'\n", filename);
        exit(EXIT_FAILURE);
    } else {
        printf("Finished!\n");
        return 0;
    }
}