
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "profile.h" // include coverage profile to determine the best alignment

int main(int argc, char *argv[]) {
    if (argc != 2) { // check that there's only one argument provided
        fprintf(stderr, "Usage: %s <input.txt>\n", argv[0]);
        exit(1);
    }

    const char *input_filename = argv[1];
    
    FILE *file = fopen(input_filename, "r"); // open input file for reading
    if (!file) {
        perror("Error: cannot open input file");
        exit(1);
    }
    
    char buf[MAX_ALIGN]; // buffer to hold input data
    size_t read = fread(buf, 1, MAX_ALIGN - 1, file); // read input data until end-of-file is reached
    if (read == 0) {
        perror("Error: cannot read input file");
        exit(1);
    }
    
    fclose(file); // close input file for future use

    // compute optimal alignment using coverage profile
    unsigned max_align = find_optimal_alignment(buf, MAX_ALIGN - 1); // find alignment that maximizes coverage
    if (max_align == 0) { // no valid alignment found; exit with error message
        fprintf(stderr, "Error: input data does not fit into any alignment\n");
        return 1;
    }
    
    char *output_filename = "aligned.txt"; // output filename for aligned data
    FILE *output = fopen(output_filename, "wb"); // open output file for writing
    if (!output) {
        perror("Error: cannot open output file");
        return 1;
    }
    
    unsigned alignment = max_align; // alignment found to align input data with
    char *aligned_data = aligned_to_bytes(buf, alignment); // allocate memory for aligned data
    
    fwrite(aligned_data, 1, alignment, output); // write aligned data to output file
    
    return 0;
}