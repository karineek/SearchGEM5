
#include <stdio.h>
#include <stdlib.h>
#define MAX_ARG 1000

int main(int argc, char *argv[]) {
    int n;
    
    if (argc <= 1) {
        printf("Usage: %s [number]\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    for (n = MAX_ARG; n >= 1 && !(argc > 2 && strcmp(argv[1], "-") == 0); --n, ++argv[0]) {
        printf("%d: %s\n", n, argv[0] ? *argv[0] : "");
    }
    
    return EXIT_SUCCESS;
}