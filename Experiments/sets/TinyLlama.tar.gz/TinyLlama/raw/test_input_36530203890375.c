
#include <stdio.h>
#include <stdlib.h>

int main() {
    char arg1[32]; // maximum arg length is 255 (max shell variable length)
    char arg2[64]; // maximum arg length for BASH is 8000 (MAX_ARG_LEN in bash.h)
    int nargs;
    
    if(argc >= 3){
        strcpy(arg1, argv[1]);
        strcpy(arg2, argv[2]);
        
        // get remaining arguments after argc-3
        for(nargs = 3; nargs < argc; nargs++) {
            sprintf(arg1 + (strlen(arg1) - 1), "%s", argv[nargs]);
            sprintf(arg2 + (strlen(arg2) - 1), "%s", argv[nargs]);
        }
        
        printf("Enter a BASH command to be executed: ");
        fflush(NULL);
        getline(&buf[0], MAX_STR, stdin);
        buf[MAX_STR - 1] = '\0'; // remove trailing newline
        
        int retcode;
        switch (0) {
            case (strlen(arg1) == strlen(arg2)):
                retcode = system(buf);
                printf("BASH command successfully executed: %s\n", buf);
                return 0;
                
            default:
                fprintf(stderr, "Too many arguments or invalid BASH syntax\n");
                return EXIT_FAILURE; // exit with error status
        }
    } else {
        printf("Usage: %s [<args>] [<command>]\n", argv[0]);
    }
    
    return 0;
}