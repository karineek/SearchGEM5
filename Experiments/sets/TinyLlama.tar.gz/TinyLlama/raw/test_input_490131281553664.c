
#include <stdio.h> /* printf() */
#include <stdlib.h> /* exit() */
#include <string.h> /* strlen() */

int main(int argc, char* argv[]) {
    
    if (argc != 2) {
        fprintf(stderr, "Usage: %s BASH\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    const char* input = argv[1]; // Read the input from argv
    
    for (int I = 0; I < strlen(input); i++) {
        printf("%c", input[i]);
    }
    
    return 0;
}