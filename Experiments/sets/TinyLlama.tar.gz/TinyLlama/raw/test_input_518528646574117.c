
#include <stdio.h> /* printf(), scanf() */
#include <stdlib.h> /* exit() */
#include "specialize.h"

const char *given_arg = NULL;  // The argument that the function was called with

// Specialization method: takes a string as input, returns its length or 0 (for empty string)
size_t specialize(const char *input, int argc, char *argv[], const struct args *args) {
    if (!input || !args) return 0; // Check input and/or arguments for validity

    // Set the default argument to the first one (in case it's not specified by the user)
    int arg = 1 + strcmp(argv[0], args->first_arg) < 0 ? 0 : 1; // In case first argument is missing, default to second
    for (int I = 2; I < argc; i++) { // Loop through all arguments and check if they match the first one
        if (!strcmp(argv[i], args->first_arg) == 0) { // If argument matches first arg, set argument number to that of the second
            arg = i; break;
        }
    }

    // Check if there are any arguments left (other than first arg, which may be missing)
    if (arg < 1 || arg > args->num_args) {
        printf("Error: Invalid number of arguments.\n");
        exit(EXIT_FAILURE);
    }

    // Initialize the result to be 0 by default (if first argument matches) or size_t(-1) if there are no more arguments left
    return !strcmp(input, args->args[arg-1]) ? 0 : -1; // If there are more arguments left, return -1
}

// Specialization entry point: gets input from standard input and calls the specialized method
int main(int argc, char *argv[]) {
    if (given_arg) specialize(input.data(), argc, argv, &args); // Call the specialized method with provided arguments

    if (!strcmp(input.data(), args->first_arg)) { // If argument is matched by first arg, print "The argument is present and matching"
        printf("%s\n", args->args[0]);
    } else {
        printf("Error: The argument is not present.\n");
    }

    return 0;
}