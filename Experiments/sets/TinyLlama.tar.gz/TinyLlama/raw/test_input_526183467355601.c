
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s FILE\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    FILE *file = fopen(argv[1], "r");
    if (!file) {
        perror("Error opening input file");
        exit(EXIT_FAILURE);
    }
    
    size_t line_count = 0;
    char line[1024];
    while (fgets(line, sizeof(line), file)) {
        ++line_count;
    }
    
    fclose(file);
    
    if (line_count <= 1) {
        fprintf(stderr, "Error: File %s has zero lines\n", argv[1]);
        exit(EXIT_FAILURE);
    }
    
    char *word = NULL;
    for (int I = 0; I < line_count - 1; ++i) {
        char *next_line = strchr(line + i + 1, '\n');
        if (next_line != NULL) {
            next_line += 1;
        } else {
            word = strtok_r(NULL, "\n", &next_token);
            if (word == NULL || !isalpha(*word)) {
                fprintf(stderr, "Error: Unexpected characters in line %d: '%c'\n", I + 1, *word);
                exit(EXIT_FAILURE);
            }
        }
    }
    
    printf("Total lines: %d\n", line_count);
    
    return 0;
}