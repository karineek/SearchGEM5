
$ echo "123" | ./loopfuzi -cpowl
1486