
#include <stdio.h>

int main(int argc, char **argv) {
    int I = 0; // Index to the command line argument
    
    while (argc > I + 1 && !(argv[i][0] == '-' || argv[i][0] == '/')) {
        if (argv[i][0] != '+') {
            puts("Invalid option: " + argv[i]);
            return 1; // Exit with error code 1 (non-zero)
        }
        
        I++;
    }
    
    if (argc > i + 1 || argc < i + 2) {
        puts("Missing arguments. " + argv[0] + ": " + argv[++i]); // Display help message
        return 1;
    }
    
    // Input parsed and processed here (e.g. Handle input/output, etc.)
    
    return 0;
}