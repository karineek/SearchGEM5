
$ cat sample_input.sh
echo "script 1" | sh
echo "script 2" | sh