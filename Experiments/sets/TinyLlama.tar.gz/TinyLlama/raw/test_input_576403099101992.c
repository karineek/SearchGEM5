
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "llvm/ADT/StringExtras.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/DerivedTypes.h"
#include "llvm/Pass.h"
#include "llvm/Support/CommandLine.h"
#include "llvm/Support/TargetSelect.h"
#include "llvm/Transforms/Vectorize/VFTargetDependentOpt.h"

using namespace llvm;

namespace {
  struct VFTargetDependentOpt : public VFTask {
    int passNum;
    bool runOnce = false;
    const char *name = "vector_pass"; // Pass name to LLVM
    unsigned numTargets = 0; // Number of targets supported by this pass

    VFTargetDependentOpt(llvm::StringRef aName, int aPassNum) : VFTask(aName), passNum(aPassNum) {}
    ~VFTargetDependentOpt() override {
      for (int I = 0; I < numTargets; i++) {
        delete llvm::TargetTransforms[i];
      }
      llvm::TargetTransforms.clear(); // Clear out all the passes
    }
    static bool classof(const VFTargetDependentOpt* op) { return op->passNum >= 0; }
  };
}

static cl::opt<int> VFNum("vector-targets",
                         cl::desc<int>(),
                         cl::init(0),
                         cl::value_desc("<num>"),
                         cl::Positional,
                         cl::NotRequired)
    .required(); // Required by LLVM

static cl::opt<std::string> VFTrans("vector-transforms",
                                    cl::desc<std::string>(),
                                    cl::value_describer(
                                        &VFTargetDependentOpt::llvm::TargetTransforms),
                                    cl::init({"default"}),
                                    cl::NotRequired)
    .required(); // Required by LLVM

int main(int argc, char **argv) {
  setlocale(LC_ALL, "");
  std::vector<std::string> targets;
  for (int I = 1; i < argc; i++) {
    if (argc == i + 1 && isspace(*++argv)) continue; // Skip options before arguments
    targets.emplace_back(argv[i]);
  }
  llvm::ErrorOr<std::vector<std::unique_ptr<llvm::Module>>> modules =
      llvm::createVectorizedModulesFromTargets(targets, VFNum, VFTrans);
  if (!modules) return 1; // Failure occurred
  std::vector<llvm::Module *> modulesPtrs = std::move(std::move(modules.get())).get();
  for (auto &M : modulesPtrs) {
    M->setDataLayout("e-");
  }
  return 0; // Successful completion with modules created from specified targets and vectorized by default
}