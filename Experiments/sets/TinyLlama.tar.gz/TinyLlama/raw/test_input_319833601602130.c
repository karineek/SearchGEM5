
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> /* for getpgid() */
#include "ctso_utils.h"

/* TSO functions */
static void tso_func(char *filename, char *str) {
  printf("%s\n", str);
}

int main(int argc, char *argv[]) {
  // Get input filename from command line argument
  if (argc > 1) {
    FILE *inputfile = fopen(argv[1], "r");
    if (!inputfile) {
      perror("Could not open file for reading");
      exit(EXIT_FAILURE);
    }
    int linecount = 0;
    char inputbuffer[MAX_FILE_SIZE]; /* Buffer to read from file */
    size_t bufferlen = sizeof(inputbuffer);
    while (fread(inputbuffer, 1, bufferlen, inputfile) != 0 && bufferlen > 0) {
      linecount++;
      if (!isatty(fileno(stdin))) {
        printf("Line %d: %s\n", linecount, inputbuffer);
      }
    }
    fclose(inputfile);
  } else {
    printf("No file specified.\n");
  }

  // Get BASH environment and perform TSO on it
  char *commandline = getenv("BASH_ENV");
  if (commandline) {
    char *filename = NULL; /* Pointer to filename */
    size_t filenamelen = strlen(commandline);
    FILE *inputfile = fopen(commandline, "r");
    if (!inputfile) {
      perror("Could not open BASH file for reading");
      exit(EXIT_FAILURE);
    }
    char inputbuffer[MAX_FILE_SIZE]; /* Buffer to read from file */
    size_t bufferlen = sizeof(inputbuffer);
    while (fread(inputbuffer, 1, bufferlen, inputfile) != 0 && bufferlen > 0) {
      linecount++;
      if (!isatty(fileno(stdin))) {
        printf("Line %d: %s\n", linecount, inputbuffer);
      }
    }
    fclose(inputfile);

    // Execute TSO on BASH file using function provided by CTSO_Utils.h
    char *command = (char *)calloc(MAX_COMMAND_LEN + 1, sizeof(char)); /* Buffer to store command */
    sprintf(command, "%s %s", CMD_TSO_FILENAME, filename); /* Command line with TSO file name and BASH input file */
    int rc = system(command); /* Run system command */
    if (rc < 0) {
      perror("CTSO failed to execute");
      exit(EXIT_FAILURE);
    }

    // Parse output of TSO and print results
    char *outputbuffer[MAX_COMMAND_LEN]; /* Buffer to read output buffer */
    size_t outputlen = 0; /* Count of bytes in output buffer */
    do {
      ssize_t rc = fread(outputbuffer, 1, MAX_COMMAND_LEN - outputlen, stdin);
      if (rc < 0) {
        perror("Error reading input from file");
        exit(EXIT_FAILURE);
      } else if (rc == 0) { /* EOF reached */
        break;
      } else if (rc > 0) {
        linecount++; // Line count is incremented even for empty output lines
        printf("Line %d: %s\n", linecount, outputbuffer);
      }
    } while (1); /* Loop until end of file reached */

    free(command);
  } else {
    printf("No BASH environment specified.\n");
  }

  return 0;
}