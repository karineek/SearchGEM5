
#include <stdio.h>
#include <stdlib.h>

int main(void) {
    char argv[2] = {"-s", "1"}; // "-s" and "1" as an array
    
    if (argc != 2 || strcmp(argv[0], "-s") != 0 || strcmp(argv[1], "1") != 0) { // Check for valid inputs
        printf("Error: Invalid arguments\n");
        return 1;
    }
    
    // Handle BASH execution by checking for exit code and exiting if it's non-zero
    if (system(argv[0]) == -1) {
        perror("Error executing BASH script: ");
        return 1;
    }
    
    printf("BASH script executed successfully\n");
    
    return 0;
}