
#include <stdio.h>
#include "llvm/IR/Module.h"
#include "llvm/IR/DerivedTypes.h"
#include "llvm/IR/TypeBuilder.h"
#include "llvm/IR/Constants.h"
#include "llvm/IR/DerivedTypes.h"
#include "llvm/IR/DerivedTypes.inc" // for builtin types (e.g., int, float)
#include "llvm/IR/Function.h"
#include "llvm/IR/FunctionBuilder.h"
#include "llvm/IR/GlobalVariable.h"

using namespace llvm;

// A simple BASH interpreter that uses LLVM IR for its operations.
struct BASh {
  LLVMContext *context;
  Module *module;
  Function *interp;
  
  // LLVM IR function builder for builtin types.
  LLVMIRBuilder *irbuilder;
  
  // LLVM IR global variable builder.
  LLVMMetadataBuilder *globalvarbuilder;

  BASh(LLVMContext *c, Module *m) : context(c), module(m), interp(nullptr) {
    irbuilder = new LLVMIRBuilder(*context);
    globalvarbuilder = new LLVMMetadataBuilder(*context);
  }
  
  ~BASh() { delete irbuilder; delete globalvarbuilder; }

  // Helper function for generating a LLVM IR function.
  void genFunc(const std::string &name, const std::vector<LLVMType *> &argtypes) {
    FunctionType *ftype = FunctionType::get(Int32Ty, argtypes, false);
    Function *f = Function::createFunction(Name(name), ftype, module->getGlobalSection(), irbuilder);
    f->setMetadata(metadata_attr::LLVMFunction, globalvarbuilder);
  }
  
  // Helper function for generating a LLVM IR global variable.
  void genGlobVar(const std::string &name, const LLVMType *typ) {
    GlobalVariable *gv = GlobalVariable::create(Name(name), typ, true, irbuilder);
    gv->setMetadata(metadata_attr::LLVMMetadata, globalvarbuilder);
  }
  
  // Generates a BASH script that can be run by the interpreter.
  void genScript() {
    std::string script = "#!/bin/bash\n";
    script += "function \"my_func\"() {\n"
            + "  echo \"hello world!\"\n"
            + "}\n";
    
    script += "\n"; // add space for user input.
    
    std::string arg1 = ""; // first argument to the function
    std::vector<std::string> args;
    for (int I = 2; I < argc; i++) {
      if (!std::istringstream(argv[i]) >> arg1) {
        fprintf(stderr, "Error: Invalid input\n");
        return;
      }
      
      std::string argtype = arg1.substr(0, 3); // extract argument type
      if (argtype != "int" && argtype != "float") {
        fprintf(stderr, "Error: Invalid input\n");
        return;
      }
      
      std::vector<LLVMType *> argtypes;
      if (argtype == "int") {
        argtypes.push_back(IntTy); // argument is int
      } else {
        argtypes.push_back(FloatTy); // argument is float
      }
      
      genFunc("my_func", argtypes);
      
      args.push_back(arg1); // add user input to the arguments
    }
    
    script += "./a.out \"";
    for (int I = 0; I < args.size(); i++) {
      script += '"' + args[i] + '"';
      if (i != args.size() - 1) {
        script += ' ';
      }
    }
    
    script += "\"\n"; // add space for user input.
    
    std::string exec = script;
    int ret = system(exec.c_str());
    
    if (ret != 0) {
      fprintf(stderr, "Error: Execution failed\n");
    }
  }
  
  // Main entry point for the interpreter.
  static void run() {
    std::string script = "#!/bin/bash\n";
    
    genScript();
    script += "./a.out \"";
    for (int I = 0; I < args.size(); i++) {
      script += '"' + args[i] + '"';
      if (i != args.size() - 1) {
        script += ' ';
      }
    }
    
    script += "\"\n"; // add space for user input.
    
    std::string exec = script;
    int ret = system(exec.c_str());
    
    if (ret != 0) {
      fprintf(stderr, "Error: Execution failed\n");
    } else {
      printf("Hello world!\n"); // run the script and print output to console
    }
  }
  
}; // end of BASh class.

int main() {
  LLVMContext *c = new LLVMContext();
  Module *m = Module::create("BASh", c);
  BASh bash(c, m);
  bash.run();
}