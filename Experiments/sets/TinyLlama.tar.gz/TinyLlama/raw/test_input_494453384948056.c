
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

// global data member to keep track of shared memory id
volatile int shared_id;

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s <shm_name>\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    // open shared memory file using shmget() and get shared memory id
    int shmid = shmget(IPC_PRIV, sizeof(int), 0644 | IPC_CREAT | IPC_NOWAIT);
    if (shmid < 0) {
        perror("Failed to open shared memory");
        exit(EXIT_FAILURE);
    }
    
    // read shared memory id from shared memory file and store in global data member
    int shared_id = shmdt(argv[1]) == -1 ? -1 : shmid;
    
    printf("Shared memory ID: %d\n", shared_id);
    
    return 0;
}