
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    int n;
    
    if (argc == 2) {
        n = atoi(argv[1]);
        
        if (n > 0 && n <= MAX_INPUT_SIZE) {
            printf("Enter a BASH script:\n");
            fgets(buf, sizeof(buf), stdin);
            
            strcpy(buf[0], "\$ "); // add space after '[' to indicate end of input
            buf[strlen(buf)-1] = '\r'; // add newline to end of input
            
            int len = strlen(buf);
            if (n >= 2 && n <= MAX_INPUT_SIZE) {
                for (int j = 0; j < len; j++) {
                    buf[j] = iswdigit((unsigned char)buf[j]) ? '\'' : '\\';
                }
            } else {
                for (int j = 0; j < n; j++) {
                    buf[j] = ' '; // replace spaces with ' ' to make input shorter
                }
            }
            
            printf("%s", buf);
            fgets(buf, sizeof(buf), stdin);
        } else {
            perror("Input size is not valid (<= 0 and < " MAX_INPUT_SIZE ")\n");
            return EXIT_FAILURE;
        }
    } else {
        printf("Usage: %s [script]\n", argv[0]);
        return EXIT_SUCCESS;
    }
    
    return 0;
}