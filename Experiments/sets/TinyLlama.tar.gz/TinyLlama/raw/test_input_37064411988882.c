
#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]) {
    char input[1024]; //input buffer for BASH
    
    if (argc != 2) { //check that there are two arguments provided
        printf("Usage: %s [BASH script]\n", argv[0]);
        return 1;
    }
    
    FILE *fptr = fopen(argv[1], "r"); //try to open the BASH file with read access
    
    if (fptr == NULL) { //check if the file was successfully opened
        printf("Error: cannot open %s for reading\n", argv[1]);
        return 2;
    }
    
    fseek(fptr, 0, SEEK_END); //set the file pointer to the end of the BASH file
    int size = ftell(fptr); //get the file size in bytes
    
    if (size == -1) { //check if the file is successfully opened
        printf("Error: cannot determine size of %s\n", argv[1]);
        fclose(fptr);
        return 3;
    }
    
    input[0] = '\0'; //reset input buffer to empty string
    
    if (fgets(input, sizeof(input), fptr) == NULL) { //check that file was fully read
        printf("Error: cannot read entire %s\n", argv[1]);
        fclose(fptr);
        return 4;
    }
    
    fclose(fptr); //close the BASH file and all associated resources
    
    if (input[0] == '\0') { //check for an empty input string
        printf("Error: empty input\n");
        return 5;
    }
    
    int loop_count = 1; //initialize loop counter to 1
    
    while (loop_count <= size / sizeof(input[0])) { //loop through the BASH input string as long as it is not empty
        printf("%.*s", sizeof(input)/sizeof(char), input); //print current input string
        
        if (strncmp(input, "while ", 4) == 0 || strncmp(input, "until ", 4) == 0 || strncmp(input, "for ", 3) == 0) { //check that the input is not a loop keyword
            printf("Error: invalid loop keyword\n");
            return 6;
        }
        
        if (strcmp(input + 4, "do") == 0 || strcmp(input + 5, "while") == 0 || strcmp(input + 7, "until") == 0) { //check that the input is not a loop body keyword
            printf("Error: invalid loop body keyword\n");
            return 6;
        }
        
        char* endptr = NULL;
        
        if (strtol(input + 8, &endptr, 10) == 0) { //check for a valid number as the loop counter
            printf("Error: invalid loop counter\n");
            return 6;
        }
        
        char* var_name = strtok(NULL, " "); //get variable name from input string
        
        if (strcmp(input + 8, "do") == 0) { //check for a do loop
            printf("Do Loop: %s\n", var_name);
            
            while (var_name = strtok(NULL, " ") && strcmp(input + 4, "do") == 0) { //loop through the BASH input string as long as it is a do loop
                printf("%.*s", sizeof(input)/sizeof(char), input); //print current input string
                
                if (strcmp(input + strlen(input), "while ") != 0 && strcmp(input + strlen(input), "until ") != 0) { //check for loop body keywords
                    printf("Error: invalid loop keyword\n");
                    return 6;
                }
                
                if (strcmp(input + strlen(input), "do") == 0 && strcmp(input + strlen(input), "while ") != 0) { //check that the input is not a while loop body keyword
                    printf("Error: invalid while loop body keyword\n");
                    return 6;
                }
            }
        } else if (strcmp(input + 8, "until") == 0) { //check for an until loop
            printf("Until Loop: %s\n", var_name);
            
            while (var_name = strtok(NULL, " ") && strcmp(input + strlen(input), "until") == 0) { //loop through the BASH input string as long as it is an until loop
                printf("%.*s", sizeof(input)/sizeof(char), input); //print current input string
                
                if (strncmp(input, "do ", 3) != 0 || strcmp(input + strlen(input), "until ") == 0) { //check for loop body keywords
                    printf("Error: invalid loop keyword\n");
                    return 6;
                }
            }
        } else if (strncmp(input, "for ", 3) == 0 || strcmp(input + 3, "while") == 0) { //check for a while loop body keyword or an iteration count
            printf("For Loop: %s\n", var_name);
            
            while (var_name = strtok(NULL, " ") && strcmp(input + strlen(input), "for ") != 0 && strcmp(input + strlen(input), "while ") != 0) { //loop through the BASH input string as long as it is not a for loop or an iteration count
                printf("%.*s", sizeof(input)/sizeof(char), input); //print current input string
                
                if (strcmp(input + strlen(input), "while ") != 0) { //check for while loop body keywords
                    printf("Error: invalid while loop body keyword\n");
                    return 6;
                }
            }
        } else { //if the input is not a valid loop keyword or a valid loop body keyword, print an error message and exit with code 7
            printf("Error: invalid loop keyword/body keyword\n");
            return 7;
        }
        
        printf("\n"); //print newline after each loop iteration
    }
    
    return 0;
}