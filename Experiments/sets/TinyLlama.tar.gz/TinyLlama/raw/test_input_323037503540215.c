
#include <stdio.h>  /* for printf() */
#include "tso_opts.h"  /* for TSO options */

int main(void) {
    int i;
    double n, d, p, sum = 0.;
    double f[10], a[10];
    char argv0[256] = "hello";

    /* TSO optimizations: */
    puts("TSO optimization options:");
    printf(" -tso-type: %s (%c, %d)\n", tso_types[0], tso_types[1], tso_types[2]);
    printf(" -tso-size: %.2f\n", tso_size);
    printf(" -tso-precision: %.2f\n", tso_precision);
    printf(" -tso-loop-cost: %d\n", tso_loop_cost);

    /* Frontend optimization: */
    puts("Frontend optimization options:");
    printf(" -f: %.15s\n", argv0);
    if (argc == 2 && strcmp(argv[1], "hello") == 0) {
        printf("Hello, World!\n");
    } else {
        printf("Expected command \"hello\" for frontend optimization.\n");
    }

    /* Log1p function: */
    puts("Log1p function (FO):");
    for(i = 0; i < 10; i++) {
        f[i] = log1p(d);
        a[i] = d + n;
        sum += f[i];
    }
    printf("Sum: %.2f\n", sum / 10.);
    return 0;
}