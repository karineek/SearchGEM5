
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <limits.h> /* for PATH_MAX */
#include "argp.h"

typedef struct {
    char *argv[2];
    char *program;
    int argc;
} argp_state_t;

static const char usage[] =
    "Usage: %s [-r | -g | -d | -i] <inputfile> [options]\n"
    "  -r         read input file (default)";

int main(int argc, char **argv) {
    argp_parse(&argp_ctx, argv[0], argc, NULL, NULL, NULL);
    return 0;
}