
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    if (argc != 2 || strcmp(argv[1], "BASH") != 0) {
        printf("Usage: %s BASH\n", argv[0]);
        return 1;
    }
    
    if (!read_input(&argv[1])) {
        printf("Input is invalid.\n");
        return 1;
    }
    
    printf("%s\n", read_output(argv[1]));
    
    return 0;
}

bool read_input(char **ptr) {
    FILE *file = fopen(*ptr, "r");
    if (file == NULL) {
        perror("Failed to open input file.\n");
        return false;
    }
    
    int c = fgetc(file);
    while (!feof(file)) {
        if (c == '\n') {
            *ptr = next_line(*ptr);
        } else if (c == '\r' && feof(file)) {
            *ptr = NULL;
        } else {
            *ptr = c;
            c = fgetc(file);
        }
    }
    
    return true;
}

char **next_line(char **ptr) {
    char line[MAXLINE] = {0};
    int len = read_line(*ptr, &line[0], MAXLINE - 1);
    if (len > 0 && memcmp(line, "\n", sizeof("\n")) == 0) {
        return ptr;
    } else {
        *ptr = line;
        return next_line(*ptr);
    }
}

bool read_output(char **ptr) {
    return fgets(*ptr, MAXLINE, stdin) != NULL;
}