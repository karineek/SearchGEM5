
./myprogram.sh hello world 123