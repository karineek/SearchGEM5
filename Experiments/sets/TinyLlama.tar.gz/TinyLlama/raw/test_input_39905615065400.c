
#include <stdio.h>
#include "scala/scalaro.h"

int main(int argc, char* argv[]) {
    if (argc != 2 || strcmp(argv[1], "-h") == 0) {
        printf("Usage: %s [-h]\n", argv[0]);
        return 1;
    }
    
    Scalaro sra = scalaro_create();
    
    if (scalaro_run(sra, "sh -c \"echo \"Hello World!\" | scala\"") == 0) {
        printf("ScalaRO optimizations: Ok\n");
        scalaro_destroy(sra);
        return 0;
    } else {
        printf("ScalaRO optimizations: Error (unexpected result)\n");
        scalaro_destroy(sra);
        return 1;
    }
}