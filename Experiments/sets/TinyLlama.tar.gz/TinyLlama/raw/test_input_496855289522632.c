
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#define N 10 // number of elements to be generated

// function to generate random integers between min and max
int rand_int(int min, int max) {
    return (rand() % (max-min + 1)) + min;
}

// main program
int main(void) {
    // check command line input
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <args>\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    // generate random integers as input
    int n = atoi(argv[1]);
    if (n <= 0) {
        fprintf(stderr, "Invalid input: must be >= 1\n");
        exit(EXIT_FAILURE);
    }
    
    // generate output
    printf("Generated integers:\n");
    for (int I = 0; I < n; i++) {
        int val = rand_int(0, n-1);
        printf("%d ", val);
    }
    puts("\n");
    
    return 0;
}