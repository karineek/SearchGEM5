
#include <stdio.h>
#include "imaxdiv_t.h"

int main(int argc, char *argv[]) {
    double a = strtod(argv[1], NULL);  // argv[1] is the value to be divided by
    int b = atoi(argv[2]);
    int r = imaxdiv_t(a, b);           // use the imaxdiv() function with the provided parameters
    
    printf("r = %d\n", r);             // print the result using printf
    
    return 0;                          // exit successfully
}