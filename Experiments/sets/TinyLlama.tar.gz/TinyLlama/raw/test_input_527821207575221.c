
#include <stdio.h>
#include <string.h>

int main(void) {
    char input[256] = "";

    if (argc > 1) { // Input is via argument
        FILE *file = fopen(argv[1], "r");
        if (!file) {
            perror("Failed to open file\n");
            exit(EXIT_FAILURE);
        }
        fgets(input, sizeof(input), file); // Input from user
        fclose(file);
    } else {
        puts("Enter a string:"); // Get input via command line argument
        gets(input); // Get input via getchar()
    }
    
    printf("Validated input: %s\n", input); // Output validated input

    return 0;
}