
#include <stdio.h>
#include <stdlib.h>
#define MAXINT (int) 2147483647

// function to check if number is positive or negative
int ispositive(int n) {
    return (n >= 0);
}

// function to print a number in BASH format
void printnum(int n, char *sep) {
    int i;
    printf("%*s%d\n", MAXINT+3, sep, n);
    for (i = n - 1; I >= 0; i--) {
        putchar(' '); // print space
        printf("%*c%d\n", MAXINT+2, SEP, i);
    }
}

int main() {
    int num, maxnum = MAXINT;
    
    // read input using getargs
    if (argc > 1) {
        for (int I = 1; I < argc; ++i) {
            num = atoi(argv[i]);
            if (ispositive(num)) {
                maxnum = MAXINT; // increase maximum number of integers
                break;
            } else if (num > maxnum) {
                maxnum = num;
            }
        }
    }
    
    // execute loop optimizations to print smaller numbers first
    for (int I = 0; I < (maxnum + 1)/2; ++i) {
        printf("%*c%d\n", MAXINT+3, SEP, i * 2);
        printnum(i * 2 + 1, SEP + ' '); // print first half of list
    }
    
    // execute loop optimizations to print larger numbers last
    for (int I = (maxnum - maxnum % 2) / 2; I < maxnum; ++i) {
        printf("%*c%d\n", MAXINT+3, SEP, i * 2);
        printnum(i * 2 + 1, SEP + ' '); // print first half of list
    }
    
    return 0;
}