
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "optims.h"

int main(int argc, char *argv[]) {
    int opt;
    
    while ((opt = getopt(argc, argv, "p:d:")) != -1) {
        switch (opt) {
            case 'p':
                printf("%s\n", optarg);
                break;
            
            case 'd':
                printf("Using %s\n", optarg);
                break;
            
            default:
                fprintf(stderr, "Invalid option.\n");
                return 1;
        }
    }
    
    if (argc <= 2) {
        fprintf(stderr, "Usage: %s [options] input\n", argv[0]);
        return 1;
    } else {
        FILE *input = fopen(argv[1], "r");
        
        if (!input) {
            perror("Error: Unable to open input file");
            return 1;
        }
        
        char inputBuffer[1024];
        int nbytesRead = 0;
        
        while ((nbytesRead = fread(inputBuffer, 1, sizeof(inputBuffer), input)) > 0) {
            int score = scalaROptimizations(inputBuffer, nbytesRead);
            
            if (score != -1) {
                printf("%s\n", optarg); // Print the result to output stream
                fprintf(stdout, "%s\n", optarg); // Print the result to standard output stream
            } else {
                fprintf(stderr, "Error: Invalid input.\n");
            }
            
            // Update score and number of input bytes read
            score = scalaROptimizations(inputBuffer + nbytesRead, strlen(inputBuffer) - nbytesRead);
        }
        
        fclose(input);
    }
    
    return 0;
}