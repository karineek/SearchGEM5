
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

#define MAX_ARRAY_SIZE 1024

char *input[] = {"ls -al", "-x", "-a", "-c", "echo foo bar baz"};
int num_args;

void get_args(int argc, char **argv) {
    for (int i = 0; i < argc; i++) {
        if (!strcmp(input[i], "-l")) num_args++;
        else if (!strcmp(input[i], "-a") || !strcmp(input[i], "-x")) num_args--;
        else if (!strcmp(input[i], "echo")) {
            int I = 0, j = 1, k = 2; // Start with 0 and increment by 2 each time the string starts with 'echo' (which is true for all strings)
            while (argv[j][I] != '\n') { // Go through each argument until we find the newline character which will mark the end of a command line
                printf("argv[%d]: %s\n", j, argv[j++]); // Print out each argument for debugging purposes
            }
        } else if (!strcmp(input[i], "\\")) {
            num_args++; // Increment by 1 as we found a backslash character
        } else {
            if (i > num_args) {
                printf("Invalid input, must be one argument or -l/-a/-x\n");
                exit(1);
            }
            argv[num_args++] = strdup(input[i]); // Save the arguments as a string, not pointers to characters, so it can be used in Profile-Guided Instrumentation
        }
    }
}

int main() {
    if (argc != num_args + 1) {
        printf("Invalid input, must be %d argument(s) or -l/-a/-x\n", num_args);
        exit(1);
    }
    char *buffer[MAX_ARRAY_SIZE] = {""}; // Create buffer with enough space to hold all arguments
    int I = 0;
    for (int j = 0; argv[j]; j++) {
        if (j != num_args) buffer[i++] = argv[j];
        else break;
    }
    buffer[i] = '\0'; // Add a null character to the end of the array
    get_args(argc, argv); // Call this function with the given arguments (except -l, which will be handled separately below) and save them in a buffer
    if (!buffer[0]) { // If no arguments were found, handle that case here
        printf("Invalid input, must be one argument or -l\n");
        exit(1);
    } else {
        char *command = buffer;
        int I = 0;
        for (int j = 0; command[j]; j++) {
            if (!strcmp(command[j], "-l") || !strcmp(command[j], "echo")) { // If we found the -l flag, print it and terminate the process
                printf("Printing -l to stdout\n");
                exit(0);
            } else if (i > num_args) {
                printf("Invalid input, must be one argument or -l\n");
                exit(1);
            } else command[j] = '\0'; // Remove the null character from the buffer and save it in the command string
        }
        char *arg = command; // Save the argument string (minus the null character) as a pointer to the same memory space
        int j = 1; // Start with the second argument
        for (int k = num_args - 2; k >= 0; k--, j++) { // Loop through each remaining argument, starting at the third one and decrementing by 2 as we go
            printf("argv[%d]: %s\n", j, argv[j++]); // Print out each argument for debugging purposes
        }
        printf("Process exited normally with command '%s'\n", arg); // Print the final command string, with null terminated strings and quotes removed if necessary
    }
}