
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static int function(int x) {
    if (x > 10) {
        return 0; // non-specialized version
    } else {
        return x * x; // specialized version, using the `pow()` function from the BASH shell
    }
}

int main(void) {
    int n = atoi(argv[1]);
    
    printf("Result: %d\n", function(n));
    
    return 0;
}