
#include <stdio.h>
#include <stdlib.h>

int main() {
    int argc;
    char *argv[10];
    
    // get arguments
    argc = 1;
    for (int I = 0; i < argc; i++) {
        argv[i] = (char *) malloc(strlen(argv[0]) + strlen(arg[i]) + 2);
        strcpy(argv[i+1], argv[0]);
        strcat(argv[i+1], arg[i]);
    }
    
    // call main() function
    system(argv[0]);
    
    return 0;
}