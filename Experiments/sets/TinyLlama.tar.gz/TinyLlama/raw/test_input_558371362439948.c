
#include <stdio.h>
#include <string.h>
#include "llvm/ExecutionEngine/GenericValue.h"
#include "llvm/ExecutionEngine/JIT.h"
#include "llvm/IR/DataLayout.h"
#include "llvm/Support/CommandLine.h"
#include <unistd.h>

static llvm::cl::OptionCategory HelpCategory("General options");
static const char *ShortName = "coding-task";
static const char *LongName = "C coding task for BASH input only, returns program and example input";
static struct cl:: OptionOps helpOp;
static llvm::cl::list<std::string> argNames(helpOpts.arg_list());

int main(int argc, char **argv) {
  std::vector<std::string> args = llvm::cl::make_vec(argv + 1, argv + argc);
  if (args.empty()) {
    printf("Error: no input arguments provided.\n");
    return 1;
  }
  int argI = 0;
  int numArgs = llvm::cl::make_vec(argNames).size();
  for (int I = 0; I < numArgs; i++) {
    if (args[i].empty()) {
      printf("Error: input argument %d missing. Expected one argument.\n", I);
      return 1;
    }
    if (!llvm::cl::isLegalArgName(args[i], argNames[i])) {
      printf("Error: illegal input argument name '%s'. Allowed values are:\n%s\n", args[i].c_str(), argNames.join(", "));
      return 1;
    }
    argI++;
  }
  char *input = args[argI];
  if (input == nullptr) {
    printf("Error: input file name missing.\n");
    return 1;
  }
  std::vector<std::string> lines;
  FILE *f = fopen(input, "r");
  if (f == nullptr) {
    printf("Error: unable to open input file '%s'.\n", input);
    return 1;
  }
  char buf[4096];
  while (fgets(buf, sizeof(buf), f)) {
    lines.push_back(std::string{buf});
  }
  fclose(f);
  // Read the input file and return an array of strings for easy access by the program
  return lines;
}