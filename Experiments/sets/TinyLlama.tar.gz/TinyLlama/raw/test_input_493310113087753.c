
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>  // For getpagesize() and sysconf() functions

// Function to convert octal to decimal
int oct2dec(int num) {
    int dec = num * 10;  // Multiply by 10 for converting to decimal
    int rem = (num % 10); // Extract last digit, divide by 10 and store as remainder
    dec += (rem < 5 ? rem : 5 - rem) * (dec % 10); // Add last digit if it's not 5 or even, otherwise add last 5
    return dec;
}

int main() {
    int size = getpagesize();
    char buffer[size];
    pid_t pid = getpid();
    unsigned int pagesize = sysconf(_SC_PAGESIZE);
    
    // Print the system's default page size for reference
    printf("System default page size: %d bytes\n", pagesize);
    
    // Generate a random string of length 8 digits
    srand(time(NULL));
    char randomstr[8];
    for (int I = 0; I < 8; i++) {
        randomstr[i] = rand() % 9 + '0';
    }
    
    // Get input from user via argv only
    int argc = sizeof(buffer) / sizeof(char *);
    for (int I = 0; I < argc; i++) {
        char *str = strdup(argv[i]);
        if (!str) {
            perror("Error: Failed to allocate memory.");
            exit(1);
        }
        str[strlen(str)] = '\0';
        buffer[i] = str;
    }
    
    // Call the function that converts octal to decimal
    printf("%s\n", buffer);
    
    int output = oct2dec(atoi(&buffer[3]) * pagesize + pid * 100);
    
    printf("Decimal value: %d\n", output);
    
    return 0;
}