
#include <iostream>
using namespace std;

int main(int argc, char* argv[]) {
    int ret = 0;
    
    // Input the number of arguments
    if (argc > 1) {
        for (int I = 1; I < argc; i++) {
            cout << "Enter argument #" << I << ": ";
            cin >> argv[i];
            
            // Exit on any error
            if (cin.fail() || !cin.good()) {
                ret = 1;
            }
        }
    } else {
        cout << "No arguments given.\n";
    }
    
    return ret;
}