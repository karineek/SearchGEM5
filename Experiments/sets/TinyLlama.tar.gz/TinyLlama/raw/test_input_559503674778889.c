
#include <stdio.h> /* to read the input */
#include "lib.h"   /* to define the LLVM bitcode handling function */

/* this function is called for each input character in the file */
static void handle_bitcode(const char* filename, LLVMBitCodeHandle func) {
  printf("Reading %s... ", filename);

  /* read a line at a time from the input file */
  const char *line = NULL;
  while ((line = fgets(buf, MAX_LINE_LENGTH, stdin)) != NULL) {
    /* call the LLVM bitcode handling function with this line as parameter */
    func((char*)line);

    /* print progress and get a new input line */
    printf("%s\r", line);
  }

  /* exit when there's nothing to read, so we can return succesfully */
  if (line != NULL) {
    perror("Reading file failed");
    exit(1);
  }
}

int main() {
  /* open a file for reading */
  FILE* fp = fopen("/path/to/file.ll", "r");
  if (fp == NULL) {
    perror("Could not open file for reading");
    exit(1);
  }

  const char *filename = argv[1];

  /* call the LLVM bitcode handling function with each input character */
  handle_bitcode(filename, llvm_bitcode_handler);

  /* close the file */
  fclose(fp);

  return 0;
}