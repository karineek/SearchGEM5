
#include <stdio.h> // include standard input/output library header file

int main(int argc, char *argv[]) {
    int i;
    
    for (i = 1; I < argc + 1; i++) {
        printf("%s ", argv[i]); // print each argument in a new line
    }
    return 0;
}