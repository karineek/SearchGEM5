
#include <stdio.h>
#include <stdlib.h>
#include "my_const_folding.h"

int main(int argc, char *argv[]) {
    FILE *in = fopen(argv[1], "r"); // input file in readable format
    if (!in) {
        printf("Error: cannot open input file\n");
        return 1;
    }

    int ret = read_file(in, argc); // read all lines from input file
    if (ret < 0) {
        fclose(in);
        printf("Error: reading input file\n");
        return 2;
    }

    // const fold the code in BASH format
    char *buf = malloc(1024);
    buf[0] = '\0';
    if (!buf) {
        printf("Error: memory allocation failed\n");
        return 3;
    }
    
    ret = my_const_folding(buf, in, argc, argv); // code generation for BASH
    if (ret < 0) {
        fclose(in);
        free(buf);
        printf("Error: const folding\n");
        return 4;
    }

    buf[0] = '\0'; // add newline to the end of generated BASH file
    
    // call function that generates C code from BASH format
    ret = compile_file(buf, in); // generate a program from input
    if (ret < 0) {
        fclose(in);
        free(buf);
        printf("Error: compiling\n");
        return 5;
    }
    
    return 0;
}