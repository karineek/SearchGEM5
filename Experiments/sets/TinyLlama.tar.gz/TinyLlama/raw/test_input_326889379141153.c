
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char**argv) {
    // Check input number of arguments
    if (argc != 2) {
        printf("Usage: %s [input_file]\n", argv[0]);
        return 1;
    }

    FILE* file = fopen(argv[1], "r");
    if (!file) {
        perror("Failed to open input file");
        return 1;
    }

    // Read input from file
    char buffer[1024];
    int size = fread(buffer, sizeof(char), 1024, file);
    if (size == 0) {
        perror("Failed to read input file");
        fclose(file);
        return 1;
    }

    // Output result on console
    printf("%s\n", buffer);

    fclose(file);
    return 0;
}