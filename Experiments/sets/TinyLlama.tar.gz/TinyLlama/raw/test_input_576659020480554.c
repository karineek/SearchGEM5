
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>

/*
 * This function takes an argv as input and returns a n-wchar sequence.
 * The 'n' argument is optional.
 */
const wchar_t* get_n_wchars(int n) {
    if (n <= 0) {
        fprintf(stderr, "Invalid n value: %d\n", n);
        exit(EXIT_FAILURE);
    }
    return (n > 1 && n < WCHAR_MAX / 2) ? wchar_t('a') : (wchar_t(*)[WCHAR_MAX + 1]) {  /* Empty array */ };
}

int main(void) {
    const wchar_t* n_chars = get_n_wchars(argc > 1 ? atoi(argv[1]) : WCHAR_MAX);
    if (n_chars == NULL) {
        fprintf(stderr, "Could not retrieve n-wchar sequence.\n");
        exit(EXIT_FAILURE);
    } else if (strcmp(n_chars, "abcd") != 0) { /* Only one character */
        fprintf(stdout, "N-wchar sequence: %s\n", n_chars);
    } else {
        fprintf(stderr, "Multiple characters.\n");
    }
    return 0;
}