
/* This program reads in a BASH input file, performs TSO on it, and writes the result to stdout. */
#include <stdio.h>  // for fopen()
#include <stdlib.h> // for exit()
#include "coverity.h"  // for Coverity analysis

int main(int argc, char *argv[]) {
    if (argc != 2) {  // Check if no arguments given
        fprintf(stderr, "Usage: %s input_file\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    char *input = NULL;
    size_t input_size;

    // Open input file for reading
    if (fopen(argv[1], "r") == NULL) {
        fprintf(stderr, "Failed to open %s: %s\n", argv[1], strerror(errno));
        exit(EXIT_FAILURE);
    }

    // Read input and handle errors (e.g., invalid BASH syntax)
    if ((input_size = getline(&input, &input_size, fdopen(fileno(stdin), "r"))) < 0) {
        fprintf(stderr, "Failed to read input file: %s\n", strerror(errno));
        exit(EXIT_FAILURE);
    }

    // Apply TSO on the input and handle errors (e.g., invalid TSO syntax)
    Coverity_Run_TSO(input, input_size, 1, 0);

    // Write the output to stdout
    if ((output = fdopen(fileno(stdout), "w")) == NULL) {
        fprintf(stderr, "Failed to open stdout for writing: %s\n", strerror(errno));
        exit(EXIT_FAILURE);
    }

    // Write the output to the output file with TSO applied
    Coverity_Set_TSO_Flags(Coverity_TSO_Fast, 1);
    Coverity_Write(output, &input[0], input_size);

    // Close input and output files and clean up
    fclose(input);
    fclose(output);
    return 0;
}