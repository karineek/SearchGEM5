
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define INF 922384623456789012 // maximum value for int type in C

#define MAX_NUM_ARG 100    // maximum number of input arguments (max length 100 chars)

// Function to get the input argument(s) and return their sum up to n. The function uses recursion
int getArgSum(char argv[], int argc, char **argv, int *arg, int *n) {
    if (arg == MAX_NUM_ARG || argc > 1 || (*n < 0)) {
        return -1; // error in input
    } else if ((*arg = strcmp(argv[0], "--help")) == 0) {
        printf("Usage: %s [options] n\n", argv[0]);
        return 1;
    } else if (strcmp(argv[0], "-h") == 0 || strcmp(argv[0], "--help") == 0) {
        printf("%s\n", help);
        return 0;
    }

    *n = atoi(&argv[1][1]); // get int value of argument n from command line, starting with 1-th char
    if (*n <= 0 || *n >= MAX_NUM_ARG) {
        return -2; // error in input (bad range for n)
    } else {
        return recursiveGetSum(argv + 1, argc - 1, argv, arg, &n); // call the function recursively with updated arguments
    }
}

// Function to get the input argument (or default "--help" value for missing argument) and return its sum up to n. The function uses recursion
int recursiveGetSum(char *argv[], int argc, char **argv, int *arg, int *n) {
    if (*n <= 0) {
        printf("%s\n", help); // print error message (--help not given or invalid range for n)
        return -2;
    }

    if (strcmp(argv[1], "--help") == 0 || strcmp(argv[1], "-h") == 0) {
        printf("%s\n", help); // print help message for missing argument
        return 0; // end recursion and return default value for n
    } else if (strcmp(argv[1], "--") == 0) { // handle special case of first argument being empty ("-")
        *n = INF; // set maximum value of n to infinity (-2)
        return recursiveGetSum(argv + 2, argc - 2, argv, arg, &n); // call the function recursively with updated arguments
    } else if ((*arg < 0) || (*arg >= MAX_NUM_ARG)) {
        printf("%s\n", help); // print error message for invalid input (invalid negative argument or out-of-range for n)
        return -3; // end recursion and return default value for n
    } else {
        *n = (*arg < 0) ? INF : *n + *(++argv); // recursive call with updated arguments (-- and number as first argument)
        return recursiveGetSum(argv + 2, argc - 2, argv, arg, &n); // call the function recursively with updated arguments
    }
}