
#include <stdio.h>

int main() {
    int a, b;
    
    // Parse input from argv
    if (1 != printf("Enter two integers: ", &a, &b)) {
        return 1;
    }
    
    // Common Subexpression Elimination optimization
    if ((__STDC_VERSION__ >= 201806L) && (strcmp(argv[1], "2") == 0 || strcmp(argv[1], "3") == 0)) {
        printf("%d\n", a * b);
    } else {
        printf("Invalid input.\n");
        return 1;
    }
    
    return 0;
}