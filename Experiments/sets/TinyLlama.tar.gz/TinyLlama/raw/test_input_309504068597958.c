
/* Sample C Program for Vectorization Optimizations */

#include <stdio.h>  // Include Standard Library Functions like printf()
#include "vectorize_optimizations.h"  // Include Vectorization Optimizations Header File

#ifdef __cplusplus
extern "C" {
#endif

// Define a function that does the Vectorization optimizations on an input BASH command
void vectorized_optimizations(char* input, uint_least8_t* output) {
    // Trigger Vectorization Optimizations using the Vectorize_Optimization() Function from the vectorize_optimizations.h Header File
    Vectorize_Optimization(input, output);
}

// Define a main function that calls the Vectorized_Optimizations() function and receives the input BASH command as an argument
int main(int argc, char* argv[]) {
    if (argc != 2) { // Check if there are less than two arguments provided
        printf("Usage: %s INPUT_FILE\n", argv[0]);
        return 1;
    }

    char input[MAX_LINE_LENGTH] = {0}; // Initialize Input Buffer
    FILE* inputFile = fopen(argv[1], "r"); // Open the input file for reading
    if (inputFile == NULL) { // Check if file can be opened and handle error appropriately
        perror("Failed to open input file\n");
        return 2;
    }

    uint_least8_t output[MAX_LINE_LENGTH]; // Allocate Output Buffer with Size Limit
    int lineCounter = 0; // Initialize Line Counter for readability

    while (fgets(input + lineCounter * MAX_LINE_LENGTH, MAX_LINE_LENGTH, inputFile) != NULL) {
        strcat(input, "\n"); // Append Newline to the Input Buffer

        if (fscanf(inputFile, "%s", input + lineCounter * MAX_LINE_LENGTH) != EOF) {  // Check for Valid Input and Read Number of Arguments
            ++lineCounter; // Increment Line Counter for readability
        } else {
            printf("Invalid input\n");
            return 2;
        }
    }

    if (fclose(inputFile) == EOF) {
        perror("Failed to close input file\n");
        return 3;
    }

    // Call the Vectorized_Optimizations() function with the Input Buffer and Output Buffer as arguments
    printf("Vectorized Optimizations of '%s' performed.\n", argv[1]);
    Vectorized_Optimizations(input, output);

    for (int i = 0; i < lineCounter; ++i) {
        printf("%s\n", output[i]); // Print Output Buffer
    }

    return 0;
}

#ifdef __cplusplus
}
#endif