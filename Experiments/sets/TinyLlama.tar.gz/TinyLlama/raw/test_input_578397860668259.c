
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void thrd_equal(const struct threads *threads, void (*func)(void *), void *data) {
    int I = 0;
    while (threads[I].thread.status == THD_STATUS_RUNNING) {
        func((void *)&threads[i]);
        i++;
    }
}

int main(int argc, char *argv[]) {
    int pid, status;
    pid = fork();
    if (pid < 0) {
        perror("fork failed");
        exit(1);
    } else if (pid > 0) {
        for (;;) {
            sleep(1);
            printf("%s", ".");
            // Wait for child process to finish before moving on.
            wait(&status);
        }
    } else {
        // Parent process.
        char buf[BUF_SIZE] = {0};
        pid_t tid;
        while (1) {
            snprintf(buf, sizeof(buf), "%s", argv[1]);
            tid = fork();
            if (tid < 0) {
                perror("fork failed");
                exit(1);
            } else if (tid > 0) {
                // Child process.
                thrd_equal(&threads, &thrd_equal, (void *)&tid);
                printf("%s", buf);
            } else {
                // Parent process.
                sleep(1);
            }
        }
    }
    return 0;
}