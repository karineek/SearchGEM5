
#include <stdio.h>

int main(int argc, char* argv[]) {
    const char* message = "Hello world!";
    int strLen;
    
    if(argc != 2) {
        fprintf(stderr, "Usage: %s [string to print]\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    strLen = strlen(argv[1]);
    
    printf("%s\n", message);
    printf("Length of string: %d\n", strLen);
    
    return EXIT_SUCCESS;
}