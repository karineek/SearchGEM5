
#include <stdio.h>

int main() {
    int num;
    char* argv[10];
    
    // Get arguments
    if (argc > 1) {
        for (int i = 1; i < argc; i++) {
            argv[i-1] = argv[i];
        }
        argv[0] = argv[0]; // Remove first argument (bash)
    } else {
        fprintf(stderr, "Error: No arguments provided\n");
        return 1;
    }
    
    while ((num = getchar()) != EOF) {
        printf("%c", num);
    }
    
    return 0;
}