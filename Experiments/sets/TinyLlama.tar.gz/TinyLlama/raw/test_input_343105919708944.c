
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    FILE* file = fopen(argv[1], "r");
    if (!file) {
        perror("Error opening file");
        return EXIT_FAILURE;
    }
    
    printf("Input file: %s\n", argv[1]);
    
    // Read file and output to stdout
    fseek(file, 0, SEEK_END);
    int size = ftell(file);
    fseek(file, 0, SEEK_SET);
    char* buffer = (char*)malloc(size + 1);
    
    // Read file data into buffer
    fread(buffer, 1, size, file);
    buffer[size] = '\0';
    
    free(buffer);
    fclose(file);
    
    printf("Output: %s\n", buffer);
    
    return EXIT_SUCCESS;
}