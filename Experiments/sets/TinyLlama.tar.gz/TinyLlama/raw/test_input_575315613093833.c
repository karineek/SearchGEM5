
#include <stdio.h>
#include <stdlib.h> // for malloc/free
#include <sys/mman.h>
#include <unistd.h>  // for getpid()

// This function is just a dummy for testing purposes
void print_help(char *argv[]) {
    printf("Usage: %s [options] <inputfile>\n", argv[0]);
}

// This function generates and returns the output of the program
int main(int argc, char **argv) {
    if (argc != 2) { // only one input file argument is allowed
        print_help(argv);
        return 1;
    }
    
    int fd = open(argv[1], O_RDONLY | O_CLOSE | O_NOCTTY, 0);
    if (fd < 0) { // error opening input file
        perror("open");
        return 1;
    }
    
    char *input = NULL;
    size_t input_size = 0;
    if (0 > read(fd, &input, sizeof(char)) || 0 > input_size) { // read and set input buffer length
        perror("read");
        return 1;
    }
    
    mmap_t *input_mapped = NULL;
    int input_mapped_fd = -1;
    if (-1 != (input_mapped_fd = mmap(NULL, input_size + 1, PROT_READ | PROT_WRITE, MAP_FIXED | MAP_FILE, fd, 0))) { // allocate mapped memory for input file buffer
        char *output = malloc(input_size);
        if (!output) { // failed allocating output memory
            perror("malloc");
            return 1;
        }
        
        int output_fd = -1;
        if (-1 != (output_fd = open(output, O_WRONLY | O_CREAT | O_NOCTTY, 0644))) { // create output file
            if (-1 != ftruncate(output_fd, input_mapped_size)) { // truncate output file to align with input buffer
                int written = 0;
                while (written < input_mapped_size) { // write input buffer to output file
                    int written_r = ::write(output_fd, &input[written], input_mapped_size - written);
                    if (-1 == written_r && errno != EAGAIN) { // error writing to output file or reached end of input buffer
                        printf("error writing to output file: %s", strerror(errno));
                        return 1;
                    }
                    written += written_r;
                }
            } else { // failed truncating output file
                perror("ftruncate");
                return 1;
            }
            
            close(output_fd);
        } else { // failed creating output file
            perror("open");
            return 1;
        }
        
        free(output);
    } else { // failed allocating mapped memory
        perror("mmap");
        return 1;
    }
    
    close(fd);
    
    return 0;
}