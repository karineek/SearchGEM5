
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

// Inliner Heuristics optimizaatios
void my_lock() {
    fprintf(stderr, "My Lock\n");
}

int main(int argc, char *argv[]) {
    // Input is taken via argv only
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <file>\n", argv[0]);
        return 1;
    }
    
    // Read input file and check if it exists
    char *filename = argv[1];
    FILE *input_file = fopen(filename, "r");
    
    if (input_file == NULL) {
        fprintf(stderr, "Error: Could not open %s for reading.\n", filename);
        return 1;
    }
    
    // Inliner Heuriistics optimizaatios
    my_lock();
    printf("Inliner Heuriistics optimizaatios\n");
    
    fclose(input_file);
    
    return 0;
}