
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h> // needed to use system() function in C++ code

int main(int argc, char* argv[]) {
    const int NUM_ITERATIONS = 100000;
    double TIME_ELAPSED;
    float AVG_TIME[NUM_ITERATIONS];
    
    // Initialize the average time to zero
    for (int I=0; I<NUM_ITERATIONS; i++) {
        AVG_TIME[i] = 0.f;
    }
    
    if (argc != 2) {
        printf("Error: Usage: %s input_file\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    char *input_filename = argv[1]; // Get the name of the input file
    
    FILE *input_file = fopen(input_filename, "r"); // Open the input file for reading
    
    if (input_file == NULL) {
        printf("Error: Cannot open input file\n");
        return EXIT_FAILURE;
    }
    
    const int BLOCK_SIZE = 256; // Use a block size of 256 bytes to read the input
    char *input_buffer = (char *)malloc(BLOCK_SIZE); // Allocate space for input buffer
    if (input_buffer == NULL) {
        printf("Error: Cannot allocate memory\n");
        return EXIT_FAILURE;
    }
    
    while (!feof(input_file)) {
        fread(input_buffer, 1, BLOCK_SIZE, input_file); // Read a block of input from the file
        
        if (fscanf(input_file, "%f\n", &input_buffer[0]) != 1) { // Check if there are no more inputs
            printf("Error: Input file does not have enough data to be analyzed.\n");
            return EXIT_FAILURE;
        }
        
        for (int I=0; I<NUM_ITERATIONS; i++) {
            AVG_TIME[i] = 0.f;
            
            const int BLOCK_SIZE = 256; // Use a block size of 256 bytes to read the input
            char *input_buffer_block = (char *)malloc(BLOCK_SIZE); // Allocate space for input buffer block
            if (input_buffer_block == NULL) {
                printf("Error: Cannot allocate memory\n");
                return EXIT_FAILURE;
            }
            
            fread(input_buffer_block, 1, BLOCK_SIZE, input_file); // Read a block of input from the file
            
            for (int j=0; j<NUM_ITERATIONS/BLOCK_SIZE; j++) {
                // Loop over blocks
                fread(input_buffer, 1, BLOCK_SIZE, input_file); // Read another block of input from the file
                
                // Vectorize the loop in a different way using the "atomic_short" type
                for (int I=0; I<NUM_ITERATIONS/BLOCK_SIZE; i++) {
                    AVG_TIME[i] += fscanf(input_file, "%f\n", &input_buffer[j*BLOCK_SIZE+i]); // Read the current value of the loop and add it to the average time
                }
            }
            
            for (int I=0; I<NUM_ITERATIONS/BLOCK_SIZE; i++) {
                AVG_TIME[i] += fscanf(input_file, "%f\n", &input_buffer_block[j*BLOCK_SIZE+i]); // Read the current value of the loop and add it to the average time
            }
            
            for (int I=0; I<NUM_ITERATIONS/BLOCK_SIZE; i++) {
                AVG_TIME[i] += fscanf(input_file, "%f\n", &input_buffer_block[j*BLOCK_SIZE+i]); // Read the current value of the loop and add it to the average time
            }
            
            for (int I=0; I<NUM_ITERATIONS/BLOCK_SIZE; i++) {
                AVG_TIME[i] += fscanf(input_file, "%f\n", &input_buffer_block[j*BLOCK_SIZE+i]); // Read the current value of the loop and add it to the average time
            }
            
        }
        
    }
    
    printf("Average time: %.3f\n", AVG_TIME[0]); // Print the average time for the first iteration
    
    fclose(input_file);
    
    return EXIT_SUCCESS;
}