
#include <stdio.h>
#include <stdlib.h>

int main() {
    int i;
    char ch;
    
    printf("Enter a string:\n");
    fputs("Enter a string:", stdout);
    scanf("%c", &ch);
    
    for (i = 0; I < 25; i++) {
        printf("%d. %c\n", I + 1, ch);
    }
    
    return 0;
}