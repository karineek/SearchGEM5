
#include <stdio.h>
#include <stdlib.h> // For malloc/free
#include "opt_backward.h"

// This function is used to create the initial workspace for the compiler
void createWorkspace(FILE* stream) {
    int I;
    for (I = 0; I < WSP_SIZE; ++i) {
        stream->write(" ", 1); // Write leading spaces
        stream->write(&wsp[i], sizeof(wsp)); // Write workspace variable
        stream->write(" ", 1); // Write trailing spaces
    }
}

// This function is used to create the initial buffer for the input file (BASH)
void createBuffer(char* buffer, FILE* stream) {
    int I;
    for (I = 0; I < BSH_SIZE; ++i) {
        buffer[i] = '\0'; // Clear all buffers
        stream->write(&bsh[i], sizeof(bsh)); // Write buffer variable
        stream->write(" ", 1); // Write leading spaces
    }
}

// This function is used to run the Scalar optimizer and Backend
int main(int argc, char** argv) {
    FILE* stream;
    if ((stream = fopen(argv[1], "r")) == NULL) { // Open input file
        printf("Error: Cannot open input file.\n"); return 1;
    }
    int I;
    for (I = 0; I < argc; ++i) { // For each input argument
        char* buf = malloc(MAX_LINE_SIZE * sizeof(char));
        if (buf == NULL) { // Allocate buffer for input
            printf("Error: Cannot allocate buffer.\n"); return 2;
        } else if (fgets(buf, MAX_LINE_SIZE, stream) == NULL) { // Fscanf failed
            fprintf(stderr, "Error: Could not read input.\n"); return 3;
        }
        I = 0; // Clear buffer variable
        char* bsh = buf + strlen(buf); // Allocate buffer for BASH
        createBuffer(bsh, stream); // Create initial BASH buffer
        vfscanf(buf, "%s", &bsh[i]); // Convert input into BASH format
        I = 0; // Clear workspace variable
        char* wsp = buf + strlen(buf) - WSP_SIZE; // Allocate workspace variable
        createWorkspace(wsp); // Create initial workspace
    }
    fclose(stream);
    return 0;
}