// Modification timestamp: 2023-08-14 13:52:44
// Original Source: https://github.com/llvm/llvm-test-suite/blob/main/SingleSource/Regression/C/gcc-c-torture/execute/990208-1.c
The program you provided already uses command line arguments, so no changes are needed.