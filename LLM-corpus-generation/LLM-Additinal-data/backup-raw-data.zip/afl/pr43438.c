// Modification timestamp: 2023-08-14 15:11:45
// Original Source: https://github.com/llvm/llvm-test-suite/blob/main/SingleSource/Regression/C/gcc-c-torture/execute/pr43438.c

#include <stdio.h>
#include <stdlib.h>

extern void abort(void);

static unsigned char g_2 = 1;
static int g_9;
static int* l_8 = &g_9;

static void func_12(int p_13) {
  int* l_17 = &g_9;
  *l_17 &= 0 < p_13;
}

int main(int argc, char* argv[]) {
  if (argc != 2) {
    printf("Usage: %s <value>\n", argv[0]);
    return 1;
  }

  unsigned char l_11 = atoi(argv[1]);
  *l_8 |= g_2;
  l_11 |= *l_8;
  func_12(l_11);
  if (g_9 != 1)
    abort();
  return 0;
}
