// Modification timestamp: 2023-08-14 11:59:19
// Original Source: https://github.com/llvm/llvm-test-suite/blob/main/SingleSource/Regression/C/gcc-c-torture/execute/20010520-1.c

#include <stdio.h>
#include <stdlib.h>

static unsigned int expr_hash_table_size = 1;

int main(int argc, char *argv[]) {
  if (argc != 2) {
    printf("Usage: %s <value>\n", argv[0]);
    return 1;
  }

  int del = atoi(argv[1]);
  unsigned int i = atoi(argv[2]);

  if (i < expr_hash_table_size && del)
    exit(0);
  abort();
}
