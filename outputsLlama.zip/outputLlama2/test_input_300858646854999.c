
#include <stdio.h>
#include <string.h>
#include "InlinerHeuristics.h"

// Function to inline a function call using Inliner Heuristics
void inline_function(int a, int b) {
  // Perform bitwise inclusive assignment using |= operator
  a |= b;
}

int main() {
  // Get input from argc[1] and argv[1]
  char input[] = argv[1];

  // Call the function with Inliner Heuristics enabled
  inline_function(5, 7);

  // Print the result
  printf("Result: %d\n", a);

  return 0;
}