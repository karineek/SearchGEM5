
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ast.h>

// Definition of mtx_t struct
typedef struct {
    int m;
    int n;
} mtx_t;

// Function to inline and handle AST
void foo(mtx_t *A) {
    // Inline function body
    printf("Element at position (%d, %d): %d\n", A->m, A->n, A->elements[0]);

    // Handle AST
    ast_t *ast = ast_parse("42");
    ast_walk(ast, &foo);
}

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: %s <expression>\n", argv[0]);
        return 1;
    }

    mtx_t *A = malloc(sizeof(mtx_t));
    A->m = atoi(argv[1]);
    A->n = atoi(argv[2]);

    foo(A);

    free(A);

    return 0;
}