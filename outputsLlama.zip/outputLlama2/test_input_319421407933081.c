
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// Define a function to test the strtoll() function
int main(int argc, char **argv) {
  // Test the strtoll() function with different inputs
  for (int i = 0; i < argc; ++i) {
    const char *input = argv[i];
    long result;
    errno_t err = strtoll(input, &result);
    if (err) {
      printf("Error parsing input %s: %s\n", input, strerror(err));
    } else {
      printf("Parsed value: %ld\n", result);
    }
  }
  return 0;
}