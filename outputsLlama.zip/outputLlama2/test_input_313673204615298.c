
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    int n = atoi(argv[1]); // argument 1 is the number of elements in the array
    int a[n]; // array created on the stack

    // initialize the array with random values
    srand((int)time(NULL));
    for (int i = 0; i < n; i++) {
        a[i] = rand() % 10;
    }

    // loop optimization: use an array of size n to store the results of the loop
    int result[] = {0};
    for (int i = 0; i < n; i++) {
        result[i] = a[i];
    }

    // print the results
    for (int i = 0; i < n; i++) {
        printf("%d ", result[i]);
    }
    puts("");

    return 0;
}