
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "passes.h"
#include "transformations.h"
#include "copysign.h"

int main(int argc, char **argv) {
    // Input is taken via `argv` only
    if (argc < 2) {
        printf("Usage: %s <input> <output>\n", argv[0]);
        return 1;
    }

    // Read the input from file
    FILE *input_file = fopen(argv[1], "r");
    if (!input_file) {
        printf("Error: cannot open input file %s\n", argv[1]);
        return 2;
    }

    // Get the number of instructions in the input code
    int num_instructions = get_num_instructions(input_file);
    fclose(input_file);

    if (argc < 3) {
        printf("Usage: %s <input> <output>\n", argv[0]);
        return 1;
    }

    // Schedule the instructions
    schedule_instructions(num_instructions, argv[2]);

    // Perform passes and transformations
    perform_passes_transformations();

    // Generate the assembled code
    assemble_code();

    // Print the assembled code
    printf("Assembled code: \n");
    print_code(argv[2]);

    return 0;
}