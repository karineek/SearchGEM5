
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>

int main(int argc, char **argv) {
    // Automatic vectorization example using ftell
    size_t num_strings = atoi(argv[1]);
    char **strings = malloc(num_strings * sizeof(char *));
    for (size_t i = 0; i < num_strings; i++) {
        strings[i] = argv[2 + i];
    }
    size_t total_size = ftell(stdin);
    for (size_t i = 0; i < num_strings; i++) {
        printf("%s\n", strings[i]);
    }
    return 0;
}