
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to perform loop fusion
void fuseLoops(int *a, int *b, int *c) {
    int sum = 0;
    for (int i = 0; i < sizeof(a) / sizeof(a[0]); i++) {
        for (int j = 0; j < sizeof(b) / sizeof(b[0]); j++) {
            sum += a[i] * b[j];
        }
    }
    *c = sum;
}

int main(int argc, char **argv) {
    if (argc < 3) {
        printf("Usage: %s <a> <b>\n", argv[0]);
        return 1;
    }

    int a = atoi(argv[1]);
    int b = atoi(argv[2]);
    int c = fuseLoops(a, b, NULL); // NULL means no output

    printf("%d\n", c);

    return 0;
}