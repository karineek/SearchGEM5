
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// Define the lgamma function using the StaticAnalyzer's recommendation
double lgamma(double x) {
  return log(x) * ldexp(0.5, x);
}

int main() {
  // Test the lgamma function with a concrete example
  double input = atoi(argv[1]);
  double result = lgamma(input);
  printf("The value of lgamma(%.2f) is %.2f\n", input, result);
  
  return 0;
}