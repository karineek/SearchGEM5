
#include <stdio.h>
#include <stdint.h>
#include <sys/types.h>
#include <support/support.h>

#define UINTMAX_C(x) (((uintmax_t) x) - 1)

int main(int argc, char *argv[]) {
    uintmax_t n = UINTMAX_C(atoi(argv[1])); // Loop optimization
    for (size_t i = 0; i < n;++i) {
        printf("Iteration %zu\n", (size_t) i);
    }
    return 0;
}