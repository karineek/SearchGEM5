
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv) {
    // Initialize vectorization and passes and transformations
    __attribute__((aligned(32))) int a[10];
    for (size_t i = 0; i < sizeof(a); i++) {
        a[i] = i * 2;
    }
    printf("Before optimization: %d\n", *(int*)&a[0]);

    // Trigger vectorization optimizations with `-flto -ftree-vectorize`
    std::string options = "-flto -ftree-vectorize";
    if (argc > 1) {
        options += " ";
        for (int i = 1; i < argc; i++) {
            options += argv[i] + " ";
        }
    }
    printf("With vectorization and passes and transformations: %d\n", *(int*)&a[0]);

    return 0;
}