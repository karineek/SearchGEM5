
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function Specialization using macros
#define FS_ADD(a, b) (a + b)
#define FS_SUB(a, b) (-FS_ADD(a, b))
#define FS_MUL(a, b) (a * b)
#define FS_DIV(a, b) ((a * b) / 100)

// Target specific architecutres
#ifdef __linux__
#define ARCH_LINUX
#else
#define ARCH_WINDOWS
#endif

// CABS function example
void cabs(float x, float y) {
    float result;
    if (x == 0) {
        result = 0;
    } else {
        result = fabs(y);
    }
    printf("The value of abs(x, y) is: %f\n", result);
}

int main() {
    // Input taken via argv only
    int n = atoi(argv[1]);
    float x = atof(argv[2]);
    float y = atof(argv[3]);
    
    // Function Specialization using macros
    if (n == 1) {
        printf("The value of abs(x, y) is: %f\n", FS_ADD(x, y));
    } else if (n == 2) {
        printf("The value of abs(x, y) is: %f\n", FS_SUB(x, y));
    } else if (n == 3) {
        printf("The value of abs(x, y) is: %f\n", FS_MUL(x, y));
    } else if (n == 4) {
        printf("The value of abs(x, y) is: %f\n", FS_DIV(x, y));
    } else {
        cabs(x, y); // Call the CABS function for other values of n
    }
    
    return 0;
}