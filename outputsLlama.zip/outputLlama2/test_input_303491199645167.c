
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <iostream>
#include <algorithm>

// Structure/union member example
struct Person {
    int age;
    char name[20];
    float height;
};

// Vectorization example
int main(int argc, char **argv) {
    // Input from command line
    int nPeople = atoi(argv[1]);
    char *names = (char *)malloc(nPeople * sizeof(char));
    for (int i = 0; i < nPeople; i++) {
        names[i] = argv[2 + i];
    }
    std::vector<Person> people(nPeople);
    for (int i = 0; i < nPeople; i++) {
        people[i].age = atoi(argv[3 + i]);
        people[i].name = names[i];
        people[i].height = atof(argv[4 + i]);
    }
    // Exercise vectorization optimizations using the backend of a modern C compiler
    std::sort(people.begin(), people.end(), [] (const Person &a, const Person &b) {
        return a.age < b.age;
    });
    // Print the sorted list of persons
    for (int i = 0; i < nPeople; i++) {
        printf("Person %d: age = %d, name = '%s', height = %f\n", i, people[i].age, people[i].name, people[i].height);
    }
    return 0;
}