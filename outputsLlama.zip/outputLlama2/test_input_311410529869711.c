
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

// Function Specialization and Support

// Function for handling input from argv
int main(int argc, char **argv) {
    if (argc == 2) {
        // Do something with the first argument
        printf("First argument: %s\n", argv[1]);
    } else if (argc == 3) {
        // Do something else with the second and third arguments
        printf("Second and third arguments: %s %s\n", argv[2], argv[3]);
    } else {
        // Handle incorrect number of arguments
        printf("Incorrect number of arguments\n");
    }
    return 0;
}

// Exercise 1: Use Function Specialization to implement a simple calculator
void calculate(int num1, int num2) {
    int result = num1 + num2;
    printf("Result: %d\n", result);
}

// Exercise 2: Use Support to implement a more complex calculation
void calculate_complex(int num1, int num2, int num3) {
    int result = num1 * num2 + num3;
    printf("Result: %d\n", result);
}

// Example of using Function Specialization and Support in C
int main_example() {
    calculate(5, 3); // Call the calculate function with arguments 5 and 3
    calculate_complex(6, 2, 4); // Call the calculate_complex function with arguments 6, 2, and 4
    return 0;
}