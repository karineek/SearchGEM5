
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// Function to test loop optimization
int optimize_loops(int n) {
  int i, result = 0;
  
  // Loop optimization: use a prefix decrement operator (-) to avoid unnecessary iterations
  for (i = 0; i < n; --i) {
    result += i * i;
  }
  
  return result;
}

int main(int argc, char **argv) {
  int n = atoi(argv[1]); // get input from command line
  
  // Print the result of the optimization
  printf("Optimized result: %d\n", optimize_loops(n));
  
  return 0;
}