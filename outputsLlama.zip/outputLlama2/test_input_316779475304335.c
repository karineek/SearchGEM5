
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <profiling.h>

#define MAX_LENGTH 1024

int main(int argc, char *argv[]) {
    // Initialize profiling tool
    PROFILE_BEGIN("vsnprintf_s");
    
    // Take input from command line
    int length = atoi(argv[1]);
    char buffer[MAX_LENGTH];
    vsnprintf_s(buffer, MAX_LENGTH, argv[2], length);
    
    // Print the output
    printf("%s\n", buffer);
    
    PROFILE_END();
    
    return 0;
}