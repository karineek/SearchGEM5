
#include <stdio.h>
#include <stdlib.h>
#include <clang/Frontend.h>

// Function to find the gcd of two integers using recursion
int gcdRecursive(int a, int b) {
  if (b == 0) {
    return a;
  } else {
    return gcdRecursive(b, a % b);
  }
}

int main(int argc, char **argv) {
  // Get the input integers from the command line arguments
  int a = atoi(argv[1]);
  int b = atoi(argv[2]);

  // Calculate the gcd of a and b using recursion
  int gcd = gcdRecursive(a, b);

  // Print the result
  printf("The gcd of %d and %d is %d\n", a, b, gcd);

  return 0;
}