
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <lex.h>

// Define the custom integer type 'uint_least8_t'
typedef uint8_t uint_least8_t;

int main(int argc, char **argv) {
  // Check if there is an input file specified
  if (argc < 2) {
    printf("Usage: %s <input.txt>\n", argv[0]);
    return 1;
  }

  // Open the input file for reading
  FILE *file = fopen(argv[1], "r");
  if (!file) {
    perror("Error opening input file");
    return 1;
  }

  // Perform WPA on the input file using Lex
  lex_t *lex = lex_open(file, LEX_NOREMAP);
  if (!lex) {
    fprintf(stderr, "Error initializing Lex\n");
    return 1;
  }

  // Print the WPA report
  uint8_t *buffer = NULL;
  size_t buffer_size = 0;
  lex_get_data(lex, &buffer, &buffer_size);
  if (buffer_size > 0) {
    printf("WPA Report:\n");
    for (size_t i = 0; i < buffer_size; i++) {
      printf("%02x ", buffer[i]);
    }
    printf("\n");
  } else {
    printf("No data found\n");
  }

  // Close the input file and Lex
  fclose(file);
  lex_close(lex);

  return 0;
}