
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// Scalar Optimizations
#define maximum(a, b) (((a) > (b)) ? (a) : (b))

int main(int argc, char **argv) {
    // Handle LLVM Bitcode
    int bitcode = *(int *)(argv[1]);

    // Exercise tss_delete
    char *tss = "hello world";
    printf("%s\n", tss_delete(tss));

    return 0;
}