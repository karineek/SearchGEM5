
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>

// Function to compute the LCM of two numbers
long long lcm(int a, int b) {
  if (a == 0 || b == 0) {
    return 0;
  }
  
  // Use vectorization to multiply two numbers and find the LCM
  long long a_vec[16];
  long long b_vec[16];
  int i;
  
  for (i = 0; i < 16; i++) {
    a_vec[i] = a % 2 == 0 ? a / 2 : a / 2 + 1;
    b_vec[i] = b % 2 == 0 ? b / 2 : b / 2 + 1;
  }
  
  long long lcm = 0;
  for (i = 0; i < 16; i++) {
    lcm = (lcm * 2) % 2 == 0 ? lcm / 2 : lcm / 2 + 1;
  }
  
  return lcm;
}

int main(int argc, char **argv) {
  if (argc != 3) {
    printf("Usage: %s <a> <b>\n", argv[0]);
    return 1;
  }
  
  int a = atoi(argv[1]);
  int b = atoi(argv[2]);
  
  long long lcm = lcm(a, b);
  printf("LCM of %d and %d is %lld\n", a, b, lcm);
  
  return 0;
}