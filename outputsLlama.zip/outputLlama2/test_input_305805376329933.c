
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Define a data structure for matrices
typedef struct {
    int rows;
    int cols;
    double *data;
} mtx_t;

// Function to initialize the matrix structure
void mtx_init(mtx_t *M, int rows, int cols) {
    M->rows = rows;
    M->cols = cols;
    M->data = malloc(rows * sizeof(double) * cols);
}

// Function to perform matrix multiplication
void mtx_mult(mtx_t A, mtx_t B, mtx_t C) {
    int rowsA = A.rows;
    int colsB = B.cols;
    int rowsC = A.rows * B.cols;
    
    // Perform matrix multiplication using TSO
    for (int i = 0; i < rowsA; i++) {
        double *rowA = A.data + i * sizeof(double) * colsB;
        double *rowB = B.data + i * sizeof(double) * colsB;
        double *rowC = C.data + i * sizeof(double) * rowsC;
        
        for (int j = 0; j < colsB; j++) {
            rowC[j] = rowA[j] * rowB[j];
        }
    }
}

// Example usage:
int main(int argc, char **argv) {
    // Check if enough arguments were provided
    if (argc < 3) {
        printf("Usage: %s <rows> <cols>\n", argv[0]);
        return 1;
    }
    
    // Initialize the matrix structure
    mtx_t A, B, C;
    mtx_init(&A, atoi(argv[1]), atoi(argv[2]));
    mtx_init(&B, atoi(argv[3]), atoi(argv[4]));
    
    // Perform matrix multiplication
    mtx_mult(A, B, C);
    
    // Print the result
    for (int i = 0; i < C.rows; i++) {
        double *rowC = C.data + i * sizeof(double) * C.cols;
        for (int j = 0; j < C.cols; j++) {
            printf("%f ", rowC[j]);
        }
        printf("\n");
    }
    
    return 0;
}