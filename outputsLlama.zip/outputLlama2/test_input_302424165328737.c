
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>

#define MAX_INPUT_LEN 100

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: %s <input_string>\n", argv[0]);
        return 1;
    }

    char *input = argv[1]; // Get the input string from argv
    uint64_t input_hex = strtoul(input, NULL, 16); // Convert the input string to a hexadecimal number
    int input_dec = (int)input_hex; // Convert the hexadecimal number to an integer

    printf("The decimal equivalent of the given hexadecimal number is: %d\n", input_dec);

    return 0;
}