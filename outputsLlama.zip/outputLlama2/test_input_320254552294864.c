
#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include <sema.h>

// Define a function to demonstrate common subexpression elimination
void eliminate_subexpressions(const char *input) {
  // Create a semaphore to manage the optimization process
  sem_t sem;
  sem_create(&sem);

  // Parse the input using `Sema`
  Sema sema;
  sema.parse_string(input, 0);

  // Perform common subexpression elimination
  sema.eliminate_subexpressions();

  // Print the optimized AST
  sema.print_ast();

  // Destroy the semaphore
  sem_destroy(&sem);
}

int main(int argc, char **argv) {
  if (argc < 2) {
    fprintf(stderr, "Usage: %s <input>\n", argv[0]);
    return 1;
  }

  eliminate_subexpressions(argv[1]);

  return 0;
}