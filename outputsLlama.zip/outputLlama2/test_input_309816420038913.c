
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <termios.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/resource.h>

// Function to print the program's name and version number
void print_program_info() {
  printf("Program Name: %s\n", PACKAGE_NAME);
  printf("Program Version: %s\n", PACKAGE_VERSION);
}

int main(int argc, char *argv[]) {
  // Check if the user provided any input
  if (argc > 1) {
    // Print the input string
    printf("Input string: %s\n", argv[1]);
  } else {
    // Print a default message if no input was provided
    printf("No input provided\n");
  }
  
  return 0;
}