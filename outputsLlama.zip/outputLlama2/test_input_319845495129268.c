
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv) {
    // Check if the user provided an input file
    if (argc < 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    // Open the input file and read its contents
    FILE *file = fopen(argv[1], "r");
    char buffer[4096];
    size_t len = 0;
    while (len < 4096 && fread(&buffer[len], 1, 4096, file) != EOF) {
        len += 4096;
    }

    // Perform constant folding on the input code
    // Replace all instances of 'x' with their value (e.g. 5)
    for (size_t i = 0; i < len; i++) {
        if (buffer[i] == 'x') {
            buffer[i] = 5;
        }
    }

    // Print the modified input code
    printf("%s", buffer);

    return 0;
}