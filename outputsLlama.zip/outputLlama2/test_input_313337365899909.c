
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>

// Function to perform constant folding on an expression
void constant_fold(char *expression) {
    int result = 0;
    char *token = strtok(expression, " ");
    while (token != NULL) {
        if (token[0] == '+') {
            result += atoi(token + 1);
        } else if (token[0] == '-') {
            result -= atoi(token + 1);
        } else if (token[0] == '*') {
            result *= atoi(token + 1);
        } else if (token[0] == '/') {
            result /= atoi(token + 1);
        }
        token = strtok(NULL, " ");
    }
    printf("%d\n", result);
}

int main() {
    char *expression = argv[1]; // Get the expression from the command line
    constant_fold(expression); // Perform constant folding on the expression
    return 0;
}