
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <iostream>

int main(int argc, char** argv) {
    // Vectorization example
    int n = atoi(argv[1]); // get the number of integers from the command line
    std::vector<int> v(n); // create a vector of integers
    for (int i = 0; i < n; i++) {
        v[i] = atoi(argv[2 + i]); // fill the vector with integers from the command line
    }
    std::cout << "Vectorized integers: ";
    for (int i : v) {
        std::cout << i << " ";
    }
    std::cout << std::endl;

    // Analysis example
    int sum = 0;
    for (int i = 0; i < n; i++) {
        sum += v[i]; // compute the sum of the vector
    }
    std::cout << "Sum of the vectors: " << sum << std::endl;

    return 0;
}