
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include < LLVM/LLVM.h>

// Function to parse the input from argv and create a LLVM IR string
void parseInput(int argc, char **argv) {
  // Check if there is an input file provided
  if (argc <= 1) {
    printf("Error: Please provide an input file\n");
    return;
  }

  // Read the input file and store it in a string
  char *input = NULL;
  FILE *file = fopen(argv[1], "r");
  if (file == NULL) {
    printf("Error: Could not open input file %s\n", argv[1]);
    return;
  }
  fseek(file, 0, SEEK_END);
  int len = ftell(file);
  input = (char *)malloc(len + 1);
  fread(input, 1, len, file);
  fclose(file);

  // Create a LLVM IR string from the input
  char *llvmIR = NULL;
  llvm::Module Module;
  llvm::target t = llvm::Target::get(llvm::Triple("x86_64-linux-gnu"));
  llvm::MCJITCompilerCtx Ctx;
  Ctx.setTarget(t);
  Ctx.setDataLayout("e-m:o-i64");
  Ctx.createModule(&Module);
  Module.addFile(input, "module");
  llvmIR = Module.getFrontend().createIR(Module);

  // Free the memory allocated for the LLVM IR string
  free(llvmIR);
}

// Function to perform instruction scheduling on the input LLVM IR
void scheduleInstructions(char *llvmIR) {
  // Create a new module and add the instructions from the input LLVM IR
  llvm::Module Module;
  llvm::target t = llvm::Target::get(llvm::Triple("x86_64-linux-gnu"));
  llvm::MCJITCompilerCtx Ctx;
  Ctx.setTarget(t);
  Ctx.setDataLayout("e-m:o-i64");
  Ctx.createModule(&Module);
  Module.addFile(llvmIR, "module");

  // Perform instruction scheduling using the LLVM IR
  llvm::ScheduleInstructions(Module);
}

int main(int argc, char **argv) {
  if (argc < 2) {
    printf("Error: Please provide an input file\n");
    return 1;
  }

  // Parse the input from argv and create a LLVM IR string
  parseInput(argc, argv);

  // Schedule instructions using the LLVM IR
  scheduleInstructions(llvmIR);

  // Print the scheduling results
  llvm::Module *M = Module.get();
  for (int i = 0; i < M->getNumBasicBlocks(); ++i) {
    llvm::BasicBlock *BB = M->getBasicBlock(i);
    for (llvm::Instruction &I : *BB) {
      if (I.isScheduled()) {
        printf("Instruction %d is scheduled\n", I.getIndex());
      } else {
        printf("Instruction %d is not scheduled\n", I.getIndex());
      }
    }
  }

  return 0;
}