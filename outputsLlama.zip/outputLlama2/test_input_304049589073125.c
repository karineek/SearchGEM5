
#include <iostream>
#include <vector>
#include <stdint.h>
#include <stdio.h>

// Primary expression example
float sum(int num1, int num2) {
    std::vector<float> vec(num1 + 1);
    for (int i = 0; i < num1 + 1;++i) {
        vec[i] = i * 2;
    }
    float sum = 0;
    for (int i : vec) {
        sum += i;
    }
    return sum;
}

int main(int argc, char** argv) {
    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);
    float result = sum(num1, num2);
    printf("%f\n", result);
    return 0;
}