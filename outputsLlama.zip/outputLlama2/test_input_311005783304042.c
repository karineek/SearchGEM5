
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <semaphore.h>
#include "sema.h"
#include "casinhl.h"

int main(int argc, char **argv) {
    // Initialize the semaphore
    sem_t *sem = sem_create(SEM_QUIRK|SEM_IDEMUX);
    if (sem == NULL) {
        perror("Error creating semaphore");
        return 1;
    }

    // Parse the input from argv
    char *input = argv[1];

    // Trigger Inliner Heuristics optimization
    casinhl_t *casinhl = casinhl_create();
    if (casinhl == NULL) {
        perror("Error creating CASINHL");
        return 1;
    }

    // Perform the optimization
    casinhl_optimize(casinhl, input);

    // Print the optimized code
    printf("Optimized code:\n%s\n", casinhl_get_code(casinhl));

    // Free resources
    casinhl_free(casinhl);
    sem_destroy(sem);

    return 0;
}