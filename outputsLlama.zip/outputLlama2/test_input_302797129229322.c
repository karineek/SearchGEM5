
#include <stdio.h>
#include <string.h>
#include "clang/clang.h"

// Define a struct to represent a single expression in the program
struct Expr {
  int value;
  Expr* left;
  Expr* right;
};

// Function to perform common subexpression elimination on an expression tree
void eliminate_subexpressions(Expr* root) {
  if (root == NULL) {
    return;
  }
  
  // Check for a single-element expression tree
  if (root->left == NULL && root->right == NULL) {
    // If we have a simple expression, replace it with the value
    printf("Value: %d\n", root->value);
    return;
  }
  
  // Recursively eliminate subexpressions from the left and right sides
  eliminate_subexpressions(root->left);
  eliminate_subexpressions(root->right);
  
  // If there are no subexpressions remaining, replace the expression with its value
  printf("Value: %d\n", root->value);
}

int main(int argc, char** argv) {
  if (argc < 2) {
    printf("Usage: %s <expression>\n", argv[0]);
    return 1;
  }
  
  // Parse the expression from the command line argument
  Expr* root = parse_expr(argv[1]);
  
  eliminate_subexpressions(root);
  
  return 0;
}

// Function to parse an expression from a string
Expr* parse_expr(const char* str) {
  // Split the string into tokens using whitespace as the delimiter
  char** tokens = strtok(str, " ");
  
  // Create an empty expression tree and recursively add nodes
  Expr* root = calloc(1, sizeof(Expr));
  root->value = atoi(tokens[0]);
  root->left = NULL;
  root->right = NULL;
  
  int token_count = strlen(str);
  for (int i = 1; i < token_count;++i) {
    char* token = tokens[i];
    if (token[0] == '(') {
      // If we have an opening parentheses, create a new expression tree
      Expr* child = parse_expr(token + 1);
      root->right = child;
      root = child;
    } else if (token[0] == ')') {
      // If we have a closing parentheses, remove the current expression tree
      root = root->left;
    } else {
      // Otherwise, add the token as a value in the expression tree
      root->value *= atoi(token);
    }
  }
  
  return root;
}