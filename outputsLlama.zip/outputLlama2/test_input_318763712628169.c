
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

double sinhf(double x) {
    return sin(x) * sinh(x);
}

int main(int argc, char** argv) {
    double x = atof(argv[1]); // Parse input from command line
    double result = sinhf(x); // Inline the function and compute the result
    printf("%.2f\n", result); // Print the result
    return 0;
}