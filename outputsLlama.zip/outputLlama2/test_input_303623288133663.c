
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "clang/Frontend/InterproceduralOptimizations.h"

int main(int argc, char **argv) {
    // Test interprocedural optimizations by calling a function from another file
    optimize_main();
    
    return 0;
}