
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

// Function Specialization Example
double square(double x) {
    return x * x;
}

int main() {
    double num = atoi(argv[1]);
    printf("The result of %f squared is %f\n", num, square(num));
    return 0;
}