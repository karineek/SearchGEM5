
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <llabs.h>

// Define a function to compute the factorial of a number
void factorial(uint64_t n) {
  if (n == 0) {
    return 1;
  } else {
    return n * factorial(n - 1);
  }
}

int main(int argc, char **argv) {
  uint64_t n = strtoul(argv[1], NULL, 10);
  uint64_t result = factorial(n);
  llabs_print_result(result);
  return 0;
}