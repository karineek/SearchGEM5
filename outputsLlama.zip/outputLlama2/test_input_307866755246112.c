
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Define a function that takes a string as input and returns its length
int get_string_length(char *str) {
    return strlen(str);
}

// Define a function that takes a double complex number as input and returns its real part
double get_real_part(double _Complex num) {
    return real(num);
}

int main() {
    // Get the input string from the command line
    char *str = argv[1];

    // Print the length of the input string
    printf("Length of input string: %d\n", get_string_length(str));

    // Convert the input string to a double complex number using the double _Complex type
    double Complex num = creal(str, 0);

    // Print the real part of the double complex number
    printf("Real part of input string: %f\n", get_real_part(num));

    return 0;
}