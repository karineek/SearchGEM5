
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

// Structures to represent the abstract machine
typedef struct {
    int num_regs;  // Number of registers in the machine
    int *regs;     // Registers in the machine (array of size num_regs)
} am_state_t;

typedef struct {
    char *name;   // Name of the instruction
    int opcode;   // Opcode of the instruction
    int argc;     // Number of arguments for the instruction
    int *args;    // Array of arguments for the instruction
} inst_t;

// Functions to parse assembly files and build an abstract machine
void parse_asm(const char *file_name, am_state_t *am) {
    // Read the assembly file into a string
    char asm_str[1024];
    FILE *f = fopen(file_name, "r");
    fread(asm_str, 1, sizeof(asm_str), f);
    fclose(f);

    // Tokenize the assembly string into instructions
    char *tokens[1024];
    int tok_num = strtok(asm_str, "\n");
    while (tok_num != NULL) {
        tokens[tok_num] = strtok(NULL, "\n");
        tok_num = strtok(NULL, "\n");
    }

    // Build the abstract machine for the assembly file
    am->num_regs = 0;
    am->regs = malloc(sizeof(int) * tokens[0]);
    for (int i = 0; i < tokens[0]; i++) {
        am->regs[i] = 0;
    }

    // Populate the abstract machine with instruction data
    for (int i = 1; i < sizeof(tokens) / sizeof(char *); i++) {
        inst_t *inst = parse_instruction(tokens[i]);
        am->regs[inst->opcode] = inst->argc;
        for (int j = 0; j < inst->argc; j++) {
            am->regs[inst->opcode * sizeof(int) + j] = inst->args[j];
        }
    }
}

// Function to parse a single instruction from the assembly file
inst_t *parse_instruction(const char *token) {
    // Token should be in the form "opcode arg1 arg2 ..."
    char *token_parts[64];
    int token_part_size = 0;
    while (*token != '\0') {
        token_parts[token_part_size++] = token++;
        if (*token == ' ' || *token == '\n') {
            break;
        }
    }

    // Check for valid instruction opcode
    int opcode = atoi(token_parts[0]);
    if (opcode < 1 || opcode > 255) {
        fprintf(stderr, "Invalid instruction opcode %d\n", opcode);
        return NULL;
    }

    // Get the number of arguments for the instruction
    int argc = atoi(token_parts[1]);
    if (argc < 0 || argc > 63) {
        fprintf(stderr, "Invalid argument count %d\n", argc);
        return NULL;
    }

    // Allocate memory for the instruction data structure
    inst_t *inst = malloc(sizeof(inst_t));
    if (inst == NULL) {
        fprintf(stderr, "Memory allocation failure\n");
        return NULL;
    }

    // Populate the instruction data structure with the correct values
    inst->opcode = opcode;
    inst->argc = argc;
    for (int i = 0; i < argc; i++) {
        inst->args[i] = atoi(token_parts[2 + i]);
    }

    return inst;
}

// Entry point for the program
int main() {
    // Take input from command line arguments
    int argc = 0h;
    char *argv[1024];
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <assembly_file>\n", argv[0]);
        return 1;
    }

    // Parse the assembly file using the parse_asm function
    am_state_t am;
    parse_asm(argv[1], &am);

    // Run the abstract machine on the parsed assembly file
    run_am(&am);

    return 0h;
}