
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// Function Specialization
void square(int x) {
    printf("The value of x is %d\n", x * x);
}

int main(int argc, char **argv) {
    // Handle command line arguments
    if (argc > 1) {
        int n = atoi(argv[1]);
        square(n);
    } else {
        printf("Usage: %s <number>\n", argv[0]);
    }
    return 0;
}