
#include <stdio.h>
#include <string.h>

// Define a macro to convert a string to a number
#define STRING_TO_NUMBER(str) (str ? strtokin(str, 10) : 0)

int main(void)
{
    // Take input from the command line using argc and argv
    int num;
    char *input = argv[1];

    // Use vscanf to parse the input string and convert it to a number
    num = vscanf("%d", input);

    // Print the result
    printf("The number is: %d\n", num);

    return 0;
}