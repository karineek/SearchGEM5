
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <clang/clang.h>

int main(int argc, char **argv) {
    // Check if the user provided a command-line argument
    if (argc < 2) {
        printf("Usage: %s <input_string>\n", argv[0]);
        return 1;
    }

    // Parse the input string into an integer value
    int input = atoi(argv[1]);

    // Demonstrate loop optimization using Clang frontend
    int result = 0;
    for (int i = 0; i < input; i++) {
        result += i * i;
    }

    printf("The value of result is: %d\n", result);

    return 0;
}