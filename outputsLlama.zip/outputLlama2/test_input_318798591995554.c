
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <strings.h>

int main(int argc, char **argv) {
    // Input from command line
    char *input = argv[1];

    // Initialize a string with the input
    wchar_t *inputW = NULL;
    size_t inputLen = 0;
    wcstombs(inputW, input, inputLen);

    // Eliminate common subexpressions
    char *result = wcsncpy_s(NULL, inputW, inputLen);

    // Print the result
    printf("Result: %s\n", result);

    return 0;
}