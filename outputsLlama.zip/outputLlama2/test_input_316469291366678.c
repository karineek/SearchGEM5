
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// Function to inline
int inline_function(int a, int b) {
    return a + b;
}

// Function to parse and evaluate
double acoshf(double x) {
    return cosh(x) - fabs(sinh(x));
}

int main(int argc, char **argv) {
    // Parse input from command line
    int n = atoi(argv[1]);
    double x = strtod(argv[2], NULL);

    // Inline function and evaluate
    int result = inline_function(n, x);
    printf("%d\n", result);

    // Parse and evaluate acoshf function
    double res = acoshf(x);
    printf("acoshf(%lf) = %lf\n", x, res);

    return 0;
}