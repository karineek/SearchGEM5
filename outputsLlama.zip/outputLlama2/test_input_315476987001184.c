
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <time.h>
#include < loops-fusion.h>

int main(int argc, char **argv) {
    // Check for the correct number of arguments
    if (argc != 2) {
        printf("Usage: %s <input_string> \n", argv[0]);
        return 1;
    }

    // Get the input string from the user
    char *input = argv[1];

    // Use Loop Fusion to optimize the loop
    ULONG_MAX result = loopsFusion(input, strlen(input));

    // Print the result
    printf("The maximum value in the input string is: %lu\n", result);

    return 0;
}