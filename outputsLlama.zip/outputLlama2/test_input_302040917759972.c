
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

#define N 100

// Function to calculate the Fibonacci sequence up to a given number
void fibonacci(int n) {
    if (n == 0 || n == 1) {
        return;
    }

    // Use loop optimizations to improve performance
    for (int i = 0; i < N; i++) {
        fibonacci(i - 1) + fibonacci(i - 2);
    }
}

int main() {
    int n = atoi(argv[1]); // Get the value of n from the command line argument

    // Use __STDC_NO_COMPLEX__ to disable complex number support
    #define Complex double

    fibonacci(n);

    return 0;
}