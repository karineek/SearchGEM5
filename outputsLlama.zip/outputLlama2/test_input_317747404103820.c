
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char **argv) {
    // Check if the input string is given as an argument
    if (argc < 2) {
        printf("Usage: %s <input_string>\n", argv[0]);
        return 1;
    }

    // Get the input string from the command line
    char *input_string = argv[1];

    // Perform loop vectorization using the `gcc` compiler's optimizations
    int result = vectorizeLoop(input_string);

    if (result == 0) {
        printf("The input string is lowercase: %s\n", input_string);
    } else {
        printf("Error: cannot perform loop vectorization\n");
    }

    return 0;
}

// Function to perform loop vectorization using the `gcc` compiler's optimizations
int vectorizeLoop(char *input_string) {
    // Declare a pointer to the input string
    char *ptr = input_string;

    // Loop over each character in the input string
    for (; *ptr != '\0'; ptr++) {
        // Check if the current character is uppercase
        if (*ptr == *(ptr + 1)) {
            // Lowercase the current character
            *ptr = tolower(*ptr);
        }
    }

    return 0; // Success
}