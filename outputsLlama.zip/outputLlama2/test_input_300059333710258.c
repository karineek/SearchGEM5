
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gcc/loop_optimize.h>

int main(int argc, char **argv) {
    // Example input for the loop optimization
    int n = atoi(argv[1]);
    for (int i = 0; i < n; i++) {
        printf("Loop optimized: %d\n", i);
    }
    return 0;
}