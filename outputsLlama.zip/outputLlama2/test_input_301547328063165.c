
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Constant folding example
double ctgamma(double x) {
  if (x <= -10) return 0; // special case for negative numbers
  else if (x == 0) return 1; // identity function for zero
  else if (x > 0) return sqrt(x); // square root of positive numbers
  else return 0; // all other inputs return 0
}

int main() {
  double input = atoi(argv[1]); // get the input from the command line
  printf("Result of ctgamma(%.2f): %.2f\n", input, ctgamma(input));
  return 0;
}