
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_CMD_LEN 1024

int main(int argc, char **argv) {
    if (argc < 3) {
        printf("Usage: %s <input> <output>\n", argv[0]);
        return 1;
    }

    // Initialize the input buffer
    char input[MAX_CMD_LEN];
    strcpy(input, argv[1]);

    // Run the command and capture the output
    FILE *output = popen(argv[2], "r");
    if (output == NULL) {
        perror("popen failed");
        return 1;
    }
    char buffer[MAX_CMD_LEN];
    while (fgets(buffer, MAX_CMD_LEN, output) != NULL) {
        printf("%s\n", buffer);
    }

    // Release the resources
    pclose(output);

    return 0;
}