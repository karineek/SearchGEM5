
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>

// Sparse Conditional Constant Propagation
#define SCCP_PROPAGATE(cond) \
    ({ __typeof__ (cond) result = (cond); })

// Atomic long-long lock-free macro
#define ATOMIC_LLONG_LOCK_FREE(var, init) \
    __atomic_store_n(&var, init, __ATOMIC_LOCK_FREE(var))

int main(int argc, char **argv) {
    // Example input: "3456 1234"
    char *input = argv[1];

    // Parse input and extract numbers
    int num1 = atoi(input);
    int num2 = atoi(input + strlen("3456"));

    // Calculate sum and print result
    printf("%d + %d = %d\n", num1, num2, num1 + num2);

    return 0;
}