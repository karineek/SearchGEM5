
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define MATH_ERRNO(x) do { if ((x) != 0) { fprintf(stderr, "Math error: %d\n", (int)(x)); exit(1); } } while (0)

int main(int argc, char **argv) {
    int n = atoi(argv[1]); // vectorize the input value
    double a[] = {1, 2, 3, 4, 5}; // array of doubles to perform math operations on
    double result; // variable to store the result of the math operation

    // Perform matrix multiplication using vectorization
    #pragma omp parallel for default(none) shared(a, n)
    for (int i = 0; i < n; i++) {
        result = a[i] * n; // vectorized multiplication
    }

    printf("%f\n", result); // print the result of the matrix multiplication

    return 0;
}