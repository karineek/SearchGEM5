
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Function to perform whole program analysis
void analyzeProgram(char *program) {
    // Tokenize the program
    char *tokens[100];
    int numTokens = tokenize(program, tokens);
    
    // Perform whole program analysis
    for (int i = 0; i < numTokens; i++) {
        // Analyze each token
        if (tokens[i][0] == '(') {
            // Found an opening paren, analyze the expression inside
            char *expression = getExpression(tokens + i + 1);
            printf("Found expression: %s\n", expression);
        } else if (tokens[i][0] == ')') {
            // Found a closing paren, analyze the expression outside
            char *expression = getExpression(tokens + i - 1);
            printf("Found expression: %s\n", expression);
        }
    }
}

// Function to tokenize a program
char *tokenize(char *program, char **tokens) {
    // Use a simple lexer to tokenize the program
    int i = 0;
    while (i < strlen(program)) {
        switch (program[i]) {
            case '(':
                tokens[0] = &program[i];
                break;
            case ')':
                tokens[1] = &program[i];
                break;
            default:
                tokens[0] = &program[i];
        }
        i += 1;
    }
    return i;
}

// Function to get an expression from a token list
char *getExpression(char **tokens) {
    // Use a recursive function to parse the expression
    char *expression = "";
    for (int i = 0; i < strlen(*tokens); i++) {
        if ((*tokens)[i] == '(') {
            expression += getExpression(&(*tokens)[i + 1]);
        } else if ((*tokens)[i] == ')') {
            expression += getExpression(&(*tokens)[i - 1]);
        } else {
            expression += (*tokens)[i];
        }
    }
    return expression;
}

int main() {
    // Take input from the command line
    char *program = malloc(strlen(argv[1]) + 1);
    strcpy(program, argv[1]);
    
    analyzeProgram(program);
    
    return 0;
}