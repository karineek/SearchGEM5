
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char **argv) {
    // Input from command line arguments
    int n = atoi(argv[1]);
    int m = atoi(argv[2]);

    // Calculate the product of two integers
    int prod = n * m;

    // Check if the product is equal to 0
    if (prod == 0) {
        printf("Product is 0\n");
    } else {
        // Calculate the width of the constant time differences
        int wid = wcstod(argv[3]);

        // Print the width of the constant time differences
        printf("Width of constant time differences: %d\n", wid);
    }

    return 0;
}