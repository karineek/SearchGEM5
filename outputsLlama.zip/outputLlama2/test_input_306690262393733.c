
#include <iostream>
#include <clang-Frontend.h>
#include "xor_eq.h"

int main(int argc, char** argv) {
  // Get the input from the command line
  int num_elems = atoi(argv[1]);

  // Initialize the loop optimizations
  clang::LoopOptimizer optimizer;

  // Perform loop optimization
  optimizer.optimizeLoops();

  // Print the result
  std::cout << "Result: ";
  for (int i = 0; i < num_elems; ++i) {
    std::cout << xor_eq(i) << " ";
  }
  std::cout << std::endl;

  return 0;
}