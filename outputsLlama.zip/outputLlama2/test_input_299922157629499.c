
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int main(int argc, char **argv) {
    // Input from command line
    int n = atoi(argv[1]);

    // Calculate the result of wcstod
    float result = wcstod(argv[2], &err);

    // Print the result and error message
    printf("Result: %f\nError: %s\n", result, err);

    return 0;
}