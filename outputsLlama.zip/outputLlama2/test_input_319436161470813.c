
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Example input for the program
int main(int argc, char **argv) {
    char *input = argv[1]; // Get the input from the command line
    size_t len = strlen(input); // Calculate the length of the input string
    int *arr = (int *) malloc(len + 1); // Allocate memory for an integer array
    memcpy(arr, input, len); // Copy the input string into the array
    for (int i = 0; i < len; i++) {
        printf("%d ", arr[i]); // Print the elements of the array
    }
    free(arr); // Free the memory allocated for the array
    return 0;
}