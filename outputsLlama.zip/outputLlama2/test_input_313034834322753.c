
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#ifdef __arm__
#define COSH_FAST_FUNCTION 1
#elif defined(__linux__) || defined(__linux__)
#define COSH_FAST_FUNCTION 1
#else
#define COSH_FAST_FUNCTION 0
#endif

double cosh(double x) {
    double y = x * tan(x);
    if (COSH_FAST_FUNCTION) {
        // Use the fast cosh function for arm architecture
        return (y > 1.79769e-08 ? y : y / 2.0 - 0.5);
    } else {
        // Use the slow cosh function for all other architectures
        return (y > 1.79769e-08 ? y : y * tan(y));
    }
}

int main(int argc, char **argv) {
    double x = atof(argv[1]); // Replace with the input from the command line
    double result = cosh(x);
    printf("%.3lf\n", result);
    return 0;
}