
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>

// Define a constant folding expression
#define PI 3.14159

// Define a function to round a number to the nearest integer
void llround(double x, int *y) {
    *y = (int)(x + 0.5);
}

int main(int argc, char **argv) {
    // Use argv[1] as input for the constant folding expression
    double input = atoi(argv[1]);
    double result = PI * input;
    llround(result, NULL); // round result to nearest integer
    printf("%f\n", result);
    return 0;
}