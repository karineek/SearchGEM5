
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {
    // Input from command line
    char *input = argv[1];

    // Remove all instances of "=" in the input string
    char *output = strtok(input, "=");

    // Print the output
    printf("%s\n", output);

    return 0;
}