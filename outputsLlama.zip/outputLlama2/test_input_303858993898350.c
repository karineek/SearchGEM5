
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <clang/clang.h>

// Define a function that demonstrates constant folding
void foo(int x, int y) {
  if (x + y == 10) {
    // Constant fold the expression (x + y) = 10
    x + y = 10;
  } else {
    // Otherwise, evaluate the expression normally
    x + y = x + y;
  }
}

int main(int argc, char **argv) {
  if (argc > 1) {
    // Take an integer argument from the command line
    int n = atoi(argv[1]);

    // Call the foo function with the constant folded
    foo(n, n);
  } else {
    // Print a message indicating that the program requires an argument
    printf("Usage: %s <integer>\n", argv[0]);
  }

  return 0;
}