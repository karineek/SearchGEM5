
#include <iostream>
#include <vector>
#include <clang/clang.h>

int main(int argc, char **argv) {
  // Get the input from the command line
  std::string input = argv[1];

  // Tokenize the input into a vector of tokens
  std::vector<std::string> tokens;
  clang::Tokenizer tok(input);
  tok.getTokens(tokens);

  // Print out the tokens and their types
  for (const auto &token : tokens) {
    clang::TokenKind kind = tok.getTokenKind(token);
    std::cout << "Token: " << token << " Kind: " << kind << std::endl;
  }

  // Check if the input contains the maximum value for an unsigned char
  UCHAR_MAX = 255;
  for (const auto &token : tokens) {
    if (tok.getTokenKind(token) == clang::TokenKind::UCHAR) {
      std::cout << "Found UCHAR: " << token << std::endl;
      if (std::stoul(token, nullptr, 10) > UCHAR_MAX) {
        std::cout << "Value exceeds UCHAR_MAX" << std::endl;
      }
    }
  }

  return 0;
}