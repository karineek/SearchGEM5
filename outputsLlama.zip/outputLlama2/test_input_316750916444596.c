
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

// Function to demonstrate scalar optimization
void foo(uint32_t x, uint32_t y) {
    if (x == 0 && y == 0) {
        // Use a constant expression to avoid a multiplication
        printf("Hello World!\n");
    } else {
        // Use a constant folding to simplify the code
        foo(x * y, x + y);
    }
}

int main(void) {
    // Get the input values from the command line
    uint32_t x = atoi(argv[1]);
    uint32_t y = atoi(argv[2]);

    // Call the foo function with the input values
    foo(x, y);

    return 0;
}