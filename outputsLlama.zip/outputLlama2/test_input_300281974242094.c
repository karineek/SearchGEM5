
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

// Utility functions
char* trim(char* str);
int is_digit(char c);

// Token concatenation function
char* concat_tokens(char** tokens);

int main(int argc, char** argv) {
    // Parse input from command line
    if (argc < 2) {
        printf("Usage: %s <input_string>\n", argv[0]);
        return 1;
    }

    // Get input string from command line
    char* input = argv[1];

    // Tokenize input string using strtok
    char** tokens = strtok(input, " ");

    // Eliminate common subexpressions using strcat
    for (int i = 0; i < sizeof(tokens) / sizeof(char*); i++) {
        char* token = tokens[i];
        if (token[0] == '(' && token[strlen(token) - 1] == ')') {
            // Eliminate common subexpression
            strcat(tokens, token + 1);
            printf("Token concatenated: %s\n", tokens[i]);
        }
    }

    // Print concatenated tokens
    for (int i = 0; i < sizeof(tokens) / sizeof(char*); i++) {
        printf("%s\n", tokens[i]);
    }

    return 0;
}

// Utility functions

char* trim(char* str) {
    while (*str && is_digit(*str)) {
        str++;
    }
    *str = '\0';
    return str;
}

int is_digit(char c) {
    return (c >= '0' && c <= '9');
}

// Token concatenation function
char* concat_tokens(char** tokens) {
    char* result = NULL;
    for (int i = 0; i < sizeof(tokens) / sizeof(char*); i++) {
        result = strcat(result, *tokens++);
    }
    return result;
}