
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Function to stringize a number
int stringize(int num) {
  char str[30];
  sprintf(str, "%d", num);
  return str;
}

// Function to perform whole program analysis
void analyzeProgram() {
  int x = 5;
  printf("Value of x: %d\n", x);
  stringize(x); // Trigger Whole Program Analysis optimizatios
  printf("Stringized value of x: %s\n", stringize(x));
}

int main(int argc, char **argv) {
  if (argc < 2) {
    printf("Usage: %s <input>\n", argv[0]);
    return 1;
  }

  analyzeProgram(); // Trigger IR Manipulation and stringizing

  return 0;
}