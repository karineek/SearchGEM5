
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to calculate the sum of an array of integers
int sumArray(int arr[], int size) {
  int sum = 0;
  for (int i = 0; i < size; i++) {
    sum += arr[i];
  }
  return sum;
}

// Function to calculate the product of an array of integers
int productArray(int arr[], int size) {
  int product = 1;
  for (int i = 0; i < size; i++) {
    product *= arr[i];
  }
  return product;
}

// Driver function to test the loop optimizations
int main(int argc, char **argv) {
  // Check if the user provided an array of integers as input
  if (argc > 1) {
    int arr[] = malloc(sizeof(int) * atoi(argv[1]));
    for (int i = 0; i < sizeof(arr); i++) {
      arr[i] = atoi(argv[2 + i]);
    }
    // Optimize the loop
    int result = sumArray(arr, sizeof(arr));
    printf("The sum of the array is %d\n", result);
  } else {
    printf("Usage: %s <array size> <array elements>\n", argv[0]);
  }
  return 0;
}