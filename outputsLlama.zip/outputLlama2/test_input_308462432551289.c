
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>

// Function specialization for floating-point operations
void fp_sqrt(double x) {
    __asm__("sqrt %0, %1" : "=f"(x) : "0.5f");
}

int main() {
    double x = 3.14; // Example input from user via argv[1]
    double y = fp_sqrt(x); // Call function specialization for sqrt()
    printf("Sqrt of %f is %f\n", x, y);
    return 0;
}