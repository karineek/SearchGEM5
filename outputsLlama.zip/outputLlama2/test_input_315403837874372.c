
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <wchar.h>

// Function to handle command-line arguments
int main(int argc, char *argv[]) {
    if (argc > 1) {
        // Parse the command-line argument
        int number = atoi(argv[1]);
        printf("The value of %s is %d\n", argv[1], number);
    } else {
        printf("No arguments provided\n");
    }
    return 0;
}