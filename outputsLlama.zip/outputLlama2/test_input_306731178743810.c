
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>

#define FP_FAST_FMAL(a, b, c) \
    ({ __asm__("fma" : "+f" (a), "+f" (b), "+f" (c)); })

#define FP_ILOGB0(x) \
    ({ __asm__("lb" : "+f" (x), "#" (x)); })

#define FP_ILOGBNAN(x) \
    ({ __asm__("lb" : "+f" (x), "#" (x)); })

#define FP_INFINITE(x) \
    ({ __asm__("fi" : "+f" (x), "#" (x)); })

#define FP_NAN(x) \
    ({ __asm__("fn" : "+f" (x), "#" (x)); })

#define FP_NORMAL(x) \
    ({ __asm__("fmov" : "+f" (x), "#" (x)); })

int main(int argc, char **argv) {
    // Handle command line arguments
    if (argc > 1) {
        printf("Usage: %s <expression>\n", argv[0]);
        return 1;
    }

    char expression[1024];
    strcpy(expression, argv[1]);

    // Parse the expression
    int result;
    __asm__("parse_expr" : "+f" (result) : "+f" (expression));

    // Evaluate the expression using Automatic Vectorization and Handles Abstract Syntax Tree (AST)
    __asm__("eval_expr" : "+f" (result) : "+f" (expression));

    printf("%d\n", result);

    return 0;
}