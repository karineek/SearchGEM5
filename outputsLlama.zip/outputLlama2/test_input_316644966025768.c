
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

// Function to perform whole program analysis
void analyzeProgram(const char* filename) {
    // Open the input file in binary mode
    int fd = open(filename, O_BINARY);
    if (fd == -1) {
        perror("Error opening input file");
        return;
    }

    // Read the entire program into memory
    char* buffer = malloc(sizeof(int) * 4096);
    read(fd, buffer, sizeof(int) * 4096);
    close(fd);

    // Analyze the program
    int count = 0;
    for (int i = 0; i < sizeof(buffer); i++) {
        if (buffer[i] == '0') {
            count++;
        }
    }
    printf("Program contains %d zero-filled instructions\n", count);
}

int main(int argc, char* argv[]) {
    // Check if the program was given as an argument
    if (argc < 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    analyzeProgram(argv[1]);

    return 0;
}