
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to optimize loops
void optimizeLoops(int num) {
    int i, j;
    for (i = 0; i < num; i++) {
        for (j = 0; j < num; j++) {
            printf("Iteration %d, %d\n", i, j);
        }
    }
}

int main(int argc, char **argv) {
    int num = atoi(argv[1]); // Get the number of iterations from the command line argument
    optimizeLoops(num);         // Call the optimization function with the number of iterations as an argument
    return 0;                     // Return 0 to indicate success
}