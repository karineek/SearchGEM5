
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <inttypes.h>
#include <signal.h>
#include <sys/wait.h>
#include "parse.h"

int main(int argc, char **argv) {
    // Check if the input file exists and is a valid binary
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    // Parse the input file using the parse.yacc module
    Parse parse = parse_file(argv[1], NULL);

    // Check if the input is a valid program
    if (parse == NULL) {
        fprintf(stderr, "Invalid input\n");
        return 2;
    }

    // Exercise the isspace() function on the parse tree
    for (int i = 0; i < parse->len; i++) {
        if (isspace(parse->data[i])) {
            fprintf(stderr, "Space found at index %d\n", i);
        }
    }

    // Free the parse tree and return success
    free(parse);
    return 0;
}