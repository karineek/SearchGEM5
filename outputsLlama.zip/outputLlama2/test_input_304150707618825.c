
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Macro to demonstrate inlining optimization
#define PUTCHAR(x) __builtin_putchar((x))

int main(int argc, char **argv) {
    // Input from command line
    if (argc != 2) {
        printf("Usage: %s <input>\n", argv[0]);
        return 1;
    }

    // Parse input string
    char *input = argv[1];
    size_t len = strlen(input);

    // Perform semantical analysis (Sema)
    if (strcmp(input, "hello") == 0) {
        printf("'hello' is a valid string\n");
    } else if (strcmp(input, "goodbye") == 0) {
        printf("'goodbye' is also a valid string\n");
    } else {
        printf("Invalid input string\n");
    }

    // Inline putchar macro
    PUTCHAR('A');
    PUTCHAR('B');
    PUTCHAR('C');

    return 0;
}