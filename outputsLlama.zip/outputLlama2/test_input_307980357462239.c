
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>

int main(int argc, char **argv) {
    // Whole Program Analysis
    // Parses assembly files
    // Exercises the idea of labeling

    // Initialize the parse tree
    parse_tree *pt = parse_tree_init();

    // Parse the assembly file
    char *assembly_file = argv[1];
    parse_tree_parse(pt, assembly_file);

    // Perform whole program analysis
    analyze_program(pt);

    // Print the results
    print_results(pt);

    // Free the parse tree
    parse_tree_free(pt);

    return 0;
}