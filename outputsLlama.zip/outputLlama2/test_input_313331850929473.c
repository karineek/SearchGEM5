
#include <stdio.h>
#include <string.h>

// Define a function to demonstrate constant folding
void add(int a, int b) {
    printf("%d + %d = %d\n", a, b, a + b);
}

// Define a function to concatenate wide strings using the + operator
char* concatStrings(char* str1, char* str2) {
    return strcat(str1, str2);
}

int main(int argc, char** argv) {
    // Parse command line arguments
    if (argc < 3) {
        printf("Usage: %s <input1> <input2>\n", argv[0]);
        return 1;
    }

    // Demonstrate constant folding using the add function
    int a = atoi(argv[1]);
    int b = atoi(argv[2]);
    add(a, b);

    // Demonstrate wide string concatenation using the concatStrings function
    char* str1 = "Hello";
    char* str2 = "World!";
    char* result = concatStrings(str1, str2);
    printf("%s\n", result);

    return 0;
}