
#include <stdio.h>
#include <semantic/semantics.h>
#include <semantic/diagnostics.h>

int main(int argc, char **argv) {
    // Initialize the Sema compiler plugin
    seman::Sema sema;
    if (sema.init() != seman::kSuccess) {
        printf("Failed to initialize Sema\n");
        return 1;
    }
    
    // Parse the input program from `argv`
    const char *program = argv[1];
    if (!sema.parse(program)) {
        printf("Parsing failed: %s\n", sema.getDiagnosticMessage().c_str());
        return 1;
    }
    
    // Perform whole program analysis using Sema
    seman::Location location = sema.getLocation();
    if (location == seman::kInvalidLocation) {
        printf("Failed to determine location of input program\n");
        return 1;
    }
    sema.performAnalysis(location);
    
    // Print any diagnostic messages found during analysis
    for (const auto &diag : sema.getDiagnostics()) {
        printf("Error or warning: %s at line %d, col %d\n", diag.message.c_str(), diag.line, diag.col);
    }
    
    return 0;
}