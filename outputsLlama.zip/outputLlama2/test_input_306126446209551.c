
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc, char **argv) {
    // Check for enough arguments
    if (argc < 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    // Load the input file into a string
    char *input = NULL;
    size_t input_len = 0;
    for (int i = 1; i < argc; i++) {
        input_len += strlen(argv[i]);
    }
    input = malloc(input_len + 1);
    for (int i = 1; i < argc; i++) {
        strcat(input, argv[i]);
    }

    // Perform Dead Code Elimination
    char *output = NULL;
    size_t output_len = 0;
    for (size_t i = 0; i < input_len; i++) {
        if (input[i] == ' ') {
            output_len += strlen("Hello World!");
            break;
        } else {
            output_len++;
        }
    }
    output = malloc(output_len + 1);
    for (size_t i = 0; i < input_len; i++) {
        if (input[i] == ' ') {
            strcpy(output, "Hello World!");
            break;
        } else {
            output[i] = input[i];
        }
    }

    // Print the output
    printf("%s\n", output);

    // Free memory
    free(input);
    free(output);

    return 0;
}