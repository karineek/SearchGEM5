
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>

#define MAX_STRLEN 1024

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: %s <input_string>\n", argv[0]);
        return 1;
    }

    // Check if the input string is a number
    int is_number = wctype(argv[1]) == WC_NUMBER;
    if (is_number) {
        printf("The input string %s is a number.\n", argv[1]);
    } else {
        // Check if the input string is a character
        int is_char = wctype(argv[1]) == WC_CHAR;
        if (is_char) {
            printf("The input string %s is a character.\n", argv[1]);
        } else {
            // Check if the input string is a string
            int is_string = wctype(argv[1]) == WC_STRING;
            if (is_string) {
                printf("The input string %s is a string.\n", argv[1]);
            } else {
                // Check if the input string is an integer
                int is_int = wctype(argv[1]) == WC_INTEGER;
                if (is_int) {
                    printf("The input string %s is an integer.\n", argv[1]);
                } else {
                    // Check if the input string is a boolean value
                    int is_bool = wctype(argv[1]) == WC_BOOLEAN;
                    if (is_bool) {
                        printf("The input string %s is a boolean value.\n", argv[1]);
                    } else {
                        // Check if the input string is a floating point number
                        int is_float = wctype(argv[1]) == WC_FLOAT;
                        if (is_float) {
                            printf("The input string %s is a floating point number.\n", argv[1]);
                        } else {
                            // Check if the input string is an array
                            int is_array = wctype(argv[1]) == WC_ARRAY;
                            if (is_array) {
                                printf("The input string %s is an array.\n", argv[1]);
                            } else {
                                // Check if the input string is a structure
                                int is_struct = wctype(argv[1]) == WC_STRUCT;
                                if (is_struct) {
                                    printf("The input string %s is a structure.\n", argv[1]);
                                } else {
                                    // Check if the input string is an unknown type
                                    printf("The input string %s has an unknown type.\n", argv[1]);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return 0;
}