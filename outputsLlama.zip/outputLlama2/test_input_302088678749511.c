
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>

// Function to promote memory to registers
void cnd_broadcast(void *data, size_t size) {
    register int *ptr = data;
    register int val = *ptr;
    // Use the promoted value in a computation
    printf("%d\n", val);
}

int main() {
    // Take input from command line arguments
    int num_elements = atoi(argv[1]);
    char *data = (char *)malloc(num_elements * sizeof(int));
    for (int i = 0; i < num_elements; i++) {
        data[i] = i;
    }

    // Promote the memory to registers and broadcast it
    cnd_broadcast((void *)data, num_elements * sizeof(int));

    return 0;
}