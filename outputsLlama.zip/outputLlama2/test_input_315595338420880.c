
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

// Target-Specific Optimizations
#ifdef TARGET_X86
    #pragma optimize("", on)
#elif TARGET_ARM
    #pragma optimize("", on)
#else
    #pragma optimize("", off)
#endif

int main(int argc, char **argv) {
    // Input from argv
    int input = atoi(argv[1]);

    // Print the result
    printf("%d\n", input);

    return 0;
}