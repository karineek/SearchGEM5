
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>

// Function specialization for accessing the contents of a file
static inline int read_file(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        perror("Error opening file");
        return -1;
    }
    char buffer[4096];
    size_t bytes_read = fread(buffer, 1, sizeof(buffer), file);
    fclose(file);
    return bytes_read;
}

int main() {
    // Get the filename from the command line argument
    const char *filename = argv[1];

    // Use function specialization to read the contents of the file
    size_t bytes_read = read_file(filename);

    // Print the number of bytes read
    printf("Bytes read: %zu\n", bytes_read);

    return 0;
}