
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

// Function to demonstrate loop-invariant code motion
void print_loop(int n) {
    int i;
    for (i = 0; i < n; ++i) {
        // Perform some operation on the loop variable
        printf("Loop variable value: %d\n", i);
    }
}

int main(int argc, char **argv) {
    int n = atoi(argv[1]); // Get the number of iterations from the command line argument
    print_loop(n); // Perform the loop-invariant code motion
    return 0;
}