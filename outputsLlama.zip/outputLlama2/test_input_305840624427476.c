
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double quadraticRoots(double x, double b) {
  double discrim = b * b;
  if (discrim > 4 * pow(x, 2)) return -1; // check for negative or non-real roots
  
  double t = 2 * pow(x, 2);
  return (-b + sqrt(discrim)) / t;
}

int main(int argc, char **argv) {
  if (argc < 3) {
    printf("Usage: %s <input_string> <output_file>\n", argv[0]);
    return 1;
  }
  
  double x = strtodouble(argv[1]); // input string is the quadratic equation in standard form
  FILE *out = fopen(argv[2], "w"); // output file is the roots of the equation
  
  if (fabs(x) < 1e-6) { // check for special case where x = 0
    fprintf(out, "The roots of the equation are: %f\n", -b / 2);
    return 0;
  }
  
  double root1 = quadraticRoots(x, b); // find the first root
  double root2 = quadraticRoots(-x, b); // find the second root
  
  fprintf(out, "The roots of the equation are: %f and %f\n", root1, root2);
  
  return 0;
}