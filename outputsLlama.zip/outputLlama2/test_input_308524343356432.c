
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "assembly_files.h"

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <assembly file>\n", argv[0]);
        return 1;
    }

    // Parse the assembly file using the assembly_files macro
    AssemblyFile *af = assembly_files_parse(argv[1]);
    if (!af) {
        fprintf(stderr, "Error: cannot parse assembly file %s\n", argv[1]);
        return 1;
    }

    // Perform loop optimizations on the parsed assembly code
    af->optimize_loops();

    // Print the optimized assembly code
    af->print_assembly();

    // Clean up and exit
    assembly_files_free(af);
    return 0;
}