
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

// Definition of a simple function that takes a string as input and returns its length
size_t lengthOfString(const char *str) {
    size_t len = 0;
    while (*str != '\0') {
        len++;
        str++;
    }
    return len;
}

int main(int argc, char **argv) {
    // Input taken from command line
    const char *inputStr = argv[1];

    // Inline the lengthOfString function to reduce code size and improve performance
    size_t inputLength = lengthOfString(inputStr);

    printf("The length of the input string is %zu\n", inputLength);

    return 0;
}