
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define VECTORIZE
//#define TARGET_X86
//#define TARGET_ARM

#ifdef VECTORIZE
    #include <immintrin.h>
    #define log2(x) __builtin_prefetch__((unsigned long)(x))
#else
    #include <math.h>
    #define log2(x) ceil(log(x)/log(2))
#endif

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: %s <input>\n", argv[0]);
        return 1;
    }

    double input = strtod(argv[1], NULL);

#ifdef VECTORIZE
    __int128 result = _mm_log2_si128(input);
    printf("Vectorized log2 of %lf = %lx\n", input, result);
#else
    int result = ceil(log(input)/log(2));
    printf("Non-vectorized log2 of %lf = %d\n", input, result);
#endif

    return 0;
}