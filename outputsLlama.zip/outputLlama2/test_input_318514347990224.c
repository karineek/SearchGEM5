
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

#define ISUPER(c) (((unsigned char)(c)) > 0x7f)

int main(int argc, char **argv) {
    // Input from command line
    if (argc < 2) {
        printf("Usage: %s <string>\n", argv[0]);
        return 1;
    }

    // Get the input string from the command line
    char *input = argv[1];

    // Check if the input is uppercase
    if (ISUPER(input[0])) {
        printf("The first character of the input is uppercase\n");
    } else {
        printf("The first character of the input is not uppercase\n");
    }

    return 0;
}