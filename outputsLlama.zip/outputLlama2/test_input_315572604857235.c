
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "y.tab.h"

int main(int argc, char *argv[]) {
    // Parse assembly file
    if (argc > 1) {
        FILE *f = fopen(argv[1], "r");
        yyscan_t scanner;
        yyerror(NULL);
        yyparse(&scanner, f);
        fclose(f);
    } else {
        printf("Usage: %s <assembly_file>\n", argv[0]);
        return 1;
    }

    // Schedule instructions
    int n = 0;
    int m = 0;
    for (int i = 0; i < yyparse->yychar; i++) {
        switch (i) {
            case YY_STATE:
                printf("State\n");
                break;
            case YY_INST:
                printf("Instruction %d: %s\n", m++, yyparse->yytext[i]);
                break;
            default:
                printf("Error: unknown instruction %d\n", i);
        }
    }

    return 0;
}