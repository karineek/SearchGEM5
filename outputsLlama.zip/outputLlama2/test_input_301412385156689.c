
#include <stdio.h>
#include <stdint.h>
#include <string.h>

#define N 1024

void loop_vectorize(int *a, int n) {
    for (int i = 0; i < n;++i) {
        a[i] = i * 2;
    }
}

int main() {
    int a[N];
    int n = atoi(argv[1]);

    if (n > 0) {
        loop_vectorize(a, n);
        printf("Loop vectorized result: ");
        for (int i = 0; i < N;++i) {
            printf("%d ", a[i]);
        }
        printf("\n");
    } else {
        printf("Invalid input, please enter a positive integer value\n");
    }
    return 0;
}