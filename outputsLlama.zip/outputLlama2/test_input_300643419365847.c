
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
  // Scalar Optimization: Constant Folding
  if (argc > 1 && !strcmp("-help", argv[1])) {
    // Do something here
    printf("Usage: %s <command>\n", argv[0]);
    return 0;
  }

  // Pass 1: Tokenization and Parsing
  int tokenCount = 0;
  char *tokens[] = {argv[0], argv[1], argv[2]};
  yyparse(tokens, &tokenCount);

  // Transformation: Renaming Variables
  int x = 5;
  y = x + 3;
  printf("x = %d, y = %d\n", x, y);

  return 0;
}