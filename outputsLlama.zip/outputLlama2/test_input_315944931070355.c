
#include <stdio.h>
#include <string.h>

// Function to perform memory-to-register promotion
void promote_mem_to_reg(char *str) {
    int len = strlen(str);
    char *ptr = str;

    // Promote the string literal to a register
    register char c;
    for (int i = 0; i < len; i++) {
        c = *ptr++;
        if (c == '\0') {
            break;
        }
    }

    // Print the promoted value
    printf("%d", c);
}

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: %s <string>\n", argv[0]);
        return 1;
    }

    // Promote the input string to a register and print its value
    promote_mem_to_reg(argv[1]);

    return 0;
}