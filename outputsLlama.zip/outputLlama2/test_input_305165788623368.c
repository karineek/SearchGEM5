
#include <stdio.h>
#include <stdlib.h>
#include <llvm/llvm.h>

// Function to compute the hyperbolic tangent of a number
float tanhf(float x) {
  // Implement your own loop optimization here
  return x * sinf(x) / cosf(x);
}

int main(int argc, char **argv) {
  float input = strtof(argv[1], NULL); // Input from command-line argument
  float result = tanhf(input);          // Compute the hyperbolic tangent
  printf("The hyperbolic tangent of %f is %f\n", input, result); // Print the result
  return 0;
}