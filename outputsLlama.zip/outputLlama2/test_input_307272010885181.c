
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>

// Definition of powl function
double powl(double x, int n) {
    if (n == 0) return 1; // Handle special case for n = 0
    uint64_t result = 1;
    for (int i = 0; i < n; i++) {
        result *= x;
    }
    return (double)result;
}

// Function to test loop vectorization and IR manipulation
void testPowl(int argc, char** argv) {
    if (argc < 2) {
        printf("Usage: %s <n> <x>\n", argv[0]);
        return;
    }
    int n = atoi(argv[1]);
    double x = strtodouble(argv[2]);
    uint64_t result = powl(x, n);
    printf("Result: %lf\n", result);
}

int main(void) {
    int argc = 0;
    char** argv = NULL;
    while (1) {
        int opt = getopt(argc, argv, "n:x:");
        if (opt == -1) break; // End of options
        switch (opt) {
            case 'n':
                n = atoi(argv[opt - 1]);
                break;
            case 'x':
                x = strtodouble(argv[opt - 1]);
                break;
        }
    }
    testPowl(argc, argv);
    return 0;
}