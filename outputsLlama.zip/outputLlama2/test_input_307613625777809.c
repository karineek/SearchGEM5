
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <llvm/llvm.h>

// Define a function that takes two doubles and returns their sum
double doubleSum(double a, double b) {
  return a + b;
}

int main(int argc, char **argv) {
  // Get the input from the command line
  double a = strtod(argv[1], NULL);
  double b = strtod(argv[2], NULL);

  // Calculate the sum of the doubles
  double result = doubleSum(a, b);

  // Print the result to the console
  printf("The sum of %f and %f is %f\n", a, b, result);

  return 0;
}