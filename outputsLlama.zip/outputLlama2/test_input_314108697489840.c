
#include <stdio.h>
#include <string.h>
#include "clang-c/wmemmove.h"

int main(int argc, char **argv) {
  // Test input string
  const char *input = argv[1];

  // Move the input string to a register
  char buffer[4096];
  wmemmove_s(buffer, sizeof(buffer), input);

  // Print the result
  printf("%s\n", buffer);

  return 0;
}