
#include <stdio.h>
#include <clang/clang.h>

int main(int argc, char **argv) {
  // Parse the input from the command line
  const char *input = argv[1];

  // Create a Clang frontend instance
  clang::Frontend frontend;

  // Perform constant folding on the input
  clang::Compiler compiler(&frontend);
  compiler.setInputFile(input, "");
  compiler.doFinalization();

  // Print the resulting assembly code
  std::string assembly = compiler.getAssembly();
  printf("Assembly code:\n%s\n", assembly.c_str());

  return 0;
}