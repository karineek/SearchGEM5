
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Function to eliminate common subexpressions
void eliminate_common_subexpressions(char **str) {
    // Take a pointer to a string as input
    char *s = str[0];

    // Eliminate common subexpressions by concatenating the strings
    char *new_str = concat_strings(s, "hello");

    // Print the new string
    printf("%s\n", new_str);
}

// Function to concatenate strings
char *concat_strings(char *s1, char *s2) {
    int len = strlen(s1) + strlen(s2) + 1; // +1 for null terminator
    char *new_str = malloc(len);
    strcpy(new_str, s1);
    strcat(new_str, s2);
    return new_str;
}

int main(int argc, char **argv) {
    // Take a pointer to a string as input from the command line
    char *input = argv[1];

    // Call the function to eliminate common subexpressions
    eliminate_common_subexpressions(&input);

    return 0;
}