
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Utility functions
double square(double x) { return x * x; }
int odd(int n) { return n % 2 == 1; }

// Main function
int main(int argc, char **argv) {
    double n = strtodouble(argv[1]); // Parse input from command line
    int result = 0;
    for (int i = 0; i < 10; i++) {
        double x = n * pow(2.0, i);
        result += odd(x) * square(x);
    }
    printf("Result: %d\n", result);
    return 0;
}