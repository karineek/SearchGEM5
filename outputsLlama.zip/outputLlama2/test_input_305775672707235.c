
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

// Function specialization for %A conversion specifier
static int a_conv(const char *str) {
    return str[0] - 'a';
}

int main(int argc, char **argv) {
    // Process input from argv
    for (int i = 1; i < argc; i++) {
        const char *input = argv[i];
        printf("Input: %s\n", input);
        int result = a_conv(input);
        printf("Result: %d\n", result);
    }
    return 0;
}