
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// Define a function that takes advantage of scalar optimizations
void scaled_optimization(int arr[10]) {
  int i;
  for (i = 0; i < 10; i++) {
    arr[i] *= 2;
  }
}

int main(int argc, char **argv) {
  // Check if the input is a valid array
  if (argc < 2 || !argv[1]) {
    printf("Usage: %s <array_input>\n", argv[0]);
    return 1;
  }

  int arr[10];
  for (int i = 0; i < 10; i++) {
    arr[i] = atoi(argv[1]);
  }

  scaled_optimization(arr); // Triggers scalar optimization

  // Print the modified array
  for (int i = 0; i < 10; i++) {
    printf("%d ", arr[i]);
  }

  return 0;
}