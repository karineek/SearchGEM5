
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Function to test the Sparse Conditional Constant Propagation optimization pass
void test_sccc_propagation(int *a, int *b, int c) {
  // Calculate the result of the function using the propagated constants
  int result = a + b + c;

  // Print the result to verify that it has been optimized correctly
  printf("result: %d\n", result);
}

// Function to test the Collection of optimization passes
void test_collection(int *a, int *b, int c) {
  // Perform a series of optimizations on the function
  optimize();

  // Calculate the result of the function using the optimized variables
  int result = a + b + c;

  // Print the result to verify that it has been optimized correctly
  printf("result: %d\n", result);
}

int main(int argc, char **argv) {
  if (argc < 3) {
    printf("Usage: %s <a> <b> <c>\n", argv[0]);
    return 1;
  }

  int a = atoi(argv[1]);
  int b = atoi(argv[2]);
  int c = atoi(argv[3]);

  // Call the test functions with the user-provided inputs
  test_sccc_propagation(&a, &b, c);
  test_collection(&a, &b, c);

  return 0;
}