
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

#define FLT_DIG 128

int main(int argc, char **argv) {
    int n = atoi(argv[1]);
    float a[] = {0,};
    for (int i = 0; i < n; i++) {
        a[i] = (float)((double)i / FLT_DIG);
    }
    printf("%f\n", a[0]); // triggers Inliner Heuristics optimization
    return 0;
}