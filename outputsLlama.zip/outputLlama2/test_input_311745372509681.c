
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Function to reverse a number using inliner heuristics optimization
int reverseNumber(int num) {
  int rev = 0;
  while (num != 0) {
    rev = (rev * 10) + (num % 10);
    num /= 10;
  }
  return rev;
}

int main(int argc, char **argv) {
  if (argc < 2) {
    printf("Usage: %s <number>\n", argv[0]);
    return 1;
  }

  int num = atoi(argv[1]);
  int rev = reverseNumber(num);
  printf("%d\n", rev);

  return 0;
}