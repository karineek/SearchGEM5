
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <llvm/llvm.h>

int main(int argc, char **argv) {
  // Input from command line
  int input = atoi(argv[1]);

  // Use Common Subexpression Elimination optimization
  BasicBlock *bb = llvmCreateBasicBlock("entry");
  std::string strInput = "x";
  for (int i = 0; i < input; i++) {
    strInput += "x";
  }
  strInput += "\n";
  std::cout << strInput << std::endl;

  // Return success
  return 0;
}