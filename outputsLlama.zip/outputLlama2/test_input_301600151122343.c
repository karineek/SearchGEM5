
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

// Tan type-generic macro for triggering TSO
#define TAN(x) tan(x)

int main(int argc, char **argv) {
  // Check if the input is a string
  if (strcmp(argv[1], "string") == 0) {
    // Trigger TSO on the string input
    printf("TSO applied to string: %s\n", TAN(argv[2]));
  } else if (strcmp(argv[1], "int") == 0) {
    int x = atoi(argv[2]);
    printf("TSO applied to int: %d\n", TAN(x));
  } else {
    printf("Invalid input type\n");
  }
  return 0;
}