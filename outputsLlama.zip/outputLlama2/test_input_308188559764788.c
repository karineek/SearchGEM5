
#include <stdio.h>
#include <string.h>
#include <stdint.h>

// Function to promote memory to registers
void promote_mem_to_reg(void *ptr) {
    // Get the address of the memory block
    uint8_t *block = ptr;

    // Loop through the block and promote each byte to a register
    for (int i = 0; i < sizeof(block); i++) {
        uint8_t val = *block++;
        __asm__("mov %0, #%x" : : "r" (val));
    }
}

int main(int argc, char **argv) {
    // Check if the input is a binary file
    if (strcmp(argv[1], "-b") == 0) {
        // Open the binary file for reading
        FILE *file = fopen(argv[2], "rb");

        // Read the entire file into memory
        size_t file_size = fread(NULL, 0, sizeof(file), file);

        // Promote the memory to registers
        promote_mem_to_reg((void *)file_size);
    } else {
        // Otherwise, just print a message
        printf("Usage: %s <binary-file> [memory-block-size]\n", argv[0]);
    }
    return 0;
}