
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    // Loop optimization example 1: Use of "continue" statement
    int n = atoi(argv[1]);
    for (int i = 0; i < n; i++) {
        if (i % 2 == 0) {
            continue; // skip next iteration
        }
        printf("iteration %d\n", i);
    }

    // Loop optimization example 2: Use of "break" statement
    int n = atoi(argv[1]);
    for (int i = 0; i < n; i++) {
        if (i == 5) {
            break; // exit loop early
        }
        printf("iteration %d\n", i);
    }

    // FP_CONTRACT example: Use of "__fpcontract" directive
    int n = atoi(argv[1]);
    for (int i = 0; i < n; i++) {
        if (i % 2 == 0) {
            __fpcontract(i); // use fp contract to compute result of expression
            printf("result: %d\n", i);
        }
    }

    return 0;
}