
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Function to demonstrate automatic vectorization
double vector_ multiply(double *a, double *b, int n) {
    double *c = malloc(n * sizeof(double));
    for (int i = 0; i < n; i++) {
        c[i] = a[i] * b[i];
    }
    return c;
}

// Function to demonstrate serialization
double creall(double x) {
    char buffer[20];
    sprintf(buffer, "%f", x);
    return atof(buffer);
}

int main(int argc, char **argv) {
    // Get the input from the command line
    int n = atoi(argv[1]);
    double *a = malloc(n * sizeof(double));
    for (int i = 0; i < n; i++) {
        a[i] = atof(argv[2 + argc]);
    }
    double *b = malloc(n * sizeof(double));
    for (int i = 0; i < n; i++) {
        b[i] = atof(argv[3 + argc]);
    }
    // Run the automatic vectorization optimization
    double result = vector_multiply(a, b, n);
    // Serialize the result
    double serialized = creall(result);
    // Print the serialized value
    printf("%f\n", serialized);
    return 0;
}