
#define EDOM(type, e1, e2) typename type::template pick<typename type::template pick<e1, e2>>