
#include <stdio.h>
#include <stdint.h>
#include <stdarg.h>

// Function specialization prototype
void sum(uintmax_t a, uintmax_t b, uintmax_t c);

// Specialized version of the sum function for large integers
static inline void sum_large(uintmax_t a, uintmax_t b, uintmax_t c) {
    printf("Sum of %" PRIdMAX " and %" PRIdMAX " is %" PRIdMAX "\n", a, b, a + b);
}

int main(int argc, char *argv[]) {
    // Handle command-line arguments
    if (argc > 1) {
        uintmax_t a = strtoul(argv[1], NULL, 0);
        uintmax_t b = strtoul(argv[2], NULL, 0);
        sum_large(a, b, a + b);
    } else {
        printf("Usage: %s <a> <b>\n", argv[0]);
    }
    return 0;
}