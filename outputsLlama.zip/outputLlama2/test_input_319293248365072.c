
#include <stdio.h>
#include <string.h>
#include <wchar.h>

int main(int argc, char **argv) {
    // Input from user
    const wchar_t *input = argv[1];

    // Constant folding example 1: Fold "abc" to "a"
    wchar_t result = wcsncat_s(NULL, input, L"a", 1);
    printf("Result: %ls\n", result);

    // Constant folding example 2: Fold "abcdefg" to "abcd"
    result = wcsncat_s(NULL, input, L"abcd", 3);
    printf("Result: %ls\n", result);

    return 0;
}