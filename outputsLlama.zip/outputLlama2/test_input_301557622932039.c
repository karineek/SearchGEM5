
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <vector>

// Function to tokenize a string using vectorization
void tokenize(char *str, int n) {
    std::vector<char*> tokens;
    for (int i = 0; i < n; i++) {
        char c = str[i];
        if (c == ' ' || c == '\t' || c == '\n') {
            // Tokenize the string at the current position
            std::vector<char*> token = {str + i, str + n};
            tokens.push_back(token);
        }
    }
}

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: %s <string>\n", argv[0]);
        return 1;
    }

    // Tokenize the input string using vectorization
    tokenize(argv[1], strlen(argv[1]));

    return 0;
}