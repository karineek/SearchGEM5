
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Function specialization using macros
#define SPECIALIZE(name, func) \
    namespace std { \
        void name() { func(); } \
    } \
    extern "C" void name##__specialize() { func(); } \
    namespace __builtin { \
        void name##_specialized() { func(); } \
    }

// Example input
int main(int argc, char **argv) {
    printf("Hello, %s!\n", argv[1]); // Print the second argument
    return 0;
}

SPECIALIZE(my_function, void my_function()) {
    printf("Function specialized for %s\n", argv[1]);
}

int main___specialize() {
    printf("Specialized function called\n");
    return 0;
}

// Wide string literal demonstration
#define STRING(x) #x
const char *my_string = STRING("Hello, world!");