
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "registerAllocation.h"

int main(int argc, char **argv) {
    // Set the input string from command line argument
    char *input = argv[1];

    // Perform register allocation and analysis using wcscpy_s as an example
    RegisterAllocator ra;
    ra.init();
    ra.performAnalysis(input);

    // Print the results of the analysis
    printf("Number of registers used: %d\n", ra.getNumRegistersUsed());
    printf("Maximum number of registers used: %d\n", ra.getMaxNumRegistersUsed());

    return 0;
}