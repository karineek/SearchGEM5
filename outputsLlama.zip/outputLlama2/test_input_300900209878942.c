
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include < LLVMIR.h>

// Function to perform the computation using vectorization
void compute(int *numbers, int numNumbers) {
  // Get the number of elements in the array
  int numElements = numNumbers / 4;
  
  // Create a vector of integers
  llvm::APIntvector vec(numElements);
  
  // Initialize the vector with the input values
  for (int i = 0; i < numElements;++i) {
    vec[i] = numbers[i];
  }
  
  // Perform the computation using the vector
  llvm::APInt result = vec.reduce();
  
  // Print the result
  printf("Result: %d\n", result.getZextValue());
}

// Entry point for the program
int main(int argc, char **argv) {
  if (argc < 3) {
    printf("Usage: %s <input> <numNumbers>\n", argv[0]);
    return 1;
  }
  
  // Get the input and number of elements from the command line
  int numNumbers = atoi(argv[2]);
  int *numbers = (int *) malloc(sizeof(int) * numNumbers);
  
  // Read the input from the command line
  char *input = argv[1];
  int len = strlen(input);
  int i;
  for (i = 0; i < len;++i) {
    numbers[i] = atoi(input + i);
  }
  
  // Call the function to perform the computation
  compute(numbers, numNumbers);
  
  return 0;
}