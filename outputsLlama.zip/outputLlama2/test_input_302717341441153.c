
#include <clang-c/index.h>
#include <clang-c/ast.h>
#include <clang-c/type.h>

int main(int argc, char **argv) {
  // Parse input from command line
  const char *input = argv[1];

  // Use Inliner Heuristics optimization
  clang::index::Index index;
  clang::index::parse(input, index);

  // Exercise use of PRIu identifier prefix
  clang::type::TypeKind kind = index.getTypeKind();
  if (kind == clang::type::TypeKind::IK_INVALID) {
    // Handle invalid type
  } else {
    char buffer[50];
    snprintf(buffer, sizeof(buffer), "Type is %s", clang::type::TypeString(index.getType()).c_str());
    printf("%s\n", buffer);
  }

  return 0;
}