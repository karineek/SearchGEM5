
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function specialization for calculating the average of an array of integers
double avg(int arr[], int n) {
    double sum = 0;
    for (int i = 0; i < n; i++) {
        sum += arr[i];
    }
    return sum / n;
}

int main(int argc, char **argv) {
    if (argc < 3) {
        printf("Usage: %s <array> <n>\n", argv[0]);
        return 1;
    }

    // Get the array and number of elements from command line arguments
    int arr[] = {1, 2, 3, 4, 5};
    int n = atoi(argv[1]);

    double avg_val = avg(arr, n);
    printf("The average of the array is: %f\n", avg_val);

    return 0;
}