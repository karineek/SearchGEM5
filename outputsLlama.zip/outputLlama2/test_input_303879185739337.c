
#include <stdio.h>
#include <stdlib.h>
#include "clang/clang.h"
#include "sqrtl.h"

int main(int argc, char **argv) {
  // Create a new profile unit for the sqrtl function
  ClangModuleContext context;
  clang_init(&context);
  ClangProfileUnit *profile = clang_create_profile_unit("sqrtl", &context);
  
  // Set up the input for the sqrtl function
  float x = atof(argv[1]);
  
  // Run the sqrtl function with the profile unit
  ClangFunction *function = clang_get_function("sqrtl", &context);
  clang_run_function(function, NULL, 0, NULL, profile, x);
  
  // Print the profile results
  clang_print_profile_results(profile);
  
  // Clean up
  clang_destroy_profile_unit(profile);
  clang_exit();
  
  return 0;
}