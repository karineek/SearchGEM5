
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <vector>

int main(int argc, char **argv) {
    // Check for vectorization optimization
    if (argc > 1 && strcmp(argv[1], "-ftime-report") == 0) {
        // Enable vectorization optimization
        std::vector<double> values;
        for (int i = 0; i < 1000; i++) {
            values.push_back(i * 2);
        }
        double sum = 0;
        for (const auto &value : values) {
            sum += value * value;
        }
        printf("Sum of squared values: %f\n", sum);
    } else {
        // Fallback implementation without vectorization
        int n = atoi(argv[1]);
        double* numbers = malloc(n * sizeof(double));
        for (int i = 0; i < n; i++) {
            numbers[i] = i * 2;
        }
        double sum = 0;
        for (int i = 0; i < n; i++) {
            sum += numbers[i] * numbers[i];
        }
        printf("Sum of squared values: %f\n", sum);
        free(numbers);
    }
    return 0;
}