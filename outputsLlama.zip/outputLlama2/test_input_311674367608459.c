
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    // Initialize variables
    int i;
    for (i = 0; i < argc; i++) {
        printf("Argument %d: %s\n", i, argv[i]);
    }

    // Check if the input is a valid integer
    if (strcmp(argv[1], "42") == 0) {
        printf("The answer to life, the universe, and everything is 42.\n");
    } else {
        printf("Invalid input. Please try again.\n");
    }

    return 0;
}