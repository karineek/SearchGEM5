
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int main(int argc, char **argv) {
    double x = atof(argv[1]); // Parse input from command line
    double y = 2 * x;          // Calculate result using Target-Specific Optimizations
    printf("%lf\n", LDBL_TRUE_MIN(y, x));   // Demonstrate support for LDBL_TRUE_MIN
    return 0;
}