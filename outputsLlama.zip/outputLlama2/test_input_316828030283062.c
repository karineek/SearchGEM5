
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv) {
    // Input: "10 20 30"
    int num_ints = atoi(argv[1]);
    int *ints = malloc(num_ints * sizeof(int));

    for (int i = 0; i < num_ints; i++) {
        ints[i] = atoi(argv[2 + i]);
    }

    // Trigger register allocation optimization using address operator &
    int result = &ints[0]; // Address operator & creates a pointer to the first element of the array
    printf("Result: %d\n", *result); // Output: 10

    return 0;
}