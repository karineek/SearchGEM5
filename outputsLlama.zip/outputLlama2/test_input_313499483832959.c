
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "ctanhf.h"

int main(int argc, char **argv) {
  // Input from command line
  if (argc < 2) {
    fprintf(stderr, "Usage: %s <expression>\n", argv[0]);
    return 1;
  }

  // Get the expression from the command line
  const char *expression = argv[1];

  // Evaluate the expression using Inliner Heuristics
  ctanhf(expression);

  // Print the result
  printf("Result: %f\n", ctanhf_result);

  return 0;
}