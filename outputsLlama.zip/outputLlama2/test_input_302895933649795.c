
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "profile.h"

#define MAX_INPUT 100

int main(int argc, char **argv) {
    // Get the input from the command line
    char *input = argv[1];

    // Initialize the profile information
    struct profile profile;
    profile.counts = malloc(sizeof(struct count_pair));
    profile.counts[0].name = "main";
    profile.counts[0].value = 1;

    // Perform the subtraction assignment operator (-=)
    int result = profile.counts[0].value - strlen(input);

    // Print the result
    printf("Result: %d\n", result);

    return 0;
}