
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

// Function to test loop vectorization
void vectorize_loops(int n) {
  for (int i = 0; i < n;++i) {
    for (int j = 0; j < n;++j) {
      int k = i * n + j;
      printf("%d ", k);
    }
  }
}

// Function to test iswctype function
char is_letter(const char* str) {
  for (int i = 0; *str != '\0';++i) {
    if (*str == 'a' || *str == 'A') return true;
    else if (*str == 'z' || *str == 'Z') return false;
    str++;
  }
  return false;
}

int main(int argc, char** argv) {
  int n = atoi(argv[1]); // Get the input from command line argument

  vectorize_loops(n); // Call the function to test loop vectorization

  char str[] = "hello world"; // String to test iswctype function
  if (is_letter(str)) {
    printf("string contains a letter\n");
  } else {
    printf("string does not contain any letters\n");
  }

  return 0;
}