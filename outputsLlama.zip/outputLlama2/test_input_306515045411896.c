
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// Function to optimize loops
void loopOptimize(int n) {
    int i;
    for (i = 0; i < n; i++) {
        printf("Iteration %d\n", i);
    }
}

// Function to deal with binary formats
void binFormat(char *str) {
    int len = strlen(str);
    char *p = str + len - 1;
    while (p >= str) {
        printf("Binary format: %c", *p);
        p--;
    }
}

// Function to exercise fwide function
void wideFormat(double num, int digits) {
    char buffer[20];
    sprintf(buffer, "%.1f", num);
    printf("Wide format: %s\n", buffer);
}

int main(int argc, char **argv) {
    // Check if input is given
    if (argc < 2) {
        printf("Usage: %s <input>\n", argv[0]);
        return 1;
    }

    int n = atoi(argv[1]);
    loopOptimize(n); // Optimize loops
    binFormat(argv[1]); // Deal with binary formats
    wideFormat(3.14, 2); // Exercise fwide function

    return 0;
}