
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

// Function to be optimized using whole program analysis
void optimize_me(int x, int y) {
    assert(x + y == 5); // Check for obvious errors
    return x * y;        // Return the result of the addition
}

int main(int argc, char **argv) {
    // Get the input from the command line arguments
    int x = atoi(argv[1]);
    int y = atoi(argv[2]);

    // Call the optimized function
    printf("%d\n", optimize_me(x, y));

    // Demonstrate composite function
    void composite_function() {
        printf("This is a composite function\n");
        optimize_me(10, 20); // Call the optimized function again
    }

    // Call the composite function
    composite_function();

    return 0;
}