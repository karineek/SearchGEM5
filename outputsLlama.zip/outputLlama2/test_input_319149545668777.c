
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <llvm/llvm.h>

// Function to compute the cpowf of two numbers
void cpowf(float a, float b, float *result) {
  // Initialize result to 1.0
  *result = 1.0f;
  
  // If b is 0, return a * 1.0
  if (b == 0) {
    return a * 1.0f;
  }
  
  // Otherwise, compute cpowf recursively
  float temp = cpowf(a, b / 2, result);
  
  // If b is even, return temp
  if (b % 2 == 0) {
    return temp;
  }
  
  // Otherwise, compute cpowf again with a * 2
  temp = cpowf(a, b / 2, result);
  *result = a * 2.0f * temp;
}

int main(int argc, char **argv) {
  if (argc < 3) {
    printf("Usage: %s <a> <b>\n", argv[0]);
    return 1;
  }
  
  float a = strtof(argv[1], NULL);
  float b = strtof(argv[2], NULL);
  float result;
  
  // Call cpowf function with arguments a and b
  cpowf(a, b, &result);
  
  // Print result to stdout
  printf("cpowf(%f, %f) = %f\n", a, b, result);
  
  return 0;
}