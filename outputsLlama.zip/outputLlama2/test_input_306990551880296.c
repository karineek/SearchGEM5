
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <semaphore.h>

// Function to demonstrate loop vectorization
void vec_loop(int n) {
  int a[n];
  for (int i = 0; i < n;++i) {
    a[i] = i * 2;
  }
  // Demonstrate observable behavior by printing the array
  printf("Array: ");
  for (int i = 0; i < n;++i) {
    printf("%d ", a[i]);
  }
  printf("\n");
}

// Function to demonstrate Sema feature
void sema_function(sem_t *sema) {
  int count = 0;
  while (count < 10) {
    sem_post(sema);
    count++;
    usleep(10000); // Delay for 10ms to demonstrate observable behavior
  }
}

int main(int argc, char *argv[]) {
  int n = atoi(argv[1]); // Get input from command line

  sem_t *sema = sem_create(sem_key_t()); // Create a semaphore

  vec_loop(n); // Call the loop vectorization function
  sema_function(sema); // Call the Sema feature function

  sem_destroy(sema); // Destroy the semaphore

  return 0;
}