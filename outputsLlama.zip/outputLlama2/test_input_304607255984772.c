
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Inline function for Fibonacci sequence
static inline int fibonacci(int n) {
  if (n == 0 || n == 1) return n;
  return fibonacci(n-1) + fibonacci(n-2);
}

int main(int argc, char **argv) {
  // Check for valid input
  if (argc < 2) {
    printf("Usage: %s <sequence size>\n", argv[0]);
    return 1;
  }

  int n = atoi(argv[1]); // Parse input from command line

  // Call the inline function to compute Fibonacci sequence
  printf("%d\n", fibonacci(n));

  return 0;
}