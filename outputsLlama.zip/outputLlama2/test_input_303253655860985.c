
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Function to demonstrate constant folding
double compute(double a, double b) {
    return a + b; // Constant folding: a + b = 2 * (a + b / 2)
}

int main(int argc, char **argv) {
    if (argc < 3) {
        printf("Usage: %s <input1> <input2>\n", argv[0]);
        return 1;
    }

    // Read input from command line arguments
    double a = strtod(argv[1], NULL);
    double b = strtod(argv[2], NULL);

    // Demonstrate constant folding using compute function
    double result = compute(a, b);
    printf("Result: %f\n", result);

    return 0;
}