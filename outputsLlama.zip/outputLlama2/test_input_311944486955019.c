
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "clang/headerfiles.h"

// Definition of the isgraph function
bool isgraph(int c) {
  return (c >='a' && c <= 'z') || (c >='A' && c <= 'Z');
}

int main() {
  // Get the input from the command line using argv
  int n = 0;
  char *input = *(argv[1]);

  // Perform inlining of isgraph function
  inline bool isgraph_inlined(int c) { return isgraph(c); }

  // Call the inlined function with the input string
  for (char *p = input; *p; p++) {
    if (!isgraph_inlined(*p)) {
      printf("Not a graphical character: %c\n", *p);
    }
  }

  return 0;
}