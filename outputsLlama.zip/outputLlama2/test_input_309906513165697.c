
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Function to inline the called function
void inline_func(int x, int y) {
    printf("Inlined function called with arguments %d and %d\n", x, y);
}

int main(int argc, char **argv) {
    // Check if the -I flag is given
    if (argc > 1 && strcmp(argv[1], "-I") == 0) {
        // Inline the called function
        inline_func(5, 10);
    } else {
        // Print a message if the -I flag is not given
        printf("Inliner heuristics are disabled\n");
    }
    return 0;
}