
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    // TSO: Use of _MAX identifier suffix
    int maxValue = _MAX(10, argc); // 10 is the maximum value

    // Analysis: Print the input array
    for (int i = 0; i < argc; i++) {
        printf("%s\n", argv[i]);
    }

    return 0;
}