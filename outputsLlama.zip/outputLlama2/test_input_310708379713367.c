
#include <stdio.h>
#include <string.h>

// Define a function that takes two strings as inputs and returns their concatenation
void concat_strings(char *s1, char *s2) {
    printf("Concatenating %s and %s...\n", s1, s2);
    char *new_string = strcat(s1, s2);
    printf("New string: %s\n", new_string);
}

int main(int argc, char **argv) {
    // Check the number of arguments passed to the program
    if (argc < 3) {
        printf("Usage: %s <input1> <input2>\n", argv[0]);
        return 1;
    }

    // Inline the concat_strings function
    concat_strings(argv[1], argv[2]); // inline the function call

    return 0;
}