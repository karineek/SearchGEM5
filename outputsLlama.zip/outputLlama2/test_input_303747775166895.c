
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Inline the isdigit function
#define ISDIGIT(x) (__builtin_isdigit(x))

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }

    int number = atoi(argv[1]);
    if (ISDIGIT(number)) {
        printf("The number %d is digit.\n", number);
    } else {
        printf("The number %d is not digit.\n", number);
    }

    return 0;
}