
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define MAX_INTEGER 1000000

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Usage: %s <start_interval> <end_interval>\n", argv[0]);
        return 1;
    }

    int start = atoi(argv[1]);
    int end = atoi(argv[2]);
    int armstrong = 0;

    for (int i = start; i <= end; i++) {
        if (is_armstrong(i)) {
            armstrong++;
        }
    }

    printf("Number of Armstrong numbers between %d and %d: %d\n", start, end, armstrong);

    return 0;
}

int is_armstrong(int n) {
    int i, pow;
    for (i = 2, pow = 1; i <= sqrt(n); i++, pow *= n / i) {
        if (pow > n) break;
    }
    return i == n;
}