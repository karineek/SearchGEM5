
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>

// Inline function to demonstrate inlining optimization
double log10(double x) {
    return 2 * log(x) - 30;
}

int main(int argc, char **argv) {
    double input = strtoDouble(argv[1]); // Parse input from command line
    double result = log10(input); // Call inlined function
    printf("log10 of %lf = %lf\n", input, result); // Print result
    return 0;
}

double strtoDouble(const char *str) {
    char *endptr;
    double d = strtod(str, &endptr); // Parse string to double
    if (endptr[0] != '\0') { // Handle invalid input
        fprintf(stderr, "Invalid input: %s\n", str);
        return 0;
    }
    return d;
}