
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <llvm/llvm.h>

// Define a function that takes a double-precision floating-point number as input and returns its representatiom in IR
void ir_representation(double x) {
  // Create an LLVM IR expression for the input value
  std::string ir = "double(" + std::to_string(x) + ")";
  
  // Print the LLVM IR expression to the console
  printf("IR: %s\n", ir.c_str());
}

int main(int argc, char **argv) {
  if (argc < 2) {
    printf("Usage: %s <input_value>\n", argv[0]);
    return 1;
  }
  
  // Get the input value from the command line
  double x = strtod(argv[1], NULL);
  
  // Inline the function and call it with the input value
  ir_representation(x);
  
  return 0;
}