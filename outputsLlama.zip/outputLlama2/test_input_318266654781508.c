
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <inttypes.h>

// Utility functions
int strlen(const char *str) { return strlen(str); }
double sqrt(double x) { return sqrt(x); }
char isdigit(int c) { return isdigit(c); }

// Main program
int main(int argc, char **argv) {
    // Input from command line
    if (argc < 2) {
        printf("Usage: %s <input string>\n", argv[0]);
        return 1;
    }

    // Get input string
    char *str = argv[1];

    // Perform Loop Fusion optimization
    int length = strlen(str);
    for (int i = 0; i < length; i++) {
        if (isdigit(str[i])) {
            // Do something with the digit
            printf("%d", str[i]);
        }
    }

    return 0;
}