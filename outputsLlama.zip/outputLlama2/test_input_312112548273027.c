
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to test SCCP optimization
int cabs(int x, int y) {
  if (x == 0) {
    return y;
  } else {
    return x + cabs(y, -x);
  }
}

int main() {
  // Test SCCP optimization with a concrete example
  int n = atoi(argv[1]);
  int m = atoi(argv[2]);
  int result = cabs(n, m);
  printf("Result: %d\n", result);
  return 0;
}