
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// Definition of a simple function that takes two integers as input and returns their sum
int sum(int a, int b) {
    return a + b;
}

// Definition of a simple function that takes a single integer as input and returns its square
int square(int x) {
    return x * x;
}

// Example input from the command line
int main(int argc, char **argv) {
    // Check for correct number of arguments
    if (argc != 3) {
        printf("Incorrect number of arguments. Expecting 3\n");
        return 1;
    }

    // Get the input values from the command line
    int a = atoi(argv[1]);
    int b = atoi(argv[2]);

    // Perform the requested operations and print the results
    printf("The sum of %d and %d is %d\n", a, b, sum(a, b));
    printf("The square of %d is %d\n", a, square(a));

    return 0;
}