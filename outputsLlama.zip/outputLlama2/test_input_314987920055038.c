
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Functions to be inlined
void ferror(const char *message) {
    perror(message);
}

int main(int argc, char **argv) {
    if (argc > 1) {
        // Inline call to ferror()
        ferror(argv[1]);
    } else {
        // Call to ferror() through the frontend
        ferror("No message provided");
    }
    return 0;
}