
#include <stdio.h>
#include <stdint.h>
#include <string.h>

int main(int argc, char **argv) {
    // Testing memory optimizations
    uint8_t buffer[1024];
    memset(buffer, 0x5a, 1024);
    printf("Original buffer: %s\n", buffer);

    // Dealing with binary formats
    char *binary = argv[1];
    size_t len = strlen(binary);
    uint8_t *data = (uint8_t *)binary;
    for (size_t i = 0; i < len; i++) {
        printf("%c", data[i]);
    }

    // Long long integer type conversion
    long long int value = strtoll(argv[2], NULL, 10);
    printf("Value: %lld\n", value);

    return 0;
}