
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Function to eliminate common subexpressions
int getwc(const char *str) {
  int count = 0;
  for (char c : str) {
    if (count == 0) {
      count = c;
    } else if (c == count) {
      count++;
    } else {
      count = 0;
    }
  }
  return count;
}

int main(int argc, char **argv) {
  // Check the number of arguments passed to the program
  if (argc != 2) {
    printf("Usage: %s <input_string>\n", argv[0]);
    return 1;
  }

  // Read the input string from the command line
  const char *str = argv[1];

  // Eliminate common subexpressions in the input string
  int count = getwc(str);

  // Print the result of the elimination
  printf("Common subexpressions eliminated: %d\n", count);

  return 0;
}