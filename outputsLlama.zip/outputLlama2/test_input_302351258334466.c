
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Define a function that takes a string representation of a number and returns its float value
float atof(const char *str) {
    float f = 0;
    int num_digits = 0;
    while (*str != '\0') {
        if (*str >= '0' && *str <= '9') {
            num_digits++;
            f = (f * 10) + (*str - '0');
        } else {
            break;
        }
        str++;
    }
    return f / pow(10, num_digits);
}

int main() {
    // Take input from the command line using argv
    int num_args = sizeof(argv) / sizeof(argv[0]);
    for (int i = 0; i < num_args; i++) {
        char *input = argv[i];
        float f = atof(input);
        printf("Input: %s, Output: %f\n", input, f);
    }
    return 0;
}