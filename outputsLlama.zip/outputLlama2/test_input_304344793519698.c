
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <fcntl.h>
#include <inttypes.h>
#include "atomic_exchange.h"

// Example input:
int main(int argc, char **argv) {
    int num_pages = atoi(argv[1]);
    void *ptr = mmap(-1, num_pages * PGSIZE, PROT_READ | PROT_WRITE, MAP_ANON | MAP_PRIVATE, -1, 0);
    char *data = ptr;
    atomic_exchange(data, "Hello, World!");
    munmap((void *)ptr, num_pages * PGSIZE);
    return 0;
}