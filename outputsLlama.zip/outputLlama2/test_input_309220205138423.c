
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char** argv) {
    // Get the binary number from the user
    int bin_num = atoi(argv[1]);

    // Convert the binary number to octal
    char octal_str[32];
    int octal = bin_to_octal(bin_num, octal_str);

    // Print the octal representation of the number
    printf("The octal representation of %d is: %s\n", bin_num, octal_str);

    return 0;
}

// Function to convert a binary number to octal
int bin_to_octal(int bin_num, char* octal_str) {
    int i = 0;
    while (bin_num != 0) {
        octal_str[i++] = (bin_num % 2 == 1) ? '1' : '0';
        bin_num /= 2;
    }
    octal_str[i] = '\0'; // null terminate the string
    return i; // return the length of the octal representation
}