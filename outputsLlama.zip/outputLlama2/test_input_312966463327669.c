
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Define a function to promote memory to registers
void cargl(int *x, int *y) {
    // Promote x and y to registers
    register int ax = *x;
    register int ay = *y;

    // Perform the operation
    int result = ax + ay;

    // Store the result in a memory location
    *(int *)(&result) = result;
}

int main() {
    // Get input from the command line
    int n = atoi(argv[1]);
    int m = atoi(argv[2]);

    // Create a pointer to an integer array
    int *a = malloc(n * sizeof(int));
    for (int i = 0; i < n; i++) {
        a[i] = i;
    }

    // Call the cargl function with the input parameters
    cargl(a, m);

    // Print the result
    printf("%d\n", *(int *)(&a[0]));

    return 0;
}