
#include <stdio.h>
#include <string.h>
#include <stdint.h>

// Function specialization using inline assembly
void inner_loop(uint8_t *ptr, int len) {
    asm("loop1: \n"
        "    dec Len\n"
        "    jg loop1\n"
        "    nop\n"
        "    jmp loop1\n");
}

void outer_loop(uint8_t *ptr, int len) {
    inner_loop(ptr, len);
}

int main() {
    // Input from command line
    uint8_t *ptr = (uint8_t *)argv[1];
    int len = atoi(argv[2]);

    // Call the outer loop
    outer_loop(ptr, len);

    return 0;
}