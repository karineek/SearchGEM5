
#include <clang-frontend/clang-frontend.h>
#include <decimal_point.h>

int main(int argc, char **argv) {
  // Parse command line arguments
  if (argc != 2) {
    fprintf(stderr, "Usage: %s <input.txt>\n", argv[0]);
    return 1;
  }

  // Load the input file
  std::ifstream input_file(argv[1], std::ios::in);
  if (!input_file) {
    fprintf(stderr, "Error: unable to open input file %s\n", argv[1]);
    return 2;
  }

  // Declare the decimal point structure member
  struct decimal_point {
    int digits;
    double value;
  };

  // Create a decimal point structure member from the input file
  std::vector<struct decimal_point> decimals;
  while (input_file >> decimals.back().digits >> decimals.back().value) {
    decimals.push_back(decimals.back());
  }

  // Schedule instructions for the decimal point structure member
  ClangFrontend::InstructionScheduler is;
  is.scheduleInstructions(decimals);

  // Print the optimized instruction sequence
  for (const auto &instruction : is.getOptimizedInstructions()) {
    fprintf(stderr, "Instruction: %s\n", instruction.getAsString());
  }

  return 0;
}