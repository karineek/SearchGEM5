
#include <stdio.h>
#include <stdarg.h>

// Function to print arguments passed to program
void print_args(int argc, char **argv) {
  int i;
  for (i = 0; i < argc; i++) {
    printf("%s ", argv[i]);
  }
  printf("\n");
}

// Function to demonstrate register allocation optimization
void foo(int a, int b, __VA_ARGS__) {
  int c = *(__VA_ARGS__); // Get the value of the last argument passed
  printf("c = %d\n", c);
}

int main(int argc, char **argv) {
  foo(1, 2, 3, 4, 5); // Call the function with 5 arguments
  return 0;
}