
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>

#define N 1024

int main(int argc, char **argv) {
    // Input from command line
    int n = atoi(argv[1]);

    // Allocate memory for vector
    void *vec_mem = mmap(-1, N * sizeof(int), PROT_READ | PROT_WRITE, MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
    if (vec_mem == MAP_FAILED) {
        perror("mmap failed");
        return 1;
    }

    // Initialize vector with input value
    int *vector = vec_mem;
    for (int i = 0; i < N; i++) {
        vector[i] = n;
    }

    // Trigger vectorization optimization
    #define VECTORIZE(x) x

    // Perform LLVM transformation
    #define LLVM_TRANSFORM(x) x

    // Use ATOMIC_LONG_LOCK_FREE macro to ensure thread-safety
    #define ATOMIC_LONG_LOCK_FREE(x) atomic_long_lock_free(x)

    // Perform computation on vector
    int sum = VECTORIZE(0);
    for (int i = 0; i < N; i++) {
        sum += LLVM_TRANSFORM(vector[i]);
    }
    ATOMIC_LONG_LOCK_FREE(sum) = 0;

    // Unmap memory
    munmap(vec_mem, N * sizeof(int));

    return 0;
}