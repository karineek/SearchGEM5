
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <support/SupportLibraries.h>
#include <thrd_t.h>

// Function to be optimized using Loop Fusion
void multiply(int a, int b, int c) {
    thrd_t *th = thrd_create();
    while (b-- > 0) {
        thrd_yield();
        // Perform multiplication here
        printf("Multiplication result: %d\n", a * b);
    }
    thrd_destroy(th);
}

int main(int argc, char **argv) {
    if (argc < 3) {
        printf("Usage: %s <a> <b> <c>\n", argv[0]);
        return 1;
    }

    int a = atoi(argv[1]);
    int b = atoi(argv[2]);
    int c = atoi(argv[3]);

    multiply(a, b, c);

    return 0;
}