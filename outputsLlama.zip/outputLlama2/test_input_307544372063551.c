
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <inttypes.h>

// Function specialization for Armstrong number check
__attribute__((noinline)) inline bool is_armstrong(uint64_t n) {
    if (n == 1 || n == 0) return true; // Special cases
    for (size_t i = 1; i <= n / 2; i++) {
        if (n % i == 0) continue; // Check for divisors
        if (is_armstrong(i * n / i)) return true; // Recursively check Armstrong number property
    }
    return false; // If no divisor found, number is not an Armstrong number
}

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }
    uint64_t n = strtoul(argv[1], NULL, 10); // Parse input number from command line
    if (!is_armstrong(n)) {
        printf("Not an Armstrong number\n");
    } else {
        printf("Armstrong number\n");
    }
    return 0;
}