
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Utility functions
double safe_sqrt(double x) {
    if (x < 0) {
        return 0;
    } else if (x == 0) {
        return 1;
    } else {
        return sqrt(x);
    }
}

double safe_exp(double x) {
    if (x < 0) {
        return 0;
    } else if (x == 0) {
        return 1;
    } else {
        return exp(x);
    }
}

// Type-generic macro for atanh
#define ATANH(x) \
    ({                         \
        double y = safe_sqrt((double)(x));   \
        double z = safe_exp(y * y);        \
        z * (1 - (z / 2));           \
    })

int main() {
    double x = atoi(argv[1]); // Input from command line
    printf("%.4f\n", ATANH(x));   // Print the result
    return 0;
}