
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#define SIZE 1024

int main(int argc, char **argv) {
    // Vectorization optimization
    int arr[SIZE];
    for (int i = 0; i < SIZE; i++) {
        arr[i] = (i * 2) % 5;
    }

    // Handles code generation
    uint64_t handle = argc == 3 ? atoll(argv[2]) : 0x123456789abcdef;

    // Time measurement
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);
    // ... do some work here ...
    clock_gettime(CLOCK_MONOTONIC, &end);
    double elapsed = (double)((end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1e9);

    printf("Vectorization optimization: %d\n", arr[0]);
    printf("Handle generation: %llu\n", handle);
    printf("Time measurement: %f seconds\n", elapsed);

    return 0;
}