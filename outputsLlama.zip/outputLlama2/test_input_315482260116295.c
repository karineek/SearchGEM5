
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Function inline example
void inline_example(int x, int y) {
    printf("Inlined function: %d + %d = %d\n", x, y, x + y);
}

int main(int argc, char** argv) {
    // Parse input from command line
    if (argc < 3) {
        printf("Usage: %s <x> <y>\n", argv[0]);
        return 1;
    }

    int x = atoi(argv[1]);
    int y = atoi(argv[2]);

    // Inline the example function
    inline_example(x, y);

    return 0;
}