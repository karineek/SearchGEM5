
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <semaphore.h>

// Define a simple struct to hold the profile data
struct profile_data {
    int count;
    double avg_time;
};

// Function to retrieve the profile data from the command line arguments
void get_profile_data(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: %s <executable> <input_file>\n", argv[0]);
        exit(1);
    }

    // Create a semaphore to control access to the profile data
    sem_t *sem = sem_create(O_CREATION, 0);
    if (sem == NULL) {
        perror("sem_create");
        exit(1);
    }

    // Get the executable and input file names from the command line
    const char *executable = argv[1];
    const char *input_file = argv[2];

    // Initialize the profile data struct with default values
    struct profile_data data;
    data.count = 0;
    data.avg_time = 0.0;

    // Profile the executable and input file using the semaphore
    while (1) {
        // Acquire the semaphore to start the profiling
        if (sem_acquire(sem)) {
            perror("sem_acquire");
            exit(1);
        }

        // Run the executable and input file in the background
        const char *proc = execv("./" + executable, NULL);
        if (proc == NULL) {
            perror("execv");
            exit(1);
        }

        // Profile the executable and input file using the semaphore
        while (1) {
            // Check if the profiling is completed
            if (sem_check(sem)) {
                break;
            }
        }

        // Release the semaphore to allow other processes to access the profile data
        sem_release(sem);
    }
}

int main(int argc, char **argv) {
    // Call the function to retrieve the profile data from the command line arguments
    get_profile_data(argc, argv);

    // Print the profile data to the console
    struct profile_data data;
    data = get_profile_data();
    printf("Count: %d\n", data.count);
    printf("Average time: %f seconds\n", data.avg_time);

    return 0;
}