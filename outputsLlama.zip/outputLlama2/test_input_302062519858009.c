
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>

// Define an enum type to represent the different operations that can be performed on a file
typedef enum {
    OP_READ, OP_WRITE, OP_DELETE
} file_op_t;

// Function to perform an operation on a file
void operateOnFile(file_op_t op, const char *filename) {
    // Switch statement to determine the appropriate action based on the operation
    switch (op) {
        case OP_READ:
            readFile(filename);
            break;
        case OP_WRITE:
            writeFile(filename);
            break;
        case OP_DELETE:
            deleteFile(filename);
            break;
        default:
            printf("Invalid operation\n");
            break;
    }
}

// Function to read the contents of a file
void readFile(const char *filename) {
    // Use fread to read the contents of the file into a buffer
    int len = 0;
    char buffer[4096];
    fread(&len, sizeof(int), 1, fileStream(filename));
    fread(buffer, sizeof(char), len, fileStream(filename));
    // Print the contents of the file
    printf("%s\n", buffer);
}

// Function to write the contents of a file
void writeFile(const char *filename) {
    // Use fwrite to write the contents of a buffer to a file
    int len = 0;
    char buffer[4096];
    fread(&len, sizeof(int), 1, fileStream(filename));
    fwrite(buffer, sizeof(char), len, fileStream(filename));
    // Print the contents of the file
    printf("%s\n", buffer);
}

// Function to delete a file
void deleteFile(const char *filename) {
    // Use unlink to delete the file
    unlink(filename);
    // Print a message indicating that the file has been deleted
    printf("File deleted successfully\n");
}

int main(int argc, char **argv) {
    if (argc < 3) {
        printf("Usage: %s <operation> <filename>\n", argv[0]);
        return 1;
    }

    file_op_t op = OP_READ; // Initialize the operation to read
    const char *filename = argv[2]; // Get the filename from the command line arguments

    operateOnFile(op, filename); // Perform the operation on the file

    return 0;
}