
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

// Constant folding example
#define PI 3.14159

int main(int argc, char **argv) {
    // Object file format example
    unsigned char obj_data[] = {0x12, 0x34, 0x56, 0x78};
    const char *obj_name = "my_object";

    // wmemchr example
    int found = wmemchr(argv[1], 'a', strlen(argv[1]));

    printf("Constant folding: %d\n", PI);
    printf("Object file format: %s\n", obj_name);
    printf("wmemchr result: %d\n", found);

    return 0;
}