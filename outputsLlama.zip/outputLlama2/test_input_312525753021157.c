
#include <stdio.h>
#include <string.h>
#include "assembly.h"
#include "parsing.h"
#include "register_allocation.h"

int main(int argc, char **argv) {
    // Parse assembly code from command line arguments
    AssemblyCode *code = parseAssemblyCode(argv[1]);

    // Perform register allocation optimizations on the code
    RegisterAllocation *ra = performRegisterAllocation(code);

    // Print the optimized assembly code
    printOptimizedAssembly(ra->assembly);

    free(ra);
    return 0;
}