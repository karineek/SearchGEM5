
#include <stdio.h>
#include <ast.h>
#include <modulus.h>

int main(int argc, char **argv) {
    // Parse the input from the command line
    char *input = argv[1];

    // Create an AST for the input
    ast_t *ast = ast_parse(input);

    // Perform Whole Program Analysis on the AST
    modulus_t *modulus = modulus_analyze(ast);

    // Print the results of the analysis
    printf("Modulus functions: \n");
    for (int i = 0; i < modulus->num_funcs; i++) {
        func_t *func = modulus->funcs[i];
        printf("  %s (%d)\n", func->name, func->arity);
    }

    // Free the AST and modulus structures
    ast_free(ast);
    modulus_free(modulus);

    return 0;
}