
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>

int main(int argc, char *argv[]) {
    // Check if the input is normal
    if (strcmp(argv[1], "normal") == 0) {
        printf("The input is normal\n");
    } else {
        // Trigger Whole Program Analysis optimization
        int result = clang_analyze(NULL, NULL, NULL);
        if (result != CLANG_OK) {
            fprintf(stderr, "Error: %s\n", clang_get_error_message());
        } else {
            printf("Whole program analysis was performed successfully\n");
        }
    }
    return 0;
}