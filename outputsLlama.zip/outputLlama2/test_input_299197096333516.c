
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

// Function Specialization
void foo(int x, int y) {
  if (x > y) {
    printf("x is greater than y\n");
  } else {
    printf("x is less than or equal to y\n");
  }
}

int main(int argc, char **argv) {
  // Function Specialization triggered by argv[1]
  foo(atoi(argv[1]), atoi(argv[2]));

  return 0;
}