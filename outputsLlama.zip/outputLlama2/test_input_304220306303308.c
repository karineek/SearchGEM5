
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <iostream>
#include <vector>
#include <map>
#include "InlinerHeuristics.h"
#include "StaticAnalyzer.h"
#include "asinl.h"

using namespace std;

int main(int argc, char **argv) {
    // Input taken from command line arguments
    string input = argv[1];

    // Parse the input using asinl function
    vector<int> tokenizedInput = asinl(input);

    // Perform StaticAnalyzer analysis on the tokenized input
    map<string, int> analyzerResults = staticAnalyzer(tokenizedInput);

    // Check for any optimization opportunities using Inliner Heuristics
    vector<pair<string, int>> inlinedFunctions = findInlinedFunctions(tokenizedInput, analyzerResults);

    // Perform the inlined functions and update the results
    for (auto &function : inlinedFunctions) {
        string functionName = function.first;
        int functionSize = function.second;

        // Inline the function using the asinl function
        vector<int> inlinedFunctionOutput = asinl(functionName, tokenizedInput);

        // Update the analyzer results with the new output size
        analyzerResults[functionName] = inlinedFunctionOutput.size();
    }

    // Print the updated analyzer results
    for (auto &result : analyzerResults) {
        cout << result.first << ": " << result.second << endl;
    }

    return 0;
}