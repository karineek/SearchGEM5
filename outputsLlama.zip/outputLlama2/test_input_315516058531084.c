
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>

// Function to perform constant folding and machine code generation
void gencode(int *code) {
  // Constant folding
  int a = 5;
  int b = 3;
  int c = a + b;
  
  // Machine code generation
  char *machineCode = " movl $a, %eax\n";
  machineCode += sprintf(machineCode + strlen(machineCode), "%d", b);
  machineCode += sprintf(machineCode + strlen(machineCode), "%d", c);
  
  // Store the generated code in the 'code' array
  code[0] = a;
  code[1] = b;
  code[2] = c;
}

int main(int argc, char **argv) {
  // Check if the user provided an input file
  if (argc < 3) {
    printf("Usage: %s <input_file> <output_file>\n", argv[0]);
    exit(1);
  }
  
  // Open the input file and read its contents
  FILE *inputFile = fopen(argv[1], "r");
  char line[256];
  while (fgets(line, sizeof(line), inputFile) != NULL) {
    gencode(line);
  }
  
  // Open the output file and write the generated code
  FILE *outputFile = fopen(argv[2], "w");
  for (int i = 0; i < argc - 2; i++) {
    fprintf(outputFile, "%d", code[i]);
  }
  
  return 0;
}