
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ast.h>

// Define a catanh function
float catanh(float x, float y) {
  return tanh(x + y);
}

int main(int argc, char **argv) {
  // Parse the command line argument
  int n = atoi(argv[1]);
  float a = atof(argv[2]);
  float b = atof(argv[3]);

  // Create an AST node for the catanh function
  ast_node_t *node = ast_create_catanh(n, a, b);

  // Perform LICM optimization on the AST node
  ast_optimize(node);

  // Print the optimized AST node
  ast_print(node);

  return 0;
}