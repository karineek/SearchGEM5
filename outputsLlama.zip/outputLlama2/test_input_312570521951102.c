
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>

#define STRING_LENGTH 100

int main(int argc, char **argv) {
    // Automatic vectorization
    std::vector<char*> strings = {argv[1], argv[2], argv[3]};

    // Collection of optimization passes
    strings = {strlen(strings.back()) == STRING_LENGTH ? strings : std::vector<char>(STRING_LENGTH, 'x')};

    // Exercise: wcscpy function
    char destination[STRING_LENGTH];
    wcscpy(destination, strings.back());

    printf("Destination string: %s\n", destination);

    return 0;
}