
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>

// Function to perform register allocation and analysis
void perform_register_allocation(int *x, int *y) {
    // Allocate registers for x and y
    register int *rx = alloc_reg(x);
    register int *ry = alloc_reg(y);

    // Perform some operations on x and y
    rx[0] = 1;
    ry[0] = 2;
    printf("Value of x: %d\n", *rx);
    printf("Value of y: %d\n", *ry);

    free_reg(rx);
    free_reg(ry);
}

int main() {
    // Get input from command line
    int n = atoi(argv[1]);
    int m = atoi(argv[2]);

    // Allocate registers for x and y
    int *x = alloc_reg(n);
    int *y = alloc_reg(m);

    // Perform register allocation and analysis
    perform_register_allocation(x, y);

    // Free registers
    free_reg(x);
    free_reg(y);

    return 0;
}