
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <iostream>
#include <fstream>
#include "StaticAnalyzer.h"

using namespace std;

int main(int argc, char** argv) {
    // Check if the input file exists
    if (argc < 2) {
        printf("Error: Please provide an input file\n");
        return 1;
    }

    // Load the input file into a vector of strings
    vector<string> lines;
    for (int i = 0; i < argc; i++) {
        lines.push_back(argv[i]);
    }

    // Run the StaticAnalyzer tool on the input vector
    StaticAnalyzer sa;
    sa.run(lines);

    // Print the results of the analysis
    for (const auto& result : sa.getResults()) {
        printf("%s\n", result.first.c_str());
    }

    return 0;
}