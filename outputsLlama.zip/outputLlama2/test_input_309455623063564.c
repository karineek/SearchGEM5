
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <iostream>

int main(int argc, char** argv) {
  // Initialize vector of integers
  std::vector<int> vecInts(argc, 0);
  for (int i = 0; i < argc; i++) {
    vecInts.push_back(atoi(argv[i]));
  }

  // Perform vectorization optimization
  std::vector<int> vecSums = vecInts;
  std::vector<int> vecDifs = vecInts;
  for (int i = 0; i < vecInts.size(); i++) {
    vecSums[i] = vecInts[i] + vecInts[i + 1];
    vecDifs[i] = vecInts[i] - vecInts[i + 1];
  }

  // Print results
  for (int i = 0; i < vecSums.size(); i++) {
    std::cout << "Sum: " << vecSums[i] << "\n";
  }
  for (int i = 0; i < vecDifs.size(); i++) {
    std::cout << "Diff: " << vecDifs[i] << "\n";
  }

  return 0;
}