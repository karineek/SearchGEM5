
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define SIZE 1024

int main(int argc, char *argv[]) {
    int n = atoi(argv[1]); // Input from command line
    short s[n]; // Declare array of short ints
    float a[n]; // Declare array of floats

    // Initialize arrays with random values
    for (int i = 0; i < n; i++) {
        s[i] = (short) rand() % 100;
        a[i] = (float) rand() / 10.0;
    }

    // Perform vectorized operations on short ints
    #pragma omp parallel num_threads(4) default(none) shared(s)
    {
        #pragma omp for schedule(static)
        for (int i = 0; i < n; i++) {
            s[i] *= 2; // Vectorized multiplication
        }
    }

    // Perform scalar operations on floats
    #pragma omp parallel num_threads(4) default(none) shared(a)
    {
        #pragma omp for schedule(static)
        for (int i = 0; i < n; i++) {
            a[i] += 1.5; // Scalar addition
        }
    }

    // Print results
    for (int i = 0; i < n; i++) {
        printf("%d ", s[i]); // Output vectorized result
        printf("%f ", a[i]); // Output scalar result
    }

    return 0;
}