
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>

#define N 1024

float complex_mag(float complex_arg) {
    float real = creal(complex_arg);
    float imag = cimag(complex_arg);
    return sqrtf(real*real + imag*imag);
}

int main() {
    int argc;
    char *argv[3];

    // Get the number of arguments from the command line
    argc = parse_command_line(argc, argv);

    // Process the input argument
    float complex_arg = strtof(argv[1], NULL);

    // Call the function to demonstrate vectorization
    float result = complex_mag(complex_arg);

    // Print the result
    printf("The mag of %f + 0i is %f\n", complex_arg, result);

    return 0;
}