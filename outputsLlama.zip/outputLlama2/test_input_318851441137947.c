
#include <stdio.h>
#include <string.h>
#include <ast.h>
#include <inliner.h>

// Function to inline small strings
void putwc(const char* str) {
  // Create an AST node for the string
  ast_node_t* str_node = ast_create_string(str);
  
  // Inline the string using Inliner heuristics
  inliner_heuristics_t heuristics;
  heuristics.type = AST_NODE_TYPE_STRING;
  heuristics.size = strlen(str);
  heuristics.node = str_node;
  inliner_inline_function(heuristics);
}

int main(int argc, char** argv) {
  if (argc < 2) {
    printf("Usage: %s <string>\n", argv[0]);
    return 1;
  }
  
  // Parse the input string from the command line
  const char* str = argv[1];
  
  // Call the putwc function with the input string
  putwc(str);
  
  return 0;
}