
#include <stdio.h>
#include <string.h>

// Function to count the number of vowels in a string
int count_vowels(char *str) {
  int vowel_count = 0;
  
  // Loop-Invariant Code Motion: move the loop invariant outside the loop
  for (size_t i = 0; i < strlen(str); i++) {
    if (str[i] == 'a' || str[i] == 'A') {
      vowel_count++;
    } else if (str[i] == 'e' || str[i] == 'E') {
      vowel_count++;
    } else if (str[i] == 'i' || str[i] == 'I') {
      vowel_count++;
    } else if (str[i] == 'o' || str[i] == 'O') {
      vowel_count++;
    } else if (str[i] == 'u' || str[i] == 'U') {
      vowel_count++;
    }
  }
  
  return vowel_count;
}

// Function to count the number of consonants in a string
int count_consonants(char *str) {
  int consonant_count = 0;
  
  // Loop-Invariant Code Motion: move the loop invariant outside the loop
  for (size_t i = 0; i < strlen(str); i++) {
    if (!(str[i] == 'a' || str[i] == 'A') && !(str[i] == 'e' || str[i] == 'E') && !(str[i] == 'i' || str[i] == 'I') && !(str[i] == 'o' || str[i] == 'O')) {
      consonant_count++;
    }
  }
  
  return consonant_count;
}

int main() {
  // Get the input string from the command line
  char *str = argv[1];
  
  // Count the number of vowels, consonants, and other characters in the input string
  int vowel_count = count_vowels(str);
  int consonant_count = count_consonants(str);
  int other_count = strlen(str) - vowel_count - consonant_count;
  
  // Print the results to the console
  printf("Vowel count: %d\n", vowel_count);
  printf("Consonant count: %d\n", consonant_count);
  printf("Other character count: %d\n", other_count);
  
  return 0;
}