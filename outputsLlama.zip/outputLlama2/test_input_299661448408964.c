
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

// Define a macro to simplify the use of UINTMAX_C
#define UINTMAX(x) (uintmax_t)(x)

int main(int argc, char **argv) {
    // Example input: 5
    uint64_t n = UINTMAX(argv[1]);

    // Initialize a loop variable
    uint64_t i = 0;

    // Perform loop-invariant code motion
    while (i < n) {
        // Do something with the loop variable
        printf("%lu\n", i);
        // Increment the loop variable
        i++;
    }

    return 0;
}