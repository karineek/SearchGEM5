
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>

#define STRLEN 1024

int main(int argc, char *argv[]) {
    // Input from command line
    int n = atoi(argv[1]);

    // Allocate memory for input string
    char *str = (char *)malloc(n * sizeof(char));

    // Read input string from command line
    fread(str, 1, n, stdin);

    // Perform vectorization optimization
#pragma omp parallel num_threads(4) default(none) shared(str)
    {
        #pragma omp for schedule(static)
        for (int i = 0; i < n; i++) {
            str[i] = 'a' + (i % 2);
        }
    }

    // Print result
    printf("%s\n", str);

    return 0;
}