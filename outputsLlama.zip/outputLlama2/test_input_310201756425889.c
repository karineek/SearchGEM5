
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Function to check if a number is prime
int is_prime(int n) {
    if (n <= 1) return false;
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) return false;
    }
    return true;
}

// Function to compute prime numbers between two intervals
void compute_primes(int low, int high) {
    for (int i = low + 1; i <= high; i++) {
        if (is_prime(i)) printf("%d ", i);
    }
}

// Program to demonstrate Loop-Invariant Code Motion optimization
int main(int argc, char **argv) {
    int low = atoi(argv[1]);
    int high = atoi(argv[2]);

    // Optimize the loop using Loop-Invariant Code Motion
    for (int i = low + 1; i <= high; i++) {
        if (is_prime(i)) {
            // Do something with the prime number
            printf("%d is prime\n", i);
        }
    }

    return 0;
}