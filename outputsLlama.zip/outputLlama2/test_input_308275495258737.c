
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <signal.h>
#include <unistd.h>

#define SIZE 1024
#define N 16

volatile int x[N];
volatile float y[N];

void sig_handler(int signum) {
    if (signum == SIG_ATOMIC_MAX) {
        for (int i = 0; i < N; i++) {
            x[i] = (int)((float)x[i] + 1.0f);
            y[i] = (float)x[i];
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    int fd = open(argv[1], O_RDONLY);
    if (fd == -1) {
        perror("open");
        return 1;
    }

    size_t size = read(fd, &x, sizeof(x));
    close(fd);

    if (size != SIZE) {
        printf("Size of input data does not match expected value\n");
        return 1;
    }

    for (int i = 0; i < N; i++) {
        x[i] = (int)((float)x[i] + 1.0f);
    }

    return 0;
}