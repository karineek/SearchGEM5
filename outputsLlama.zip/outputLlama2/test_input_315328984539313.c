
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// Function to calculate standard deviation
double stdDev(int *numbers, int numElements) {
  double sum = 0;
  for (int i = 0; i < numElements; i++) {
    sum += numbers[i];
  }
  return sqrt(sum / (double)numElements);
}

// Function to inline the standard deviation calculation
double inlineStdDev(int *numbers, int numElements) {
  return stdDev(numbers, numElements);
}

int main(int argc, char **argv) {
  if (argc < 2) {
    printf("Usage: %s <numElements>\n", argv[0]);
    return 1;
  }
  
  int numElements = atoi(argv[1]);
  int *numbers = malloc(numElements * sizeof(int));
  
  // Read input from standard input
  for (int i = 0; i < numElements; i++) {
    int value;
    scanf("%d", &value);
    numbers[i] = value;
  }
  
  // Calculate standard deviation using Inliner Heuristics and Code Generation
  double stdDev = inlineStdDev(numbers, numElements);
  
  printf("Standard deviation: %f\n", stdDev);
  
  return 0;
}