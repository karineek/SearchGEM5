
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ast.h"

// Define a ctanh function for analysis
float ctanh(float x) {
    return 0.5 * (1.0 + cos(x));
}

int main(int argc, char **argv) {
    // Get the input from the command line
    if (argc < 2) {
        printf("Usage: %s <input>\n", argv[0]);
        return 1;
    }

    // Perform WPA on the input
    Tree *ast = parse_program(argv[1]);
    perform_whole_program_analysis(ast);

    // Print the optimized output
    if (ast->types[0] == TYPE_FLOAT) {
        float result = ctanh(ast->expressions[0]->value.float_val);
        printf("Optimized output: %f\n", result);
    } else {
        printf("Error: Unsupported type %d\n", ast->types[0]);
    }

    // Free the AST
    free_ast(ast);

    return 0;
}