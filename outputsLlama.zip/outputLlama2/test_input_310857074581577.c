
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include <time.h>
#include <sys/mman.h>

#define MAX_INPUT_SIZE 1024

int main(int argc, char *argv[]) {
    // Check if the input is a valid string
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <input_string>\n", argv[0]);
        return 1;
    }

    // Allocate memory for the input string
    char *input = malloc(MAX_INPUT_SIZE * sizeof(char));
    if (!input) {
        fprintf(stderr, "Memory allocation failed\n");
        return 2;
    }

    // Copy the input string into the allocated memory
    strcpy(input, argv[1]);

    // Perform register allocation and collection of optimization passes
    int_fast64_t result = optimize_and_run(input);

    // Print the result
    printf("Result: %d\n", result);

    // Free the memory allocated for the input string
    free(input);

    return 0;
}