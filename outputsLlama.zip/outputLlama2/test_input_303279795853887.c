
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>

// Function to demonstrate Loop Fusion optimization
void fusion_loops(int a, int b, int c) {
  int result = 0;
  
  // Perform loop fusion using the LDBL_MAX_EXP constant
  for (int i = 0; i < LDBL_MAX_EXP; i++) {
    result += a * b * c;
  }
  
  printf("Result: %d\n", result);
}

int main(int argc, char **argv) {
  if (argc > 1) {
    int a = atoi(argv[1]);
    int b = atoi(argv[2]);
    fusion_loops(a, b, LDBL_MAX_EXP);
  } else {
    printf("Usage: %s <a> <b>\n", argv[0]);
  }
  
  return 0;
}