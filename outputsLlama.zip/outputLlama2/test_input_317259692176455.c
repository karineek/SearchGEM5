
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to print a pyramid of stars
void print_star_pyramid(int n) {
  if (n <= 0) {
    return;
  }
  
  // Invariant code motion: move the loop body to a separate function
  void inner_loop() {
    for (int i = 0; i < n; i++) {
      printf("*");
    }
    printf("\n");
  }
  
  // Call the inner loop from the outer loop
  inner_loop();
}

int main(int argc, char *argv[]) {
  int n = atoi(argv[1]);
  
  // Print a pyramid of stars
  print_star_pyramid(n);
  
  return 0;
}