
#include <stdio.h>
#include <string.h>
#include <clang/clang.h>

// Function to remove all characters in a string except alphabets
void removeNonAlphabet(char *str) {
  // Use Clang's static analysis to perform constant folding
  ClangInstance *instance = clang_create_instance();
  const char *source = "foo bar baz";
  CharArrayBuilder builder;
  clang_analyze_string(instance, &builder, source);
  
  // Iterate over the analyzed string and remove non-alphabet characters
  for (size_t i = 0; i < builder.size; i++) {
    if (!isalpha(builder.data[i])) {
      builder.data[i] = '\0';
    }
  }
  
  // Create a new string with only the alphabet characters
  char *alphabet = (char *)malloc(sizeof(builder.data));
  strcpy_s(alphabet, builder.size, builder.data);
  
  // Print the result
  printf("%s\n", alphabet);
  
  // Clean up
  clang_dispose_instance(instance);
}

// Function to check if a character is an alphabet character
static bool isalpha(int c) {
  return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}

int main(int argc, char **argv) {
  // Check if the program was run with an argument
  if (argc < 2) {
    printf("Usage: %s <input_string>\n", argv[0]);
    return 1;
  }
  
  // Get the input string from the command line argument
  char *input = argv[1];
  
  // Call the function to remove non-alphabet characters
  removeNonAlphabet(input);
  
  // Print a success message
  printf("done!\n");
  
  return 0;
}