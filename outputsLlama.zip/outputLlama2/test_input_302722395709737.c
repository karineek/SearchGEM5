
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Function to be inlined
void inline_function(int a, int b) {
    printf("Inlined function called with arguments %d and %d\n", a, b);
}

int main(int argc, char **argv) {
    // Check for the presence of the --inline-function flag
    if (argc > 1 && strcmp(argv[1], "--inline-function") == 0) {
        // Inline the function
        inline_function(5, 10);
    } else {
        // Call the non-inlined version of the function
        inline_function(5, 10);
    }
    return 0;
}