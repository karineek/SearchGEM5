
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <llvm/llvm.h>

// Function to print the IR of a given C program
void printIR(const char *program) {
  // Create a new LLVM module from the given C program
  ModuleModule module;
  module.readSingleFile(program, "text");
  
  // Create a function for each function in the program
  Function func;
  for (auto &func : module.getFunctions()) {
    std::cout << "Function: " << func.getName() << std::endl;
    
    // Print the IR of each function
    for (auto &bb : func.getBody()) {
      std::cout << "  Block: " << bb.getName() << std::endl;
      
      // Print the instructions in each block
      for (auto &i : bb.getInstructions()) {
        std::cout << "    Instruction: " << i.getOpcode() << std::endl;
      }
    }
  }
}

int main(int argc, char **argv) {
  // Check if a program was provided as an argument
  if (argc < 2) {
    std::cerr << "Usage: " << argv[0] << " <program>" << std::endl;
    return 1;
  }
  
  // Print the IR of the given C program
  printIR(argv[1]);
  
  return 0;
}