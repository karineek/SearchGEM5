
#include <stdio.h>
#include <string.h>
#include <llvm/LLVM.h>

// Define a function to perform strstr() on two strings
size_t strstr(const char *haystack, const char *needsle) {
  // Implement the strstr() function here
  return 0; // For now, just returning 0 will do
}

int main(int argc, char **argv) {
  // Get the input from argv
  const char *input = argv[1];

  // Perform Whole Program Analysis using LLVM bitcode
  LLVMModule module;
  LLVMInitialize(&module);
  LLVMParseBitcode(input, NULL, NULL, &module);
  LLVMAddFunction(&module, "main", 0);
  LLVMRunFunction(module, 0);

  // Print the result of the strstr() function
  const char *result = strstr(argv[2], argv[3]);
  printf("%s\n", result);

  // Clean up
  LLVMDisposeModule(&module);
  return 0;
}