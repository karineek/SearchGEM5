
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// Function to demonstrate loop fusion
void roundl(int n, int m) {
  int i, j;
  for (i = 0; i < n; i++) {
    for (j = 0; j < m; j++) {
      printf(" %d ", i * m + j);
    }
    printf("\n");
  }
}

int main(int argc, char **argv) {
  int n = atoi(argv[1]);
  int m = atoi(argv[2]);

  // Demonstrate loop fusion using the roundl function
  roundl(n, m);

  return 0;
}