
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "registerAllocation.h"

int main(int argc, char **argv) {
    // Initialize the register allocation algorithm
    RegisterAllocation alg;

    // Check if the user provided an argument
    if (argc > 1) {
        // Read the input from the command line
        char *input = argv[1];

        // Use the register allocation algorithm to optimize the input
        alg.optimize(input);

        // Print the optimized output
        printf("Optimized output: %s\n", alg.output());
    } else {
        // Print a default message if no input is provided
        printf("No input provided. Please provide an argument.\n");
    }

    return 0;
}