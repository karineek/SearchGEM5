
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <inttypes.h>
#include <sched.h>

// Define the type for uint_fast8_t
typedef int8_t uint_fast8_t;

int main(int argc, char **argv) {
    // Check if the input is a string
    if (argc > 1) {
        // Parse the input as an integer
        uint_fast8_t value = strtol(argv[1], NULL, 2);
        // Print the result
        printf("%d\n", value);
    } else {
        // Print a default message
        printf("Usage: %s <value>\n", argv[0]);
    }
    return 0;
}