
#include <stdio.h>
#include <string.h>
#include <profile.h>

double cpow(double base, double exp) {
    if (exp == 0) {
        return 1;
    }
    double result = 1;
    while (exp > 0) {
        result *= base;
        base *= base;
        exp--;
    }
    return result;
}

int main(int argc, char **argv) {
    if (argc < 3) {
        printf("Usage: %s <input> <profile-file>\n", argv[0]);
        return 1;
    }

    double base = strtod(argv[1], NULL);
    double exp = strtod(argv[2], NULL);

    // Perform Profile-Guided Optimization
    Profile profile;
    profile.init();
    profile.add_event(CPOW, 1); // Add a profile event for cpow()
    profile.add_event(main, 1); // Add a profile event for main()

    // Run the optimization pass
    Optimizer optimizer;
    optimizer.init();
    optimizer.set_profile(&profile);
    optimizer.perform_optimization();

    // Evaluate the optimized code
    double optimized_result = cpow(base, exp);
    printf("Optimized result: %f\n", optimized_result);

    return 0;
}