
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>

#define FLT_RADIX 2

int main(int argc, char **argv) {
    double x = strtof(argv[1], NULL);
    float y = (float)x;
    double z = y * FLT_RADIX;
    printf("%.4f\n", z);
    return 0;
}