
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "parse_assembly.h"

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: %s <assembly_file>\n", argv[0]);
        return 1;
    }

    // Parse the assembly file using the read_assembly() function
    AssemblyCode code;
    read_assembly(argv[1], &code);

    // Perform Memory-to-Register Promotion optimization
    OptimizeCode(code);

    // Evaluate the rintf function
    int result = EvalRintf(code);

    // Print the result
    printf("Result: %d\n", result);

    return 0;
}