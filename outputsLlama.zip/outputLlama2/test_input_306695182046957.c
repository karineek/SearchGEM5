
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <inttypes.h>

// Function to parse assembly files using readelf
void parse_assembly(const char* assembly_file) {
    int status = 0; // return status of readelf
    char buffer[4096]; // buffer for readelf output

    // Read the assembly file using readelf
    status = readelf(assembly_file, buffer, sizeof(buffer));
    if (status != 0) {
        perror("readelf");
        return;
    }

    // Print the assembly code
    printf("Assembly code: %s\n", buffer);
}

int main(int argc, char** argv) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <assembly_file>\n", argv[0]);
        return 1;
    }

    // Parse the assembly file using readelf
    parse_assembly(argv[1]);

    return 0;
}