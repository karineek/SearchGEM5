
#include <stdio.h>
#include <string.h>

// Function to demonstrate Loop Fusion optimization
void f(int n) {
    int i;
    for (i = 0; i < n;++) {
        printf("Hello, world!\n");
    }
}

// Function to demonstrate Serialization
void g(int n) {
    char str[n];
    for (int i = 0; i < n; ++i) {
        str[i] = 'a' + i;
    }
    printf("%s\n", str);
}

// Function to demonstrate isspace() function
void h(int n) {
    char str[n];
    for (int i = 0; i < n; ++i) {
        str[i] = 'a' + i;
        if (isspace(str[i])) {
            printf("Space found at position %d\n", i);
        }
    }
}

int main(int argc, char **argv) {
    int n = atoi(argv[1]); // Get the input from command line

    // Demonstrate Loop Fusion optimization
    f(n);

    // Demonstrate Serialization
    g(n);

    // Demonstrate isspace() function
    h(n);

    return 0;
}