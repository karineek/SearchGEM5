
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Function specialization example
void foo(int x) {
    if (x == 1) {
        printf("Specialized function called with x = 1\n");
    } else if (x == 2) {
        printf("Specialized function called with x = 2\n");
    } else {
        printf("General function called with x != 1 and x != 2\n");
    }
}

int main(int argc, char **argv) {
    if (argc > 1) {
        int x = atoi(argv[1]); // Parse input from command line
        foo(x); // Call specialized function or general function depending on x
    } else {
        printf("Usage: %s <x>\n", argv[0]);
    }
    return 0;
}