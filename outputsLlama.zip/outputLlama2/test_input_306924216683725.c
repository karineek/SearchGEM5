
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "profile.h"

// Function to profile the time it takes to execute a piece of code
void time_function(int num_iterations) {
  int i;
  for (i = 0; i < num_iterations;++i) {
    // Code to be profiled
    clock_t start = clock();
    do_something();
    clock_t end = clock();
    double time_taken = (double)(end - start);
    printf("Time taken: %f seconds\n", time_taken);
  }
}

int main(int argc, char *argv[]) {
  if (argc < 2) {
    fprintf(stderr, "Usage: %s <num_iterations>\n", argv[0]);
    return 1;
  }

  int num_iterations = atoi(argv[1]);
  time_function(num_iterations);
  return 0;
}