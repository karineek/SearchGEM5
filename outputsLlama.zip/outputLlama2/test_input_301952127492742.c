
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Define a function that takes an integer as input and returns its square
int square(int n) {
    int result = 0;
    for (int i = 0; i < n; i++) {
        result += i * i;
    }
    return result;
}

// Define a function that takes an integer as input and returns its cube
int cube(int n) {
    int result = 1;
    for (int i = 0; i < n; i++) {
        result *= i + 1;
    }
    return result;
}

int main() {
    int n = atoi(argv[1]); // Get the input from the command line

    // Demonstrate loop optimization by using a for loop instead of a while loop
    // and showing that the resulting code is identical
    for (int i = 0; i < n; i++) {
        printf("Iteration %d: ", i + 1);
        cube(i);
        printf("\n");
    }

    return 0;
}