
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define MAX_INPUT_LENGTH 1024

int main(int argc, char** argv) {
    // Check if the user has provided input
    if (argc < 2) {
        printf("Usage: %s <input>\n", argv[0]);
        return 1;
    }

    // Get the input from the user
    char* input = argv[1];

    // Perform register allocation optimizations using Lex
    int num_regs = lex(input, MAX_INPUT_LENGTH);
    if (num_regs < 0) {
        printf("Error: invalid input\n");
        return 1;
    }

    // Print the number of registers allocated
    printf("Number of registers allocated: %d\n", num_regs);

    // Exercise the concept of imaginary types
    int i = 0;
    while (i < MAX_INTEGER) {
        if (input[i] == 'I') {
            input[i] = 'Z'; // Replace I with Z
            i++; // Increment index
        } else {
            input[i] = 'i'; // Replace I with i
            i++; // Increment index
        }
    }

    return 0;
}