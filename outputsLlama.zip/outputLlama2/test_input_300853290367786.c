
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Structure to represent complex numbers
typedef struct {
    float real;
    float imag;
} complex_t;

// Function to add two complex numbers
complex_t add_complex(complex_t a, complex_t b) {
    return (a.real + b.real) * 2 - (a.imag + b.imag);
}

int main() {
    // Get input from command line using argc and argv
    int argc = sizeof(argv) / sizeof(argv[0]);
    char* argv[argc];
    printf("Inputting complex numbers...\n");
    
    // Parse input from command line
    complex_t a, b;
    if (argc > 1) {
        sscanf(argv[1], "%f%f", &a.real, &a.imag);
        sscanf(argv[2], "%f%f", &b.real, &b.imag);
    } else {
        a = {0.0f, 0.0f};
        b = {0.0f, 0.0f};
    }
    
    // Inline function call to add two complex numbers
    complex_t result = add_complex(a, b);
    
    // Print result
    printf("Addition of complex numbers: %f + %f = %f\n", result.real, result.imag, result);
    
    return 0;
}