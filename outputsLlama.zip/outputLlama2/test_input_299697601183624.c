
#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Function to promote memory to registers
void* promote_memory_to_registers(void* mem) {
    // Get the size of the memory block
    size_t size = strlen((const char*)mem);

    // Allocate a register for the size
    uint32_t size_reg = alloca(sizeof(size_t));
    *(size_reg) = size;

    // Promote the memory block to a register
    void* reg = (void*)size_reg;
    memcpy(reg, mem, size);

    return reg;
}

int main(int argc, char** argv) {
    // Get the input from the command line
    const char* input = argv[1];

    // Promote the memory to registers
    void* promoted_mem = promote_memory_to_registers(input);

    // Print the promoted memory
    printf("Promoted memory: %p\n", promoted_mem);

    return 0;
}