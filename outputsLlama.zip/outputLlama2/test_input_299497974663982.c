
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Function to compute the real and imaginary parts of a complex number
double complex_number_real(double complex_num) {
    return creal(complex_num);
}

double complex_number_imag(double complex_num) {
    return cimag(complex_num);
}

// Function to compute the conjugate of a complex number
double conjugate(double complex_num) {
    return conj(complex_num);
}

int main() {
    // Get input from command line
    int num_complex_numbers = atoi(argv[1]);
    double *complex_numbers = malloc(num_complex_numbers * sizeof(double));
    for (int i = 0; i < num_complex_numbers; i++) {
        sscanf(argv[2 + i], "%lf", &complex_numbers[i]);
    }

    // Perform Sparse Conditional Constant Propagation optimization
    double *result = malloc(num_complex_numbers * sizeof(double));
    for (int i = 0; i < num_complex_numbers; i++) {
        result[i] = sccp_complex_number(complex_numbers[i]);
    }

    // Print the results
    for (int i = 0; i < num_complex_numbers; i++) {
        printf("Real part: %lf\n", complex_number_real(result[i]));
        printf("Imaginary part: %lf\n", complex_number_imag(result[i]));
        printf("Conjugate: %lf\n", conjugate(result[i]));
    }

    free(complex_numbers);
    free(result);
    return 0;
}