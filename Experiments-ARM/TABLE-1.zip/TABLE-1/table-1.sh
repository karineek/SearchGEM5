echo ">> Token-1 Examples"
grep -e "Scalar Optimizations" ID*.log
grep -e "Dead Code Elimination" ID*.log
grep -e "Constant Folding" ID*.log

echo ">> Token-2 Examples"
grep -e "Sema" ID*.log
grep -e "Serialization" ID*.log 
grep -e "Parse\"" ID*.log
grep -e "Lex\"" ID*.log
grep -e "AST\"" ID*.log

echo ">> Token-3 Examples"
grep -e "C Program to Sort an Array using Merge Sort" ID*.log
grep -e "Calendar Year in Different Formats" ID*.log
grep -e "input include several arguments" ID*.log

echo ">> Token-4 Examples"
grep -e "AND operators" ID*.log
grep -e "cimagl function" ID*.log
grep -e ":EOF," ID*.log
grep -e ":locale," ID*.log
grep -e ":pow," ID*.log
grep -e "SCNiMAX," ID*.log

wc -l ID*.log